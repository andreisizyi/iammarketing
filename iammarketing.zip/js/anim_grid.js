(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.Tween84 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#F6F6F7","#ECEEF0","#BCBEC5"],[0,0.447,0.961],41.8,12.4,-48.6,-5.2).s().p("AnXDHIEnmmIKIG/g");
	this.shape.setTransform(-268.25,-40.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#F6F6F7","#ECEEF0","#BCBEC5"],[0,0.447,0.961],-91.6,-0.3,91.8,0.2).s().p("AuVouIcrGRIrgLMg");
	this.shape_1.setTransform(192.45,138.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#BCBEC5","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-73,-11.7,15,75.6).s().p("AvBHiIeD0AIzMY9g");
	this.shape_2.setTransform(-195.025,241.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#F6F6F7","#ECEEF0","#BCBEC5"],[0,0.447,0.961],-46.6,115.5,8.7,-96.4).s().p("ApwJ5IFc5uIOFfrg");
	this.shape_3.setTransform(-68.35,-191.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-17.4,-2.6,22.2,7.7).s().p("AjLghIGXhBIgFDFg");
	this.shape_4.setTransform(243.075,36.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-27.7,0,27.8,0).s().p("AkUkpIHXBlIBSHug");
	this.shape_5.setTransform(-211.025,-220.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-22.1,17.8,34.7,-16.4).s().p("AniEMIPFpWIjlKVg");
	this.shape_6.setTransform(-249.55,82.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-53.3,0,53.4,0).s().p("ABKmAIHMFBIwrHAg");
	this.shape_7.setTransform(262.1,-28.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],1.3,-19,-3.2,20.4).s().p("AibgDIBji3IDUF1g");
	this.shape_8.setTransform(-8.75,-246.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#ECEEF0","#F1F2F4","#FFFFFF"],[0,0.22,1],-2.7,-18.7,3.6,21.7).s().p("AgmjGICzBTIkZE6g");
	this.shape_9.setTransform(229.075,-301.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#ECEEF0","#F1F2F4","#FFFFFF"],[0,0.22,1],-12.1,-4.1,12.2,21.2).s().p("AkBBRID+iqIEFCzg");
	this.shape_10.setTransform(-277.15,144.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-315.4,-321.2,630.9,642.5);


(lib.Tween82 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#ECEEF0","#F5F6F7","#FFFFFF"],[0,0.384,1],-31.5,-19.2,51.9,65.9).s().p("AwaDyIWHqhIKuNfg");
	this.shape.setTransform(20.85,-219.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#ECEEF0","#E4E5E8","#D8D9DD"],[0,0.525,1],-57.3,0,57.4,0).s().p("Ao8mwIR5E7InMImg");
	this.shape_1.setTransform(114.725,-219.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#ECEEF0","#F1F2F4","#FFFFFF"],[0,0.22,1],-66.4,-48.5,22,24).s().p("ApToSISniSIuZVJg");
	this.shape_2.setTransform(231.65,-177.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#BCBEC5","#ECEEF0"],[0.039,0.553],-83.2,0,83.2,0).s().p("As/IVIZ/6IMgUDAjng");
	this.shape_3.setTransform(115.775,148.35);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#ECEEF0","#BCBEC5"],[0,0.961],-27.9,0,28.1,0).s().p("AkWswIItNUIhAMNg");
	this.shape_4.setTransform(-131.3,169.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-71.2,0,71.3,0).s().p("AqGmFIVPEZI2RHyg");
	this.shape_5.setTransform(-38.55,212.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#ECEEF0","#F0F1F3","#F6F6F7"],[0,0.631,1],-36.5,0,36.6,0).s().p("Altg1IHMomIEOS3g");
	this.shape_6.setTransform(162.45,-170.55);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-36.5,0,36.6,0).s().p("AltqRILaKRIraKRg");
	this.shape_7.setTransform(162.45,-110.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-83.2,0,83.2,0).s().p("Aqeu6IXeDsI5/aJg");
	this.shape_8.setTransform(115.775,106.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-47.9,0,48,0).s().p("AnfHBIO/17Iihd1g");
	this.shape_9.setTransform(0.775,106.125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-67.9,0,68,0).s().p("AqmgbIIvjhIMfH5g");
	this.shape_10.setTransform(-35.25,176.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-109.6,0,109.7,0).s().p("AvtkSMAg1AC/MgiPAFmg");
	this.shape_11.setTransform(16.35,-167.475);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.565,0.961],-75.1,0,75.2,0).s().p("AruCdIMDolILaMRg");
	this.shape_12.setTransform(123.9,-5.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-48,0,48,0).s().p("AgRtxIHxFoIu/V7g");
	this.shape_13.setTransform(0.7,62.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#BCBEC5","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-0.7,66.7,31.3,-40).s().p("AxHjEMAiPgFoIquRZg");
	this.shape_14.setTransform(16.25,-120.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-55.9,0,56,0).s().p("AoumqIRdJ0IovDhg");
	this.shape_15.setTransform(-103.3,130.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["#ECEEF0","#EEF0F1","#FBFBFC","#FFFFFF"],[0,0.051,0.541,1],67.4,-32,-73.4,22).s().p("Am1mCINrECIAAIDg");
	this.shape_16.setTransform(-247.35,-87.725);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#ECEEF0","#EEF0F1","#FBFBFC","#FFFFFF"],[0,0.051,0.541,1],10.8,-33.4,-42.2,34).s().p("AkLkpIJLGUIp/C/g");
	this.shape_17.setTransform(-116.4,-205.675);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],0,-27.5,0,27.5).s().p("AlAhUIKBi+IhaIlg");
	this.shape_18.setTransform(-116.35,-167.45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#ECEEF0","#FFFFFF"],[0,1],0,-37.6,0,37.7).s().p("AAAl4IInFoIxNGJg");
	this.shape_19.setTransform(-148.4,-138.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["#BCBEC5","#ECEEF0","#F6F6F7"],[0.039,0.553,1],86.8,-69.5,-69.1,36.7).s().p("AomgbIRNmKIAANKg");
	this.shape_20.setTransform(-148.45,-97.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#ECEEF0","#BCBEC5"],[0,0.961],-55,0,55.1,0).s().p("AomkBIRNHBIxNBCg");
	this.shape_21.setTransform(-148.45,-74.75);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-61.5,0,61.6,0).s().p("ApnIyIMUzfIG7Vag");
	this.shape_22.setTransform(-220.8,19.55);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-55,0,55.1,0).s().p("AomlRIRNhCIlcMng");
	this.shape_23.setTransform(-148.45,-15.25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-66,58.5,41.8,-58.7).s().p("Al3qtILvLlIk2J1g");
	this.shape_24.setTransform(-165.875,19.55);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#BCBEC5","#CBCDD2","#E3E5E8","#ECEEF0"],[0,0.243,0.71,1],49.9,-37.7,-47,55.1).s().p("AovAAIE2p1IMpTqg");
	this.shape_25.setTransform(-103.25,88.15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-1.9,-9.8,13.3,65.2).s().p("AlWHIIKtxZIAAUig");
	this.shape_26.setTransform(91.7,-110.15);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-38.6,0,38.6,0).s().p("Akrl3IKtDKIsDIlg");
	this.shape_27.setTransform(87.375,-27);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["#BCBEC5","#ECEEF0"],[0,1],39.5,30.8,-11,-51.8).s().p("AkjAQIJHmHIhWLvg");
	this.shape_28.setTransform(28.05,-27.05);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#F6F6F7","#ECEEF0","#BCBEC5"],[0,0.447,0.961],-75.3,0,75.4,0).s().p("Arxo8IXiLxIpHGIg");
	this.shape_29.setTransform(-18.1,-82.725);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["#ECEEF0","#BCBEC5"],[0,0.961],-46.1,0,46.2,0).s().p("AnMEOIAAtKIOZR5g");
	this.shape_30.setTransform(-47.25,-82.675);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#BCBEC5","#ECEEF0"],[0.039,1],69,59.4,-54.9,-73).s().p("Ap7l3IT3n6InObjg");
	this.shape_31.setTransform(-64.7,62.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["#D8D9DD","#ECEEF0"],[0.043,1],-78.8,-39.9,47.6,21.6).s().p("AkemTIOZEuIz1H5g");
	this.shape_32.setTransform(-64.65,-15.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-291.2,-262.3,582.5,524.7);


(lib.Tween80 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AoCCcIQFk3");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52.5,-16.6,105,33.3);


(lib.Tween79 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AoCCcIQFk3");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52.5,-16.6,105,33.3);


(lib.Tween78 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AqdJlIFRH4AqdJlIVWDCAq4xcIAbbB");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.7,-112.7,141.4,225.5);


(lib.Tween77 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AqdJlIFRH4AqdJlIVWDCAq4xcIAbbB");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.7,-112.7,141.4,225.5);


(lib.Tween76 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("ABsBxIUjQiABsBxIUCqdABsBxI3YBkA2OySIX6UD");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-143.2,-118,286.5,236.1);


(lib.Tween75 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("ABsBxIUjQiABsBxIUCqdABsBxI3YBkA2OySIX6UD");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-143.2,-118,286.5,236.1);


(lib.Tween74 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("ALEhEIwjG8Ilkrv");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-71.7,-38.6,143.5,77.30000000000001);


(lib.Tween73 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("ALEhEIwjG8Ilkrv");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-71.7,-38.6,143.5,77.30000000000001);


(lib.Tween72 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AlMBxImxskAlMBxImOJDAlMBxIRKHd");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.6,-70.1,155.3,140.3);


(lib.Tween71 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AlMBxImxskAlMBxImOJDAlMBxIRKHd");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.6,-70.1,155.3,140.3);


(lib.Tween69 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AEERdMANogi5AEERdIlLw7AxrHdIVvKA");
	this.shape.setTransform(43.625,-57.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.6,-170.2,228.5,225.39999999999998);


(lib.Tween68 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AhwtTIgxRCIFDJl");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.2,-86.2,34.4,172.5);


(lib.Tween67 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AhwtTIgxRCIFDJl");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.2,-86.2,34.4,172.5);


(lib.Tween66 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AC3ErIhas7AC3ErITGDmAC3ErI4zrW");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-141.5,-53.9,283.1,107.9);


(lib.Tween65 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AC3ErIhas7AC3ErITGDmAC3ErI4zrW");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-141.5,-53.9,283.1,107.9);


(lib.Tween64 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AGhEzItBgTIH8pS");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.7,-31.6,85.5,63.3);


(lib.Tween63 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AGhEzItBgTIH8pS");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.7,-31.6,85.5,63.3);


(lib.Tween62 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AApLmILNj1AApLmIRds1AApLmIKn5eAApLmIyuF8AApLmIlH9H");
	this.shape.setTransform(-2.35,-0.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-119.1,-113.8,233.6,226.39999999999998);


(lib.Tween60 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("ApNHyIi8vjApNHyIVXkDAG8kLIwJL9");
	this.shape.setTransform(-0.6,0.125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.3,-50.7,157.5,101.7);


(lib.Tween58 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("ApwCVITgkp");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.4,-15.8,126.9,31.700000000000003);


(lib.Tween57 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("ApwCVIThkp");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.4,-15.8,126.9,31.700000000000003);


(lib.Tween56 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AJswnMgTVAhPIgC8s");
	this.shape.setTransform(-0.575,-0.125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.5,-107.5,125.9,214.8);


(lib.Tween54 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("Aq4p+INIT9IIpp7");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.6,-64.8,141.3,129.7);


(lib.Tween53 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("Aq4p+INIT9IIpp7");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.6,-64.8,141.3,129.7);


(lib.Tween52 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ah7LiIjIxJAh7LiIPn3DAh7LiIrwnP");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-88.5,-74.8,177.1,149.6);


(lib.Tween51 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("Ah7LiIjIxJAh7LiIPn3DAh7LiIrwnP");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-88.5,-74.8,177.1,149.6);


(lib.Tween48 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AFomCIhtMFIpilf");
	this.shape.setTransform(5.425,-21.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-31.5,-60.7,73.9,79.30000000000001);


(lib.Tween47 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AnbLmIqo/gAnbLmIRKknAnbLmIZfIVAnbLmIOL0J");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-116.5,-128.4,233.1,256.9);


(lib.Tween46 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AnbLmIqo/gAnbLmIRKknAnbLmIZfIVAnbLmIOL0J");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-116.5,-128.4,233.1,256.9);


(lib.Tween45 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AFljQIrJGh");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.7,-21.9,73.4,43.8);


(lib.Tween44 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AFljQIrJGh");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.7,-21.9,73.4,43.8);


(lib.Tween43 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AN/t0IsKM8IvzOuAB1g4Itzme");
	this.shape.setTransform(-6.375,47.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-96.8,-42.4,180.89999999999998,179.1);


(lib.Tween41 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AIGDJIiAspAIGDJI6AGYAIGDJIJ0lf");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115.6,-61.8,231.3,123.69999999999999);


(lib.Tween40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AIGDJIiAspAIGDJI6AGYAIGDJIJ0lf");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115.6,-61.8,231.3,123.69999999999999);


(lib.Tween39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("Am6QaIqPGRAm6QaIohlzAm6QaMAK2gnEAm6QaIYEzO");
	this.shape.setTransform(-11.6,-0.65);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-122.3,-146.7,221.5,292.2);


(lib.Tween37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AEtEYIrRMkAEtEYIoUu9AEtEYIB41T");
	this.shape.setTransform(-44.65,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-87.7,-109.4,86.2,218.9);


(lib.Tween36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AClh7IHUytAClh7Iofj6AClh7IOoWkAClh7IzxIp");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-111.1,-133.1,222.3,266.29999999999995);


(lib.Tween35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AnaMMIO14Y");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.5,-79,97.1,158.1);


(lib.Tween34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AnaMMIO14Y");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.5,-79,97.1,158.1);


(lib.Tween33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AiPD2IEKJVAiPD2IMEAAAiPD2Iobs1AiPD2IM6xA");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69.2,-85.3,138.5,170.7);


(lib.Tween32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AiPD2IEKJVAiPD2IMEAAAiPD2Iobs1AiPD2IM6xA");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-69.2,-85.3,138.5,170.7);


(lib.Tween28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AxCJIMAiFgSP");
	this.shape.setTransform(-104.15,46.1,0.9993,0.9915,0,0,0,-109.1,58.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(1,1,1).p("AuMHNIhjNFAuMHNITOGTAuMHNId87e");
	this.shape_1.setTransform(-13.3,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115,-130.7,229.9,261.5);


(lib.Tween27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AA3H1IepjiAA3H1IAyX9AA3H1Iw+VLAA3H1MgQwgnmAA3H1MggWgQmAA3H1IFAr0");
	this.shape.setTransform(0,-0.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-202.5,-205.1,405.1,408.7);


(lib.Tween25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AoEBGIQJiL");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52.6,-8,105.30000000000001,16.1);


(lib.Tween24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AoEBGIQJiL");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52.6,-8,105.30000000000001,16.1);


(lib.Tween22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AAXo/IRwCvAAXo/IAAR/AQkG0IwNvzIydCtAAXo/IqpKx");
	this.shape.setTransform(0.45,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-116.4,-58.6,233.8,117.2);


(lib.Tween21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AJCkoIH8IEABHupIH7KBIrWTSAJCkoI6AjS");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.6,-94.8,219.3,189.6);


(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AJCkoIH8IEABHupIH7KBIrWTSAJCkoI6AjS");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.6,-94.8,219.3,189.6);


(lib.Tween19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AIWJIIBY4+AptP3ISDmvIqvr+");
	this.shape.setTransform(-20.9,-10.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.1,-113,126.39999999999999,205.1);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D02E1B").s().p("AgxCBQgYgIgTgSQg5g2APhMQALg5AwgfQA2gjA9ATQA+ATAZA8QAYA3gaA4QgOAegaAUQgoAegsAAQgYAAgagKg");
	this.shape.setTransform(-0.0177,-0.0181);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.8,-13.8,27.700000000000003,27.700000000000003);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AFTGBIQepoAEvRjIAkriIzHONAFTGBIzHKSIn8mCIbDkQI5y0yAFTGBIv96O");
	this.shape.setTransform(139.3,129.35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,280.6,260.7);


(lib.Tween18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Tween3("synched",0);
	this.instance.setTransform(472.1,517.95,0.508,0.508);
	this.instance.alpha = 0.0156;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({_off:false},0).wait(1).to({scaleX:0.5248,scaleY:0.5248,x:472.1013,alpha:0.033,startPosition:1},0).wait(1).to({scaleX:0.5483,scaleY:0.5483,x:472.1031,alpha:0.0572,startPosition:0},0).wait(1).to({scaleX:0.5789,scaleY:0.5789,x:472.1054,alpha:0.0888,startPosition:1},0).wait(1).to({scaleX:0.6172,scaleY:0.6172,x:472.1084,alpha:0.1283,startPosition:0},0).wait(1).to({scaleX:0.6635,scaleY:0.6635,x:472.1119,alpha:0.176,startPosition:1},0).wait(1).to({scaleX:0.7176,scaleY:0.7176,x:472.1161,alpha:0.2318,startPosition:0},0).wait(1).to({scaleX:0.779,scaleY:0.779,x:472.1208,alpha:0.2952,startPosition:1},0).wait(1).to({scaleX:0.8465,scaleY:0.8465,x:472.1259,alpha:0.3648,startPosition:0},0).wait(1).to({scaleX:0.9181,scaleY:0.9181,x:472.1314,alpha:0.4387,startPosition:1},0).wait(1).to({scaleX:0.9914,scaleY:0.9914,x:472.137,alpha:0.5144,startPosition:0},0).wait(1).to({scaleX:1.0637,scaleY:1.0637,x:472.1426,alpha:0.5889,startPosition:1},0).wait(1).to({scaleX:1.1324,scaleY:1.1324,x:472.1478,alpha:0.6599,startPosition:0},0).wait(1).to({scaleX:1.1958,scaleY:1.1958,x:472.1527,alpha:0.7252,startPosition:1},0).wait(1).to({scaleX:1.2525,scaleY:1.2525,x:472.1571,alpha:0.7838,startPosition:0},0).wait(1).to({scaleX:1.302,scaleY:1.302,x:472.1608,alpha:0.8348,startPosition:1},0).wait(1).to({scaleX:1.3441,scaleY:1.3441,x:472.1641,alpha:0.8782,startPosition:0},0).wait(1).to({scaleX:1.379,scaleY:1.379,x:472.1667,alpha:0.9143,startPosition:1},0).wait(1).to({scaleX:1.4072,scaleY:1.4072,x:472.1689,alpha:0.9434,startPosition:0},0).wait(1).to({scaleX:1.4291,scaleY:1.4291,x:472.1706,alpha:0.966,startPosition:1},0).wait(1).to({scaleX:1.4452,scaleY:1.4452,x:472.1718,alpha:0.9826,startPosition:0},0).wait(1).to({scaleX:1.4561,scaleY:1.4561,x:472.1726,alpha:0.9938,startPosition:1},0).wait(1).to({scaleX:1.4621,scaleY:1.4621,x:472.1,alpha:1,startPosition:0},0).to({scaleX:1,scaleY:1},25,cjs.Ease.quadInOut).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({scaleX:1.0032,scaleY:1.0032,x:472.1005,startPosition:1},0).wait(1).to({scaleX:1.0075,scaleY:1.0075,x:472.1012,startPosition:0},0).wait(1).to({scaleX:1.0129,scaleY:1.0129,x:472.1021,startPosition:1},0).wait(1).to({scaleX:1.0195,scaleY:1.0195,x:472.1031,startPosition:0},0).wait(1).to({scaleX:1.0272,scaleY:1.0272,x:472.1043,startPosition:1},0).wait(1).to({scaleX:1.0361,scaleY:1.0361,x:472.1057,startPosition:0},0).wait(1).to({scaleX:1.0462,scaleY:1.0462,x:472.1073,startPosition:1},0).wait(1).to({scaleX:1.0575,scaleY:1.0575,x:472.1091,startPosition:0},0).wait(1).to({scaleX:1.07,scaleY:1.07,x:472.1111,startPosition:1},0).wait(1).to({scaleX:1.0839,scaleY:1.0839,x:472.1133,startPosition:0},0).wait(1).to({scaleX:1.099,scaleY:1.099,x:472.1157,startPosition:1},0).wait(1).to({scaleX:1.1155,scaleY:1.1155,x:472.1183,startPosition:0},0).wait(1).to({scaleX:1.1333,scaleY:1.1333,x:472.1211,startPosition:1},0).wait(1).to({scaleX:1.1525,scaleY:1.1525,x:472.1241,startPosition:0},0).wait(1).to({scaleX:1.1731,scaleY:1.1731,x:472.1274,startPosition:1},0).wait(1).to({scaleX:1.1952,scaleY:1.1952,x:472.1309,startPosition:0},0).wait(1).to({scaleX:1.2187,scaleY:1.2187,x:472.1346,startPosition:1},0).wait(1).to({scaleX:1.2437,scaleY:1.2437,x:472.1386,startPosition:0},0).wait(1).to({scaleX:1.2702,scaleY:1.2702,x:472.1427,startPosition:1},0).wait(1).to({scaleX:1.2982,scaleY:1.2982,x:472.1472,startPosition:0},0).wait(1).to({scaleX:1.3278,scaleY:1.3278,x:472.1519,startPosition:1},0).wait(1).to({scaleX:1.3589,scaleY:1.3589,x:472.1568,startPosition:0},0).wait(1).to({scaleX:1.3917,scaleY:1.3917,x:472.162,startPosition:1},0).wait(1).to({scaleX:1.4261,scaleY:1.4261,x:472.1674,startPosition:0},0).wait(1).to({scaleX:1.4621,scaleY:1.4621,x:472.1},0).to({scaleX:1,scaleY:1},25,cjs.Ease.quadInOut).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({scaleX:1.0032,scaleY:1.0032,x:472.1014,y:517.9508,startPosition:1},0).wait(1).to({scaleX:1.0075,scaleY:1.0075,x:472.1032,y:517.9518,startPosition:0},0).wait(1).to({scaleX:1.0129,scaleY:1.0129,x:472.1054,y:517.953,startPosition:1},0).wait(1).to({scaleX:1.0195,scaleY:1.0195,x:472.1082,y:517.9546,startPosition:0},0).wait(1).to({scaleX:1.0272,scaleY:1.0272,x:472.1114,y:517.9564,startPosition:1},0).wait(1).to({scaleX:1.0361,scaleY:1.0361,x:472.1152,y:517.9585,startPosition:0},0).wait(1).to({scaleX:1.0462,scaleY:1.0462,x:472.1194,y:517.9609,startPosition:1},0).wait(1).to({scaleX:1.0575,scaleY:1.0575,x:472.1241,y:517.9635,startPosition:0},0).wait(1).to({scaleX:1.07,scaleY:1.07,x:472.1294,y:517.9665,startPosition:1},0).wait(1).to({scaleX:1.0839,scaleY:1.0839,x:472.1352,y:517.9697,startPosition:0},0).wait(1).to({scaleX:1.099,scaleY:1.099,x:472.1416,y:517.9733,startPosition:1},0).wait(1).to({scaleX:1.1155,scaleY:1.1155,x:472.1485,y:517.9772,startPosition:0},0).wait(1).to({scaleX:1.1333,scaleY:1.1333,x:472.156,y:517.9813,startPosition:1},0).wait(1).to({scaleX:1.1525,scaleY:1.1525,x:472.1641,y:517.9859,startPosition:0},0).wait(1).to({scaleX:1.1731,scaleY:1.1731,x:472.1727,y:517.9907,startPosition:1},0).wait(1).to({scaleX:1.1952,scaleY:1.1952,x:472.182,y:517.9959,startPosition:0},0).wait(1).to({scaleX:1.2187,scaleY:1.2187,x:472.1919,y:518.0014,startPosition:1},0).wait(1).to({scaleX:1.2437,scaleY:1.2437,x:472.2024,y:518.0073,startPosition:0},0).wait(1).to({scaleX:1.2702,scaleY:1.2702,x:472.15,y:517.95,startPosition:1},0).to({_off:true},1).wait(421));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(451.9,497.7,40.5,40.50000000000006);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol1();
	this.instance.setTransform(0,-0.05,1,1,0,0,0,139.3,129.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(62));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-140.3,-130.3,280.6,260.70000000000005);


(lib.Tween86 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_8
	this.instance = new lib.Tween18("synched",2);
	this.instance.setTransform(316.55,131.85,0.8023,0.8023,0,0,0,472.2,517.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(504).to({_off:false},0).wait(306));

	// Layer_8
	this.instance_1 = new lib.Tween18("synched",2);
	this.instance_1.setTransform(174.65,100.35,0.3569,0.3569,0,0,0,471.3,517.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(411).to({_off:false},0).wait(399));

	// Layer_6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_411 = new cjs.Graphics().p("AgPAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAGgGAJAAIAAAAQAKAAAGAGIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgGAGgKAAIAAAAQgJAAgGgGg");
	var mask_graphics_412 = new cjs.Graphics().p("AgPAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAGgGAJAAIAAAAQAKAAAGAGIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgGAGgKAAIAAAAQgJAAgGgGg");
	var mask_graphics_413 = new cjs.Graphics().p("AgQAQQgHgGAAgKIAAAAQAAgJAHgGIAAAAQAHgHAJAAIAAAAQAKAAAHAHIAAAAQAHAGAAAJIAAAAQAAAKgHAGIAAAAQgHAHgKAAIAAAAQgJAAgHgHg");
	var mask_graphics_414 = new cjs.Graphics().p("AgRARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAIgHAJAAIAAAAQAKAAAIAHIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgIAHgKAAIAAAAQgJAAgIgHg");
	var mask_graphics_415 = new cjs.Graphics().p("AgSASQgIgHAAgLIAAAAQAAgKAIgHIAAAAQAIgIAKAAIAAAAQALAAAIAIIAAAAQAIAHAAAKIAAAAQAAALgIAHIAAAAQgIAIgLAAIAAAAQgKAAgIgIg");
	var mask_graphics_416 = new cjs.Graphics().p("AgUAUQgIgIAAgMIAAAAQAAgLAIgIIAAAAQAJgIALAAIAAAAQAMAAAJAIIAAAAQAIAIAAALIAAAAQAAAMgIAIIAAAAQgJAIgMAAIAAAAQgLAAgJgIg");
	var mask_graphics_417 = new cjs.Graphics().p("AgWAWQgJgJAAgNIAAAAQAAgMAJgJIAAAAQAKgJAMAAIAAAAQANAAAKAJIAAAAQAJAJAAAMIAAAAQAAANgJAJIAAAAQgKAJgNAAIAAAAQgMAAgKgJg");
	var mask_graphics_418 = new cjs.Graphics().p("AgYAYQgKgKAAgOIAAAAQAAgNAKgKIAAAAQAKgKAOAAIAAAAQAPAAAKAKIAAAAQAKAKAAANIAAAAQAAAOgKAKIAAAAQgKAKgPAAIAAAAQgOAAgKgKg");
	var mask_graphics_419 = new cjs.Graphics().p("AgbAbQgLgLAAgQIAAAAQAAgPALgLIAAAAQAMgLAPAAIAAAAQAQAAAMALIAAAAQALALAAAPIAAAAQAAAQgLALIAAAAQgMALgQAAIAAAAQgPAAgMgLg");
	var mask_graphics_420 = new cjs.Graphics().p("AgeAdQgNgMAAgRIAAAAQAAgQANgMIAAAAQANgNARAAIAAAAQASAAANANIAAAAQANAMAAAQIAAAAQAAARgNAMIAAAAQgNANgSAAIAAAAQgRAAgNgNg");
	var mask_graphics_421 = new cjs.Graphics().p("AghAhQgOgOAAgTIAAAAQAAgSAOgOIAAAAQAOgNATAAIAAAAQAUAAAOANIAAAAQAOAOAAASIAAAAQAAATgOAOIAAAAQgOANgUAAIAAAAQgTAAgOgNg");
	var mask_graphics_422 = new cjs.Graphics().p("AglAkQgQgPAAgVIAAAAQAAgUAQgPIAAAAQAQgPAVAAIAAAAQAWAAAQAPIAAAAQAQAPAAAUIAAAAQAAAVgQAPIAAAAQgQAPgWAAIAAAAQgVAAgQgPg");
	var mask_graphics_423 = new cjs.Graphics().p("AgpAoQgRgQAAgYIAAAAQAAgXARgQIAAAAQARgRAYAAIAAAAQAZAAARARIAAAAQARAQAAAXIAAAAQAAAYgRAQIAAAAQgRARgZAAIAAAAQgYAAgRgRg");
	var mask_graphics_424 = new cjs.Graphics().p("AguAtQgTgTAAgaIAAAAQAAgZATgTIAAAAQAUgSAaAAIAAAAQAbAAAUASIAAAAQATATAAAZIAAAAQAAAagTATIAAAAQgUASgbAAIAAAAQgaAAgUgSg");
	var mask_graphics_425 = new cjs.Graphics().p("AgyAxQgWgUAAgdIAAAAQAAgcAWgUIAAAAQAVgVAdAAIAAAAQAeAAAVAVIAAAAQAWAUAAAcIAAAAQAAAdgWAUIAAAAQgVAVgeAAIAAAAQgdAAgVgVg");
	var mask_graphics_426 = new cjs.Graphics().p("Ag4A2QgXgWAAggIAAAAQAAgfAXgWIAAAAQAYgXAgAAIAAAAQAhAAAYAXIAAAAQAXAWAAAfIAAAAQAAAggXAWIAAAAQgYAXghAAIAAAAQggAAgYgXg");
	var mask_graphics_427 = new cjs.Graphics().p("Ag9A8QgagZAAgjIAAAAQAAgiAagZIAAAAQAagYAjAAIAAAAQAkAAAaAYIAAAAQAaAZAAAiIAAAAQAAAjgaAZIAAAAQgaAYgkAAIAAAAQgjAAgagYg");
	var mask_graphics_428 = new cjs.Graphics().p("AhDBBQgcgbAAgmIAAAAQAAglAcgbIAAAAQAcgbAnAAIAAAAQAoAAAcAbIAAAAQAcAbAAAlIAAAAQAAAmgcAbIAAAAQgcAbgoAAIAAAAQgnAAgcgbg");
	var mask_graphics_429 = new cjs.Graphics().p("AhJBHQgfgdAAgqIAAAAQAAgpAfgdIAAAAQAegeArAAIAAAAQAsAAAeAeIAAAAQAfAdAAApIAAAAQAAAqgfAdIAAAAQgeAegsAAIAAAAQgrAAgegeg");
	var mask_graphics_430 = new cjs.Graphics().p("AhQBOQghghAAgtIAAAAQAAgsAhghIAAAAQAiggAuAAIAAAAQAvAAAiAgIAAAAQAhAhAAAsIAAAAQAAAtghAhIAAAAQgiAggvAAIAAAAQguAAgiggg");
	var mask_graphics_431 = new cjs.Graphics().p("AhXBUQgkgjAAgxIAAAAQAAgwAkgjIAAAAQAlgjAyAAIAAAAQAzAAAlAjIAAAAQAkAjAAAwIAAAAQAAAxgkAjIAAAAQglAjgzAAIAAAAQgyAAglgjg");
	var mask_graphics_432 = new cjs.Graphics().p("AheBbQgogmAAg1IAAAAQAAg0AogmIAAAAQAngmA3AAIAAAAQA4AAAnAmIAAAAQAoAmAAA0IAAAAQAAA1goAmIAAAAQgnAmg4AAIAAAAQg3AAgngmg");
	var mask_graphics_433 = new cjs.Graphics().p("AhmBjQgrgpAAg6IAAAAQAAg5ArgpIAAAAQArgpA7AAIAAAAQA8AAArApIAAAAQArApAAA5IAAAAQAAA6grApIAAAAQgrApg8AAIAAAAQg7AAgrgpg");
	var mask_graphics_434 = new cjs.Graphics().p("AhuBqQgugsAAg+IAAAAQAAg9AugsIAAAAQAugsBAAAIAAAAQBBAAAuAsIAAAAQAuAsAAA9IAAAAQAAA+guAsIAAAAQguAshBAAIAAAAQhAAAgugsg");
	var mask_graphics_435 = new cjs.Graphics().p("Ah2ByQgygvAAhDIAAAAQAAhCAygvIAAAAQAxgwBFAAIAAAAQBGAAAxAwIAAAAQAyAvAABCIAAAAQAABDgyAvIAAAAQgxAwhGAAIAAAAQhFAAgxgwg");
	var mask_graphics_436 = new cjs.Graphics().p("Ah/B7Qg1gzAAhIIAAAAQAAhHA1gzIAAAAQA1gzBKAAIAAAAQBLAAA1AzIAAAAQA1AzAABHIAAAAQAABIg1AzIAAAAQg1AzhLAAIAAAAQhKAAg1gzg");
	var mask_graphics_437 = new cjs.Graphics().p("AiICEQg5g3AAhNIAAAAQAAhMA5g3IAAAAQA5g2BPAAIAAAAQBQAAA5A2IAAAAQA5A3AABMIAAAAQAABNg5A3IAAAAQg5A2hQAAIAAAAQhPAAg5g2g");
	var mask_graphics_438 = new cjs.Graphics().p("AiSCNQg9g7AAhSIAAAAQAAhRA9g7IAAAAQA9g6BVAAIAAAAQBWAAA9A6IAAAAQA9A7AABRIAAAAQAABSg9A7IAAAAQg9A6hWAAIAAAAQhVAAg9g6g");
	var mask_graphics_439 = new cjs.Graphics().p("AicCWQhBg+AAhYIAAAAQAAhXBBg+IAAAAQBBg+BbAAIAAAAQBcAABBA+IAAAAQBBA+AABXIAAAAQAABYhBA+IAAAAQhBA+hcAAIAAAAQhbAAhBg+g");
	var mask_graphics_440 = new cjs.Graphics().p("AimCgQhFhCAAheIAAAAQAAhdBFhCIAAAAQBFhCBhAAIAAAAQBiAABFBCIAAAAQBFBCAABdIAAAAQAABehFBCIAAAAQhFBChiAAIAAAAQhhAAhFhCg");
	var mask_graphics_441 = new cjs.Graphics().p("AixCqQhJhGAAhkIAAAAQAAhjBJhGIAAAAQBKhHBnAAIAAAAQBoAABJBHIAAAAQBKBGAABjIAAAAQAABkhKBGIAAAAQhJBHhoAAIAAAAQhnAAhKhHg");
	var mask_graphics_442 = new cjs.Graphics().p("Ai7C1QhPhLAAhqIAAAAQAAhpBPhLIAAAAQBOhKBtAAIAAAAQBuAABOBKIAAAAQBPBLAABpIAAAAQAABqhPBLIAAAAQhOBKhuAAIAAAAQhtAAhOhKg");
	var mask_graphics_443 = new cjs.Graphics().p("AjHC/QhShPAAhwIAAAAQAAhvBShPIAAAAQBThQB0AAIAAAAQB1AABTBQIAAAAQBSBPAABvIAAAAQAABwhSBPIAAAAQhTBQh1AAIAAAAQh0AAhThQg");
	var mask_graphics_444 = new cjs.Graphics().p("AjSDKQhYhTAAh3IAAAAQAAh2BYhUIAAAAQBXhTB7AAIAAAAQB8AABXBTIAAAAQBYBUAAB2IAAAAQAAB3hYBTIAAAAQhXBUh8AAIAAAAQh7AAhXhUg");
	var mask_graphics_445 = new cjs.Graphics().p("AjeDWQhdhZAAh9IAAAAQAAh8BdhZIAAAAQBchZCCAAIAAAAQCDAABcBZIAAAAQBdBZAAB8IAAAAQAAB9hdBZIAAAAQhcBZiDAAIAAAAQiCAAhchZg");
	var mask_graphics_446 = new cjs.Graphics().p("AjrDiQhhheAAiEIAAAAQAAiDBhheIAAAAQBihdCJAAIAAAAQCKAABiBdIAAAAQBhBeAACDIAAAAQAACEhhBeIAAAAQhiBdiKAAIAAAAQiJAAhihdg");
	var mask_graphics_447 = new cjs.Graphics().p("Aj4DuQhmhjAAiLIAAAAQAAiKBmhjIAAAAQBnhjCRAAIAAAAQCSAABmBjIAAAAQBnBjAACKIAAAAQAACLhnBjIAAAAQhmBjiSAAIAAAAQiRAAhnhjg");
	var mask_graphics_448 = new cjs.Graphics().p("AkFD7QhshoAAiTIAAAAQAAiSBshoIAAAAQBthnCYAAIAAAAQCZAABsBnIAAAAQBtBoAACSIAAAAQAACThtBoIAAAAQhsBniZAAIAAAAQiYAAhthng");
	var mask_graphics_449 = new cjs.Graphics().p("AkSEHQhyhtAAiaIAAAAQAAiZByhuIAAAAQByhtCgAAIAAAAQChAAByBtIAAAAQByBuAACZIAAAAQAACahyBtIAAAAQhyBuihAAIAAAAQigAAhyhug");
	var mask_graphics_450 = new cjs.Graphics().p("AkgEVQh3hzAAiiIAAAAQAAihB3hzIAAAAQB4hyCoAAIAAAAQCpAAB4ByIAAAAQB3BzAAChIAAAAQAACih3BzIAAAAQh4ByipAAIAAAAQioAAh4hyg");
	var mask_graphics_451 = new cjs.Graphics().p("AkuEiQh9h4AAiqIAAAAQAAipB9h4IAAAAQB+h5CwAAIAAAAQCxAAB+B5IAAAAQB9B4AACpIAAAAQAACqh9B4IAAAAQh+B5ixAAIAAAAQiwAAh+h5g");
	var mask_graphics_452 = new cjs.Graphics().p("Ak9EwQiDh+AAiyIAAAAQAAixCDh+IAAAAQCEh+C5AAIAAAAQC6AACDB+IAAAAQCEB+AACxIAAAAQAACyiEB+IAAAAQiDB+i6AAIAAAAQi5AAiEh+g");
	var mask_graphics_453 = new cjs.Graphics().p("AlLE+QiKiDAAi7IAAAAQAAi6CKiEIAAAAQCJiDDCAAIAAAAQDDAACJCDIAAAAQCKCEAAC6IAAAAQAAC7iKCDIAAAAQiJCEjDAAIAAAAQjCAAiJiEg");
	var mask_graphics_454 = new cjs.Graphics().p("AlbFNQiQiKAAjDIAAAAQAAjCCQiKIAAAAQCQiKDLAAIAAAAQDMAACPCKIAAAAQCRCKAADCIAAAAQAADDiRCKIAAAAQiPCKjMAAIAAAAQjLAAiQiKg");
	var mask_graphics_455 = new cjs.Graphics().p("AlqFcQiXiQAAjMIAAAAQAAjLCXiQIAAAAQCWiQDUAAIAAAAQDVAACWCQIAAAAQCXCQAADLIAAAAQAADMiXCQIAAAAQiWCQjVAAIAAAAQjUAAiWiQg");
	var mask_graphics_456 = new cjs.Graphics().p("Al6FrQidiWAAjVIAAAAQAAjUCdiWIAAAAQCdiXDdAAIAAAAQDeAACdCXIAAAAQCdCWAADUIAAAAQAADVidCWIAAAAQidCXjeAAIAAAAQjdAAidiXg");
	var mask_graphics_457 = new cjs.Graphics().p("AmLF7QijidAAjeIAAAAQAAjdCjidIAAAAQCkidDnAAIAAAAQDoAACjCdIAAAAQCkCdAADdIAAAAQAADeikCdIAAAAQijCdjoAAIAAAAQjnAAikidg");
	var mask_graphics_458 = new cjs.Graphics().p("AmbGLQirikAAjnIAAAAQAAjmCrikIAAAAQCrijDwAAIAAAAQDxAACrCjIAAAAQCrCkAADmIAAAAQAADnirCkIAAAAQirCjjxAAIAAAAQjwAAirijg");
	var mask_graphics_459 = new cjs.Graphics().p("AmsGbQiyiqAAjxIAAAAQAAjwCyiqIAAAAQCyiqD6AAIAAAAQD7AACyCqIAAAAQCyCqAADwIAAAAQAADxiyCqIAAAAQiyCqj7AAIAAAAQj6AAiyiqg");
	var mask_graphics_460 = new cjs.Graphics().p("Am+GsQi4ixAAj7IAAAAQAAj6C4ixIAAAAQC5ixEFAAIAAAAQEGAAC4CxIAAAAQC5CxAAD6IAAAAQAAD7i5CxIAAAAQi4CxkGAAIAAAAQkFAAi5ixg");
	var mask_graphics_461 = new cjs.Graphics().p("AnPG9QjBi4AAkFIAAAAQAAkEDBi4IAAAAQDAi4EPAAIAAAAQEQAADAC4IAAAAQDBC4AAEEIAAAAQAAEFjBC4IAAAAQjAC4kQAAIAAAAQkPAAjAi4g");
	var mask_graphics_462 = new cjs.Graphics().p("AnhHOQjIi/AAkPIAAAAQAAkODIi/IAAAAQDHjAEaAAIAAAAQEbAADHDAIAAAAQDIC/AAEOIAAAAQAAEPjIC/IAAAAQjHDAkbAAIAAAAQkaAAjHjAg");
	var mask_graphics_463 = new cjs.Graphics().p("An0HgQjPjHAAkZIAAAAQAAkYDPjHIAAAAQDQjHEkAAIAAAAQElAADQDHIAAAAQDPDHAAEYIAAAAQAAEZjPDHIAAAAQjQDHklAAIAAAAQkkAAjQjHg");
	var mask_graphics_464 = new cjs.Graphics().p("AoHHyQjXjOAAkkIAAAAQAAkjDXjOIAAAAQDYjOEvAAIAAAAQEwAADXDOIAAAAQDYDOAAEjIAAAAQAAEkjYDOIAAAAQjXDOkwAAIAAAAQkvAAjYjOg");
	var mask_graphics_465 = new cjs.Graphics().p("AoaIEQjfjWAAkuIAAAAQAAktDfjWIAAAAQDfjWE7AAIAAAAQE8AADfDWIAAAAQDfDWAAEtIAAAAQAAEujfDWIAAAAQjfDWk8AAIAAAAQk7AAjfjWg");
	var mask_graphics_466 = new cjs.Graphics().p("AotIWQjnjdAAk5IAAAAQAAk4DnjeIAAAAQDnjdFGAAIAAAAQFHAADnDdIAAAAQDnDeAAE4IAAAAQAAE5jnDdIAAAAQjnDelHAAIAAAAQlGAAjnjeg");
	var mask_graphics_467 = new cjs.Graphics().p("ApAIpQjvjlAAlEIAAAAQAAlDDvjlIAAAAQDvjlFRAAIAAAAQFSAADvDlIAAAAQDvDlAAFDIAAAAQAAFEjvDlIAAAAQjvDllSAAIAAAAQlRAAjvjlg");
	var mask_graphics_468 = new cjs.Graphics().p("ApSI6Qj3jsAAlOIAAAAQAAlND3jsIAAAAQD2jtFcAAIAAAAQFdAAD2DtIAAAAQD3DsAAFNIAAAAQAAFOj3DsIAAAAQj2DtldAAIAAAAQlcAAj2jtg");
	var mask_graphics_469 = new cjs.Graphics().p("ApkJMQj+j0AAlYIAAAAQAAlXD+j0IAAAAQD+jzFmAAIAAAAQFnAAD+DzIAAAAQD+D0AAFXIAAAAQAAFYj+D0IAAAAQj+DzlnAAIAAAAQlmAAj+jzg");
	var mask_graphics_470 = new cjs.Graphics().p("Ap2JdQkFj7AAliIAAAAQAAlhEFj7IAAAAQEFj6FxAAIAAAAQFyAAEFD6IAAAAQEFD7AAFhIAAAAQAAFikFD7IAAAAQkFD6lyAAIAAAAQlxAAkFj6g");
	var mask_graphics_471 = new cjs.Graphics().p("AqIJtQkMkBAAlsIAAAAQAAlrEMkBIAAAAQENkCF7AAIAAAAQF8AAEMECIAAAAQENEBAAFrIAAAAQAAFskNEBIAAAAQkMECl8AAIAAAAQl7AAkNkCg");
	var mask_graphics_472 = new cjs.Graphics().p("AqZJ9QkTkIAAl1IAAAAQAAl0ETkJIAAAAQEUkIGFAAIAAAAQGGAAETEIIAAAAQEUEJAAF0IAAAAQAAF1kUEIIAAAAQkTEJmGAAIAAAAQmFAAkUkJg");
	var mask_graphics_473 = new cjs.Graphics().p("AqpKNQkbkOAAl/IAAAAQAAl+EbkPIAAAAQEakOGPAAIAAAAQGQAAEaEOIAAAAQEbEPAAF+IAAAAQAAF/kbEOIAAAAQkaEPmQAAIAAAAQmPAAkakPg");
	var mask_graphics_474 = new cjs.Graphics().p("Aq6KdQkhkVAAmIIAAAAQAAmHEhkVIAAAAQEikVGYAAIAAAAQGZAAEhEVIAAAAQEiEVAAGHIAAAAQAAGIkiEVIAAAAQkhEVmZAAIAAAAQmYAAkikVg");
	var mask_graphics_475 = new cjs.Graphics().p("ArKKsQknkbAAmRIAAAAQAAmQEnkcIAAAAQEpkbGhAAIAAAAQGiAAEoEbIAAAAQEoEcAAGQIAAAAQAAGRkoEbIAAAAQkoEcmiAAIAAAAQmhAAkpkcg");
	var mask_graphics_476 = new cjs.Graphics().p("ArZK7QkukhAAmaIAAAAQAAmZEukiIAAAAQEukhGrAAIAAAAQGsAAEuEhIAAAAQEuEiAAGZIAAAAQAAGakuEhIAAAAQkuEimsAAIAAAAQmrAAkukig");
	var mask_graphics_477 = new cjs.Graphics().p("AroLKQk1koAAmiIAAAAQAAmhE1koIAAAAQE1koGzAAIAAAAQG0AAE1EoIAAAAQE1EoAAGhIAAAAQAAGik1EoIAAAAQk1Eom0AAIAAAAQmzAAk1kog");
	var mask_graphics_478 = new cjs.Graphics().p("Ar3LYQk7ktAAmrIAAAAQAAmqE7ktIAAAAQE7kuG8AAIAAAAQG9AAE7EuIAAAAQE7EtAAGqIAAAAQAAGrk7EtIAAAAQk7Eum9AAIAAAAQm8AAk7kug");
	var mask_graphics_479 = new cjs.Graphics().p("AsGLmQlAkzAAmzIAAAAQAAmyFAkzIAAAAQFBk0HFAAIAAAAQHGAAFAE0IAAAAQFBEzAAGyIAAAAQAAGzlBEzIAAAAQlAE0nGAAIAAAAQnFAAlBk0g");
	var mask_graphics_480 = new cjs.Graphics().p("AsUL0QlGk5AAm7IAAAAQAAm6FGk5IAAAAQFHk5HNAAIAAAAQHOAAFHE5IAAAAQFGE5AAG6IAAAAQAAG7lGE5IAAAAQlHE5nOAAIAAAAQnNAAlHk5g");
	var mask_graphics_481 = new cjs.Graphics().p("AsiMBQlMk/AAnCIAAAAQAAnBFMk/IAAAAQFNk/HVAAIAAAAQHWAAFME/IAAAAQFNE/AAHBIAAAAQAAHClNE/IAAAAQlME/nWAAIAAAAQnVAAlNk/g");
	var mask_graphics_482 = new cjs.Graphics().p("AsvMOQlSlEAAnKIAAAAQAAnJFSlEIAAAAQFSlEHdAAIAAAAQHeAAFSFEIAAAAQFSFEAAHJIAAAAQAAHKlSFEIAAAAQlSFEneAAIAAAAQndAAlSlEg");
	var mask_graphics_483 = new cjs.Graphics().p("As8MaQlXlJAAnRIAAAAQAAnQFXlKIAAAAQFXlIHlAAIAAAAQHmAAFXFIIAAAAQFXFKAAHQIAAAAQAAHRlXFJIAAAAQlXFJnmAAIAAAAQnlAAlXlJg");
	var mask_graphics_484 = new cjs.Graphics().p("AtJMmQlclOAAnYIAAAAQAAnXFclPIAAAAQFdlOHsAAIAAAAQHtAAFdFOIAAAAQFcFPAAHXIAAAAQAAHYlcFOIAAAAQldFPntAAIAAAAQnsAAldlPg");
	var mask_graphics_485 = new cjs.Graphics().p("AtVMyQlilTAAnfIAAAAQAAneFilUIAAAAQFilSHzAAIAAAAQH0AAFiFSIAAAAQFiFUAAHeIAAAAQAAHfliFTIAAAAQliFTn0AAIAAAAQnzAAlilTg");
	var mask_graphics_486 = new cjs.Graphics().p("AthM+QlnlYAAnmIAAAAQAAnlFnlYIAAAAQFnlYH6AAIAAAAQH7AAFnFYIAAAAQFnFYAAHlIAAAAQAAHmlnFYIAAAAQlnFYn7AAIAAAAQn6AAlnlYg");
	var mask_graphics_487 = new cjs.Graphics().p("AttNJQlrlcAAntIAAAAQAAnsFrlcIAAAAQFsldIBAAIAAAAQICAAFsFdIAAAAQFrFcAAHsIAAAAQAAHtlrFcIAAAAQlsFdoCAAIAAAAQoBAAlsldg");
	var mask_graphics_488 = new cjs.Graphics().p("At4NUQlwlhAAnzIAAAAQAAnyFwlhIAAAAQFwlhIIAAIAAAAQIJAAFwFhIAAAAQFwFhAAHyIAAAAQAAHzlwFhIAAAAQlwFhoJAAIAAAAQoIAAlwlhg");
	var mask_graphics_489 = new cjs.Graphics().p("AuDNeQl1llAAn5IAAAAQAAn4F1lmIAAAAQF1llIOAAIAAAAQIPAAF1FlIAAAAQF1FmAAH4IAAAAQAAH5l1FlIAAAAQl1FmoPAAIAAAAQoOAAl1lmg");
	var mask_graphics_490 = new cjs.Graphics().p("AuONoQl5lpAAn/IAAAAQAAn+F5lqIAAAAQF6lpIUAAIAAAAQIVAAF5FpIAAAAQF6FqAAH+IAAAAQAAH/l6FpIAAAAQl5FqoVAAIAAAAQoUAAl6lqg");
	var mask_graphics_491 = new cjs.Graphics().p("AuYNyQl9ltAAoFIAAAAQAAoEF9luIAAAAQF+ltIaAAIAAAAQIbAAF+FtIAAAAQF9FuAAIEIAAAAQAAIFl9FtIAAAAQl+FuobAAIAAAAQoaAAl+lug");
	var mask_graphics_492 = new cjs.Graphics().p("AuiN8QmBlyAAoKIAAAAQAAoJGBlyIAAAAQGClxIgAAIAAAAQIhAAGBFxIAAAAQGCFyAAIJIAAAAQAAIKmCFyIAAAAQmBFxohAAIAAAAQogAAmClxg");
	var mask_graphics_493 = new cjs.Graphics().p("AurOFQmGl1AAoQIAAAAQAAoPGGl1IAAAAQGFl1ImAAIAAAAQInAAGFF1IAAAAQGGF1AAIPIAAAAQAAIQmGF1IAAAAQmFF1onAAIAAAAQomAAmFl1g");
	var mask_graphics_494 = new cjs.Graphics().p("Au1ONQmJl4AAoVIAAAAQAAoUGJl5IAAAAQGKl4IrAAIAAAAQIsAAGJF4IAAAAQGKF5AAIUIAAAAQAAIVmKF4IAAAAQmJF5osAAIAAAAQorAAmKl5g");
	var mask_graphics_495 = new cjs.Graphics().p("Au9OWQmNl8AAoaIAAAAQAAoZGNl8IAAAAQGNl8IwAAIAAAAQIxAAGNF8IAAAAQGNF8AAIZIAAAAQAAIamNF8IAAAAQmNF8oxAAIAAAAQowAAmNl8g");
	var mask_graphics_496 = new cjs.Graphics().p("AvGOeQmQmAAAoeIAAAAQAAodGQmAIAAAAQGRmAI1AAIAAAAQI2AAGQGAIAAAAQGRGAAAIdIAAAAQAAIemRGAIAAAAQmQGAo2AAIAAAAQo1AAmRmAg");
	var mask_graphics_497 = new cjs.Graphics().p("AvOOmQmTmDAAojIAAAAQAAoiGTmDIAAAAQGUmDI6AAIAAAAQI7AAGTGDIAAAAQGUGDAAIiIAAAAQAAIjmUGDIAAAAQmTGDo7AAIAAAAQo6AAmUmDg");
	var mask_graphics_498 = new cjs.Graphics().p("AvVOtQmXmGAAonIAAAAQAAomGXmGIAAAAQGXmGI+AAIAAAAQI/AAGXGGIAAAAQGXGGAAImIAAAAQAAInmXGGIAAAAQmXGGo/AAIAAAAQo+AAmXmGg");
	var mask_graphics_499 = new cjs.Graphics().p("AvdO0QmamJAAorIAAAAQAAoqGamJIAAAAQGamJJDAAIAAAAQJEAAGZGJIAAAAQGbGJAAIqIAAAAQAAIrmbGJIAAAAQmZGJpEAAIAAAAQpDAAmamJg");
	var mask_graphics_500 = new cjs.Graphics().p("AvkO7QmcmMAAovIAAAAQAAouGcmMIAAAAQGdmMJHAAIAAAAQJIAAGcGMIAAAAQGdGMAAIuIAAAAQAAIvmdGMIAAAAQmcGMpIAAIAAAAQpHAAmdmMg");
	var mask_graphics_501 = new cjs.Graphics().p("AvqPBQmgmOAAozIAAAAQAAoyGgmPIAAAAQGfmOJLAAIAAAAQJMAAGfGOIAAAAQGgGPAAIyIAAAAQAAIzmgGOIAAAAQmfGPpMAAIAAAAQpLAAmfmPg");
	var mask_graphics_502 = new cjs.Graphics().p("AvxPHQmimQAAo3IAAAAQAAo2GimRIAAAAQGjmQJOAAIAAAAQJPAAGiGQIAAAAQGjGRAAI2IAAAAQAAI3mjGQIAAAAQmiGRpPAAIAAAAQpOAAmjmRg");
	var mask_graphics_503 = new cjs.Graphics().p("Av3PNQmkmTAAo6IAAAAQAAo5GkmTIAAAAQGlmTJSAAIAAAAQJTAAGkGTIAAAAQGlGTAAI5IAAAAQAAI6mlGTIAAAAQmkGTpTAAIAAAAQpSAAmlmTg");
	var mask_graphics_504 = new cjs.Graphics().p("Av8PSQmnmVAAo9IAAAAQAAo8GnmWIAAAAQGnmVJVAAIAAAAQJWAAGnGVIAAAAQGnGWAAI8IAAAAQAAI9mnGVIAAAAQmnGWpWAAIAAAAQpVAAmnmWg");
	var mask_graphics_505 = new cjs.Graphics().p("AwBPXQmpmXAApAIAAAAQAAo/GpmXIAAAAQGpmYJYAAIAAAAQJZAAGpGYIAAAAQGpGXAAI/IAAAAQAAJAmpGXIAAAAQmpGYpZAAIAAAAQpYAAmpmYg");
	var mask_graphics_506 = new cjs.Graphics().p("AwGPcQmrmZAApDIAAAAQAApCGrmZIAAAAQGrmZJbAAIAAAAQJcAAGrGZIAAAAQGrGZAAJCIAAAAQAAJDmrGZIAAAAQmrGZpcAAIAAAAQpbAAmrmZg");
	var mask_graphics_507 = new cjs.Graphics().p("AwLPgQmsmbAApFIAAAAQAApEGsmbIAAAAQGtmbJeAAIAAAAQJfAAGsGbIAAAAQGtGbAAJEIAAAAQAAJFmtGbIAAAAQmsGbpfAAIAAAAQpeAAmtmbg");
	var mask_graphics_508 = new cjs.Graphics().p("AwPPkQmumdAApHIAAAAQAApGGumdIAAAAQGvmdJgAAIAAAAQJhAAGuGdIAAAAQGvGdAAJGIAAAAQAAJHmvGdIAAAAQmuGdphAAIAAAAQpgAAmvmdg");
	var mask_graphics_509 = new cjs.Graphics().p("AwTPnQmwmdAApKIAAAAQAApJGwmeIAAAAQGxmeJiAAIAAAAQJjAAGwGeIAAAAQGxGeAAJJIAAAAQAAJKmxGdIAAAAQmwGfpjAAIAAAAQpiAAmxmfg");
	var mask_graphics_510 = new cjs.Graphics().p("AwWPrQmxmgAApLIAAAAQAApKGxmgIAAAAQGymgJkAAIAAAAQJlAAGyGgIAAAAQGxGgAAJKIAAAAQAAJLmxGgIAAAAQmyGgplAAIAAAAQpkAAmymgg");
	var mask_graphics_511 = new cjs.Graphics().p("AwZPuQmzmhAApNIAAAAQAApMGzmhIAAAAQGzmhJmAAIAAAAQJnAAGzGhIAAAAQGzGhAAJMIAAAAQAAJNmzGhIAAAAQmzGhpnAAIAAAAQpmAAmzmhg");
	var mask_graphics_512 = new cjs.Graphics().p("AwcPwQm0mhAApPIAAAAQAApOG0miIAAAAQG1mhJnAAIAAAAQJoAAG0GhIAAAAQG1GiAAJOIAAAAQAAJPm1GhIAAAAQm0GipoAAIAAAAQpnAAm1mig");
	var mask_graphics_513 = new cjs.Graphics().p("AwePyQm1miAApQIAAAAQAApPG1mjIAAAAQG1miJpAAIAAAAQJqAAG1GiIAAAAQG1GjAAJPIAAAAQAAJQm1GiIAAAAQm1GjpqAAIAAAAQppAAm1mjg");
	var mask_graphics_514 = new cjs.Graphics().p("AwgP0Qm2mjAApRIAAAAQAApQG2mkIAAAAQG2mjJqAAIAAAAQJrAAG2GjIAAAAQG2GkAAJQIAAAAQAAJRm2GjIAAAAQm2GkprAAIAAAAQpqAAm2mkg");
	var mask_graphics_515 = new cjs.Graphics().p("AwiP2Qm2mkAApSIAAAAQAApRG2mkIAAAAQG3mkJrAAIAAAAQJsAAG2GkIAAAAQG3GkAAJRIAAAAQAAJSm3GkIAAAAQm2GkpsAAIAAAAQprAAm3mkg");
	var mask_graphics_516 = new cjs.Graphics().p("AwjP3Qm3mkAApTIAAAAQAApSG3mlIAAAAQG3mkJsAAIAAAAQJtAAG2GkIAAAAQG4GlAAJSIAAAAQAAJTm4GkIAAAAQm2GlptAAIAAAAQpsAAm3mlg");
	var mask_graphics_517 = new cjs.Graphics().p("AwkP4Qm3mlAApTIAAAAQAApSG3mlIAAAAQG4mlJsAAIAAAAQJtAAG3GlIAAAAQG4GlAAJSIAAAAQAAJTm4GlIAAAAQm3GlptAAIAAAAQpsAAm4mlg");
	var mask_graphics_518 = new cjs.Graphics().p("AwkP4Qm4mkAApUIAAAAQAApTG4mlIAAAAQG3mlJtAAIAAAAQJuAAG3GlIAAAAQG4GlAAJTIAAAAQAAJUm4GkIAAAAQm3GmpuAAIAAAAQptAAm3mmg");
	var mask_graphics_519 = new cjs.Graphics().p("AwlP5Qm3mlAApUIAAAAQAApTG3mlIAAAAQG4mlJtAAIAAAAQJuAAG3GlIAAAAQG4GlAAJTIAAAAQAAJUm4GlIAAAAQm3GlpuAAIAAAAQptAAm4mlg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(411).to({graphics:mask_graphics_411,x:174.6,y:100.3}).wait(1).to({graphics:mask_graphics_412,x:174.6004,y:100.2991}).wait(1).to({graphics:mask_graphics_413,x:174.6022,y:100.296}).wait(1).to({graphics:mask_graphics_414,x:174.604,y:100.291}).wait(1).to({graphics:mask_graphics_415,x:174.6076,y:100.2834}).wait(1).to({graphics:mask_graphics_416,x:174.6117,y:100.2744}).wait(1).to({graphics:mask_graphics_417,x:174.6162,y:100.2631}).wait(1).to({graphics:mask_graphics_418,x:174.622,y:100.2501}).wait(1).to({graphics:mask_graphics_419,x:174.6288,y:100.2348}).wait(1).to({graphics:mask_graphics_420,x:174.6365,y:100.2177}).wait(1).to({graphics:mask_graphics_421,x:174.645,y:100.1983}).wait(1).to({graphics:mask_graphics_422,x:174.6544,y:100.1772}).wait(1).to({graphics:mask_graphics_423,x:174.6648,y:100.1534}).wait(1).to({graphics:mask_graphics_424,x:174.676,y:100.1277}).wait(1).to({graphics:mask_graphics_425,x:174.6882,y:100.1003}).wait(1).to({graphics:mask_graphics_426,x:174.7012,y:100.071}).wait(1).to({graphics:mask_graphics_427,x:174.7147,y:100.039}).wait(1).to({graphics:mask_graphics_428,x:174.7296,y:100.0053}).wait(1).to({graphics:mask_graphics_429,x:174.7453,y:99.9702}).wait(1).to({graphics:mask_graphics_430,x:174.762,y:99.9319}).wait(1).to({graphics:mask_graphics_431,x:174.7795,y:99.8923}).wait(1).to({graphics:mask_graphics_432,x:174.798,y:99.8505}).wait(1).to({graphics:mask_graphics_433,x:174.8173,y:99.8064}).wait(1).to({graphics:mask_graphics_434,x:174.8372,y:99.761}).wait(1).to({graphics:mask_graphics_435,x:174.8583,y:99.7128}).wait(1).to({graphics:mask_graphics_436,x:174.8803,y:99.6628}).wait(1).to({graphics:mask_graphics_437,x:174.9033,y:99.6111}).wait(1).to({graphics:mask_graphics_438,x:174.9271,y:99.5571}).wait(1).to({graphics:mask_graphics_439,x:174.9519,y:99.5009}).wait(1).to({graphics:mask_graphics_440,x:174.9771,y:99.4428}).wait(1).to({graphics:mask_graphics_441,x:175.0036,y:99.3825}).wait(1).to({graphics:mask_graphics_442,x:175.0311,y:99.3204}).wait(1).to({graphics:mask_graphics_443,x:175.0594,y:99.256}).wait(1).to({graphics:mask_graphics_444,x:175.0887,y:99.1899}).wait(1).to({graphics:mask_graphics_445,x:175.1184,y:99.1215}).wait(1).to({graphics:mask_graphics_446,x:175.1495,y:99.0513}).wait(1).to({graphics:mask_graphics_447,x:175.1814,y:98.9788}).wait(1).to({graphics:mask_graphics_448,x:175.2138,y:98.9046}).wait(1).to({graphics:mask_graphics_449,x:175.2475,y:98.8285}).wait(1).to({graphics:mask_graphics_450,x:175.2822,y:98.7498}).wait(1).to({graphics:mask_graphics_451,x:175.3173,y:98.6692}).wait(1).to({graphics:mask_graphics_452,x:175.3538,y:98.5869}).wait(1).to({graphics:mask_graphics_453,x:175.3911,y:98.5019}).wait(1).to({graphics:mask_graphics_454,x:175.4289,y:98.4154}).wait(1).to({graphics:mask_graphics_455,x:175.468,y:98.3268}).wait(1).to({graphics:mask_graphics_456,x:175.5081,y:98.2359}).wait(1).to({graphics:mask_graphics_457,x:175.549,y:98.1432}).wait(1).to({graphics:mask_graphics_458,x:175.5909,y:98.0482}).wait(1).to({graphics:mask_graphics_459,x:175.6332,y:97.9515}).wait(1).to({graphics:mask_graphics_460,x:175.6769,y:97.8525}).wait(1).to({graphics:mask_graphics_461,x:175.7214,y:97.7517}).wait(1).to({graphics:mask_graphics_462,x:175.7664,y:97.6491}).wait(1).to({graphics:mask_graphics_463,x:175.8123,y:97.5438}).wait(1).to({graphics:mask_graphics_464,x:175.8596,y:97.4367}).wait(1).to({graphics:mask_graphics_465,x:175.9072,y:97.3278}).wait(1).to({graphics:mask_graphics_466,x:175.9558,y:97.2189}).wait(1).to({graphics:mask_graphics_467,x:176.0026,y:97.1118}).wait(1).to({graphics:mask_graphics_468,x:176.0485,y:97.0065}).wait(1).to({graphics:mask_graphics_469,x:176.094,y:96.9039}).wait(1).to({graphics:mask_graphics_470,x:176.1381,y:96.8031}).wait(1).to({graphics:mask_graphics_471,x:176.1817,y:96.7041}).wait(1).to({graphics:mask_graphics_472,x:176.2245,y:96.6069}).wait(1).to({graphics:mask_graphics_473,x:176.2659,y:96.5119}).wait(1).to({graphics:mask_graphics_474,x:176.3069,y:96.4197}).wait(1).to({graphics:mask_graphics_475,x:176.3469,y:96.3288}).wait(1).to({graphics:mask_graphics_476,x:176.3856,y:96.2401}).wait(1).to({graphics:mask_graphics_477,x:176.4238,y:96.1533}).wait(1).to({graphics:mask_graphics_478,x:176.4612,y:96.0687}).wait(1).to({graphics:mask_graphics_479,x:176.4976,y:95.9863}).wait(1).to({graphics:mask_graphics_480,x:176.5332,y:95.9058}).wait(1).to({graphics:mask_graphics_481,x:176.5674,y:95.827}).wait(1).to({graphics:mask_graphics_482,x:176.6007,y:95.751}).wait(1).to({graphics:mask_graphics_483,x:176.6336,y:95.6763}).wait(1).to({graphics:mask_graphics_484,x:176.6655,y:95.6039}).wait(1).to({graphics:mask_graphics_485,x:176.6965,y:95.5336}).wait(1).to({graphics:mask_graphics_486,x:176.7267,y:95.4653}).wait(1).to({graphics:mask_graphics_487,x:176.756,y:95.3991}).wait(1).to({graphics:mask_graphics_488,x:176.7838,y:95.3347}).wait(1).to({graphics:mask_graphics_489,x:176.8113,y:95.2727}).wait(1).to({graphics:mask_graphics_490,x:176.8378,y:95.2128}).wait(1).to({graphics:mask_graphics_491,x:176.8631,y:95.1543}).wait(1).to({graphics:mask_graphics_492,x:176.8878,y:95.0985}).wait(1).to({graphics:mask_graphics_493,x:176.9116,y:95.0445}).wait(1).to({graphics:mask_graphics_494,x:176.9346,y:94.9923}).wait(1).to({graphics:mask_graphics_495,x:176.9567,y:94.9423}).wait(1).to({graphics:mask_graphics_496,x:176.9773,y:94.8942}).wait(1).to({graphics:mask_graphics_497,x:176.9976,y:94.8483}).wait(1).to({graphics:mask_graphics_498,x:177.017,y:94.8046}).wait(1).to({graphics:mask_graphics_499,x:177.0354,y:94.7632}).wait(1).to({graphics:mask_graphics_500,x:177.0529,y:94.7232}).wait(1).to({graphics:mask_graphics_501,x:177.0696,y:94.6854}).wait(1).to({graphics:mask_graphics_502,x:177.0853,y:94.6498}).wait(1).to({graphics:mask_graphics_503,x:177.1002,y:94.6166}).wait(1).to({graphics:mask_graphics_504,x:177.1141,y:94.5846}).wait(1).to({graphics:mask_graphics_505,x:177.1267,y:94.5553}).wait(1).to({graphics:mask_graphics_506,x:177.1394,y:94.5279}).wait(1).to({graphics:mask_graphics_507,x:177.1501,y:94.5022}).wait(1).to({graphics:mask_graphics_508,x:177.1605,y:94.4784}).wait(1).to({graphics:mask_graphics_509,x:177.17,y:94.4572}).wait(1).to({graphics:mask_graphics_510,x:177.1785,y:94.4379}).wait(1).to({graphics:mask_graphics_511,x:177.1862,y:94.4208}).wait(1).to({graphics:mask_graphics_512,x:177.1924,y:94.4051}).wait(1).to({graphics:mask_graphics_513,x:177.1987,y:94.392}).wait(1).to({graphics:mask_graphics_514,x:177.2037,y:94.3808}).wait(1).to({graphics:mask_graphics_515,x:177.2077,y:94.3713}).wait(1).to({graphics:mask_graphics_516,x:177.2109,y:94.3645}).wait(1).to({graphics:mask_graphics_517,x:177.2131,y:94.3591}).wait(1).to({graphics:mask_graphics_518,x:177.2145,y:94.3564}).wait(1).to({graphics:mask_graphics_519,x:177.2149,y:94.3078}).wait(291));

	// Layer_38
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("ArFidIWKE7");
	this.shape.setTransform(245.55,116.05);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(411).to({_off:false},0).wait(399));

	// Layer_6 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_341 = new cjs.Graphics().p("AgPAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAGgGAJAAIAAAAQAKAAAGAGIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgGAGgKAAIAAAAQgJAAgGgGg");
	var mask_1_graphics_342 = new cjs.Graphics().p("AgPAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAGgGAJAAIAAAAQAKAAAGAGIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgGAGgKAAIAAAAQgJAAgGgGg");
	var mask_1_graphics_343 = new cjs.Graphics().p("AgQAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAHgHAJAAIAAAAQAKAAAHAHIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgHAHgKAAIAAAAQgJAAgHgHg");
	var mask_1_graphics_344 = new cjs.Graphics().p("AgRARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAIgHAJAAIAAAAQAKAAAIAHIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgIAHgKAAIAAAAQgJAAgIgHg");
	var mask_1_graphics_345 = new cjs.Graphics().p("AgRASQgIgIAAgKIAAAAQAAgJAIgIIAAAAQAHgHAKAAIAAAAQALAAAHAHIAAAAQAIAIAAAJIAAAAQAAAKgIAIIAAAAQgHAHgLAAIAAAAQgKAAgHgHg");
	var mask_1_graphics_346 = new cjs.Graphics().p("AgTATQgIgIAAgLIAAAAQAAgKAIgIIAAAAQAIgIALAAIAAAAQAMAAAIAIIAAAAQAIAIAAAKIAAAAQAAALgIAIIAAAAQgIAIgMAAIAAAAQgLAAgIgIg");
	var mask_1_graphics_347 = new cjs.Graphics().p("AgUAUQgJgIAAgMIAAAAQAAgLAJgIIAAAAQAJgJALAAIAAAAQAMAAAJAJIAAAAQAJAIAAALIAAAAQAAAMgJAIIAAAAQgJAJgMAAIAAAAQgLAAgJgJg");
	var mask_1_graphics_348 = new cjs.Graphics().p("AgWAWQgKgJAAgNIAAAAQAAgMAKgJIAAAAQAJgJANAAIAAAAQAOAAAJAJIAAAAQAKAJAAAMIAAAAQAAANgKAJIAAAAQgJAJgOAAIAAAAQgNAAgJgJg");
	var mask_1_graphics_349 = new cjs.Graphics().p("AgYAYQgLgKAAgOIAAAAQAAgNALgKIAAAAQAKgKAOAAIAAAAQAPAAAKAKIAAAAQALAKAAANIAAAAQAAAOgLAKIAAAAQgKAKgPAAIAAAAQgOAAgKgKg");
	var mask_1_graphics_350 = new cjs.Graphics().p("AgbAaQgLgKAAgQIAAAAQAAgOALgLIAAAAQAMgLAPAAIAAAAQAQAAAMALIAAAAQALALAAAOIAAAAQAAAQgLAKIAAAAQgMALgQAAIAAAAQgPAAgMgLg");
	var mask_1_graphics_351 = new cjs.Graphics().p("AgdAdQgNgMAAgRIAAAAQAAgQANgMIAAAAQAMgMARAAIAAAAQASAAAMAMIAAAAQANAMAAAQIAAAAQAAARgNAMIAAAAQgMAMgSAAIAAAAQgRAAgMgMg");
	var mask_1_graphics_352 = new cjs.Graphics().p("AggAgQgOgNAAgTIAAAAQAAgSAOgNIAAAAQAOgNASAAIAAAAQATAAAOANIAAAAQAOANAAASIAAAAQAAATgOANIAAAAQgOANgTAAIAAAAQgSAAgOgNg");
	var mask_1_graphics_353 = new cjs.Graphics().p("AgjAjQgQgPAAgUIAAAAQAAgTAQgPIAAAAQAPgOAUAAIAAAAQAVAAAPAOIAAAAQAQAPAAATIAAAAQAAAUgQAPIAAAAQgPAOgVAAIAAAAQgUAAgPgOg");
	var mask_1_graphics_354 = new cjs.Graphics().p("AgnAmQgRgQAAgWIAAAAQAAgVARgQIAAAAQARgQAWAAIAAAAQAXAAARAQIAAAAQARAQAAAVIAAAAQAAAWgRAQIAAAAQgRAQgXAAIAAAAQgWAAgRgQg");
	var mask_1_graphics_355 = new cjs.Graphics().p("AgrAqQgSgRAAgZIAAAAQAAgYASgRIAAAAQASgRAZAAIAAAAQAaAAASARIAAAAQASARAAAYIAAAAQAAAZgSARIAAAAQgSARgaAAIAAAAQgZAAgSgRg");
	var mask_1_graphics_356 = new cjs.Graphics().p("AgvAuQgUgTAAgbIAAAAQAAgaAUgTIAAAAQAUgTAbAAIAAAAQAcAAAUATIAAAAQAUATAAAaIAAAAQAAAbgUATIAAAAQgUATgcAAIAAAAQgbAAgUgTg");
	var mask_1_graphics_357 = new cjs.Graphics().p("AgzAyQgWgVAAgdIAAAAQAAgcAWgVIAAAAQAVgVAeAAIAAAAQAfAAAVAVIAAAAQAWAVAAAcIAAAAQAAAdgWAVIAAAAQgVAVgfAAIAAAAQgeAAgVgVg");
	var mask_1_graphics_358 = new cjs.Graphics().p("Ag4A2QgXgWAAggIAAAAQAAgfAXgWIAAAAQAYgXAgAAIAAAAQAhAAAYAXIAAAAQAXAWAAAfIAAAAQAAAggXAWIAAAAQgYAXghAAIAAAAQggAAgYgXg");
	var mask_1_graphics_359 = new cjs.Graphics().p("Ag9A7QgZgYAAgjIAAAAQAAgiAZgYIAAAAQAagZAjAAIAAAAQAkAAAaAZIAAAAQAZAYAAAiIAAAAQAAAjgZAYIAAAAQgaAZgkAAIAAAAQgjAAgagZg");
	var mask_1_graphics_360 = new cjs.Graphics().p("AhCBAQgcgaAAgmIAAAAQAAglAcgaIAAAAQAcgbAmAAIAAAAQAnAAAcAbIAAAAQAcAaAAAlIAAAAQAAAmgcAaIAAAAQgcAbgnAAIAAAAQgmAAgcgbg");
	var mask_1_graphics_361 = new cjs.Graphics().p("AhHBFQgegcAAgpIAAAAQAAgoAegcIAAAAQAegdApAAIAAAAQAqAAAeAdIAAAAQAeAcAAAoIAAAAQAAApgeAcIAAAAQgeAdgqAAIAAAAQgpAAgegdg");
	var mask_1_graphics_362 = new cjs.Graphics().p("AhNBLQghgfAAgsIAAAAQAAgrAhgfIAAAAQAggfAtAAIAAAAQAuAAAgAfIAAAAQAhAfAAArIAAAAQAAAsghAfIAAAAQggAfguAAIAAAAQgtAAgggfg");
	var mask_1_graphics_363 = new cjs.Graphics().p("AhTBRQgjgiAAgvIAAAAQAAguAjgiIAAAAQAjghAwAAIAAAAQAxAAAjAhIAAAAQAjAiAAAuIAAAAQAAAvgjAiIAAAAQgjAhgxAAIAAAAQgwAAgjghg");
	var mask_1_graphics_364 = new cjs.Graphics().p("AhaBXQglgkAAgzIAAAAQAAgyAlgkIAAAAQAmgkA0AAIAAAAQA1AAAmAkIAAAAQAlAkAAAyIAAAAQAAAzglAkIAAAAQgmAkg1AAIAAAAQg0AAgmgkg");
	var mask_1_graphics_365 = new cjs.Graphics().p("AhgBdQgogmAAg3IAAAAQAAg2AogmIAAAAQAognA4AAIAAAAQA5AAAoAnIAAAAQAoAmAAA2IAAAAQAAA3goAmIAAAAQgoAng5AAIAAAAQg4AAgogng");
	var mask_1_graphics_366 = new cjs.Graphics().p("AhnBkQgrgqAAg6IAAAAQAAg5ArgqIAAAAQArgpA8AAIAAAAQA9AAArApIAAAAQArAqAAA5IAAAAQAAA6grAqIAAAAQgrApg9AAIAAAAQg8AAgrgpg");
	var mask_1_graphics_367 = new cjs.Graphics().p("AhuBqQgugsAAg+IAAAAQAAg9AugtIAAAAQAugsBAAAIAAAAQBBAAAuAsIAAAAQAuAtAAA9IAAAAQAAA+guAsIAAAAQguAthBAAIAAAAQhAAAgugtg");
	var mask_1_graphics_368 = new cjs.Graphics().p("Ah2ByQgxgvAAhDIAAAAQAAhCAxgvIAAAAQAygvBEAAIAAAAQBFAAAyAvIAAAAQAxAvAABCIAAAAQAABDgxAvIAAAAQgyAvhFAAIAAAAQhEAAgygvg");
	var mask_1_graphics_369 = new cjs.Graphics().p("Ah9B5Qg1gyAAhHIAAAAQAAhGA1gyIAAAAQA0gyBJAAIAAAAQBKAAA0AyIAAAAQA1AyAABGIAAAAQAABHg1AyIAAAAQg0AyhKAAIAAAAQhJAAg0gyg");
	var mask_1_graphics_370 = new cjs.Graphics().p("AiFCBQg4g2AAhLIAAAAQAAhKA4g2IAAAAQA3g1BOAAIAAAAQBPAAA3A1IAAAAQA4A2AABKIAAAAQAABLg4A2IAAAAQg3A1hPAAIAAAAQhOAAg3g1g");
	var mask_1_graphics_371 = new cjs.Graphics().p("AiOCJQg7g5AAhQIAAAAQAAhPA7g5IAAAAQA7g4BTAAIAAAAQBUAAA7A4IAAAAQA7A5AABPIAAAAQAABQg7A5IAAAAQg7A4hUAAIAAAAQhTAAg7g4g");
	var mask_1_graphics_372 = new cjs.Graphics().p("AiWCRQg/g8AAhVIAAAAQAAhUA/g8IAAAAQA+g8BYAAIAAAAQBZAAA+A8IAAAAQA/A8AABUIAAAAQAABVg/A8IAAAAQg+A8hZAAIAAAAQhYAAg+g8g");
	var mask_1_graphics_373 = new cjs.Graphics().p("AifCZQhCg/AAhaIAAAAQAAhZBCg/IAAAAQBChABdAAIAAAAQBeAABCBAIAAAAQBCA/AABZIAAAAQAABahCA/IAAAAQhCBAheAAIAAAAQhdAAhChAg");
	var mask_1_graphics_374 = new cjs.Graphics().p("AioCiQhGhDAAhfIAAAAQAAheBGhDIAAAAQBGhDBiAAIAAAAQBjAABGBDIAAAAQBGBDAABeIAAAAQAABfhGBDIAAAAQhGBDhjAAIAAAAQhiAAhGhDg");
	var mask_1_graphics_375 = new cjs.Graphics().p("AiyCrQhKhHAAhkIAAAAQAAhjBKhHIAAAAQBKhHBoAAIAAAAQBpAABKBHIAAAAQBKBHAABjIAAAAQAABkhKBHIAAAAQhKBHhpAAIAAAAQhoAAhKhHg");
	var mask_1_graphics_376 = new cjs.Graphics().p("Ai7C0QhOhKAAhqIAAAAQAAhpBOhKIAAAAQBOhLBtAAIAAAAQBuAABOBLIAAAAQBOBKAABpIAAAAQAABqhOBKIAAAAQhOBLhuAAIAAAAQhtAAhOhLg");
	var mask_1_graphics_377 = new cjs.Graphics().p("AjFC+QhShPAAhvIAAAAQAAhuBShPIAAAAQBShPBzAAIAAAAQB0AABSBPIAAAAQBSBPAABuIAAAAQAABvhSBPIAAAAQhSBPh0AAIAAAAQhzAAhShPg");
	var mask_1_graphics_378 = new cjs.Graphics().p("AjQDIQhWhTAAh1IAAAAQAAh0BWhTIAAAAQBXhTB5AAIAAAAQB6AABWBTIAAAAQBXBTAAB0IAAAAQAAB1hXBTIAAAAQhWBTh6AAIAAAAQh5AAhXhTg");
	var mask_1_graphics_379 = new cjs.Graphics().p("AjaDSQhbhXAAh7IAAAAQAAh6BbhXIAAAAQBbhXB/AAIAAAAQCAAABbBXIAAAAQBbBXAAB6IAAAAQAAB7hbBXIAAAAQhbBXiAAAIAAAAQh/AAhbhXg");
	var mask_1_graphics_380 = new cjs.Graphics().p("AjlDcQhfhbAAiBIAAAAQAAiABfhbIAAAAQBfhbCGAAIAAAAQCHAABfBbIAAAAQBfBbAACAIAAAAQAACBhfBbIAAAAQhfBbiHAAIAAAAQiGAAhfhbg");
	var mask_1_graphics_381 = new cjs.Graphics().p("AjwDnQhkhgAAiHIAAAAQAAiGBkhgIAAAAQBkhfCMAAIAAAAQCNAABkBfIAAAAQBkBgAACGIAAAAQAACHhkBgIAAAAQhkBfiNAAIAAAAQiMAAhkhfg");
	var mask_1_graphics_382 = new cjs.Graphics().p("Aj7DyQhphkAAiOIAAAAQAAiNBphkIAAAAQBohkCTAAIAAAAQCUAABoBkIAAAAQBpBkAACNIAAAAQAACOhpBkIAAAAQhoBkiUAAIAAAAQiTAAhohkg");
	var mask_1_graphics_383 = new cjs.Graphics().p("AkHD9QhthpAAiUIAAAAQAAiTBthpIAAAAQBthpCaAAIAAAAQCbAABtBpIAAAAQBtBpAACTIAAAAQAACUhtBpIAAAAQhtBpibAAIAAAAQiaAAhthpg");
	var mask_1_graphics_384 = new cjs.Graphics().p("AkTEIQhyhtAAibIAAAAQAAiaByhtIAAAAQByhuChAAIAAAAQCiAAByBuIAAAAQByBtAACaIAAAAQAACbhyBtIAAAAQhyBuiiAAIAAAAQihAAhyhug");
	var mask_1_graphics_385 = new cjs.Graphics().p("AkfEUQh3hyAAiiIAAAAQAAihB3hyIAAAAQB3hyCoAAIAAAAQCpAAB3ByIAAAAQB3ByAAChIAAAAQAACih3ByIAAAAQh3ByipAAIAAAAQioAAh3hyg");
	var mask_1_graphics_386 = new cjs.Graphics().p("AksEgQh8h3AAipIAAAAQAAioB8h3IAAAAQB9h3CvAAIAAAAQCwAAB9B3IAAAAQB8B3AACoIAAAAQAACph8B3IAAAAQh9B3iwAAIAAAAQivAAh9h3g");
	var mask_1_graphics_387 = new cjs.Graphics().p("Ak4EsQiCh8AAiwIAAAAQAAivCCh8IAAAAQCBh9C3AAIAAAAQC4AACBB9IAAAAQCCB8AACvIAAAAQAACwiCB8IAAAAQiBB9i4AAIAAAAQi3AAiBh9g");
	var mask_1_graphics_388 = new cjs.Graphics().p("AlGE5QiHiCAAi3IAAAAQAAi2CHiCIAAAAQCIiBC+AAIAAAAQC/AACHCBIAAAAQCICCAAC2IAAAAQAAC3iICCIAAAAQiHCBi/AAIAAAAQi+AAiIiBg");
	var mask_1_graphics_389 = new cjs.Graphics().p("AlTFFQiNiGAAi/IAAAAQAAi+CNiHIAAAAQCNiGDGAAIAAAAQDHAACNCGIAAAAQCNCHAAC+IAAAAQAAC/iNCGIAAAAQiNCHjHAAIAAAAQjGAAiNiHg");
	var mask_1_graphics_390 = new cjs.Graphics().p("AlgFTQiTiNAAjGIAAAAQAAjFCTiNIAAAAQCSiMDOAAIAAAAQDPAACSCMIAAAAQCTCNAADFIAAAAQAADGiTCNIAAAAQiSCMjPAAIAAAAQjOAAiSiMg");
	var mask_1_graphics_391 = new cjs.Graphics().p("AluFgQiYiSAAjOIAAAAQAAjNCYiSIAAAAQCYiSDWAAIAAAAQDXAACYCSIAAAAQCYCSAADNIAAAAQAADOiYCSIAAAAQiYCSjXAAIAAAAQjWAAiYiSg");
	var mask_1_graphics_392 = new cjs.Graphics().p("Al9FtQieiXAAjWIAAAAQAAjVCeiYIAAAAQCfiXDeAAIAAAAQDfAACeCXIAAAAQCfCYAADVIAAAAQAADWifCXIAAAAQieCYjfAAIAAAAQjeAAifiYg");
	var mask_1_graphics_393 = new cjs.Graphics().p("AmLF7QikidAAjeIAAAAQAAjdCkidIAAAAQCkieDnAAIAAAAQDoAACkCeIAAAAQCkCdAADdIAAAAQAADeikCdIAAAAQikCejoAAIAAAAQjnAAikieg");
	var mask_1_graphics_394 = new cjs.Graphics().p("AmaGJQiqijAAjmIAAAAQAAjlCqikIAAAAQCqijDwAAIAAAAQDxAACqCjIAAAAQCqCkAADlIAAAAQAADmiqCjIAAAAQiqCkjxAAIAAAAQjwAAiqikg");
	var mask_1_graphics_395 = new cjs.Graphics().p("AmpGYQiwipAAjvIAAAAQAAjuCwipIAAAAQCxipD4AAIAAAAQD5AACxCpIAAAAQCwCpAADuIAAAAQAADviwCpIAAAAQixCpj5AAIAAAAQj4AAixipg");
	var mask_1_graphics_396 = new cjs.Graphics().p("Am4GmQi2ivAAj3IAAAAQAAj2C2ivIAAAAQC3ivEBAAIAAAAQECAAC3CvIAAAAQC2CvAAD2IAAAAQAAD3i2CvIAAAAQi3CvkCAAIAAAAQkBAAi3ivg");
	var mask_1_graphics_397 = new cjs.Graphics().p("AnHG0Qi8i0AAkAIAAAAQAAj/C8i1IAAAAQC9i0EKAAIAAAAQELAAC8C0IAAAAQC9C1AAD/IAAAAQAAEAi9C0IAAAAQi8C1kLAAIAAAAQkKAAi9i1g");
	var mask_1_graphics_398 = new cjs.Graphics().p("AnVHCQjDi6AAkIIAAAAQAAkHDDi6IAAAAQDDi7ESAAIAAAAQETAADDC7IAAAAQDDC6AAEHIAAAAQAAEIjDC6IAAAAQjDC7kTAAIAAAAQkSAAjDi7g");
	var mask_1_graphics_399 = new cjs.Graphics().p("AnjHQQjJjAAAkQIAAAAQAAkPDJjAIAAAAQDIjAEbAAIAAAAQEcAADIDAIAAAAQDJDAAAEPIAAAAQAAEQjJDAIAAAAQjIDAkcAAIAAAAQkbAAjIjAg");
	var mask_1_graphics_400 = new cjs.Graphics().p("AnxHdQjOjFAAkYIAAAAQAAkXDOjFIAAAAQDOjGEjAAIAAAAQEkAADODGIAAAAQDODFAAEXIAAAAQAAEYjODFIAAAAQjODGkkAAIAAAAQkjAAjOjGg");
	var mask_1_graphics_401 = new cjs.Graphics().p("An/HqQjUjLAAkfIAAAAQAAkeDUjLIAAAAQDUjLErAAIAAAAQEsAADUDLIAAAAQDUDLAAEeIAAAAQAAEfjUDLIAAAAQjUDLksAAIAAAAQkrAAjUjLg");
	var mask_1_graphics_402 = new cjs.Graphics().p("AoMH3QjZjQAAknIAAAAQAAkmDZjQIAAAAQDajQEyAAIAAAAQE0AADZDQIAAAAQDZDQAAEmIAAAAQAAEnjZDQIAAAAQjZDQk0AAIAAAAQkyAAjajQg");
	var mask_1_graphics_403 = new cjs.Graphics().p("AoZIDQjfjVAAkuIAAAAQAAktDfjWIAAAAQDfjVE6AAIAAAAQE7AADfDVIAAAAQDfDWAAEtIAAAAQAAEujfDVIAAAAQjfDWk7AAIAAAAQk6AAjfjWg");
	var mask_1_graphics_404 = new cjs.Graphics().p("AomIQQjkjbAAk1IAAAAQAAk0DkjbIAAAAQDkjaFCAAIAAAAQFDAADkDaIAAAAQDkDbAAE0IAAAAQAAE1jkDbIAAAAQjkDalDAAIAAAAQlCAAjkjag");
	var mask_1_graphics_405 = new cjs.Graphics().p("AoyIcQjqjgAAk8IAAAAQAAk7DqjgIAAAAQDpjfFJAAIAAAAQFKAADpDfIAAAAQDqDgAAE7IAAAAQAAE8jqDgIAAAAQjpDflKAAIAAAAQlJAAjpjfg");
	var mask_1_graphics_406 = new cjs.Graphics().p("Ao/InQjujkAAlDIAAAAQAAlCDujlIAAAAQDvjkFQAAIAAAAQFRAADuDkIAAAAQDvDlAAFCIAAAAQAAFDjvDkIAAAAQjuDllRAAIAAAAQlQAAjvjlg");
	var mask_1_graphics_407 = new cjs.Graphics().p("ApLIzQjzjpAAlKIAAAAQAAlJDzjpIAAAAQD0jpFXAAIAAAAQFYAADzDpIAAAAQD0DpAAFJIAAAAQAAFKj0DpIAAAAQjzDplYAAIAAAAQlXAAj0jpg");
	var mask_1_graphics_408 = new cjs.Graphics().p("ApWI+Qj4juAAlQIAAAAQAAlPD4juIAAAAQD4juFeAAIAAAAQFfAAD4DuIAAAAQD4DuAAFPIAAAAQAAFQj4DuIAAAAQj4DulfAAIAAAAQleAAj4jug");
	var mask_1_graphics_409 = new cjs.Graphics().p("ApiJJQj8jyAAlXIAAAAQAAlWD8jyIAAAAQD9jyFlAAIAAAAQFmAAD8DyIAAAAQD9DyAAFWIAAAAQAAFXj9DyIAAAAQj8DylmAAIAAAAQllAAj9jyg");
	var mask_1_graphics_410 = new cjs.Graphics().p("AptJTQkBj2AAldIAAAAQAAlcEBj3IAAAAQECj2FrAAIAAAAQFsAAEBD2IAAAAQECD3AAFcIAAAAQAAFdkCD2IAAAAQkBD3lsAAIAAAAQlrAAkCj3g");
	var mask_1_graphics_411 = new cjs.Graphics().p("Ap4JeQkFj7AAljIAAAAQAAliEFj7IAAAAQEHj7FxAAIAAAAQFyAAEGD7IAAAAQEGD7AAFiIAAAAQAAFjkGD7IAAAAQkGD7lyAAIAAAAQlxAAkHj7g");
	var mask_1_graphics_412 = new cjs.Graphics().p("AqCJoQkKj/AAlpIAAAAQAAloEKj/IAAAAQEKj/F4AAIAAAAQF5AAEKD/IAAAAQEKD/AAFoIAAAAQAAFpkKD/IAAAAQkKD/l5AAIAAAAQl4AAkKj/g");
	var mask_1_graphics_413 = new cjs.Graphics().p("AqMJyQkPkDAAlvIAAAAQAAluEPkDIAAAAQEOkDF+AAIAAAAQF/AAEOEDIAAAAQEPEDAAFuIAAAAQAAFvkPEDIAAAAQkOEDl/AAIAAAAQl+AAkOkDg");
	var mask_1_graphics_414 = new cjs.Graphics().p("AqWJ7QkTkHAAl0IAAAAQAAlzETkIIAAAAQETkHGDAAIAAAAQGEAAETEHIAAAAQETEIAAFzIAAAAQAAF0kTEHIAAAAQkTEImEAAIAAAAQmDAAkTkIg");
	var mask_1_graphics_415 = new cjs.Graphics().p("AqgKFQkXkLAAl6IAAAAQAAl5EXkLIAAAAQEXkLGJAAIAAAAQGKAAEXELIAAAAQEXELAAF5IAAAAQAAF6kXELIAAAAQkXELmKAAIAAAAQmJAAkXkLg");
	var mask_1_graphics_416 = new cjs.Graphics().p("AqpKOQkbkPAAl/IAAAAQAAl+EbkPIAAAAQEakPGPAAIAAAAQGQAAEaEPIAAAAQEbEPAAF+IAAAAQAAF/kbEPIAAAAQkaEPmQAAIAAAAQmPAAkakPg");
	var mask_1_graphics_417 = new cjs.Graphics().p("AqzKWQkekSAAmEIAAAAQAAmDEekTIAAAAQEfkSGUAAIAAAAQGVAAEeESIAAAAQEfETAAGDIAAAAQAAGEkfESIAAAAQkeETmVAAIAAAAQmUAAkfkTg");
	var mask_1_graphics_418 = new cjs.Graphics().p("Aq7KfQkikWAAmJIAAAAQAAmIEikWIAAAAQEikWGZAAIAAAAQGaAAEiEWIAAAAQEiEWAAGIIAAAAQAAGJkiEWIAAAAQkiEWmaAAIAAAAQmZAAkikWg");
	var mask_1_graphics_419 = new cjs.Graphics().p("ArEKnQklkZAAmOIAAAAQAAmNElkZIAAAAQEmkaGeAAIAAAAQGfAAEmEaIAAAAQElEZAAGNIAAAAQAAGOklEZIAAAAQkmEamfAAIAAAAQmeAAkmkag");
	var mask_1_graphics_420 = new cjs.Graphics().p("ArMKvQkpkdAAmSIAAAAQAAmREpkdIAAAAQEpkdGjAAIAAAAQGkAAEpEdIAAAAQEpEdAAGRIAAAAQAAGSkpEdIAAAAQkpEdmkAAIAAAAQmjAAkpkdg");
	var mask_1_graphics_421 = new cjs.Graphics().p("ArUK3QkskgAAmXIAAAAQAAmWEskgIAAAAQEskgGoAAIAAAAQGpAAEsEgIAAAAQEsEgAAGWIAAAAQAAGXksEgIAAAAQksEgmpAAIAAAAQmoAAkskgg");
	var mask_1_graphics_422 = new cjs.Graphics().p("ArcK+QkvkjAAmbIAAAAQAAmaEvkjIAAAAQEwkjGsAAIAAAAQGtAAEwEjIAAAAQEvEjAAGaIAAAAQAAGbkvEjIAAAAQkwEjmtAAIAAAAQmsAAkwkjg");
	var mask_1_graphics_423 = new cjs.Graphics().p("ArjLFQkzkmAAmfIAAAAQAAmeEzkmIAAAAQEykmGxAAIAAAAQGyAAEyEmIAAAAQEzEmAAGeIAAAAQAAGfkzEmIAAAAQkyEmmyAAIAAAAQmxAAkykmg");
	var mask_1_graphics_424 = new cjs.Graphics().p("ArrLMQk1kpAAmjIAAAAQAAmiE1kpIAAAAQE2kpG1AAIAAAAQG2AAE1EpIAAAAQE2EpAAGiIAAAAQAAGjk2EpIAAAAQk1Epm2AAIAAAAQm1AAk2kpg");
	var mask_1_graphics_425 = new cjs.Graphics().p("ArxLTQk5ksAAmnIAAAAQAAmmE5ksIAAAAQE4krG5AAIAAAAQG6AAE4ErIAAAAQE5EsAAGmIAAAAQAAGnk5EsIAAAAQk4Erm6AAIAAAAQm5AAk4krg");
	var mask_1_graphics_426 = new cjs.Graphics().p("Ar4LZQk7kuAAmrIAAAAQAAmqE7kuIAAAAQE7kuG9AAIAAAAQG+AAE7EuIAAAAQE7EuAAGqIAAAAQAAGrk7EuIAAAAQk7Eum+AAIAAAAQm9AAk7kug");
	var mask_1_graphics_427 = new cjs.Graphics().p("Ar+LfQk+kwAAmvIAAAAQAAmuE+kwIAAAAQE+kxHAAAIAAAAQHBAAE+ExIAAAAQE+EwAAGuIAAAAQAAGvk+EwIAAAAQk+ExnBAAIAAAAQnAAAk+kxg");
	var mask_1_graphics_428 = new cjs.Graphics().p("AsELlQlBkzAAmyIAAAAQAAmxFBkzIAAAAQFAkzHEAAIAAAAQHFAAFAEzIAAAAQFBEzAAGxIAAAAQAAGylBEzIAAAAQlAEznFAAIAAAAQnEAAlAkzg");
	var mask_1_graphics_429 = new cjs.Graphics().p("AsKLqQlDk1AAm1IAAAAQAAm0FDk2IAAAAQFDk1HHAAIAAAAQHIAAFDE1IAAAAQFDE2AAG0IAAAAQAAG1lDE1IAAAAQlDE2nIAAIAAAAQnHAAlDk2g");
	var mask_1_graphics_430 = new cjs.Graphics().p("AsQLvQlEk3AAm4IAAAAQAAm3FEk4IAAAAQFGk3HKAAIAAAAQHLAAFFE3IAAAAQFFE4AAG3IAAAAQAAG4lFE3IAAAAQlFE4nLAAIAAAAQnKAAlGk4g");
	var mask_1_graphics_431 = new cjs.Graphics().p("AsVL0QlHk5AAm7IAAAAQAAm6FHk6IAAAAQFHk5HOAAIAAAAQHPAAFGE5IAAAAQFIE6AAG6IAAAAQAAG7lIE5IAAAAQlGE6nPAAIAAAAQnOAAlHk6g");
	var mask_1_graphics_432 = new cjs.Graphics().p("AsaL5QlJk7AAm+IAAAAQAAm9FJk8IAAAAQFKk7HQAAIAAAAQHRAAFJE7IAAAAQFKE8AAG9IAAAAQAAG+lKE7IAAAAQlJE8nRAAIAAAAQnQAAlKk8g");
	var mask_1_graphics_433 = new cjs.Graphics().p("AseL+QlLk9AAnBIAAAAQAAnAFLk9IAAAAQFLk9HTAAIAAAAQHUAAFLE9IAAAAQFLE9AAHAIAAAAQAAHBlLE9IAAAAQlLE9nUAAIAAAAQnTAAlLk9g");
	var mask_1_graphics_434 = new cjs.Graphics().p("AsjMCQlMk/AAnDIAAAAQAAnCFMk/IAAAAQFNk/HWAAIAAAAQHXAAFME/IAAAAQFNE/AAHCIAAAAQAAHDlNE/IAAAAQlME/nXAAIAAAAQnWAAlNk/g");
	var mask_1_graphics_435 = new cjs.Graphics().p("AsnMGQlOlBAAnFIAAAAQAAnEFOlBIAAAAQFPlAHYAAIAAAAQHZAAFOFAIAAAAQFPFBAAHEIAAAAQAAHFlPFBIAAAAQlOFAnZAAIAAAAQnYAAlPlAg");
	var mask_1_graphics_436 = new cjs.Graphics().p("AsrMJQlQlCAAnHIAAAAQAAnGFQlDIAAAAQFRlCHaAAIAAAAQHbAAFQFCIAAAAQFRFDAAHGIAAAAQAAHHlRFCIAAAAQlQFDnbAAIAAAAQnaAAlRlDg");
	var mask_1_graphics_437 = new cjs.Graphics().p("AsuMNQlSlEAAnJIAAAAQAAnIFSlEIAAAAQFSlDHcAAIAAAAQHdAAFSFDIAAAAQFSFEAAHIIAAAAQAAHJlSFEIAAAAQlSFDndAAIAAAAQncAAlSlDg");
	var mask_1_graphics_438 = new cjs.Graphics().p("AsxMQQlTlFAAnLIAAAAQAAnKFTlFIAAAAQFTlFHeAAIAAAAQHfAAFTFFIAAAAQFTFFAAHKIAAAAQAAHLlTFFIAAAAQlTFFnfAAIAAAAQneAAlTlFg");
	var mask_1_graphics_439 = new cjs.Graphics().p("As0MTQlUlGAAnNIAAAAQAAnMFUlGIAAAAQFUlGHgAAIAAAAQHhAAFUFGIAAAAQFUFGAAHMIAAAAQAAHNlUFGIAAAAQlUFGnhAAIAAAAQngAAlUlGg");
	var mask_1_graphics_440 = new cjs.Graphics().p("As3MVQlVlHAAnOIAAAAQAAnNFVlIIAAAAQFVlGHiAAIAAAAQHjAAFVFGIAAAAQFVFIAAHNIAAAAQAAHOlVFHIAAAAQlVFHnjAAIAAAAQniAAlVlHg");
	var mask_1_graphics_441 = new cjs.Graphics().p("As5MXQlWlHAAnQIAAAAQAAnPFWlIIAAAAQFWlIHjAAIAAAAQHkAAFWFIIAAAAQFWFIAAHPIAAAAQAAHQlWFHIAAAAQlWFJnkAAIAAAAQnjAAlWlJg");
	var mask_1_graphics_442 = new cjs.Graphics().p("As7MZQlXlIAAnRIAAAAQAAnQFXlJIAAAAQFXlIHkAAIAAAAQHlAAFXFIIAAAAQFXFJAAHQIAAAAQAAHRlXFIIAAAAQlXFJnlAAIAAAAQnkAAlXlJg");
	var mask_1_graphics_443 = new cjs.Graphics().p("As9MbQlYlJAAnSIAAAAQAAnRFYlKIAAAAQFYlJHlAAIAAAAQHmAAFYFJIAAAAQFYFKAAHRIAAAAQAAHSlYFJIAAAAQlYFKnmAAIAAAAQnlAAlYlKg");
	var mask_1_graphics_444 = new cjs.Graphics().p("As/MdQlYlKAAnTIAAAAQAAnSFYlKIAAAAQFZlKHmAAIAAAAQHnAAFYFKIAAAAQFZFKAAHSIAAAAQAAHTlZFKIAAAAQlYFKnnAAIAAAAQnmAAlZlKg");
	var mask_1_graphics_445 = new cjs.Graphics().p("AtAMeQlZlLAAnTIAAAAQAAnSFZlLIAAAAQFZlLHnAAIAAAAQHoAAFZFLIAAAAQFZFLAAHSIAAAAQAAHTlZFLIAAAAQlZFLnoAAIAAAAQnnAAlZlLg");
	var mask_1_graphics_446 = new cjs.Graphics().p("AtBMfQlZlLAAnUIAAAAQAAnTFZlLIAAAAQFalLHnAAIAAAAQHoAAFaFLIAAAAQFZFLAAHTIAAAAQAAHUlZFLIAAAAQlaFLnoAAIAAAAQnnAAlalLg");
	var mask_1_graphics_447 = new cjs.Graphics().p("AtCMgQlZlMAAnUIAAAAQAAnTFZlMIAAAAQFalLHoAAIAAAAQHpAAFZFLIAAAAQFaFMAAHTIAAAAQAAHUlaFMIAAAAQlZFLnpAAIAAAAQnoAAlalLg");
	var mask_1_graphics_448 = new cjs.Graphics().p("AtCMgQlalLAAnVIAAAAQAAnUFalLIAAAAQFalMHoAAIAAAAQHpAAFaFMIAAAAQFaFLAAHUIAAAAQAAHVlaFLIAAAAQlaFMnpAAIAAAAQnoAAlalMg");
	var mask_1_graphics_449 = new cjs.Graphics().p("AtCMgQlalLAAnVIAAAAQAAnUFalLIAAAAQFalMHoAAIAAAAQHpAAFaFMIAAAAQFaFLAAHUIAAAAQAAHVlaFLIAAAAQlaFMnpAAIAAAAQnoAAlalMg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(341).to({graphics:mask_1_graphics_341,x:210.2004,y:175.8001}).wait(1).to({graphics:mask_1_graphics_342,x:210.2004,y:175.8001}).wait(1).to({graphics:mask_1_graphics_343,x:210.2004,y:175.8006}).wait(1).to({graphics:mask_1_graphics_344,x:210.2004,y:175.8001}).wait(1).to({graphics:mask_1_graphics_345,x:210.2004,y:175.8006}).wait(1).to({graphics:mask_1_graphics_346,x:210.2009,y:175.8006}).wait(1).to({graphics:mask_1_graphics_347,x:210.2008,y:175.801}).wait(1).to({graphics:mask_1_graphics_348,x:210.2017,y:175.8019}).wait(1).to({graphics:mask_1_graphics_349,x:210.2017,y:175.8019}).wait(1).to({graphics:mask_1_graphics_350,x:210.2027,y:175.8024}).wait(1).to({graphics:mask_1_graphics_351,x:210.2031,y:175.8033}).wait(1).to({graphics:mask_1_graphics_352,x:210.2035,y:175.8042}).wait(1).to({graphics:mask_1_graphics_353,x:210.2044,y:175.8051}).wait(1).to({graphics:mask_1_graphics_354,x:210.2049,y:175.8055}).wait(1).to({graphics:mask_1_graphics_355,x:210.2058,y:175.8064}).wait(1).to({graphics:mask_1_graphics_356,x:210.2067,y:175.8074}).wait(1).to({graphics:mask_1_graphics_357,x:210.2076,y:175.8087}).wait(1).to({graphics:mask_1_graphics_358,x:210.2085,y:175.8096}).wait(1).to({graphics:mask_1_graphics_359,x:210.2089,y:175.8109}).wait(1).to({graphics:mask_1_graphics_360,x:210.2103,y:175.8123}).wait(1).to({graphics:mask_1_graphics_361,x:210.2112,y:175.8137}).wait(1).to({graphics:mask_1_graphics_362,x:210.2121,y:175.8145}).wait(1).to({graphics:mask_1_graphics_363,x:210.2139,y:175.8163}).wait(1).to({graphics:mask_1_graphics_364,x:210.2148,y:175.8177}).wait(1).to({graphics:mask_1_graphics_365,x:210.2161,y:175.819}).wait(1).to({graphics:mask_1_graphics_366,x:210.2175,y:175.8208}).wait(1).to({graphics:mask_1_graphics_367,x:210.2188,y:175.8222}).wait(1).to({graphics:mask_1_graphics_368,x:210.2202,y:175.8244}).wait(1).to({graphics:mask_1_graphics_369,x:210.222,y:175.8262}).wait(1).to({graphics:mask_1_graphics_370,x:210.2233,y:175.828}).wait(1).to({graphics:mask_1_graphics_371,x:210.2251,y:175.8298}).wait(1).to({graphics:mask_1_graphics_372,x:210.227,y:175.8321}).wait(1).to({graphics:mask_1_graphics_373,x:210.2287,y:175.8339}).wait(1).to({graphics:mask_1_graphics_374,x:210.2305,y:175.8361}).wait(1).to({graphics:mask_1_graphics_375,x:210.2319,y:175.8384}).wait(1).to({graphics:mask_1_graphics_376,x:210.2341,y:175.8406}).wait(1).to({graphics:mask_1_graphics_377,x:210.2359,y:175.8429}).wait(1).to({graphics:mask_1_graphics_378,x:210.2382,y:175.8456}).wait(1).to({graphics:mask_1_graphics_379,x:210.24,y:175.8483}).wait(1).to({graphics:mask_1_graphics_380,x:210.2427,y:175.8505}).wait(1).to({graphics:mask_1_graphics_381,x:210.2445,y:175.8532}).wait(1).to({graphics:mask_1_graphics_382,x:210.2467,y:175.8555}).wait(1).to({graphics:mask_1_graphics_383,x:210.249,y:175.8586}).wait(1).to({graphics:mask_1_graphics_384,x:210.2512,y:175.8618}).wait(1).to({graphics:mask_1_graphics_385,x:210.2539,y:175.864}).wait(1).to({graphics:mask_1_graphics_386,x:210.2562,y:175.8672}).wait(1).to({graphics:mask_1_graphics_387,x:210.2589,y:175.8703}).wait(1).to({graphics:mask_1_graphics_388,x:210.2611,y:175.873}).wait(1).to({graphics:mask_1_graphics_389,x:210.2638,y:175.8766}).wait(1).to({graphics:mask_1_graphics_390,x:210.2665,y:175.8798}).wait(1).to({graphics:mask_1_graphics_391,x:210.2692,y:175.8829}).wait(1).to({graphics:mask_1_graphics_392,x:210.2724,y:175.8865}).wait(1).to({graphics:mask_1_graphics_393,x:210.2751,y:175.8901}).wait(1).to({graphics:mask_1_graphics_394,x:210.2782,y:175.8928}).wait(1).to({graphics:mask_1_graphics_395,x:210.2809,y:175.8969}).wait(1).to({graphics:mask_1_graphics_396,x:210.2836,y:175.9005}).wait(1).to({graphics:mask_1_graphics_397,x:210.2868,y:175.9041}).wait(1).to({graphics:mask_1_graphics_398,x:210.2899,y:175.9073}).wait(1).to({graphics:mask_1_graphics_399,x:210.2922,y:175.9109}).wait(1).to({graphics:mask_1_graphics_400,x:210.2953,y:175.9135}).wait(1).to({graphics:mask_1_graphics_401,x:210.2976,y:175.9171}).wait(1).to({graphics:mask_1_graphics_402,x:210.3003,y:175.9203}).wait(1).to({graphics:mask_1_graphics_403,x:210.303,y:175.9235}).wait(1).to({graphics:mask_1_graphics_404,x:210.3057,y:175.9262}).wait(1).to({graphics:mask_1_graphics_405,x:210.3084,y:175.9293}).wait(1).to({graphics:mask_1_graphics_406,x:210.3102,y:175.9324}).wait(1).to({graphics:mask_1_graphics_407,x:210.3124,y:175.9352}).wait(1).to({graphics:mask_1_graphics_408,x:210.3151,y:175.9379}).wait(1).to({graphics:mask_1_graphics_409,x:210.3174,y:175.9405}).wait(1).to({graphics:mask_1_graphics_410,x:210.3196,y:175.9432}).wait(1).to({graphics:mask_1_graphics_411,x:210.3214,y:175.9459}).wait(1).to({graphics:mask_1_graphics_412,x:210.3237,y:175.9482}).wait(1).to({graphics:mask_1_graphics_413,x:210.3255,y:175.9504}).wait(1).to({graphics:mask_1_graphics_414,x:210.3278,y:175.9527}).wait(1).to({graphics:mask_1_graphics_415,x:210.3295,y:175.9549}).wait(1).to({graphics:mask_1_graphics_416,x:210.3313,y:175.9576}).wait(1).to({graphics:mask_1_graphics_417,x:210.3336,y:175.9594}).wait(1).to({graphics:mask_1_graphics_418,x:210.3349,y:175.9617}).wait(1).to({graphics:mask_1_graphics_419,x:210.3367,y:175.9639}).wait(1).to({graphics:mask_1_graphics_420,x:210.3381,y:175.9658}).wait(1).to({graphics:mask_1_graphics_421,x:210.3399,y:175.9671}).wait(1).to({graphics:mask_1_graphics_422,x:210.3412,y:175.9693}).wait(1).to({graphics:mask_1_graphics_423,x:210.3426,y:175.9711}).wait(1).to({graphics:mask_1_graphics_424,x:210.3444,y:175.9729}).wait(1).to({graphics:mask_1_graphics_425,x:210.3457,y:175.9743}).wait(1).to({graphics:mask_1_graphics_426,x:210.3466,y:175.9756}).wait(1).to({graphics:mask_1_graphics_427,x:210.3485,y:175.9774}).wait(1).to({graphics:mask_1_graphics_428,x:210.3493,y:175.9788}).wait(1).to({graphics:mask_1_graphics_429,x:210.3507,y:175.9806}).wait(1).to({graphics:mask_1_graphics_430,x:210.3516,y:175.9815}).wait(1).to({graphics:mask_1_graphics_431,x:210.3525,y:175.9828}).wait(1).to({graphics:mask_1_graphics_432,x:210.3538,y:175.9842}).wait(1).to({graphics:mask_1_graphics_433,x:210.3547,y:175.9851}).wait(1).to({graphics:mask_1_graphics_434,x:210.3556,y:175.986}).wait(1).to({graphics:mask_1_graphics_435,x:210.3566,y:175.9869}).wait(1).to({graphics:mask_1_graphics_436,x:210.357,y:175.9878}).wait(1).to({graphics:mask_1_graphics_437,x:210.3579,y:175.9887}).wait(1).to({graphics:mask_1_graphics_438,x:210.3584,y:175.9896}).wait(1).to({graphics:mask_1_graphics_439,x:210.3588,y:175.9905}).wait(1).to({graphics:mask_1_graphics_440,x:210.3597,y:175.9909}).wait(1).to({graphics:mask_1_graphics_441,x:210.3597,y:175.9914}).wait(1).to({graphics:mask_1_graphics_442,x:210.3606,y:175.9918}).wait(1).to({graphics:mask_1_graphics_443,x:210.3606,y:175.9923}).wait(1).to({graphics:mask_1_graphics_444,x:210.361,y:175.9927}).wait(1).to({graphics:mask_1_graphics_445,x:210.361,y:175.9932}).wait(1).to({graphics:mask_1_graphics_446,x:210.3615,y:175.9932}).wait(1).to({graphics:mask_1_graphics_447,x:210.3615,y:175.9937}).wait(1).to({graphics:mask_1_graphics_448,x:210.3615,y:175.9932}).wait(1).to({graphics:mask_1_graphics_449,x:210.3615,y:175.9559}).wait(361));

	// Layer_37
	this.instance_2 = new lib.Tween73("synched",0);
	this.instance_2.setTransform(245.55,138.3);
	this.instance_2.alpha = 0.5;
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween74("synched",0);
	this.instance_3.setTransform(245.55,138.3);

	var maskedShapeInstanceList = [this.instance_2,this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2}]},341).to({state:[{t:this.instance_3}]},108).wait(361));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(341).to({_off:false},0).to({_off:true,alpha:1},108).wait(361));

	// Layer_8
	this.instance_4 = new lib.Tween18("synched",2);
	this.instance_4.setTransform(884,494.7,0.4746,0.4746,0,0,0,472.3,518.1);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(392).to({_off:false},0).wait(418));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_347 = new cjs.Graphics().p("AgLAMQgFgFAAgHIAAAAQAAgGAFgFIAAAAQAFgFAGAAIAAAAQAHAAAFAFIAAAAQAFAFAAAGIAAAAQAAAHgFAFIAAAAQgFAFgHAAIAAAAQgGAAgFgFg");
	var mask_2_graphics_348 = new cjs.Graphics().p("AgMAMQgFgFAAgHIAAAAQAAgGAFgFIAAAAQAGgFAGAAIAAAAQAHAAAGAFIAAAAQAFAFAAAGIAAAAQAAAHgFAFIAAAAQgGAFgHAAIAAAAQgGAAgGgFg");
	var mask_2_graphics_349 = new cjs.Graphics().p("AgMANQgGgFAAgIIAAAAQAAgHAGgFIAAAAQAFgFAHAAIAAAAQAIAAAFAFIAAAAQAGAFAAAHIAAAAQAAAIgGAFIAAAAQgFAFgIAAIAAAAQgHAAgFgFg");
	var mask_2_graphics_350 = new cjs.Graphics().p("AgOAOQgGgGAAgIIAAAAQAAgHAGgGIAAAAQAGgGAIAAIAAAAQAJAAAGAGIAAAAQAGAGAAAHIAAAAQAAAIgGAGIAAAAQgGAGgJAAIAAAAQgIAAgGgGg");
	var mask_2_graphics_351 = new cjs.Graphics().p("AgQAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAHgHAJAAIAAAAQAKAAAHAHIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgHAHgKAAIAAAAQgJAAgHgHg");
	var mask_2_graphics_352 = new cjs.Graphics().p("AgSASQgIgHAAgLIAAAAQAAgKAIgHIAAAAQAIgIAKAAIAAAAQALAAAIAIIAAAAQAIAHAAAKIAAAAQAAALgIAHIAAAAQgIAIgLAAIAAAAQgKAAgIgIg");
	var mask_2_graphics_353 = new cjs.Graphics().p("AgVAVQgJgJAAgMIAAAAQAAgLAJgJIAAAAQAJgJAMAAIAAAAQANAAAJAJIAAAAQAJAJAAALIAAAAQAAAMgJAJIAAAAQgJAJgNAAIAAAAQgMAAgJgJg");
	var mask_2_graphics_354 = new cjs.Graphics().p("AgZAZQgKgLAAgOIAAAAQAAgNAKgLIAAAAQALgKAOAAIAAAAQAPAAALAKIAAAAQAKALAAANIAAAAQAAAOgKALIAAAAQgLAKgPAAIAAAAQgOAAgLgKg");
	var mask_2_graphics_355 = new cjs.Graphics().p("AgdAdQgMgMAAgRIAAAAQAAgQAMgMIAAAAQANgLAQAAIAAAAQARAAANALIAAAAQAMAMAAAQIAAAAQAAARgMAMIAAAAQgNALgRAAIAAAAQgQAAgNgLg");
	var mask_2_graphics_356 = new cjs.Graphics().p("AghAhQgPgOAAgTIAAAAQAAgSAPgOIAAAAQAOgOATAAIAAAAQAUAAAOAOIAAAAQAPAOAAASIAAAAQAAATgPAOIAAAAQgOAOgUAAIAAAAQgTAAgOgOg");
	var mask_2_graphics_357 = new cjs.Graphics().p("AgnAmQgQgQAAgWIAAAAQAAgVAQgQIAAAAQARgQAWAAIAAAAQAXAAARAQIAAAAQAQAQAAAVIAAAAQAAAWgQAQIAAAAQgRAQgXAAIAAAAQgWAAgRgQg");
	var mask_2_graphics_358 = new cjs.Graphics().p("AgsArQgTgSAAgZIAAAAQAAgYATgSIAAAAQASgSAaAAIAAAAQAbAAASASIAAAAQATASAAAYIAAAAQAAAZgTASIAAAAQgSASgbAAIAAAAQgaAAgSgSg");
	var mask_2_graphics_359 = new cjs.Graphics().p("AgzAxQgVgUAAgdIAAAAQAAgcAVgUIAAAAQAWgVAdAAIAAAAQAeAAAWAVIAAAAQAVAUAAAcIAAAAQAAAdgVAUIAAAAQgWAVgeAAIAAAAQgdAAgWgVg");
	var mask_2_graphics_360 = new cjs.Graphics().p("Ag5A4QgZgXAAghIAAAAQAAggAZgXIAAAAQAYgXAhAAIAAAAQAiAAAYAXIAAAAQAZAXAAAgIAAAAQAAAhgZAXIAAAAQgYAXgiAAIAAAAQghAAgYgXg");
	var mask_2_graphics_361 = new cjs.Graphics().p("AhBA/QgbgaAAglIAAAAQAAgkAbgaIAAAAQAcgaAlAAIAAAAQAmAAAcAaIAAAAQAbAaAAAkIAAAAQAAAlgbAaIAAAAQgcAagmAAIAAAAQglAAgcgag");
	var mask_2_graphics_362 = new cjs.Graphics().p("AhJBHQgegeAAgpIAAAAQAAgoAegeIAAAAQAfgdAqAAIAAAAQArAAAfAdIAAAAQAeAeAAAoIAAAAQAAApgeAeIAAAAQgfAdgrAAIAAAAQgqAAgfgdg");
	var mask_2_graphics_363 = new cjs.Graphics().p("AhRBPQgighAAguIAAAAQAAgtAighIAAAAQAiggAvAAIAAAAQAwAAAiAgIAAAAQAiAhAAAtIAAAAQAAAugiAhIAAAAQgiAggwAAIAAAAQgvAAgiggg");
	var mask_2_graphics_364 = new cjs.Graphics().p("AhaBXQgmgkAAgzIAAAAQAAgyAmgkIAAAAQAmgkA0AAIAAAAQA1AAAmAkIAAAAQAmAkAAAyIAAAAQAAAzgmAkIAAAAQgmAkg1AAIAAAAQg0AAgmgkg");
	var mask_2_graphics_365 = new cjs.Graphics().p("AhkBgQgpgoAAg4IAAAAQAAg3ApgoIAAAAQAqgoA6AAIAAAAQA7AAAqAoIAAAAQApAoAAA3IAAAAQAAA4gpAoIAAAAQgqAog7AAIAAAAQg6AAgqgog");
	var mask_2_graphics_366 = new cjs.Graphics().p("AhuBqQgtgsAAg+IAAAAQAAg9AtgsIAAAAQAugsBAAAIAAAAQBBAAAuAsIAAAAQAtAsAAA9IAAAAQAAA+gtAsIAAAAQguAshBAAIAAAAQhAAAgugsg");
	var mask_2_graphics_367 = new cjs.Graphics().p("Ah4B0QgzgwABhEIAAAAQgBhDAzgwIAAAAQAygwBGAAIAAAAQBHAAAyAwIAAAAQAzAwgBBDIAAAAQABBEgzAwIAAAAQgyAwhHAAIAAAAQhGAAgygwg");
	var mask_2_graphics_368 = new cjs.Graphics().p("AiDB/Qg3g1AAhKIAAAAQAAhJA3g1IAAAAQA2g0BNAAIAAAAQBOAAA2A0IAAAAQA3A1AABJIAAAAQAABKg3A1IAAAAQg2A0hOAAIAAAAQhNAAg2g0g");
	var mask_2_graphics_369 = new cjs.Graphics().p("AiPCKQg8g5AAhRIAAAAQAAhQA8g5IAAAAQA8g5BTAAIAAAAQBUAAA8A5IAAAAQA8A5AABQIAAAAQAABRg8A5IAAAAQg8A5hUAAIAAAAQhTAAg8g5g");
	var mask_2_graphics_370 = new cjs.Graphics().p("AibCWQhBg+AAhYIAAAAQAAhXBBg+IAAAAQBAg+BbAAIAAAAQBcAABAA+IAAAAQBBA+AABXIAAAAQAABYhBA+IAAAAQhAA+hcAAIAAAAQhbAAhAg+g");
	var mask_2_graphics_371 = new cjs.Graphics().p("AioCiQhGhDAAhfIAAAAQAAheBGhDIAAAAQBGhDBiAAIAAAAQBjAABGBDIAAAAQBGBDAABeIAAAAQAABfhGBDIAAAAQhGBDhjAAIAAAAQhiAAhGhDg");
	var mask_2_graphics_372 = new cjs.Graphics().p("Ai2CvQhLhJAAhmIAAAAQAAhlBLhJIAAAAQBMhIBqAAIAAAAQBrAABLBIIAAAAQBMBJAABlIAAAAQAABmhMBJIAAAAQhLBIhrAAIAAAAQhqAAhMhIg");
	var mask_2_graphics_373 = new cjs.Graphics().p("AjDC8QhShOAAhuIAAAAQAAhtBShOIAAAAQBRhOByAAIAAAAQBzAABRBOIAAAAQBSBOAABtIAAAAQAABuhSBOIAAAAQhRBOhzAAIAAAAQhyAAhRhOg");
	var mask_2_graphics_374 = new cjs.Graphics().p("AjSDKQhXhUAAh2IAAAAQAAh1BXhUIAAAAQBXhUB7AAIAAAAQB7AABYBUIAAAAQBXBUAAB1IAAAAQAAB2hXBUIAAAAQhYBUh7AAIAAAAQh7AAhXhUg");
	var mask_2_graphics_375 = new cjs.Graphics().p("AjhDYQhdhZAAh/IAAAAQAAh+BdhZIAAAAQBehaCDAAIAAAAQCEAABeBaIAAAAQBdBZAAB+IAAAAQAAB/hdBZIAAAAQheBaiEAAIAAAAQiDAAhehag");
	var mask_2_graphics_376 = new cjs.Graphics().p("AjwDnQhkhgAAiHIAAAAQAAiGBkhgIAAAAQBkhgCMAAIAAAAQCNAABkBgIAAAAQBkBgAACGIAAAAQAACHhkBgIAAAAQhkBgiNAAIAAAAQiMAAhkhgg");
	var mask_2_graphics_377 = new cjs.Graphics().p("AkAD3QhrhnAAiQIAAAAQAAiPBrhnIAAAAQBqhmCWAAIAAAAQCXAABqBmIAAAAQBrBnAACPIAAAAQAACQhrBnIAAAAQhqBmiXAAIAAAAQiWAAhqhmg");
	var mask_2_graphics_378 = new cjs.Graphics().p("AkREGQhyhsAAiaIAAAAQAAiZByhtIAAAAQByhsCfAAIAAAAQCgAAByBsIAAAAQByBtAACZIAAAAQAACahyBsIAAAAQhyBtigAAIAAAAQifAAhyhtg");
	var mask_2_graphics_379 = new cjs.Graphics().p("AkiEXQh5h0AAijIAAAAQAAiiB5h0IAAAAQB4h0CqAAIAAAAQCrAAB4B0IAAAAQB5B0AACiIAAAAQAACjh5B0IAAAAQh4B0irAAIAAAAQiqAAh4h0g");
	var mask_2_graphics_380 = new cjs.Graphics().p("Ak0EoQiAh7AAitIAAAAQAAisCAh7IAAAAQCAh7C0AAIAAAAQC1AACAB7IAAAAQCAB7AACsIAAAAQAACtiAB7IAAAAQiAB7i1AAIAAAAQi0AAiAh7g");
	var mask_2_graphics_381 = new cjs.Graphics().p("AlGE5QiIiBAAi4IAAAAQAAi3CIiBIAAAAQCHiCC/AAIAAAAQDAAACHCCIAAAAQCICBAAC3IAAAAQAAC4iICBIAAAAQiHCCjAAAIAAAAQi/AAiHiCg");
	var mask_2_graphics_382 = new cjs.Graphics().p("AlZFLQiPiJAAjCIAAAAQAAjBCPiKIAAAAQCPiJDKAAIAAAAQDLAACPCJIAAAAQCPCKAADBIAAAAQAADCiPCJIAAAAQiPCKjLAAIAAAAQjKAAiPiKg");
	var mask_2_graphics_383 = new cjs.Graphics().p("AlsFeQiYiRAAjNIAAAAQAAjMCYiRIAAAAQCXiRDVAAIAAAAQDWAACXCRIAAAAQCYCRAADMIAAAAQAADNiYCRIAAAAQiXCRjWAAIAAAAQjVAAiXiRg");
	var mask_2_graphics_384 = new cjs.Graphics().p("AmAFxQigiZAAjYIAAAAQAAjXCgiZIAAAAQCfiZDhAAIAAAAQDiAACfCZIAAAAQCgCZAADXIAAAAQAADYigCZIAAAAQifCZjiAAIAAAAQjhAAifiZg");
	var mask_2_graphics_385 = new cjs.Graphics().p("AmVGEQioigAAjkIAAAAQAAjjCoihIAAAAQCoihDtAAIAAAAQDuAACnChIAAAAQCpChAADjIAAAAQAADkipCgIAAAAQinCijuAAIAAAAQjtAAioiig");
	var mask_2_graphics_386 = new cjs.Graphics().p("AmqGZQiwiqAAjvIAAAAQAAjuCwiqIAAAAQCxipD5AAIAAAAQD6AACwCpIAAAAQCxCqAADuIAAAAQAADvixCqIAAAAQiwCpj6AAIAAAAQj5AAixipg");
	var mask_2_graphics_387 = new cjs.Graphics().p("Am/GtQi5iyAAj7IAAAAQAAj6C5iyIAAAAQC6ixEFAAIAAAAQEGAAC5CxIAAAAQC6CyAAD6IAAAAQAAD7i6CyIAAAAQi5CxkGAAIAAAAQkFAAi6ixg");
	var mask_2_graphics_388 = new cjs.Graphics().p("AnTHAQjCi5AAkHIAAAAQAAkGDCi5IAAAAQDCi6ERAAIAAAAQESAADCC6IAAAAQDCC5AAEGIAAAAQAAEHjCC5IAAAAQjCC6kSAAIAAAAQkRAAjCi6g");
	var mask_2_graphics_389 = new cjs.Graphics().p("AnnHTQjKjBAAkSIAAAAQAAkRDKjBIAAAAQDKjCEdAAIAAAAQEeAADKDCIAAAAQDKDBAAERIAAAAQAAESjKDBIAAAAQjKDCkeAAIAAAAQkdAAjKjCg");
	var mask_2_graphics_390 = new cjs.Graphics().p("An6HmQjSjJAAkdIAAAAQAAkcDSjJIAAAAQDSjJEoAAIAAAAQEpAADSDJIAAAAQDSDJAAEcIAAAAQAAEdjSDJIAAAAQjSDJkpAAIAAAAQkoAAjSjJg");
	var mask_2_graphics_391 = new cjs.Graphics().p("AoNH4QjajRAAknIAAAAQAAkmDajRIAAAAQDajREzAAIAAAAQE0AADaDRIAAAAQDaDRAAEmIAAAAQAAEnjaDRIAAAAQjaDRk0AAIAAAAQkzAAjajRg");
	var mask_2_graphics_392 = new cjs.Graphics().p("AofIJQjhjYAAkxIAAAAQAAkwDhjYIAAAAQDhjYE+AAIAAAAQE/AADhDYIAAAAQDhDYAAEwIAAAAQAAExjhDYIAAAAQjhDYk/AAIAAAAQk+AAjhjYg");
	var mask_2_graphics_393 = new cjs.Graphics().p("AoxIaQjpjfAAk7IAAAAQAAk6DpjfIAAAAQDpjfFIAAIAAAAQFJAADpDfIAAAAQDpDfAAE6IAAAAQAAE7jpDfIAAAAQjpDflJAAIAAAAQlIAAjpjfg");
	var mask_2_graphics_394 = new cjs.Graphics().p("ApCIrQjwjmAAlFIAAAAQAAlEDwjmIAAAAQDwjmFSAAIAAAAQFTAADwDmIAAAAQDwDmAAFEIAAAAQAAFFjwDmIAAAAQjwDmlTAAIAAAAQlSAAjwjmg");
	var mask_2_graphics_395 = new cjs.Graphics().p("ApTI7Qj2jtAAlOIAAAAQAAlND2jtIAAAAQD3jsFcAAIAAAAQFdAAD2DsIAAAAQD3DtAAFNIAAAAQAAFOj3DtIAAAAQj2DsldAAIAAAAQlcAAj3jsg");
	var mask_2_graphics_396 = new cjs.Graphics().p("ApjJKQj9jzAAlXIAAAAQAAlWD9jzIAAAAQD+jzFlAAIAAAAQFmAAD9DzIAAAAQD+DzAAFWIAAAAQAAFXj+DzIAAAAQj9DzlmAAIAAAAQllAAj+jzg");
	var mask_2_graphics_397 = new cjs.Graphics().p("ApyJZQkEj5AAlgIAAAAQAAlfEEj5IAAAAQEEj5FuAAIAAAAQFvAAEED5IAAAAQEED5AAFfIAAAAQAAFgkED5IAAAAQkED5lvAAIAAAAQluAAkEj5g");
	var mask_2_graphics_398 = new cjs.Graphics().p("AqBJnQkKj/AAloIAAAAQAAlnEKj/IAAAAQEKj/F3AAIAAAAQF4AAEKD/IAAAAQEKD/AAFnIAAAAQAAFokKD/IAAAAQkKD/l4AAIAAAAQl3AAkKj/g");
	var mask_2_graphics_399 = new cjs.Graphics().p("AqQJ1QkQkFAAlwIAAAAQAAlvEQkFIAAAAQEQkFGAAAIAAAAQGBAAEPEFIAAAAQEREFAAFvIAAAAQAAFwkREFIAAAAQkPEFmBAAIAAAAQmAAAkQkFg");
	var mask_2_graphics_400 = new cjs.Graphics().p("AqeKCQkVkKAAl4IAAAAQAAl3EVkLIAAAAQEWkKGIAAIAAAAQGJAAEVEKIAAAAQEWELAAF3IAAAAQAAF4kWEKIAAAAQkVELmJAAIAAAAQmIAAkWkLg");
	var mask_2_graphics_401 = new cjs.Graphics().p("AqrKPQkbkPAAmAIAAAAQAAl/EbkPIAAAAQEckQGPAAIAAAAQGQAAEcEQIAAAAQEbEPAAF/IAAAAQAAGAkbEPIAAAAQkcEQmQAAIAAAAQmPAAkckQg");
	var mask_2_graphics_402 = new cjs.Graphics().p("Aq4KbQkgkUAAmHIAAAAQAAmGEgkVIAAAAQEhkUGXAAIAAAAQGYAAEgEUIAAAAQEhEVAAGGIAAAAQAAGHkhEUIAAAAQkgEVmYAAIAAAAQmXAAkhkVg");
	var mask_2_graphics_403 = new cjs.Graphics().p("ArEKnQklkZAAmOIAAAAQAAmNElkZIAAAAQEmkaGeAAIAAAAQGfAAEmEaIAAAAQElEZAAGNIAAAAQAAGOklEZIAAAAQkmEamfAAIAAAAQmeAAkmkag");
	var mask_2_graphics_404 = new cjs.Graphics().p("ArQKyQkqkeAAmUIAAAAQAAmTEqkfIAAAAQErkdGlAAIAAAAQGmAAEqEdIAAAAQErEfAAGTIAAAAQAAGUkrEeIAAAAQkqEemmAAIAAAAQmlAAkrkeg");
	var mask_2_graphics_405 = new cjs.Graphics().p("ArbK9QkvkiAAmbIAAAAQAAmaEvkiIAAAAQEvkjGsAAIAAAAQGtAAEvEjIAAAAQEvEiAAGaIAAAAQAAGbkvEiIAAAAQkvEjmtAAIAAAAQmsAAkvkjg");
	var mask_2_graphics_406 = new cjs.Graphics().p("ArlLHQk0kmAAmhIAAAAQAAmgE0kmIAAAAQEzknGyAAIAAAAQGzAAEzEnIAAAAQE0EmAAGgIAAAAQAAGhk0EmIAAAAQkzEnmzAAIAAAAQmyAAkzkng");
	var mask_2_graphics_407 = new cjs.Graphics().p("ArwLRQk3krAAmmIAAAAQAAmlE3krIAAAAQE4krG4AAIAAAAQG5AAE3ErIAAAAQE4ErAAGlIAAAAQAAGmk4ErIAAAAQk3Erm5AAIAAAAQm4AAk4krg");
	var mask_2_graphics_408 = new cjs.Graphics().p("Ar5LaQk8kuAAmsIAAAAQAAmrE8kuIAAAAQE8kuG9AAIAAAAQG+AAE8EuIAAAAQE8EuAAGrIAAAAQAAGsk8EuIAAAAQk8Eum+AAIAAAAQm9AAk8kug");
	var mask_2_graphics_409 = new cjs.Graphics().p("AsCLiQk/kxAAmxIAAAAQAAmwE/kyIAAAAQE/kyHDAAIAAAAQHEAAE/EyIAAAAQE/EyAAGwIAAAAQAAGxk/ExIAAAAQk/EznEAAIAAAAQnDAAk/kzg");
	var mask_2_graphics_410 = new cjs.Graphics().p("AsLLrQlCk2AAm1IAAAAQAAm0FCk2IAAAAQFEk1HHAAIAAAAQHIAAFDE1IAAAAQFDE2AAG0IAAAAQAAG1lDE2IAAAAQlDE1nIAAIAAAAQnHAAlEk1g");
	var mask_2_graphics_411 = new cjs.Graphics().p("AsSLyQlGk4AAm6IAAAAQAAm5FGk4IAAAAQFGk5HMAAIAAAAQHNAAFGE5IAAAAQFGE4AAG5IAAAAQAAG6lGE4IAAAAQlGE5nNAAIAAAAQnMAAlGk5g");
	var mask_2_graphics_412 = new cjs.Graphics().p("AsaL5QlJk7AAm+IAAAAQAAm9FJk8IAAAAQFKk7HQAAIAAAAQHRAAFJE7IAAAAQFKE8AAG9IAAAAQAAG+lKE7IAAAAQlJE8nRAAIAAAAQnQAAlKk8g");
	var mask_2_graphics_413 = new cjs.Graphics().p("AshMAQlLk+AAnCIAAAAQAAnBFLk+IAAAAQFNk+HUAAIAAAAQHVAAFME+IAAAAQFME+AAHBIAAAAQAAHClME+IAAAAQlME+nVAAIAAAAQnUAAlNk+g");
	var mask_2_graphics_414 = new cjs.Graphics().p("AsnMGQlOlBAAnFIAAAAQAAnEFOlBIAAAAQFPlAHYAAIAAAAQHZAAFOFAIAAAAQFPFBAAHEIAAAAQAAHFlPFBIAAAAQlOFAnZAAIAAAAQnYAAlPlAg");
	var mask_2_graphics_415 = new cjs.Graphics().p("AstMLQlQlDAAnIIAAAAQAAnHFQlEIAAAAQFSlCHbAAIAAAAQHcAAFRFCIAAAAQFRFEAAHHIAAAAQAAHIlRFDIAAAAQlRFDncAAIAAAAQnbAAlSlDg");
	var mask_2_graphics_416 = new cjs.Graphics().p("AsyMQQlTlFAAnLIAAAAQAAnKFTlGIAAAAQFUlEHeAAIAAAAQHfAAFTFEIAAAAQFUFGAAHKIAAAAQAAHLlUFFIAAAAQlTFFnfAAIAAAAQneAAlUlFg");
	var mask_2_graphics_417 = new cjs.Graphics().p("As2MVQlVlHAAnOIAAAAQAAnNFVlHIAAAAQFVlHHhAAIAAAAQHiAAFVFHIAAAAQFVFHAAHNIAAAAQAAHOlVFHIAAAAQlVFHniAAIAAAAQnhAAlVlHg");
	var mask_2_graphics_418 = new cjs.Graphics().p("As6MYQlXlIAAnQIAAAAQAAnPFXlJIAAAAQFWlIHkAAIAAAAQHlAAFWFIIAAAAQFXFJAAHPIAAAAQAAHQlXFIIAAAAQlWFJnlAAIAAAAQnkAAlWlJg");
	var mask_2_graphics_419 = new cjs.Graphics().p("As+McQlYlKAAnSIAAAAQAAnRFYlKIAAAAQFYlKHmAAIAAAAQHnAAFYFKIAAAAQFYFKAAHRIAAAAQAAHSlYFKIAAAAQlYFKnnAAIAAAAQnmAAlYlKg");
	var mask_2_graphics_420 = new cjs.Graphics().p("AtBMfQlZlLAAnUIAAAAQAAnTFZlLIAAAAQFalLHnAAIAAAAQHoAAFaFLIAAAAQFZFLAAHTIAAAAQAAHUlZFLIAAAAQlaFLnoAAIAAAAQnnAAlalLg");
	var mask_2_graphics_421 = new cjs.Graphics().p("AtDMhQlblMAAnVIAAAAQAAnUFblMIAAAAQFalMHpAAIAAAAQHqAAFaFMIAAAAQFbFMAAHUIAAAAQAAHVlbFMIAAAAQlaFMnqAAIAAAAQnpAAlalMg");
	var mask_2_graphics_422 = new cjs.Graphics().p("AtFMjQlblNAAnWIAAAAQAAnVFblNIAAAAQFblNHqAAIAAAAQHrAAFbFNIAAAAQFbFNAAHVIAAAAQAAHWlbFNIAAAAQlbFNnrAAIAAAAQnqAAlblNg");
	var mask_2_graphics_423 = new cjs.Graphics().p("AtHMkQlblNAAnXIAAAAQAAnWFblOIAAAAQFclNHrAAIAAAAQHsAAFbFNIAAAAQFcFOAAHWIAAAAQAAHXlcFNIAAAAQlbFOnsAAIAAAAQnrAAlclOg");
	var mask_2_graphics_424 = new cjs.Graphics().p("AtIMlQlblNAAnYIAAAAQAAnXFblNIAAAAQFdlOHrAAIAAAAQHsAAFcFOIAAAAQFcFNAAHXIAAAAQAAHYlcFNIAAAAQlcFOnsAAIAAAAQnrAAldlOg");
	var mask_2_graphics_425 = new cjs.Graphics().p("AtIMlQlclNAAnYIAAAAQAAnXFclOIAAAAQFdlNHrAAIAAAAQHsAAFcFNIAAAAQFdFOAAHXIAAAAQAAHYldFNIAAAAQlcFOnsAAIAAAAQnrAAldlOg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(347).to({graphics:mask_2_graphics_347,x:850.7502,y:433.6002}).wait(1).to({graphics:mask_2_graphics_348,x:850.7502,y:433.6002}).wait(1).to({graphics:mask_2_graphics_349,x:850.7502,y:433.6002}).wait(1).to({graphics:mask_2_graphics_350,x:850.7506,y:433.6002}).wait(1).to({graphics:mask_2_graphics_351,x:850.7511,y:433.6011}).wait(1).to({graphics:mask_2_graphics_352,x:850.7516,y:433.6011}).wait(1).to({graphics:mask_2_graphics_353,x:850.752,y:433.602}).wait(1).to({graphics:mask_2_graphics_354,x:850.7524,y:433.6024}).wait(1).to({graphics:mask_2_graphics_355,x:850.7534,y:433.6033}).wait(1).to({graphics:mask_2_graphics_356,x:850.7542,y:433.6042}).wait(1).to({graphics:mask_2_graphics_357,x:850.7551,y:433.6051}).wait(1).to({graphics:mask_2_graphics_358,x:850.7565,y:433.606}).wait(1).to({graphics:mask_2_graphics_359,x:850.7578,y:433.6074}).wait(1).to({graphics:mask_2_graphics_360,x:850.7592,y:433.6087}).wait(1).to({graphics:mask_2_graphics_361,x:850.7606,y:433.6101}).wait(1).to({graphics:mask_2_graphics_362,x:850.7624,y:433.6119}).wait(1).to({graphics:mask_2_graphics_363,x:850.7637,y:433.6132}).wait(1).to({graphics:mask_2_graphics_364,x:850.7655,y:433.6151}).wait(1).to({graphics:mask_2_graphics_365,x:850.7673,y:433.6169}).wait(1).to({graphics:mask_2_graphics_366,x:850.7691,y:433.6187}).wait(1).to({graphics:mask_2_graphics_367,x:850.7713,y:433.6209}).wait(1).to({graphics:mask_2_graphics_368,x:850.7736,y:433.6227}).wait(1).to({graphics:mask_2_graphics_369,x:850.7758,y:433.6249}).wait(1).to({graphics:mask_2_graphics_370,x:850.7781,y:433.6272}).wait(1).to({graphics:mask_2_graphics_371,x:850.7808,y:433.6294}).wait(1).to({graphics:mask_2_graphics_372,x:850.7835,y:433.6317}).wait(1).to({graphics:mask_2_graphics_373,x:850.7862,y:433.6349}).wait(1).to({graphics:mask_2_graphics_374,x:850.7889,y:433.6375}).wait(1).to({graphics:mask_2_graphics_375,x:850.7916,y:433.6402}).wait(1).to({graphics:mask_2_graphics_376,x:850.7947,y:433.6434}).wait(1).to({graphics:mask_2_graphics_377,x:850.7979,y:433.6461}).wait(1).to({graphics:mask_2_graphics_378,x:850.8011,y:433.6492}).wait(1).to({graphics:mask_2_graphics_379,x:850.8042,y:433.6524}).wait(1).to({graphics:mask_2_graphics_380,x:850.8078,y:433.656}).wait(1).to({graphics:mask_2_graphics_381,x:850.8118,y:433.6591}).wait(1).to({graphics:mask_2_graphics_382,x:850.8154,y:433.6627}).wait(1).to({graphics:mask_2_graphics_383,x:850.8191,y:433.6668}).wait(1).to({graphics:mask_2_graphics_384,x:850.8226,y:433.67}).wait(1).to({graphics:mask_2_graphics_385,x:850.8271,y:433.674}).wait(1).to({graphics:mask_2_graphics_386,x:850.8307,y:433.678}).wait(1).to({graphics:mask_2_graphics_387,x:850.8348,y:433.6817}).wait(1).to({graphics:mask_2_graphics_388,x:850.8393,y:433.6857}).wait(1).to({graphics:mask_2_graphics_389,x:850.8429,y:433.6897}).wait(1).to({graphics:mask_2_graphics_390,x:850.8465,y:433.6933}).wait(1).to({graphics:mask_2_graphics_391,x:850.8501,y:433.6965}).wait(1).to({graphics:mask_2_graphics_392,x:850.8542,y:433.7001}).wait(1).to({graphics:mask_2_graphics_393,x:850.8573,y:433.7032}).wait(1).to({graphics:mask_2_graphics_394,x:850.8609,y:433.7068}).wait(1).to({graphics:mask_2_graphics_395,x:850.864,y:433.71}).wait(1).to({graphics:mask_2_graphics_396,x:850.8672,y:433.7131}).wait(1).to({graphics:mask_2_graphics_397,x:850.8703,y:433.7158}).wait(1).to({graphics:mask_2_graphics_398,x:850.873,y:433.7186}).wait(1).to({graphics:mask_2_graphics_399,x:850.8757,y:433.7212}).wait(1).to({graphics:mask_2_graphics_400,x:850.8784,y:433.724}).wait(1).to({graphics:mask_2_graphics_401,x:850.8811,y:433.7266}).wait(1).to({graphics:mask_2_graphics_402,x:850.8839,y:433.7289}).wait(1).to({graphics:mask_2_graphics_403,x:850.8861,y:433.7311}).wait(1).to({graphics:mask_2_graphics_404,x:850.8883,y:433.7334}).wait(1).to({graphics:mask_2_graphics_405,x:850.8906,y:433.7356}).wait(1).to({graphics:mask_2_graphics_406,x:850.8924,y:433.7374}).wait(1).to({graphics:mask_2_graphics_407,x:850.8947,y:433.7392}).wait(1).to({graphics:mask_2_graphics_408,x:850.8964,y:433.7415}).wait(1).to({graphics:mask_2_graphics_409,x:850.8983,y:433.7428}).wait(1).to({graphics:mask_2_graphics_410,x:850.8996,y:433.7446}).wait(1).to({graphics:mask_2_graphics_411,x:850.9014,y:433.746}).wait(1).to({graphics:mask_2_graphics_412,x:850.9027,y:433.7473}).wait(1).to({graphics:mask_2_graphics_413,x:850.9036,y:433.7487}).wait(1).to({graphics:mask_2_graphics_414,x:850.9054,y:433.75}).wait(1).to({graphics:mask_2_graphics_415,x:850.9063,y:433.7509}).wait(1).to({graphics:mask_2_graphics_416,x:850.9072,y:433.7518}).wait(1).to({graphics:mask_2_graphics_417,x:850.9086,y:433.7523}).wait(1).to({graphics:mask_2_graphics_418,x:850.9091,y:433.7532}).wait(1).to({graphics:mask_2_graphics_419,x:850.9095,y:433.7541}).wait(1).to({graphics:mask_2_graphics_420,x:850.9104,y:433.7545}).wait(1).to({graphics:mask_2_graphics_421,x:850.9108,y:433.755}).wait(1).to({graphics:mask_2_graphics_422,x:850.9113,y:433.7554}).wait(1).to({graphics:mask_2_graphics_423,x:850.9113,y:433.7559}).wait(1).to({graphics:mask_2_graphics_424,x:850.9117,y:433.7559}).wait(1).to({graphics:mask_2_graphics_425,x:850.9117,y:433.7559}).wait(385));

	// Layer_34
	this.instance_5 = new lib.Tween67("synched",0);
	this.instance_5.setTransform(866.95,409.7);
	this.instance_5.alpha = 0.5;
	this.instance_5._off = true;

	this.instance_6 = new lib.Tween68("synched",0);
	this.instance_6.setTransform(866.95,409.7);

	var maskedShapeInstanceList = [this.instance_5,this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_5}]},347).to({state:[{t:this.instance_6}]},78).wait(385));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(347).to({_off:false},0).to({_off:true,alpha:1},78).wait(385));

	// Layer_6 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_200 = new cjs.Graphics().p("AgMAMQgFgFAAgHIAAAAQAAgGAFgFIAAAAQAFgGAHAAIAAAAQAIAAAFAGIAAAAQAFAFAAAGIAAAAQAAAHgFAFIAAAAQgFAGgIAAIAAAAQgHAAgFgGg");
	var mask_3_graphics_201 = new cjs.Graphics().p("AgMAMQgFgFAAgHIAAAAQAAgGAFgFIAAAAQAFgGAHAAIAAAAQAIAAAFAGIAAAAQAFAFAAAGIAAAAQAAAHgFAFIAAAAQgFAGgIAAIAAAAQgHAAgFgGg");
	var mask_3_graphics_202 = new cjs.Graphics().p("AgMANQgGgFAAgIIAAAAQAAgHAGgFIAAAAQAFgFAHAAIAAAAQAIAAAFAFIAAAAQAGAFAAAHIAAAAQAAAIgGAFIAAAAQgFAFgIAAIAAAAQgHAAgFgFg");
	var mask_3_graphics_203 = new cjs.Graphics().p("AgNANQgGgFAAgIIAAAAQAAgHAGgFIAAAAQAGgGAHAAIAAAAQAIAAAGAGIAAAAQAGAFAAAHIAAAAQAAAIgGAFIAAAAQgGAGgIAAIAAAAQgHAAgGgGg");
	var mask_3_graphics_204 = new cjs.Graphics().p("AgOAOQgGgGAAgIIAAAAQAAgHAGgGIAAAAQAGgGAIAAIAAAAQAJAAAGAGIAAAAQAGAGAAAHIAAAAQAAAIgGAGIAAAAQgGAGgJAAIAAAAQgIAAgGgGg");
	var mask_3_graphics_205 = new cjs.Graphics().p("AgPAPQgGgGAAgJIAAAAQAAgIAGgGIAAAAQAHgGAIAAIAAAAQAJAAAHAGIAAAAQAGAGAAAIIAAAAQAAAJgGAGIAAAAQgHAGgJAAIAAAAQgIAAgHgGg");
	var mask_3_graphics_206 = new cjs.Graphics().p("AgQAQQgHgGAAgKIAAAAQAAgJAHgGIAAAAQAHgHAJAAIAAAAQAKAAAHAHIAAAAQAHAGAAAJIAAAAQAAAKgHAGIAAAAQgHAHgKAAIAAAAQgJAAgHgHg");
	var mask_3_graphics_207 = new cjs.Graphics().p("AgSASQgHgIAAgKIAAAAQAAgJAHgIIAAAAQAIgHAKAAIAAAAQALAAAIAHIAAAAQAHAIAAAJIAAAAQAAAKgHAIIAAAAQgIAHgLAAIAAAAQgKAAgIgHg");
	var mask_3_graphics_208 = new cjs.Graphics().p("AgTATQgJgIAAgLIAAAAQAAgKAJgJIAAAAQAIgIALAAIAAAAQAMAAAIAIIAAAAQAJAJAAAKIAAAAQAAALgJAIIAAAAQgIAJgMAAIAAAAQgLAAgIgJg");
	var mask_3_graphics_209 = new cjs.Graphics().p("AgVAVQgKgIAAgNIAAAAQAAgMAKgIIAAAAQAJgJAMAAIAAAAQANAAAJAJIAAAAQAKAIAAAMIAAAAQAAANgKAIIAAAAQgJAJgNAAIAAAAQgMAAgJgJg");
	var mask_3_graphics_210 = new cjs.Graphics().p("AgYAXQgKgJAAgOIAAAAQAAgNAKgKIAAAAQALgJANAAIAAAAQAOAAALAJIAAAAQAKAKAAANIAAAAQAAAOgKAJIAAAAQgLAKgOAAIAAAAQgNAAgLgKg");
	var mask_3_graphics_211 = new cjs.Graphics().p("AgaAaQgLgLAAgPIAAAAQAAgOALgLIAAAAQALgLAPAAIAAAAQAQAAALALIAAAAQALALAAAOIAAAAQAAAPgLALIAAAAQgLALgQAAIAAAAQgPAAgLgLg");
	var mask_3_graphics_212 = new cjs.Graphics().p("AgdAcQgMgLAAgRIAAAAQAAgQAMgLIAAAAQANgMAQAAIAAAAQARAAANAMIAAAAQAMALAAAQIAAAAQAAARgMALIAAAAQgNAMgRAAIAAAAQgQAAgNgMg");
	var mask_3_graphics_213 = new cjs.Graphics().p("AggAfQgNgNAAgSIAAAAQAAgRANgNIAAAAQAOgNASAAIAAAAQATAAAOANIAAAAQANANAAARIAAAAQAAASgNANIAAAAQgOANgTAAIAAAAQgSAAgOgNg");
	var mask_3_graphics_214 = new cjs.Graphics().p("AgjAiQgOgOAAgUIAAAAQAAgTAOgOIAAAAQAPgOAUAAIAAAAQAVAAAPAOIAAAAQAOAOAAATIAAAAQAAAUgOAOIAAAAQgPAOgVAAIAAAAQgUAAgPgOg");
	var mask_3_graphics_215 = new cjs.Graphics().p("AgmAlQgQgPAAgWIAAAAQAAgVAQgPIAAAAQAQgQAWAAIAAAAQAXAAAQAQIAAAAQAQAPAAAVIAAAAQAAAWgQAPIAAAAQgQAQgXAAIAAAAQgWAAgQgQg");
	var mask_3_graphics_216 = new cjs.Graphics().p("AgqApQgRgRAAgYIAAAAQAAgXARgRIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQARARAAAXIAAAAQAAAYgRARIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_3_graphics_217 = new cjs.Graphics().p("AgtAtQgUgTAAgaIAAAAQAAgZAUgTIAAAAQATgSAaAAIAAAAQAbAAATASIAAAAQAUATAAAZIAAAAQAAAagUATIAAAAQgTASgbAAIAAAAQgaAAgTgSg");
	var mask_3_graphics_218 = new cjs.Graphics().p("AgyAwQgUgUAAgcIAAAAQAAgbAUgUIAAAAQAVgUAdAAIAAAAQAeAAAVAUIAAAAQAUAUAAAbIAAAAQAAAcgUAUIAAAAQgVAUgeAAIAAAAQgdAAgVgUg");
	var mask_3_graphics_219 = new cjs.Graphics().p("Ag2A1QgXgWAAgfIAAAAQAAgeAXgWIAAAAQAXgVAfAAIAAAAQAgAAAXAVIAAAAQAXAWAAAeIAAAAQAAAfgXAWIAAAAQgXAVggAAIAAAAQgfAAgXgVg");
	var mask_3_graphics_220 = new cjs.Graphics().p("Ag6A5QgZgYAAghIAAAAQAAggAZgYIAAAAQAYgXAiAAIAAAAQAjAAAYAXIAAAAQAZAYAAAgIAAAAQAAAhgZAYIAAAAQgYAXgjAAIAAAAQgiAAgYgXg");
	var mask_3_graphics_221 = new cjs.Graphics().p("Ag/A9QgbgZAAgkIAAAAQAAgjAbgZIAAAAQAagaAlAAIAAAAQAmAAAaAaIAAAAQAbAZAAAjIAAAAQAAAkgbAZIAAAAQgaAagmAAIAAAAQglAAgagag");
	var mask_3_graphics_222 = new cjs.Graphics().p("AhEBCQgdgbAAgnIAAAAQAAgmAdgbIAAAAQAdgcAnAAIAAAAQAoAAAdAcIAAAAQAdAbAAAmIAAAAQAAAngdAbIAAAAQgdAcgoAAIAAAAQgnAAgdgcg");
	var mask_3_graphics_223 = new cjs.Graphics().p("AhJBHQgfgdAAgqIAAAAQAAgpAfgdIAAAAQAegeArAAIAAAAQAsAAAeAeIAAAAQAfAdAAApIAAAAQAAAqgfAdIAAAAQgeAegsAAIAAAAQgrAAgegeg");
	var mask_3_graphics_224 = new cjs.Graphics().p("AhPBMQghgfAAgtIAAAAQAAgsAhgfIAAAAQAhggAuAAIAAAAQAvAAAhAgIAAAAQAhAfAAAsIAAAAQAAAtghAfIAAAAQghAggvAAIAAAAQguAAghggg");
	var mask_3_graphics_225 = new cjs.Graphics().p("AhVBSQgjgiAAgwIAAAAQAAgvAjgiIAAAAQAkgiAxAAIAAAAQAyAAAjAiIAAAAQAkAiAAAvIAAAAQAAAwgkAiIAAAAQgjAigyAAIAAAAQgxAAgkgig");
	var mask_3_graphics_226 = new cjs.Graphics().p("AhaBYQgmglAAgzIAAAAQAAgyAmglIAAAAQAlgkA1AAIAAAAQA2AAAlAkIAAAAQAmAlAAAyIAAAAQAAAzgmAlIAAAAQglAkg2AAIAAAAQg1AAglgkg");
	var mask_3_graphics_227 = new cjs.Graphics().p("AhhBdQgogmAAg3IAAAAQAAg2AognIAAAAQApgmA4AAIAAAAQA5AAApAmIAAAAQAoAnAAA2IAAAAQAAA3goAmIAAAAQgpAng5AAIAAAAQg4AAgpgng");
	var mask_3_graphics_228 = new cjs.Graphics().p("AhnBkQgrgqAAg6IAAAAQAAg5ArgqIAAAAQArgpA8AAIAAAAQA9AAArApIAAAAQArAqAAA5IAAAAQAAA6grAqIAAAAQgrApg9AAIAAAAQg8AAgrgpg");
	var mask_3_graphics_229 = new cjs.Graphics().p("AhuBqQgtgsAAg+IAAAAQAAg9AtgsIAAAAQAugsBAAAIAAAAQBBAAAuAsIAAAAQAtAsAAA9IAAAAQAAA+gtAsIAAAAQguAshBAAIAAAAQhAAAgugsg");
	var mask_3_graphics_230 = new cjs.Graphics().p("Ah0BwQgxguAAhCIAAAAQAAhBAxgvIAAAAQAwguBEAAIAAAAQBFAAAwAuIAAAAQAxAvAABBIAAAAQAABCgxAuIAAAAQgwAvhFAAIAAAAQhEAAgwgvg");
	var mask_3_graphics_231 = new cjs.Graphics().p("Ah8B3QgzgxAAhGIAAAAQAAhFAzgxIAAAAQA0gyBIAAIAAAAQBJAAAzAyIAAAAQA0AxAABFIAAAAQAABGg0AxIAAAAQgzAyhJAAIAAAAQhIAAg0gyg");
	var mask_3_graphics_232 = new cjs.Graphics().p("AiDB+Qg2g0AAhKIAAAAQAAhJA2g0IAAAAQA3g1BMAAIAAAAQBNAAA3A1IAAAAQA2A0AABJIAAAAQAABKg2A0IAAAAQg3A1hNAAIAAAAQhMAAg3g1g");
	var mask_3_graphics_233 = new cjs.Graphics().p("AiKCGQg6g4AAhOIAAAAQAAhNA6g4IAAAAQA5g3BRAAIAAAAQBSAAA5A3IAAAAQA6A4AABNIAAAAQAABOg6A4IAAAAQg5A3hSAAIAAAAQhRAAg5g3g");
	var mask_3_graphics_234 = new cjs.Graphics().p("AiSCNQg9g6AAhTIAAAAQAAhSA9g6IAAAAQA9g6BVAAIAAAAQBWAAA9A6IAAAAQA9A6AABSIAAAAQAABTg9A6IAAAAQg9A6hWAAIAAAAQhVAAg9g6g");
	var mask_3_graphics_235 = new cjs.Graphics().p("AiaCVQhAg+AAhXIAAAAQAAhWBAg+IAAAAQBAg9BaAAIAAAAQBbAABAA9IAAAAQBAA+AABWIAAAAQAABXhAA+IAAAAQhAA9hbAAIAAAAQhaAAhAg9g");
	var mask_3_graphics_236 = new cjs.Graphics().p("AiiCdQhEhBAAhcIAAAAQAAhbBEhBIAAAAQBDhABfAAIAAAAQBgAABDBAIAAAAQBEBBAABbIAAAAQAABchEBBIAAAAQhDBAhgAAIAAAAQhfAAhDhAg");
	var mask_3_graphics_237 = new cjs.Graphics().p("AirClQhHhFAAhgIAAAAQAAhfBHhFIAAAAQBHhEBkAAIAAAAQBlAABHBEIAAAAQBHBFAABfIAAAAQAABghHBFIAAAAQhHBEhlAAIAAAAQhkAAhHhEg");
	var mask_3_graphics_238 = new cjs.Graphics().p("Ai0CtQhKhIAAhlIAAAAQAAhkBKhIIAAAAQBLhIBpAAIAAAAQBqAABLBIIAAAAQBKBIAABkIAAAAQAABlhKBIIAAAAQhLBIhqAAIAAAAQhpAAhLhIg");
	var mask_3_graphics_239 = new cjs.Graphics().p("Ai9C2QhOhMAAhqIAAAAQAAhpBOhMIAAAAQBPhLBuAAIAAAAQBvAABOBLIAAAAQBPBMAABpIAAAAQAABqhPBMIAAAAQhOBLhvAAIAAAAQhuAAhPhLg");
	var mask_3_graphics_240 = new cjs.Graphics().p("AjGC+QhShOAAhwIAAAAQAAhvBShOIAAAAQBThPBzAAIAAAAQB0AABTBPIAAAAQBSBOAABvIAAAAQAABwhSBOIAAAAQhTBPh0AAIAAAAQhzAAhThPg");
	var mask_3_graphics_241 = new cjs.Graphics().p("AjPDHQhWhSAAh1IAAAAQAAh0BWhSIAAAAQBWhTB5AAIAAAAQB6AABWBTIAAAAQBWBSAAB0IAAAAQAAB1hWBSIAAAAQhWBTh6AAIAAAAQh5AAhWhTg");
	var mask_3_graphics_242 = new cjs.Graphics().p("AjZDRQhahXAAh6IAAAAQAAh5BahXIAAAAQBahWB/AAIAAAAQCAAABaBWIAAAAQBaBXAAB5IAAAAQAAB6haBXIAAAAQhaBWiAAAIAAAAQh/AAhahWg");
	var mask_3_graphics_243 = new cjs.Graphics().p("AjjDaQhehaAAiAIAAAAQAAh/BehaIAAAAQBfhaCEAAIAAAAQCFAABfBaIAAAAQBeBaAAB/IAAAAQAACAheBaIAAAAQhfBaiFAAIAAAAQiEAAhfhag");
	var mask_3_graphics_244 = new cjs.Graphics().p("AjtDkQhihfAAiFIAAAAQAAiEBihfIAAAAQBjheCKAAIAAAAQCLAABjBeIAAAAQBiBfAACEIAAAAQAACFhiBfIAAAAQhjBeiLAAIAAAAQiKAAhjheg");
	var mask_3_graphics_245 = new cjs.Graphics().p("Aj3DuQhnhjAAiLIAAAAQAAiKBnhjIAAAAQBnhiCQAAIAAAAQCRAABnBiIAAAAQBnBjAACKIAAAAQAACLhnBjIAAAAQhnBiiRAAIAAAAQiQAAhnhig");
	var mask_3_graphics_246 = new cjs.Graphics().p("AkCD4QhrhnAAiRIAAAAQAAiQBrhnIAAAAQBshmCWAAIAAAAQCXAABsBmIAAAAQBrBnAACQIAAAAQAACRhrBnIAAAAQhsBmiXAAIAAAAQiWAAhshmg");
	var mask_3_graphics_247 = new cjs.Graphics().p("AkMECQhwhrAAiXIAAAAQAAiWBwhrIAAAAQBvhrCdAAIAAAAQCeAABvBrIAAAAQBwBrAACWIAAAAQAACXhwBrIAAAAQhvBrieAAIAAAAQidAAhvhrg");
	var mask_3_graphics_248 = new cjs.Graphics().p("AkXEMQhzhvAAidIAAAAQAAicBzhvIAAAAQB0hvCjAAIAAAAQCkAABzBvIAAAAQB0BvAACcIAAAAQAACdh0BvIAAAAQhzBvikAAIAAAAQijAAh0hvg");
	var mask_3_graphics_249 = new cjs.Graphics().p("AkhEVQh4hyAAijIAAAAQAAiiB4hzIAAAAQB4hzCpAAIAAAAQCqAAB4BzIAAAAQB4BzAACiIAAAAQAACjh4ByIAAAAQh4B0iqAAIAAAAQipAAh4h0g");
	var mask_3_graphics_250 = new cjs.Graphics().p("AkrEfQh8h3AAioIAAAAQAAinB8h3IAAAAQB9h3CuAAIAAAAQCvAAB8B3IAAAAQB9B3AACnIAAAAQAACoh9B3IAAAAQh8B3ivAAIAAAAQiuAAh9h3g");
	var mask_3_graphics_251 = new cjs.Graphics().p("Ak0EoQiAh6AAiuIAAAAQAAitCAh6IAAAAQCAh7C0AAIAAAAQC1AACAB7IAAAAQCAB6AACtIAAAAQAACuiAB6IAAAAQiAB7i1AAIAAAAQi0AAiAh7g");
	var mask_3_graphics_252 = new cjs.Graphics().p("Ak+ExQiEh+AAizIAAAAQAAiyCEh+IAAAAQCEh/C6AAIAAAAQC7AACDB/IAAAAQCFB+AACyIAAAAQAACziFB+IAAAAQiDB/i7AAIAAAAQi6AAiEh/g");
	var mask_3_graphics_253 = new cjs.Graphics().p("AlHE6QiIiCAAi4IAAAAQAAi3CIiCIAAAAQCIiCC/AAIAAAAQDAAACICCIAAAAQCICCAAC3IAAAAQAAC4iICCIAAAAQiICCjAAAIAAAAQi/AAiIiCg");
	var mask_3_graphics_254 = new cjs.Graphics().p("AlQFDQiLiGAAi9IAAAAQAAi8CLiGIAAAAQCMiFDEAAIAAAAQDFAACMCFIAAAAQCLCGAAC8IAAAAQAAC9iLCGIAAAAQiMCFjFAAIAAAAQjEAAiMiFg");
	var mask_3_graphics_255 = new cjs.Graphics().p("AlYFLQiPiJAAjCIAAAAQAAjBCPiJIAAAAQCPiJDJAAIAAAAQDKAACPCJIAAAAQCPCJAADBIAAAAQAADCiPCJIAAAAQiPCJjKAAIAAAAQjJAAiPiJg");
	var mask_3_graphics_256 = new cjs.Graphics().p("AlhFTQiSiMAAjHIAAAAQAAjGCSiMIAAAAQCTiNDOAAIAAAAQDPAACTCNIAAAAQCSCMAADGIAAAAQAADHiSCMIAAAAQiTCNjPAAIAAAAQjOAAiTiNg");
	var mask_3_graphics_257 = new cjs.Graphics().p("AlpFbQiWiQAAjLIAAAAQAAjKCWiQIAAAAQCWiQDTAAIAAAAQDUAACWCQIAAAAQCWCQAADKIAAAAQAADLiWCQIAAAAQiWCQjUAAIAAAAQjTAAiWiQg");
	var mask_3_graphics_258 = new cjs.Graphics().p("AlxFjQiZiTAAjQIAAAAQAAjPCZiTIAAAAQCZiTDYAAIAAAAQDZAACZCTIAAAAQCZCTAADPIAAAAQAADQiZCTIAAAAQiZCTjZAAIAAAAQjYAAiZiTg");
	var mask_3_graphics_259 = new cjs.Graphics().p("Al5FqQiciWAAjUIAAAAQAAjTCciWIAAAAQCdiWDcAAIAAAAQDdAACdCWIAAAAQCcCWAADTIAAAAQAADUicCWIAAAAQidCWjdAAIAAAAQjcAAidiWg");
	var mask_3_graphics_260 = new cjs.Graphics().p("AmBFxQifiZAAjYIAAAAQAAjXCfiZIAAAAQCgiZDhAAIAAAAQDiAACfCZIAAAAQCgCZAADXIAAAAQAADYigCZIAAAAQifCZjiAAIAAAAQjhAAigiZg");
	var mask_3_graphics_261 = new cjs.Graphics().p("AmIF4QiiicAAjcIAAAAQAAjbCiicIAAAAQCjicDlAAIAAAAQDmAACjCcIAAAAQCiCcAADbIAAAAQAADciiCcIAAAAQijCcjmAAIAAAAQjlAAijicg");
	var mask_3_graphics_262 = new cjs.Graphics().p("AmPF/QilifAAjgIAAAAQAAjfClifIAAAAQCmifDpAAIAAAAQDqAACmCfIAAAAQClCfAADfIAAAAQAADgilCfIAAAAQimCfjqAAIAAAAQjpAAimifg");
	var mask_3_graphics_263 = new cjs.Graphics().p("AmWGGQioiiAAjkIAAAAQAAjjCoiiIAAAAQCpihDtAAIAAAAQDuAACpChIAAAAQCoCiAADjIAAAAQAADkioCiIAAAAQipChjuAAIAAAAQjtAAipihg");
	var mask_3_graphics_264 = new cjs.Graphics().p("AmcGMQisikAAjoIAAAAQAAjnCsikIAAAAQCrikDxAAIAAAAQDyAACrCkIAAAAQCsCkAADnIAAAAQAADoisCkIAAAAQirCkjyAAIAAAAQjxAAirikg");
	var mask_3_graphics_265 = new cjs.Graphics().p("AmjGSQiuimAAjsIAAAAQAAjrCuimIAAAAQCuinD1AAIAAAAQD2AACuCnIAAAAQCuCmAADrIAAAAQAADsiuCmIAAAAQiuCnj2AAIAAAAQj1AAiuing");
	var mask_3_graphics_266 = new cjs.Graphics().p("AmpGYQiwipAAjvIAAAAQAAjuCwipIAAAAQCxipD4AAIAAAAQD5AACxCpIAAAAQCwCpAADuIAAAAQAADviwCpIAAAAQixCpj5AAIAAAAQj4AAixipg");
	var mask_3_graphics_267 = new cjs.Graphics().p("AmvGeQizisAAjyIAAAAQAAjxCzisIAAAAQCzirD8AAIAAAAQD9AACzCrIAAAAQCzCsAADxIAAAAQAADyizCsIAAAAQizCrj9AAIAAAAQj8AAizirg");
	var mask_3_graphics_268 = new cjs.Graphics().p("Am1GjQi1itAAj2IAAAAQAAj1C1itIAAAAQC2iuD/AAIAAAAQEAAAC1CuIAAAAQC2CtAAD1IAAAAQAAD2i2CtIAAAAQi1CukAAAIAAAAQj/AAi2iug");
	var mask_3_graphics_269 = new cjs.Graphics().p("Am6GoQi3ivAAj5IAAAAQAAj4C3iwIAAAAQC4ivECAAIAAAAQEDAAC4CvIAAAAQC3CwAAD4IAAAAQAAD5i3CvIAAAAQi4CwkDAAIAAAAQkCAAi4iwg");
	var mask_3_graphics_270 = new cjs.Graphics().p("Am/GtQi6ixAAj8IAAAAQAAj7C6iyIAAAAQC6ixEFAAIAAAAQEGAAC6CxIAAAAQC6CyAAD7IAAAAQAAD8i6CxIAAAAQi6CykGAAIAAAAQkFAAi6iyg");
	var mask_3_graphics_271 = new cjs.Graphics().p("AnEGyQi8i0AAj+IAAAAQAAj9C8i0IAAAAQC8i0EIAAIAAAAQEJAAC8C0IAAAAQC8C0AAD9IAAAAQAAD+i8C0IAAAAQi8C0kJAAIAAAAQkIAAi8i0g");
	var mask_3_graphics_272 = new cjs.Graphics().p("AnJG3Qi+i2AAkBIAAAAQAAkAC+i2IAAAAQC+i2ELAAIAAAAQEMAAC+C2IAAAAQC+C2AAEAIAAAAQAAEBi+C2IAAAAQi+C2kMAAIAAAAQkLAAi+i2g");
	var mask_3_graphics_273 = new cjs.Graphics().p("AnOG7Qi/i3AAkEIAAAAQAAkDC/i3IAAAAQDAi4EOAAIAAAAQEPAAC/C4IAAAAQDAC3AAEDIAAAAQAAEEjAC3IAAAAQi/C4kPAAIAAAAQkOAAjAi4g");
	var mask_3_graphics_274 = new cjs.Graphics().p("AnSG/QjBi5AAkGIAAAAQAAkFDBi5IAAAAQDCi5EQAAIAAAAQERAADCC5IAAAAQDBC5AAEFIAAAAQAAEGjBC5IAAAAQjCC5kRAAIAAAAQkQAAjCi5g");
	var mask_3_graphics_275 = new cjs.Graphics().p("AnWHDQjDi7AAkIIAAAAQAAkHDDi7IAAAAQDDi7ETAAIAAAAQEUAADDC7IAAAAQDDC7AAEHIAAAAQAAEIjDC7IAAAAQjDC7kUAAIAAAAQkTAAjDi7g");
	var mask_3_graphics_276 = new cjs.Graphics().p("AnaHHQjEi9AAkKIAAAAQAAkJDEi9IAAAAQDFi8EVAAIAAAAQEWAADFC8IAAAAQDEC9AAEJIAAAAQAAEKjEC9IAAAAQjFC8kWAAIAAAAQkVAAjFi8g");
	var mask_3_graphics_277 = new cjs.Graphics().p("AndHKQjGi+AAkMIAAAAQAAkLDGi+IAAAAQDGi+EXAAIAAAAQEYAADGC+IAAAAQDGC+AAELIAAAAQAAEMjGC+IAAAAQjGC+kYAAIAAAAQkXAAjGi+g");
	var mask_3_graphics_278 = new cjs.Graphics().p("AnhHNQjHi/AAkOIAAAAQAAkNDHjAIAAAAQDIi/EZAAIAAAAQEaAADHC/IAAAAQDIDAAAENIAAAAQAAEOjIC/IAAAAQjHDAkaAAIAAAAQkZAAjIjAg");
	var mask_3_graphics_279 = new cjs.Graphics().p("AnkHQQjJjAAAkQIAAAAQAAkPDJjBIAAAAQDJjAEbAAIAAAAQEcAADJDAIAAAAQDJDBAAEPIAAAAQAAEQjJDAIAAAAQjJDBkcAAIAAAAQkbAAjJjBg");
	var mask_3_graphics_280 = new cjs.Graphics().p("AnnHTQjKjBAAkSIAAAAQAAkRDKjBIAAAAQDKjCEdAAIAAAAQEeAADKDCIAAAAQDKDBAAERIAAAAQAAESjKDBIAAAAQjKDCkeAAIAAAAQkdAAjKjCg");
	var mask_3_graphics_281 = new cjs.Graphics().p("AnpHWQjLjDAAkTIAAAAQAAkSDLjDIAAAAQDLjCEeAAIAAAAQEfAADLDCIAAAAQDLDDAAESIAAAAQAAETjLDDIAAAAQjLDCkfAAIAAAAQkeAAjLjCg");
	var mask_3_graphics_282 = new cjs.Graphics().p("AnsHYQjMjDAAkVIAAAAQAAkUDMjDIAAAAQDMjEEgAAIAAAAQEhAADMDEIAAAAQDMDDAAEUIAAAAQAAEVjMDDIAAAAQjMDEkhAAIAAAAQkgAAjMjEg");
	var mask_3_graphics_283 = new cjs.Graphics().p("AnuHaQjNjEAAkWIAAAAQAAkVDNjEIAAAAQDNjFEhAAIAAAAQEiAADNDFIAAAAQDNDEAAEVIAAAAQAAEWjNDEIAAAAQjNDFkiAAIAAAAQkhAAjNjFg");
	var mask_3_graphics_284 = new cjs.Graphics().p("AnwHcQjOjFAAkXIAAAAQAAkWDOjFIAAAAQDOjFEiAAIAAAAQEjAADODFIAAAAQDODFAAEWIAAAAQAAEXjODFIAAAAQjODFkjAAIAAAAQkiAAjOjFg");
	var mask_3_graphics_285 = new cjs.Graphics().p("AnyHeQjOjGAAkYIAAAAQAAkXDOjGIAAAAQDPjGEjAAIAAAAQEkAADPDGIAAAAQDODGAAEXIAAAAQAAEYjODGIAAAAQjPDGkkAAIAAAAQkjAAjPjGg");
	var mask_3_graphics_286 = new cjs.Graphics().p("AnzHfQjPjGAAkZIAAAAQAAkYDPjGIAAAAQDPjHEkAAIAAAAQElAADPDHIAAAAQDPDGAAEYIAAAAQAAEZjPDGIAAAAQjPDHklAAIAAAAQkkAAjPjHg");
	var mask_3_graphics_287 = new cjs.Graphics().p("An1HgQjPjHAAkZIAAAAQAAkYDPjIIAAAAQDQjHElAAIAAAAQEmAADPDHIAAAAQDQDIAAEYIAAAAQAAEZjQDHIAAAAQjPDIkmAAIAAAAQklAAjQjIg");
	var mask_3_graphics_288 = new cjs.Graphics().p("An2HhQjQjHAAkaIAAAAQAAkZDQjIIAAAAQDRjHElAAIAAAAQEmAADQDHIAAAAQDRDIAAEZIAAAAQAAEajRDHIAAAAQjQDIkmAAIAAAAQklAAjRjIg");
	var mask_3_graphics_289 = new cjs.Graphics().p("An2HiQjRjIAAkaIAAAAQAAkZDRjIIAAAAQDQjIEmAAIAAAAQEnAADQDIIAAAAQDRDIAAEZIAAAAQAAEajRDIIAAAAQjQDIknAAIAAAAQkmAAjQjIg");
	var mask_3_graphics_290 = new cjs.Graphics().p("An3HjQjRjIAAkbIAAAAQAAkaDRjIIAAAAQDRjIEmAAIAAAAQEnAADRDIIAAAAQDRDIAAEaIAAAAQAAEbjRDIIAAAAQjRDIknAAIAAAAQkmAAjRjIg");
	var mask_3_graphics_291 = new cjs.Graphics().p("An3HjQjRjIAAkbIAAAAQAAkaDRjIIAAAAQDRjIEmAAIAAAAQEnAADRDIIAAAAQDRDIAAEaIAAAAQAAEbjRDIIAAAAQjRDIknAAIAAAAQkmAAjRjIg");
	var mask_3_graphics_292 = new cjs.Graphics().p("An3HjQjRjIAAkbIAAAAQAAkaDRjIIAAAAQDRjIEmAAIAAAAQEnAADRDIIAAAAQDRDIAAEaIAAAAQAAEbjRDIIAAAAQjRDIknAAIAAAAQkmAAjRjIg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(200).to({graphics:mask_3_graphics_200,x:611.3502,y:378.85}).wait(1).to({graphics:mask_3_graphics_201,x:611.3497,y:378.8505}).wait(1).to({graphics:mask_3_graphics_202,x:611.3484,y:378.8509}).wait(1).to({graphics:mask_3_graphics_203,x:611.3461,y:378.8523}).wait(1).to({graphics:mask_3_graphics_204,x:611.343,y:378.8541}).wait(1).to({graphics:mask_3_graphics_205,x:611.3389,y:378.8563}).wait(1).to({graphics:mask_3_graphics_206,x:611.3344,y:378.8586}).wait(1).to({graphics:mask_3_graphics_207,x:611.329,y:378.8618}).wait(1).to({graphics:mask_3_graphics_208,x:611.3223,y:378.8653}).wait(1).to({graphics:mask_3_graphics_209,x:611.3151,y:378.8689}).wait(1).to({graphics:mask_3_graphics_210,x:611.307,y:378.8739}).wait(1).to({graphics:mask_3_graphics_211,x:611.2975,y:378.8784}).wait(1).to({graphics:mask_3_graphics_212,x:611.2872,y:378.8842}).wait(1).to({graphics:mask_3_graphics_213,x:611.2764,y:378.8901}).wait(1).to({graphics:mask_3_graphics_214,x:611.2647,y:378.8968}).wait(1).to({graphics:mask_3_graphics_215,x:611.2521,y:378.9032}).wait(1).to({graphics:mask_3_graphics_216,x:611.2386,y:378.9108}).wait(1).to({graphics:mask_3_graphics_217,x:611.2242,y:378.9184}).wait(1).to({graphics:mask_3_graphics_218,x:611.2094,y:378.9265}).wait(1).to({graphics:mask_3_graphics_219,x:611.1931,y:378.9355}).wait(1).to({graphics:mask_3_graphics_220,x:611.176,y:378.945}).wait(1).to({graphics:mask_3_graphics_221,x:611.158,y:378.9549}).wait(1).to({graphics:mask_3_graphics_222,x:611.1396,y:378.9648}).wait(1).to({graphics:mask_3_graphics_223,x:611.1198,y:378.9756}).wait(1).to({graphics:mask_3_graphics_224,x:611.0991,y:378.9868}).wait(1).to({graphics:mask_3_graphics_225,x:611.0779,y:378.9985}).wait(1).to({graphics:mask_3_graphics_226,x:611.0559,y:379.0103}).wait(1).to({graphics:mask_3_graphics_227,x:611.0325,y:379.0229}).wait(1).to({graphics:mask_3_graphics_228,x:611.0086,y:379.0363}).wait(1).to({graphics:mask_3_graphics_229,x:610.9839,y:379.0494}).wait(1).to({graphics:mask_3_graphics_230,x:610.9583,y:379.0633}).wait(1).to({graphics:mask_3_graphics_231,x:610.9312,y:379.0777}).wait(1).to({graphics:mask_3_graphics_232,x:610.9038,y:379.0926}).wait(1).to({graphics:mask_3_graphics_233,x:610.8759,y:379.1083}).wait(1).to({graphics:mask_3_graphics_234,x:610.8466,y:379.1241}).wait(1).to({graphics:mask_3_graphics_235,x:610.8165,y:379.1407}).wait(1).to({graphics:mask_3_graphics_236,x:610.7854,y:379.1574}).wait(1).to({graphics:mask_3_graphics_237,x:610.7539,y:379.1745}).wait(1).to({graphics:mask_3_graphics_238,x:610.7211,y:379.1925}).wait(1).to({graphics:mask_3_graphics_239,x:610.6878,y:379.2105}).wait(1).to({graphics:mask_3_graphics_240,x:610.6536,y:379.2294}).wait(1).to({graphics:mask_3_graphics_241,x:610.618,y:379.2487}).wait(1).to({graphics:mask_3_graphics_242,x:610.582,y:379.2681}).wait(1).to({graphics:mask_3_graphics_243,x:610.5451,y:379.2888}).wait(1).to({graphics:mask_3_graphics_244,x:610.5069,y:379.3091}).wait(1).to({graphics:mask_3_graphics_245,x:610.4682,y:379.3302}).wait(1).to({graphics:mask_3_graphics_246,x:610.4286,y:379.3522}).wait(1).to({graphics:mask_3_graphics_247,x:610.389,y:379.3734}).wait(1).to({graphics:mask_3_graphics_248,x:610.3498,y:379.3945}).wait(1).to({graphics:mask_3_graphics_249,x:610.3125,y:379.4148}).wait(1).to({graphics:mask_3_graphics_250,x:610.2756,y:379.4355}).wait(1).to({graphics:mask_3_graphics_251,x:610.2391,y:379.4548}).wait(1).to({graphics:mask_3_graphics_252,x:610.204,y:379.4742}).wait(1).to({graphics:mask_3_graphics_253,x:610.1694,y:379.4931}).wait(1).to({graphics:mask_3_graphics_254,x:610.1357,y:379.5115}).wait(1).to({graphics:mask_3_graphics_255,x:610.1032,y:379.5291}).wait(1).to({graphics:mask_3_graphics_256,x:610.0713,y:379.5462}).wait(1).to({graphics:mask_3_graphics_257,x:610.0402,y:379.5628}).wait(1).to({graphics:mask_3_graphics_258,x:610.0105,y:379.5795}).wait(1).to({graphics:mask_3_graphics_259,x:609.9813,y:379.5952}).wait(1).to({graphics:mask_3_graphics_260,x:609.9529,y:379.611}).wait(1).to({graphics:mask_3_graphics_261,x:609.9255,y:379.6258}).wait(1).to({graphics:mask_3_graphics_262,x:609.8989,y:379.6402}).wait(1).to({graphics:mask_3_graphics_263,x:609.8733,y:379.6542}).wait(1).to({graphics:mask_3_graphics_264,x:609.8481,y:379.6673}).wait(1).to({graphics:mask_3_graphics_265,x:609.8242,y:379.6807}).wait(1).to({graphics:mask_3_graphics_266,x:609.8013,y:379.6933}).wait(1).to({graphics:mask_3_graphics_267,x:609.7792,y:379.705}).wait(1).to({graphics:mask_3_graphics_268,x:609.7576,y:379.7167}).wait(1).to({graphics:mask_3_graphics_269,x:609.7374,y:379.728}).wait(1).to({graphics:mask_3_graphics_270,x:609.718,y:379.7388}).wait(1).to({graphics:mask_3_graphics_271,x:609.6987,y:379.7491}).wait(1).to({graphics:mask_3_graphics_272,x:609.6811,y:379.7586}).wait(1).to({graphics:mask_3_graphics_273,x:609.6645,y:379.7681}).wait(1).to({graphics:mask_3_graphics_274,x:609.6483,y:379.7771}).wait(1).to({graphics:mask_3_graphics_275,x:609.633,y:379.7852}).wait(1).to({graphics:mask_3_graphics_276,x:609.6186,y:379.7932}).wait(1).to({graphics:mask_3_graphics_277,x:609.6046,y:379.8004}).wait(1).to({graphics:mask_3_graphics_278,x:609.5925,y:379.8072}).wait(1).to({graphics:mask_3_graphics_279,x:609.5804,y:379.8135}).wait(1).to({graphics:mask_3_graphics_280,x:609.5695,y:379.8198}).wait(1).to({graphics:mask_3_graphics_281,x:609.5596,y:379.8252}).wait(1).to({graphics:mask_3_graphics_282,x:609.5506,y:379.8297}).wait(1).to({graphics:mask_3_graphics_283,x:609.5425,y:379.8346}).wait(1).to({graphics:mask_3_graphics_284,x:609.5349,y:379.8382}).wait(1).to({graphics:mask_3_graphics_285,x:609.5286,y:379.8423}).wait(1).to({graphics:mask_3_graphics_286,x:609.5227,y:379.845}).wait(1).to({graphics:mask_3_graphics_287,x:609.5178,y:379.8477}).wait(1).to({graphics:mask_3_graphics_288,x:609.5137,y:379.8495}).wait(1).to({graphics:mask_3_graphics_289,x:609.5106,y:379.8517}).wait(1).to({graphics:mask_3_graphics_290,x:609.5088,y:379.8526}).wait(1).to({graphics:mask_3_graphics_291,x:609.5074,y:379.8535}).wait(1).to({graphics:mask_3_graphics_292,x:609.507,y:379.8535}).wait(518));

	// Layer_33
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(1,1,1).p("AlFgNIKLAb");
	this.shape_1.setTransform(576.875,378.475);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(200).to({_off:false},0).wait(610));

	// Layer_6 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_200 = new cjs.Graphics().p("AgMAMQgFgFAAgHIAAAAQAAgGAFgFIAAAAQAFgGAHAAIAAAAQAIAAAFAGIAAAAQAFAFAAAGIAAAAQAAAHgFAFIAAAAQgFAGgIAAIAAAAQgHAAgFgGg");
	var mask_4_graphics_201 = new cjs.Graphics().p("AgMANQgGgGAAgHIAAAAQAAgGAGgGIAAAAQAFgFAHAAIAAAAQAIAAAFAFIAAAAQAGAGAAAGIAAAAQAAAHgGAGIAAAAQgFAFgIAAIAAAAQgHAAgFgFg");
	var mask_4_graphics_202 = new cjs.Graphics().p("AgNAOQgGgGAAgIIAAAAQAAgHAGgGIAAAAQAGgFAHAAIAAAAQAIAAAGAFIAAAAQAGAGAAAHIAAAAQAAAIgGAGIAAAAQgGAFgIAAIAAAAQgHAAgGgFg");
	var mask_4_graphics_203 = new cjs.Graphics().p("AgPAPQgHgGAAgJIAAAAQAAgIAHgGIAAAAQAHgHAIAAIAAAAQAJAAAHAHIAAAAQAHAGAAAIIAAAAQAAAJgHAGIAAAAQgHAHgJAAIAAAAQgIAAgHgHg");
	var mask_4_graphics_204 = new cjs.Graphics().p("AgSASQgHgIAAgKIAAAAQAAgJAHgIIAAAAQAIgHAKAAIAAAAQALAAAIAHIAAAAQAHAIAAAJIAAAAQAAAKgHAIIAAAAQgIAHgLAAIAAAAQgKAAgIgHg");
	var mask_4_graphics_205 = new cjs.Graphics().p("AgVAVQgJgJAAgMIAAAAQAAgLAJgJIAAAAQAJgIAMAAIAAAAQANAAAJAIIAAAAQAJAJAAALIAAAAQAAAMgJAJIAAAAQgJAIgNAAIAAAAQgMAAgJgIg");
	var mask_4_graphics_206 = new cjs.Graphics().p("AgZAYQgKgKAAgOIAAAAQAAgNAKgLIAAAAQALgKAOAAIAAAAQAPAAALAKIAAAAQAKALAAANIAAAAQAAAOgKAKIAAAAQgLALgPAAIAAAAQgOAAgLgLg");
	var mask_4_graphics_207 = new cjs.Graphics().p("AgdAdQgNgMAAgRIAAAAQAAgQANgMIAAAAQAMgMARAAIAAAAQASAAAMAMIAAAAQANAMAAAQIAAAAQAAARgNAMIAAAAQgMAMgSAAIAAAAQgRAAgMgMg");
	var mask_4_graphics_208 = new cjs.Graphics().p("AgiAiQgPgOAAgUIAAAAQAAgTAPgOIAAAAQAOgOAUAAIAAAAQAVAAAOAOIAAAAQAPAOAAATIAAAAQAAAUgPAOIAAAAQgOAOgVAAIAAAAQgUAAgOgOg");
	var mask_4_graphics_209 = new cjs.Graphics().p("AgoAoQgSgRAAgXIAAAAQAAgWASgRIAAAAQARgQAXAAIAAAAQAYAAARAQIAAAAQASARAAAWIAAAAQAAAXgSARIAAAAQgRAQgYAAIAAAAQgXAAgRgQg");
	var mask_4_graphics_210 = new cjs.Graphics().p("AgvAuQgUgTAAgbIAAAAQAAgaAUgTIAAAAQAUgTAbAAIAAAAQAcAAAUATIAAAAQAUATAAAaIAAAAQAAAbgUATIAAAAQgUATgcAAIAAAAQgbAAgUgTg");
	var mask_4_graphics_211 = new cjs.Graphics().p("Ag2A1QgXgWAAgfIAAAAQAAgeAXgWIAAAAQAXgWAfAAIAAAAQAgAAAXAWIAAAAQAXAWAAAeIAAAAQAAAfgXAWIAAAAQgXAWggAAIAAAAQgfAAgXgWg");
	var mask_4_graphics_212 = new cjs.Graphics().p("Ag/A9QgagZAAgkIAAAAQAAgjAagZIAAAAQAbgZAkAAIAAAAQAlAAAbAZIAAAAQAaAZAAAjIAAAAQAAAkgaAZIAAAAQgbAZglAAIAAAAQgkAAgbgZg");
	var mask_4_graphics_213 = new cjs.Graphics().p("AhHBFQgegcAAgpIAAAAQAAgoAegcIAAAAQAegdApAAIAAAAQAqAAAeAdIAAAAQAeAcAAAoIAAAAQAAApgeAcIAAAAQgeAdgqAAIAAAAQgpAAgegdg");
	var mask_4_graphics_214 = new cjs.Graphics().p("AhRBOQgiggAAguIAAAAQAAgtAiggIAAAAQAighAvAAIAAAAQAwAAAiAhIAAAAQAiAgAAAtIAAAAQAAAugiAgIAAAAQgiAhgwAAIAAAAQgvAAgighg");
	var mask_4_graphics_215 = new cjs.Graphics().p("AhbBYQgmgkAAg0IAAAAQAAgzAmgkIAAAAQAmglA1AAIAAAAQA2AAAmAlIAAAAQAmAkAAAzIAAAAQAAA0gmAkIAAAAQgmAlg2AAIAAAAQg1AAgmglg");
	var mask_4_graphics_216 = new cjs.Graphics().p("AhmBjQgrgpAAg6IAAAAQAAg5ArgpIAAAAQArgoA7AAIAAAAQA8AAArAoIAAAAQArApAAA5IAAAAQAAA6grApIAAAAQgrAog8AAIAAAAQg7AAgrgog");
	var mask_4_graphics_217 = new cjs.Graphics().p("AhyBuQgvguAAhAIAAAAQAAg/AvguIAAAAQAwgtBCAAIAAAAQBDAAAvAtIAAAAQAwAuAAA/IAAAAQAABAgwAuIAAAAQgvAthDAAIAAAAQhCAAgwgtg");
	var mask_4_graphics_218 = new cjs.Graphics().p("Ah+B5Qg0gyAAhHIAAAAQAAhGA0gzIAAAAQA1gyBJAAIAAAAQBKAAA1AyIAAAAQA0AzAABGIAAAAQAABHg0AyIAAAAQg1AzhKAAIAAAAQhJAAg1gzg");
	var mask_4_graphics_219 = new cjs.Graphics().p("AiLCGQg6g4AAhOIAAAAQAAhNA6g4IAAAAQA6g3BRAAIAAAAQBSAAA6A3IAAAAQA6A4AABNIAAAAQAABOg6A4IAAAAQg6A3hSAAIAAAAQhRAAg6g3g");
	var mask_4_graphics_220 = new cjs.Graphics().p("AiZCTQg/g9AAhWIAAAAQAAhVA/g9IAAAAQBAg9BZAAIAAAAQBaAAA/A9IAAAAQBAA9AABVIAAAAQAABWhAA9IAAAAQg/A9haAAIAAAAQhZAAhAg9g");
	var mask_4_graphics_221 = new cjs.Graphics().p("AinChQhFhDAAheIAAAAQAAhdBFhDIAAAAQBGhDBhAAIAAAAQBiAABGBDIAAAAQBFBDAABdIAAAAQAABehFBDIAAAAQhGBDhiAAIAAAAQhhAAhGhDg");
	var mask_4_graphics_222 = new cjs.Graphics().p("Ai2CvQhMhIAAhnIAAAAQAAhmBMhIIAAAAQBMhJBqAAIAAAAQBrAABMBJIAAAAQBMBIAABmIAAAAQAABnhMBIIAAAAQhMBJhrAAIAAAAQhqAAhMhJg");
	var mask_4_graphics_223 = new cjs.Graphics().p("AjGC+QhShOAAhwIAAAAQAAhvBShPIAAAAQBThOBzAAIAAAAQB0AABTBOIAAAAQBSBPAABvIAAAAQAABwhSBOIAAAAQhTBPh0AAIAAAAQhzAAhThPg");
	var mask_4_graphics_224 = new cjs.Graphics().p("AjWDOQhahVAAh5IAAAAQAAh4BahVIAAAAQBZhWB9AAIAAAAQB+AABZBWIAAAAQBaBVAAB4IAAAAQAAB5haBVIAAAAQhZBWh+AAIAAAAQh9AAhZhWg");
	var mask_4_graphics_225 = new cjs.Graphics().p("AjoDfQhghcAAiDIAAAAQAAiCBghcIAAAAQBhhcCHAAIAAAAQCIAABhBcIAAAAQBgBcAACCIAAAAQAACDhgBcIAAAAQhhBciIAAIAAAAQiHAAhhhcg");
	var mask_4_graphics_226 = new cjs.Graphics().p("Aj6DwQhnhjAAiNIAAAAQAAiMBnhjIAAAAQBohjCSAAIAAAAQCTAABnBjIAAAAQBoBjAACMIAAAAQAACNhoBjIAAAAQhnBjiTAAIAAAAQiSAAhohjg");
	var mask_4_graphics_227 = new cjs.Graphics().p("AkMECQhwhrAAiXIAAAAQAAiWBwhrIAAAAQBvhrCdAAIAAAAQCeAABvBrIAAAAQBwBrAACWIAAAAQAACXhwBrIAAAAQhvBrieAAIAAAAQidAAhvhrg");
	var mask_4_graphics_228 = new cjs.Graphics().p("AkgEUQh3hyAAiiIAAAAQAAihB3hyIAAAAQB4hzCoAAIAAAAQCpAAB3BzIAAAAQB4ByAAChIAAAAQAACih4ByIAAAAQh3BzipAAIAAAAQioAAh4hzg");
	var mask_4_graphics_229 = new cjs.Graphics().p("Ak0EnQh/h6AAitIAAAAQAAisB/h7IAAAAQCAh6C0AAIAAAAQC1AAB/B6IAAAAQCAB7AACsIAAAAQAACtiAB6IAAAAQh/B7i1AAIAAAAQi0AAiAh7g");
	var mask_4_graphics_230 = new cjs.Graphics().p("AlIE7QiJiCAAi5IAAAAQAAi4CJiDIAAAAQCIiCDAAAIAAAAQDBAACICCIAAAAQCJCDAAC4IAAAAQAAC5iJCCIAAAAQiICDjBAAIAAAAQjAAAiIiDg");
	var mask_4_graphics_231 = new cjs.Graphics().p("AleFQQiRiLAAjFIAAAAQAAjECRiLIAAAAQCSiLDMAAIAAAAQDNAACSCLIAAAAQCRCLAADEIAAAAQAADFiRCLIAAAAQiSCLjNAAIAAAAQjMAAiSiLg");
	var mask_4_graphics_232 = new cjs.Graphics().p("Al0FlQiaiUAAjRIAAAAQAAjQCaiUIAAAAQCbiUDZAAIAAAAQDaAACbCUIAAAAQCaCUAADQIAAAAQAADRiaCUIAAAAQibCUjaAAIAAAAQjZAAibiUg");
	var mask_4_graphics_233 = new cjs.Graphics().p("AmLF7QikidAAjeIAAAAQAAjdCkidIAAAAQCkidDnAAIAAAAQDoAACkCdIAAAAQCkCdAADdIAAAAQAADeikCdIAAAAQikCdjoAAIAAAAQjnAAikidg");
	var mask_4_graphics_234 = new cjs.Graphics().p("AmiGSQiuinAAjrIAAAAQAAjqCuinIAAAAQCtimD1AAIAAAAQD2AACtCmIAAAAQCuCnAADqIAAAAQAADriuCnIAAAAQitCmj2AAIAAAAQj1AAitimg");
	var mask_4_graphics_235 = new cjs.Graphics().p("Am7GpQi3iwAAj5IAAAAQAAj4C3iwIAAAAQC4iwEDAAIAAAAQEEAAC3CwIAAAAQC4CwAAD4IAAAAQAAD5i4CwIAAAAQi3CwkEAAIAAAAQkDAAi4iwg");
	var mask_4_graphics_236 = new cjs.Graphics().p("AnTHBQjCi6AAkHIAAAAQAAkGDCi6IAAAAQDCi6ERAAIAAAAQESAADCC6IAAAAQDCC6AAEGIAAAAQAAEHjCC6IAAAAQjCC6kSAAIAAAAQkRAAjCi6g");
	var mask_4_graphics_237 = new cjs.Graphics().p("AntHZQjNjEAAkVIAAAAQAAkUDNjEIAAAAQDNjEEgAAIAAAAQEhAADNDEIAAAAQDNDEAAEUIAAAAQAAEVjNDEIAAAAQjNDEkhAAIAAAAQkgAAjNjEg");
	var mask_4_graphics_238 = new cjs.Graphics().p("AoIHzQjXjPAAkkIAAAAQAAkjDXjPIAAAAQDYjOEwAAIAAAAQExAADXDOIAAAAQDYDPAAEjIAAAAQAAEkjYDPIAAAAQjXDOkxAAIAAAAQkwAAjYjOg");
	var mask_4_graphics_239 = new cjs.Graphics().p("AojIMQjijZAAkzIAAAAQAAkyDijaIAAAAQDjjZFAAAIAAAAQFBAADiDZIAAAAQDjDaAAEyIAAAAQAAEzjjDZIAAAAQjiDalBAAIAAAAQlAAAjjjag");
	var mask_4_graphics_240 = new cjs.Graphics().p("Ao+InQjujkAAlDIAAAAQAAlCDujkIAAAAQDujkFQAAIAAAAQFRAADuDkIAAAAQDuDkAAFCIAAAAQAAFDjuDkIAAAAQjuDklRAAIAAAAQlQAAjujkg");
	var mask_4_graphics_241 = new cjs.Graphics().p("ApbJCQj6jvAAlTIAAAAQAAlSD6jwIAAAAQD6jvFhAAIAAAAQFiAAD6DvIAAAAQD6DwAAFSIAAAAQAAFTj6DvIAAAAQj6DwliAAIAAAAQlhAAj6jwg");
	var mask_4_graphics_242 = new cjs.Graphics().p("Ap4JeQkGj7AAljIAAAAQAAliEGj8IAAAAQEGj7FyAAIAAAAQFzAAEGD7IAAAAQEGD8AAFiIAAAAQAAFjkGD7IAAAAQkGD8lzAAIAAAAQlyAAkGj8g");
	var mask_4_graphics_243 = new cjs.Graphics().p("AqWJ7QkSkHAAl0IAAAAQAAlzESkHIAAAAQETkHGDAAIAAAAQGEAAETEHIAAAAQESEHAAFzIAAAAQAAF0kSEHIAAAAQkTEHmEAAIAAAAQmDAAkTkHg");
	var mask_4_graphics_244 = new cjs.Graphics().p("Aq0KYQkfkTAAmFIAAAAQAAmEEfkTIAAAAQEfkUGVAAIAAAAQGWAAEfEUIAAAAQEfETAAGEIAAAAQAAGFkfETIAAAAQkfETmWABIAAAAQmVgBkfkTg");
	var mask_4_graphics_245 = new cjs.Graphics().p("ArUK2QkskfAAmXIAAAAQAAmWEskfIAAAAQEtkgGnAAIAAAAQGoAAEsEgIAAAAQEtEfAAGWIAAAAQAAGXktEfIAAAAQksEgmoAAIAAAAQmnAAktkgg");
	var mask_4_graphics_246 = new cjs.Graphics().p("Ar0LVQk5ksAAmpIAAAAQAAmoE5ksIAAAAQE6ksG6AAIAAAAQG7AAE5EsIAAAAQE6EsAAGoIAAAAQAAGpk6EsIAAAAQk5Esm7AAIAAAAQm6AAk6ksg");
	var mask_4_graphics_247 = new cjs.Graphics().p("AsULzQlGk4AAm7IAAAAQAAm6FGk5IAAAAQFHk5HNAAIAAAAQHOAAFGE5IAAAAQFHE5AAG6IAAAAQAAG7lHE4IAAAAQlGE6nOAAIAAAAQnNAAlHk6g");
	var mask_4_graphics_248 = new cjs.Graphics().p("AszMRQlTlFAAnMIAAAAQAAnLFTlGIAAAAQFUlFHfAAIAAAAQHgAAFUFFIAAAAQFTFGAAHLIAAAAQAAHMlTFFIAAAAQlUFGngAAIAAAAQnfAAlUlGg");
	var mask_4_graphics_249 = new cjs.Graphics().p("AtSMvQlglSAAndIAAAAQAAncFglSIAAAAQFhlRHxAAIAAAAQHyAAFgFRIAAAAQFhFSAAHcIAAAAQAAHdlhFSIAAAAQlgFRnyAAIAAAAQnxAAlhlRg");
	var mask_4_graphics_250 = new cjs.Graphics().p("AtvNLQltldAAnuIAAAAQAAntFtleIAAAAQFsldIDAAIAAAAQIEAAFsFdIAAAAQFtFeAAHtIAAAAQAAHultFdIAAAAQlsFeoEAAIAAAAQoDAAlsleg");
	var mask_4_graphics_251 = new cjs.Graphics().p("AuNNnQl4lpAAn+IAAAAQAAn9F4lqIAAAAQF5loIUAAIAAAAQIVAAF4FoIAAAAQF5FqAAH9IAAAAQAAH+l5FpIAAAAQl4FpoVAAIAAAAQoUAAl5lpg");
	var mask_4_graphics_252 = new cjs.Graphics().p("AupOCQmEl0AAoOIAAAAQAAoNGEl1IAAAAQGFl0IkAAIAAAAQIlAAGFF0IAAAAQGEF1AAINIAAAAQAAIOmEF0IAAAAQmFF1olAAIAAAAQokAAmFl1g");
	var mask_4_graphics_253 = new cjs.Graphics().p("AvFOdQmQl/AAoeIAAAAQAAodGQl/IAAAAQGQmAI1AAIAAAAQI2AAGPGAIAAAAQGRF/AAIdIAAAAQAAIemRF/IAAAAQmPGAo2AAIAAAAQo1AAmQmAg");
	var mask_4_graphics_254 = new cjs.Graphics().p("AvgO3QmbmKAAotIAAAAQAAosGbmKIAAAAQGcmKJEAAIAAAAQJFAAGbGKIAAAAQGcGKAAIsIAAAAQAAItmcGKIAAAAQmbGKpFAAIAAAAQpEAAmcmKg");
	var mask_4_graphics_255 = new cjs.Graphics().p("Av6PQQmmmUAAo8IAAAAQAAo7GmmVIAAAAQGmmUJUAAIAAAAQJVAAGmGUIAAAAQGmGVAAI7IAAAAQAAI8mmGUIAAAAQmmGVpVAAIAAAAQpUAAmmmVg");
	var mask_4_graphics_256 = new cjs.Graphics().p("AwUPpQmxmfAApKIAAAAQAApJGxmfIAAAAQGxmfJjAAIAAAAQJkAAGwGfIAAAAQGyGfAAJJIAAAAQAAJKmyGfIAAAAQmwGfpkAAIAAAAQpjAAmxmfg");
	var mask_4_graphics_257 = new cjs.Graphics().p("AwtQBQm7mpAApYIAAAAQAApXG7mpIAAAAQG7mpJyAAIAAAAQJzAAG6GpIAAAAQG8GpAAJXIAAAAQAAJYm8GpIAAAAQm6GppzAAIAAAAQpyAAm7mpg");
	var mask_4_graphics_258 = new cjs.Graphics().p("AxFQYQnFmyAApmIAAAAQAAplHFmyIAAAAQHFmyKAAAIAAAAQKBAAHFGyIAAAAQHFGyAAJlIAAAAQAAJmnFGyIAAAAQnFGyqBAAIAAAAQqAAAnFmyg");
	var mask_4_graphics_259 = new cjs.Graphics().p("AxdQuQnOm7AApzIAAAAQAApyHOm8IAAAAQHPm7KOAAIAAAAQKPAAHOG7IAAAAQHPG8AAJyIAAAAQAAJznPG7IAAAAQnOG8qPAAIAAAAQqOAAnPm8g");
	var mask_4_graphics_260 = new cjs.Graphics().p("Ax0REQnYnEAAqAIAAAAQAAp/HYnFIAAAAQHZnEKbAAIAAAAQKcAAHYHEIAAAAQHZHFAAJ/IAAAAQAAKAnZHEIAAAAQnYHFqcAAIAAAAQqbAAnZnFg");
	var mask_4_graphics_261 = new cjs.Graphics().p("AyKRaQnhnOAAqMIAAAAQAAqLHhnOIAAAAQHinNKoAAIAAAAQKpAAHhHNIAAAAQHiHOAAKLIAAAAQAAKMniHOIAAAAQnhHNqpAAIAAAAQqoAAninNg");
	var mask_4_graphics_262 = new cjs.Graphics().p("AyfRuQnqnWAAqYIAAAAQAAqXHqnXIAAAAQHrnVK0AAIAAAAQK1AAHrHVIAAAAQHqHXAAKXIAAAAQAAKYnqHWIAAAAQnrHWq1AAIAAAAQq0AAnrnWg");
	var mask_4_graphics_263 = new cjs.Graphics().p("Ay0SCQnzneAAqkIAAAAQAAqjHznfIAAAAQHzndLBAAIAAAAQLCAAHyHdIAAAAQH0HfAAKjIAAAAQAAKkn0HeIAAAAQnyHerCAAIAAAAQrBAAnzneg");
	var mask_4_graphics_264 = new cjs.Graphics().p("AzISVQn7nmAAqvIAAAAQAAquH7nnIAAAAQH8nmLMAAIAAAAQLNAAH7HmIAAAAQH8HnAAKuIAAAAQAAKvn8HmIAAAAQn7HnrNAAIAAAAQrMAAn8nng");
	var mask_4_graphics_265 = new cjs.Graphics().p("AzbSoQoDnuAAq6IAAAAQAAq5IDnuIAAAAQIDnuLYAAIAAAAQLZAAIDHuIAAAAQIDHuAAK5IAAAAQAAK6oDHuIAAAAQoDHurZAAIAAAAQrYAAoDnug");
	var mask_4_graphics_266 = new cjs.Graphics().p("AzuS6QoLn1AArFIAAAAQAArEILn1IAAAAQILn1LjAAIAAAAQLkAAIKH1IAAAAQIMH1AALEIAAAAQAALFoMH1IAAAAQoKH1rkAAIAAAAQrjAAoLn1g");
	var mask_4_graphics_267 = new cjs.Graphics().p("A0ATLQoSn8AArPIAAAAQAArOISn8IAAAAQITn8LtAAIAAAAQLuAAISH8IAAAAQITH8AALOIAAAAQAALPoTH8IAAAAQoSH8ruAAIAAAAQrtAAoTn8g");
	var mask_4_graphics_268 = new cjs.Graphics().p("A0RTbQoZoDAArYIAAAAQAArXIZoEIAAAAQIaoDL3AAIAAAAQL4AAIZIDIAAAAQIaIEAALXIAAAAQAALYoaIDIAAAAQoZIEr4AAIAAAAQr3AAoaoEg");
	var mask_4_graphics_269 = new cjs.Graphics().p("A0iTrQogoJAAriIAAAAQAArhIgoKIAAAAQIhoJMBAAIAAAAQMCAAIgIJIAAAAQIhIKAALhIAAAAQAALiohIJIAAAAQogIKsCAAIAAAAQsBAAohoKg");
	var mask_4_graphics_270 = new cjs.Graphics().p("A0xT6QonoQAArqIAAAAQAArpInoRIAAAAQInoPMKAAIAAAAQMLAAInIPIAAAAQInIRAALpIAAAAQAALqonIQIAAAAQonIQsLAAIAAAAQsKAAonoQg");
	var mask_4_graphics_271 = new cjs.Graphics().p("A1BUJQosoWAArzIAAAAQAAryIsoWIAAAAQIuoWMTAAIAAAAQMUAAItIWIAAAAQItIWAALyIAAAAQAALzotIWIAAAAQotIWsUAAIAAAAQsTAAouoWg");
	var mask_4_graphics_272 = new cjs.Graphics().p("A1PUWQozobAAr7IAAAAQAAr6IzocIAAAAQI0obMbAAIAAAAQMcAAIzIbIAAAAQI0IcAAL6IAAAAQAAL7o0IbIAAAAQozIcscAAIAAAAQsbAAo0ocg");
	var mask_4_graphics_273 = new cjs.Graphics().p("A1dUkQo4ohAAsDIAAAAQAAsCI4ohIAAAAQI6ohMjAAIAAAAQMkAAI5IhIAAAAQI5IhAAMCIAAAAQAAMDo5IhIAAAAQo5IhskAAIAAAAQsjAAo6ohg");
	var mask_4_graphics_274 = new cjs.Graphics().p("A1qUwQo+omAAsKIAAAAQAAsJI+onIAAAAQI/omMrAAIAAAAQMsAAI+ImIAAAAQI/InAAMJIAAAAQAAMKo/ImIAAAAQo+InssAAIAAAAQsrAAo/ong");
	var mask_4_graphics_275 = new cjs.Graphics().p("A12U8QpDorAAsRIAAAAQAAsQJDorIAAAAQJEorMyAAIAAAAQMzAAJDIrIAAAAQJEIrAAMQIAAAAQAAMRpEIrIAAAAQpDIrszAAIAAAAQsyAApEorg");
	var mask_4_graphics_276 = new cjs.Graphics().p("A2CVHQpHowAAsXIAAAAQAAsWJHoxIAAAAQJJovM5AAIAAAAQM6AAJIIvIAAAAQJIIxAAMWIAAAAQAAMXpIIwIAAAAQpIIws6AAIAAAAQs5AApJowg");
	var mask_4_graphics_277 = new cjs.Graphics().p("A2MVRQpNozAAseIAAAAQAAsdJNo0IAAAAQJNo0M/AAIAAAAQNAAAJNI0IAAAAQJNI0AAMdIAAAAQAAMepNIzIAAAAQpNI1tAAAIAAAAQs/AApNo1g");
	var mask_4_graphics_278 = new cjs.Graphics().p("A2XVbQpQo4AAsjIAAAAQAAsiJQo5IAAAAQJSo4NFAAIAAAAQNGAAJRI4IAAAAQJRI5AAMiIAAAAQAAMjpRI4IAAAAQpRI5tGAAIAAAAQtFAApSo5g");
	var mask_4_graphics_279 = new cjs.Graphics().p("A2gVkQpVo7AAspIAAAAQAAsoJVo8IAAAAQJVo7NLAAIAAAAQNMAAJUI7IAAAAQJWI8AAMoIAAAAQAAMppWI7IAAAAQpUI8tMAAIAAAAQtLAApVo8g");
	var mask_4_graphics_280 = new cjs.Graphics().p("A2pVtQpYo/AAsuIAAAAQAAstJYo/IAAAAQJZo/NQAAIAAAAQNRAAJYI/IAAAAQJZI/AAMtIAAAAQAAMupZI/IAAAAQpYI/tRAAIAAAAQtQAApZo/g");
	var mask_4_graphics_281 = new cjs.Graphics().p("A2xV0QpcpCAAsyIAAAAQAAsxJcpDIAAAAQJcpCNVAAIAAAAQNWAAJbJCIAAAAQJdJDAAMxIAAAAQAAMypdJCIAAAAQpbJDtWAAIAAAAQtVAApcpDg");
	var mask_4_graphics_282 = new cjs.Graphics().p("A24V7QpfpFAAs2IAAAAQAAs1JfpGIAAAAQJfpFNZAAIAAAAQNaAAJfJFIAAAAQJfJGAAM1IAAAAQAAM2pfJFIAAAAQpfJGtaAAIAAAAQtZAApfpGg");
	var mask_4_graphics_283 = new cjs.Graphics().p("A2/WCQphpIAAs6IAAAAQAAs5JhpJIAAAAQJipHNdAAIAAAAQNeAAJhJHIAAAAQJiJJAAM5IAAAAQAAM6piJIIAAAAQphJIteAAIAAAAQtdAApipIg");
	var mask_4_graphics_284 = new cjs.Graphics().p("A3FWIQpkpLAAs9IAAAAQAAs8JkpLIAAAAQJkpKNhAAIAAAAQNiAAJjJKIAAAAQJlJLAAM8IAAAAQAAM9plJLIAAAAQpjJKtiAAIAAAAQthAApkpKg");
	var mask_4_graphics_285 = new cjs.Graphics().p("A3KWNQpmpNAAtAIAAAAQAAs/JmpNIAAAAQJmpNNkAAIAAAAQNlAAJmJNIAAAAQJmJNAAM/IAAAAQAANApmJNIAAAAQpmJNtlAAIAAAAQtkAApmpNg");
	var mask_4_graphics_286 = new cjs.Graphics().p("A3PWRQpopOAAtDIAAAAQAAtCJopPIAAAAQJppONmAAIAAAAQNnAAJoJOIAAAAQJpJPAANCIAAAAQAANDppJOIAAAAQpoJPtnAAIAAAAQtmAApppPg");
	var mask_4_graphics_287 = new cjs.Graphics().p("A3TWVQpppQAAtFIAAAAQAAtEJppQIAAAAQJqpQNpAAIAAAAQNqAAJpJQIAAAAQJqJQAANEIAAAAQAANFpqJQIAAAAQppJQtqAAIAAAAQtpAApqpQg");
	var mask_4_graphics_288 = new cjs.Graphics().p("A3WWYQprpRAAtHIAAAAQAAtGJrpRIAAAAQJspRNqAAIAAAAQNrAAJrJRIAAAAQJsJRAANGIAAAAQAANHpsJRIAAAAQprJRtrAAIAAAAQtqAApspRg");
	var mask_4_graphics_289 = new cjs.Graphics().p("A3YWaQpspSAAtIIAAAAQAAtHJspTIAAAAQJspSNsAAIAAAAQNtAAJsJSIAAAAQJsJTAANHIAAAAQAANIpsJSIAAAAQpsJTttAAIAAAAQtsAApspTg");
	var mask_4_graphics_290 = new cjs.Graphics().p("A3aWcQptpTAAtJIAAAAQAAtIJtpTIAAAAQJtpTNtAAIAAAAQNuAAJsJTIAAAAQJuJTAANIIAAAAQAANJpuJTIAAAAQpsJTtuAAIAAAAQttAAptpTg");
	var mask_4_graphics_291 = new cjs.Graphics().p("A3bWdQptpTAAtKIAAAAQAAtJJtpTIAAAAQJupTNtAAIAAAAQNuAAJtJTIAAAAQJuJTAANJIAAAAQAANKpuJTIAAAAQptJTtuAAIAAAAQttAApupTg");
	var mask_4_graphics_292 = new cjs.Graphics().p("A3cWdQptpTAAtKIAAAAQAAtJJtpUIAAAAQJupTNuAAIAAAAQNvAAJtJTIAAAAQJuJUAANJIAAAAQAANKpuJTIAAAAQptJUtvAAIAAAAQtuAApupUg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(200).to({graphics:mask_4_graphics_200,x:541.3,y:175.7502}).wait(1).to({graphics:mask_4_graphics_201,x:541.3,y:175.7506}).wait(1).to({graphics:mask_4_graphics_202,x:541.3005,y:175.752}).wait(1).to({graphics:mask_4_graphics_203,x:541.3005,y:175.7542}).wait(1).to({graphics:mask_4_graphics_204,x:541.3005,y:175.7583}).wait(1).to({graphics:mask_4_graphics_205,x:541.3009,y:175.7628}).wait(1).to({graphics:mask_4_graphics_206,x:541.3009,y:175.7682}).wait(1).to({graphics:mask_4_graphics_207,x:541.3014,y:175.7745}).wait(1).to({graphics:mask_4_graphics_208,x:541.3018,y:175.7817}).wait(1).to({graphics:mask_4_graphics_209,x:541.3027,y:175.7902}).wait(1).to({graphics:mask_4_graphics_210,x:541.3032,y:175.7997}).wait(1).to({graphics:mask_4_graphics_211,x:541.3036,y:175.8105}).wait(1).to({graphics:mask_4_graphics_212,x:541.3045,y:175.8222}).wait(1).to({graphics:mask_4_graphics_213,x:541.305,y:175.8339}).wait(1).to({graphics:mask_4_graphics_214,x:541.3059,y:175.8478}).wait(1).to({graphics:mask_4_graphics_215,x:541.3068,y:175.8622}).wait(1).to({graphics:mask_4_graphics_216,x:541.3072,y:175.8775}).wait(1).to({graphics:mask_4_graphics_217,x:541.3086,y:175.8942}).wait(1).to({graphics:mask_4_graphics_218,x:541.3095,y:175.9113}).wait(1).to({graphics:mask_4_graphics_219,x:541.3104,y:175.9297}).wait(1).to({graphics:mask_4_graphics_220,x:541.3117,y:175.9495}).wait(1).to({graphics:mask_4_graphics_221,x:541.3131,y:175.9698}).wait(1).to({graphics:mask_4_graphics_222,x:541.3144,y:175.9914}).wait(1).to({graphics:mask_4_graphics_223,x:541.3153,y:176.0135}).wait(1).to({graphics:mask_4_graphics_224,x:541.3172,y:176.0368}).wait(1).to({graphics:mask_4_graphics_225,x:541.3185,y:176.0616}).wait(1).to({graphics:mask_4_graphics_226,x:541.3198,y:176.0868}).wait(1).to({graphics:mask_4_graphics_227,x:541.3216,y:176.1133}).wait(1).to({graphics:mask_4_graphics_228,x:541.323,y:176.1408}).wait(1).to({graphics:mask_4_graphics_229,x:541.3244,y:176.1696}).wait(1).to({graphics:mask_4_graphics_230,x:541.3266,y:176.1984}).wait(1).to({graphics:mask_4_graphics_231,x:541.3279,y:176.229}).wait(1).to({graphics:mask_4_graphics_232,x:541.3297,y:176.26}).wait(1).to({graphics:mask_4_graphics_233,x:541.332,y:176.2929}).wait(1).to({graphics:mask_4_graphics_234,x:541.3338,y:176.3262}).wait(1).to({graphics:mask_4_graphics_235,x:541.3356,y:176.3608}).wait(1).to({graphics:mask_4_graphics_236,x:541.3378,y:176.3959}).wait(1).to({graphics:mask_4_graphics_237,x:541.3401,y:176.4324}).wait(1).to({graphics:mask_4_graphics_238,x:541.3419,y:176.4697}).wait(1).to({graphics:mask_4_graphics_239,x:541.3446,y:176.508}).wait(1).to({graphics:mask_4_graphics_240,x:541.3468,y:176.5471}).wait(1).to({graphics:mask_4_graphics_241,x:541.3491,y:176.5876}).wait(1).to({graphics:mask_4_graphics_242,x:541.3513,y:176.629}).wait(1).to({graphics:mask_4_graphics_243,x:541.354,y:176.6713}).wait(1).to({graphics:mask_4_graphics_244,x:541.3563,y:176.715}).wait(1).to({graphics:mask_4_graphics_245,x:541.359,y:176.7595}).wait(1).to({graphics:mask_4_graphics_246,x:541.3617,y:176.8045}).wait(1).to({graphics:mask_4_graphics_247,x:541.3644,y:176.85}).wait(1).to({graphics:mask_4_graphics_248,x:541.3667,y:176.8945}).wait(1).to({graphics:mask_4_graphics_249,x:541.3693,y:176.9377}).wait(1).to({graphics:mask_4_graphics_250,x:541.372,y:176.9796}).wait(1).to({graphics:mask_4_graphics_251,x:541.3743,y:177.021}).wait(1).to({graphics:mask_4_graphics_252,x:541.377,y:177.0615}).wait(1).to({graphics:mask_4_graphics_253,x:541.3788,y:177.1011}).wait(1).to({graphics:mask_4_graphics_254,x:541.3815,y:177.1398}).wait(1).to({graphics:mask_4_graphics_255,x:541.3833,y:177.1772}).wait(1).to({graphics:mask_4_graphics_256,x:541.3855,y:177.2132}).wait(1).to({graphics:mask_4_graphics_257,x:541.3878,y:177.2487}).wait(1).to({graphics:mask_4_graphics_258,x:541.3891,y:177.2833}).wait(1).to({graphics:mask_4_graphics_259,x:541.3918,y:177.3162}).wait(1).to({graphics:mask_4_graphics_260,x:541.3932,y:177.3486}).wait(1).to({graphics:mask_4_graphics_261,x:541.395,y:177.3801}).wait(1).to({graphics:mask_4_graphics_262,x:541.3968,y:177.4107}).wait(1).to({graphics:mask_4_graphics_263,x:541.3986,y:177.44}).wait(1).to({graphics:mask_4_graphics_264,x:541.4004,y:177.4683}).wait(1).to({graphics:mask_4_graphics_265,x:541.4022,y:177.4957}).wait(1).to({graphics:mask_4_graphics_266,x:541.4031,y:177.5223}).wait(1).to({graphics:mask_4_graphics_267,x:541.4053,y:177.5479}).wait(1).to({graphics:mask_4_graphics_268,x:541.4063,y:177.5722}).wait(1).to({graphics:mask_4_graphics_269,x:541.4076,y:177.5956}).wait(1).to({graphics:mask_4_graphics_270,x:541.4094,y:177.6181}).wait(1).to({graphics:mask_4_graphics_271,x:541.4103,y:177.6393}).wait(1).to({graphics:mask_4_graphics_272,x:541.4117,y:177.6595}).wait(1).to({graphics:mask_4_graphics_273,x:541.4125,y:177.6789}).wait(1).to({graphics:mask_4_graphics_274,x:541.4139,y:177.6978}).wait(1).to({graphics:mask_4_graphics_275,x:541.4148,y:177.7149}).wait(1).to({graphics:mask_4_graphics_276,x:541.4157,y:177.7315}).wait(1).to({graphics:mask_4_graphics_277,x:541.4166,y:177.7468}).wait(1).to({graphics:mask_4_graphics_278,x:541.4175,y:177.7617}).wait(1).to({graphics:mask_4_graphics_279,x:541.4179,y:177.7747}).wait(1).to({graphics:mask_4_graphics_280,x:541.4188,y:177.7874}).wait(1).to({graphics:mask_4_graphics_281,x:541.4198,y:177.799}).wait(1).to({graphics:mask_4_graphics_282,x:541.4202,y:177.8094}).wait(1).to({graphics:mask_4_graphics_283,x:541.4206,y:177.8189}).wait(1).to({graphics:mask_4_graphics_284,x:541.4211,y:177.8274}).wait(1).to({graphics:mask_4_graphics_285,x:541.4216,y:177.8346}).wait(1).to({graphics:mask_4_graphics_286,x:541.4225,y:177.8413}).wait(1).to({graphics:mask_4_graphics_287,x:541.4224,y:177.8467}).wait(1).to({graphics:mask_4_graphics_288,x:541.4229,y:177.8513}).wait(1).to({graphics:mask_4_graphics_289,x:541.4229,y:177.8544}).wait(1).to({graphics:mask_4_graphics_290,x:541.4233,y:177.8571}).wait(1).to({graphics:mask_4_graphics_291,x:541.4234,y:177.8584}).wait(1).to({graphics:mask_4_graphics_292,x:541.2208,y:176.5107}).wait(518));

	// Layer_32
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(1,1,1).p("AgOvkIAdfI");
	this.shape_2.setTransform(542.725,277.45);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(200).to({_off:false},0).wait(610));

	// Layer_6 (mask)
	var mask_5 = new cjs.Shape();
	mask_5._off = true;
	var mask_5_graphics_266 = new cjs.Graphics().p("AgMAMQgFgFAAgHIAAAAQAAgGAFgFIAAAAQAFgGAHAAIAAAAQAIAAAFAGIAAAAQAFAFAAAGIAAAAQAAAHgFAFIAAAAQgFAGgIAAIAAAAQgHAAgFgGg");
	var mask_5_graphics_267 = new cjs.Graphics().p("AgMANQgFgGAAgHIAAAAQAAgGAFgGIAAAAQAFgFAHAAIAAAAQAIAAAFAFIAAAAQAFAGAAAGIAAAAQAAAHgFAGIAAAAQgFAFgIAAIAAAAQgHAAgFgFg");
	var mask_5_graphics_268 = new cjs.Graphics().p("AgMANQgGgFAAgIIAAAAQAAgHAGgFIAAAAQAFgFAHAAIAAAAQAIAAAFAFIAAAAQAGAFAAAHIAAAAQAAAIgGAFIAAAAQgFAFgIAAIAAAAQgHAAgFgFg");
	var mask_5_graphics_269 = new cjs.Graphics().p("AgNAOQgGgGAAgIIAAAAQAAgHAGgGIAAAAQAGgFAHAAIAAAAQAIAAAGAFIAAAAQAGAGAAAHIAAAAQAAAIgGAGIAAAAQgGAFgIAAIAAAAQgHAAgGgFg");
	var mask_5_graphics_270 = new cjs.Graphics().p("AgOAOQgGgGAAgIIAAAAQAAgHAGgGIAAAAQAGgHAIAAIAAAAQAJAAAGAHIAAAAQAGAGAAAHIAAAAQAAAIgGAGIAAAAQgGAHgJAAIAAAAQgIAAgGgHg");
	var mask_5_graphics_271 = new cjs.Graphics().p("AgPAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAGgGAJAAIAAAAQAKAAAGAGIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgGAGgKAAIAAAAQgJAAgGgGg");
	var mask_5_graphics_272 = new cjs.Graphics().p("AgRARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAIgHAJAAIAAAAQAKAAAIAHIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgIAHgKAAIAAAAQgJAAgIgHg");
	var mask_5_graphics_273 = new cjs.Graphics().p("AgTATQgIgIAAgLIAAAAQAAgKAIgIIAAAAQAIgIALAAIAAAAQAMAAAIAIIAAAAQAIAIAAAKIAAAAQAAALgIAIIAAAAQgIAIgMAAIAAAAQgLAAgIgIg");
	var mask_5_graphics_274 = new cjs.Graphics().p("AgVAVQgJgJAAgMIAAAAQAAgLAJgJIAAAAQAJgIAMAAIAAAAQANAAAJAIIAAAAQAJAJAAALIAAAAQAAAMgJAJIAAAAQgJAIgNAAIAAAAQgMAAgJgIg");
	var mask_5_graphics_275 = new cjs.Graphics().p("AgXAXQgKgJAAgOIAAAAQAAgNAKgJIAAAAQAKgKANAAIAAAAQAOAAAKAKIAAAAQAKAJAAANIAAAAQAAAOgKAJIAAAAQgKAKgOAAIAAAAQgNAAgKgKg");
	var mask_5_graphics_276 = new cjs.Graphics().p("AgaAaQgLgLAAgPIAAAAQAAgOALgLIAAAAQALgKAPAAIAAAAQAQAAALAKIAAAAQALALAAAOIAAAAQAAAPgLALIAAAAQgLAKgQAAIAAAAQgPAAgLgKg");
	var mask_5_graphics_277 = new cjs.Graphics().p("AgdAcQgMgLAAgRIAAAAQAAgQAMgLIAAAAQANgMAQAAIAAAAQARAAANAMIAAAAQAMALAAAQIAAAAQAAARgMALIAAAAQgNAMgRAAIAAAAQgQAAgNgMg");
	var mask_5_graphics_278 = new cjs.Graphics().p("AggAfQgNgNAAgSIAAAAQAAgRANgNIAAAAQAOgNASAAIAAAAQATAAAOANIAAAAQANANAAARIAAAAQAAASgNANIAAAAQgOANgTAAIAAAAQgSAAgOgNg");
	var mask_5_graphics_279 = new cjs.Graphics().p("AgjAjQgPgPAAgUIAAAAQAAgTAPgPIAAAAQAPgOAUAAIAAAAQAVAAAPAOIAAAAQAPAPAAATIAAAAQAAAUgPAPIAAAAQgPAOgVAAIAAAAQgUAAgPgOg");
	var mask_5_graphics_280 = new cjs.Graphics().p("AgnAmQgRgQAAgWIAAAAQAAgVARgQIAAAAQARgQAWAAIAAAAQAXAAARAQIAAAAQARAQAAAVIAAAAQAAAWgRAQIAAAAQgRAQgXAAIAAAAQgWAAgRgQg");
	var mask_5_graphics_281 = new cjs.Graphics().p("AgrAqQgSgRAAgZIAAAAQAAgYASgRIAAAAQASgSAZAAIAAAAQAaAAASASIAAAAQASARAAAYIAAAAQAAAZgSARIAAAAQgSASgaAAIAAAAQgZAAgSgSg");
	var mask_5_graphics_282 = new cjs.Graphics().p("AgvAuQgUgTAAgbIAAAAQAAgaAUgTIAAAAQAUgTAbAAIAAAAQAcAAAUATIAAAAQAUATAAAaIAAAAQAAAbgUATIAAAAQgUATgcAAIAAAAQgbAAgUgTg");
	var mask_5_graphics_283 = new cjs.Graphics().p("Ag0AzQgWgVAAgeIAAAAQAAgdAWgVIAAAAQAWgVAeAAIAAAAQAfAAAWAVIAAAAQAWAVAAAdIAAAAQAAAegWAVIAAAAQgWAVgfAAIAAAAQgeAAgWgVg");
	var mask_5_graphics_284 = new cjs.Graphics().p("Ag5A3QgYgXAAggIAAAAQAAgfAYgXIAAAAQAYgXAhAAIAAAAQAiAAAYAXIAAAAQAYAXAAAfIAAAAQAAAggYAXIAAAAQgYAXgiAAIAAAAQghAAgYgXg");
	var mask_5_graphics_285 = new cjs.Graphics().p("Ag+A8QgagZAAgjIAAAAQAAgiAagZIAAAAQAagZAkAAIAAAAQAlAAAaAZIAAAAQAaAZAAAiIAAAAQAAAjgaAZIAAAAQgaAZglAAIAAAAQgkAAgagZg");
	var mask_5_graphics_286 = new cjs.Graphics().p("AhDBBQgcgbAAgmIAAAAQAAglAcgbIAAAAQAcgbAnAAIAAAAQAoAAAcAbIAAAAQAcAbAAAlIAAAAQAAAmgcAbIAAAAQgcAbgoAAIAAAAQgnAAgcgbg");
	var mask_5_graphics_287 = new cjs.Graphics().p("AhJBHQgegeAAgpIAAAAQAAgoAegeIAAAAQAfgdAqAAIAAAAQArAAAfAdIAAAAQAeAeAAAoIAAAAQAAApgeAeIAAAAQgfAdgrAAIAAAAQgqAAgfgdg");
	var mask_5_graphics_288 = new cjs.Graphics().p("AhPBMQghgfAAgtIAAAAQAAgsAhgfIAAAAQAhggAuAAIAAAAQAvAAAhAgIAAAAQAhAfAAAsIAAAAQAAAtghAfIAAAAQghAggvAAIAAAAQguAAghggg");
	var mask_5_graphics_289 = new cjs.Graphics().p("AhVBSQgkgiAAgwIAAAAQAAgvAkgiIAAAAQAkgjAxAAIAAAAQAyAAAkAjIAAAAQAkAiAAAvIAAAAQAAAwgkAiIAAAAQgkAigyABIAAAAQgxgBgkgig");
	var mask_5_graphics_290 = new cjs.Graphics().p("AhbBZQgnglAAg0IAAAAQAAgzAnglIAAAAQAmgkA1AAIAAAAQA2AAAmAkIAAAAQAnAlAAAzIAAAAQAAA0gnAlIAAAAQgmAkg2AAIAAAAQg1AAgmgkg");
	var mask_5_graphics_291 = new cjs.Graphics().p("AhiBfQgpgnAAg4IAAAAQAAg3ApgnIAAAAQApgnA5AAIAAAAQA6AAApAnIAAAAQApAnAAA3IAAAAQAAA4gpAnIAAAAQgpAng6AAIAAAAQg5AAgpgng");
	var mask_5_graphics_292 = new cjs.Graphics().p("AhpBmQgsgqAAg8IAAAAQAAg7AsgqIAAAAQAsgqA9AAIAAAAQA+AAAsAqIAAAAQAsAqAAA7IAAAAQAAA8gsAqIAAAAQgsAqg+AAIAAAAQg9AAgsgqg");
	var mask_5_graphics_293 = new cjs.Graphics().p("AhxBtQgvgtAAhAIAAAAQAAg/AvgtIAAAAQAvgtBCAAIAAAAQBDAAAvAtIAAAAQAvAtAAA/IAAAAQAABAgvAtIAAAAQgvAthDAAIAAAAQhCAAgvgtg");
	var mask_5_graphics_294 = new cjs.Graphics().p("Ah4B0QgygwAAhEIAAAAQAAhDAygwIAAAAQAygwBGAAIAAAAQBHAAAyAwIAAAAQAyAwAABDIAAAAQAABEgyAwIAAAAQgyAwhHAAIAAAAQhGAAgygwg");
	var mask_5_graphics_295 = new cjs.Graphics().p("AiAB8Qg2g0AAhIIAAAAQAAhHA2g0IAAAAQA1gzBLAAIAAAAQBMAAA1AzIAAAAQA2A0AABHIAAAAQAABIg2A0IAAAAQg1AzhMAAIAAAAQhLAAg1gzg");
	var mask_5_graphics_296 = new cjs.Graphics().p("AiICDQg5g2AAhNIAAAAQAAhMA5g2IAAAAQA5g3BPAAIAAAAQBQAAA5A3IAAAAQA5A2AABMIAAAAQAABNg5A2IAAAAQg5A3hQAAIAAAAQhPAAg5g3g");
	var mask_5_graphics_297 = new cjs.Graphics().p("AiRCMQg8g6AAhSIAAAAQAAhRA8g6IAAAAQA9g5BUAAIAAAAQBVAAA9A5IAAAAQA8A6AABRIAAAAQAABSg8A6IAAAAQg9A5hVAAIAAAAQhUAAg9g5g");
	var mask_5_graphics_298 = new cjs.Graphics().p("AiZCUQhAg9AAhXIAAAAQAAhWBAg9IAAAAQBAg9BZAAIAAAAQBaAABAA9IAAAAQBAA9AABWIAAAAQAABXhAA9IAAAAQhAA9haAAIAAAAQhZAAhAg9g");
	var mask_5_graphics_299 = new cjs.Graphics().p("AiiCcQhEhAAAhcIAAAAQAAhbBEhBIAAAAQBDhABfAAIAAAAQBgAABDBAIAAAAQBEBBAABbIAAAAQAABchEBAIAAAAQhDBBhgAAIAAAAQhfAAhDhBg");
	var mask_5_graphics_300 = new cjs.Graphics().p("AisClQhHhEAAhhIAAAAQAAhgBHhEIAAAAQBIhFBkAAIAAAAQBlAABIBFIAAAAQBHBEAABgIAAAAQAABhhHBEIAAAAQhIBFhlAAIAAAAQhkAAhIhFg");
	var mask_5_graphics_301 = new cjs.Graphics().p("Ai1CuQhMhIAAhmIAAAAQAAhlBMhJIAAAAQBLhIBqAAIAAAAQBrAABLBIIAAAAQBMBJAABlIAAAAQAABmhMBIIAAAAQhLBJhrAAIAAAAQhqAAhLhJg");
	var mask_5_graphics_302 = new cjs.Graphics().p("Ai/C4QhPhMAAhsIAAAAQAAhrBPhMIAAAAQBQhMBvAAIAAAAQBwAABQBMIAAAAQBPBMAABrIAAAAQAABshPBMIAAAAQhQBMhwAAIAAAAQhvAAhQhMg");
	var mask_5_graphics_303 = new cjs.Graphics().p("AjJDBQhUhQAAhxIAAAAQAAhwBUhRIAAAAQBUhQB1AAIAAAAQB2AABUBQIAAAAQBUBRAABwIAAAAQAABxhUBQIAAAAQhUBRh2AAIAAAAQh1AAhUhRg");
	var mask_5_graphics_304 = new cjs.Graphics().p("AjTDLQhYhUAAh3IAAAAQAAh2BYhUIAAAAQBYhVB7AAIAAAAQB8AABYBVIAAAAQBYBUAAB2IAAAAQAAB3hYBUIAAAAQhYBVh8AAIAAAAQh7AAhYhVg");
	var mask_5_graphics_305 = new cjs.Graphics().p("AjeDWQhchZAAh9IAAAAQAAh8BchZIAAAAQBchYCCAAIAAAAQCDAABcBYIAAAAQBcBZAAB8IAAAAQAAB9hcBZIAAAAQhcBYiDAAIAAAAQiCAAhchYg");
	var mask_5_graphics_306 = new cjs.Graphics().p("AjpDgQhhhdAAiDIAAAAQAAiCBhhdIAAAAQBhhdCIAAIAAAAQCJAABhBdIAAAAQBhBdAACCIAAAAQAACDhhBdIAAAAQhhBdiJAAIAAAAQiIAAhhhdg");
	var mask_5_graphics_307 = new cjs.Graphics().p("Aj0DrQhmhhAAiKIAAAAQAAiJBmhhIAAAAQBlhhCPAAIAAAAQCQAABlBhIAAAAQBmBhAACJIAAAAQAACKhmBhIAAAAQhlBhiQAAIAAAAQiPAAhlhhg");
	var mask_5_graphics_308 = new cjs.Graphics().p("AkAD2QhqhmAAiQIAAAAQAAiPBqhmIAAAAQBrhmCVAAIAAAAQCWAABqBmIAAAAQBrBmAACPIAAAAQAACQhrBmIAAAAQhqBmiWAAIAAAAQiVAAhrhmg");
	var mask_5_graphics_309 = new cjs.Graphics().p("AkLEBQhvhqAAiXIAAAAQAAiWBvhqIAAAAQBvhrCcAAIAAAAQCdAABvBrIAAAAQBvBqAACWIAAAAQAACXhvBqIAAAAQhvBridAAIAAAAQicAAhvhrg");
	var mask_5_graphics_310 = new cjs.Graphics().p("AkXEMQh0hvAAidIAAAAQAAicB0hwIAAAAQB0hvCjAAIAAAAQCkAAB0BvIAAAAQB0BwAACcIAAAAQAACdh0BvIAAAAQh0BwikAAIAAAAQijAAh0hwg");
	var mask_5_graphics_311 = new cjs.Graphics().p("AkkEYQh5h0AAikIAAAAQAAijB5h0IAAAAQB6h0CqAAIAAAAQCrAAB5B0IAAAAQB6B0AACjIAAAAQAACkh6B0IAAAAQh5B0irAAIAAAAQiqAAh6h0g");
	var mask_5_graphics_312 = new cjs.Graphics().p("AkwEkQh/h5AAirIAAAAQAAiqB/h5IAAAAQB+h5CyAAIAAAAQCzAAB+B5IAAAAQB/B5AACqIAAAAQAACrh/B5IAAAAQh+B5izAAIAAAAQiyAAh+h5g");
	var mask_5_graphics_313 = new cjs.Graphics().p("Ak9EwQiDh+AAiyIAAAAQAAixCDh+IAAAAQCEh/C5AAIAAAAQC6AACEB/IAAAAQCDB+AACxIAAAAQAACyiDB+IAAAAQiEB/i6AAIAAAAQi5AAiEh/g");
	var mask_5_graphics_314 = new cjs.Graphics().p("AlJE8QiJiDAAi5IAAAAQAAi4CJiDIAAAAQCJiDDAAAIAAAAQDBAACJCDIAAAAQCJCDAAC4IAAAAQAAC5iJCDIAAAAQiJCDjBAAIAAAAQjAAAiJiDg");
	var mask_5_graphics_315 = new cjs.Graphics().p("AlVFIQiOiIAAjAIAAAAQAAi/COiIIAAAAQCOiHDHAAIAAAAQDIAACOCHIAAAAQCOCIAAC/IAAAAQAADAiOCIIAAAAQiOCHjIAAIAAAAQjHAAiOiHg");
	var mask_5_graphics_316 = new cjs.Graphics().p("AlhFTQiSiMAAjHIAAAAQAAjGCSiMIAAAAQCTiMDOAAIAAAAQDPAACTCMIAAAAQCSCMAADGIAAAAQAADHiSCMIAAAAQiTCMjPAAIAAAAQjOAAiTiMg");
	var mask_5_graphics_317 = new cjs.Graphics().p("AlsFeQiXiRAAjNIAAAAQAAjMCXiRIAAAAQCXiRDVAAIAAAAQDWAACXCRIAAAAQCXCRAADMIAAAAQAADNiXCRIAAAAQiXCRjWAAIAAAAQjVAAiXiRg");
	var mask_5_graphics_318 = new cjs.Graphics().p("Al3FpQiciWAAjTIAAAAQAAjSCciWIAAAAQCciVDbAAIAAAAQDcAACcCVIAAAAQCcCWAADSIAAAAQAADTicCWIAAAAQicCVjcAAIAAAAQjbAAiciVg");
	var mask_5_graphics_319 = new cjs.Graphics().p("AmCFzQihiaAAjZIAAAAQAAjYChiaIAAAAQCgiaDiAAIAAAAQDjAACgCaIAAAAQChCaAADYIAAAAQAADZihCaIAAAAQigCajjAAIAAAAQjiAAigiag");
	var mask_5_graphics_320 = new cjs.Graphics().p("AmNF9QilieAAjfIAAAAQAAjeClieIAAAAQClieDoAAIAAAAQDpAAClCeIAAAAQClCeAADeIAAAAQAADfilCeIAAAAQilCejpAAIAAAAQjoAAilieg");
	var mask_5_graphics_321 = new cjs.Graphics().p("AmXGHQipiiAAjlIAAAAQAAjkCpiiIAAAAQCpiiDuAAIAAAAQDvAACpCiIAAAAQCpCiAADkIAAAAQAADlipCiIAAAAQipCijvAAIAAAAQjuAAipiig");
	var mask_5_graphics_322 = new cjs.Graphics().p("AmhGRQiuimAAjrIAAAAQAAjqCuimIAAAAQCtimD0AAIAAAAQD1AACtCmIAAAAQCuCmAADqIAAAAQAADriuCmIAAAAQitCmj1AAIAAAAQj0AAitimg");
	var mask_5_graphics_323 = new cjs.Graphics().p("AmrGaQiyiqAAjwIAAAAQAAjvCyiqIAAAAQCxiqD6AAIAAAAQD7AACxCqIAAAAQCyCqAADvIAAAAQAADwiyCqIAAAAQixCqj7AAIAAAAQj6AAixiqg");
	var mask_5_graphics_324 = new cjs.Graphics().p("Am1GjQi1itAAj2IAAAAQAAj1C1itIAAAAQC2iuD/AAIAAAAQEAAAC2CuIAAAAQC1CtAAD1IAAAAQAAD2i1CtIAAAAQi2CukAAAIAAAAQj/AAi2iug");
	var mask_5_graphics_325 = new cjs.Graphics().p("Am+GsQi5ixAAj7IAAAAQAAj6C5ixIAAAAQC5iyEFAAIAAAAQEGAAC5CyIAAAAQC5CxAAD6IAAAAQAAD7i5CxIAAAAQi5CykGAAIAAAAQkFAAi5iyg");
	var mask_5_graphics_326 = new cjs.Graphics().p("AnHG1Qi9i1AAkAIAAAAQAAj/C9i1IAAAAQC9i1EKAAIAAAAQELAAC9C1IAAAAQC9C1AAD/IAAAAQAAEAi9C1IAAAAQi9C1kLAAIAAAAQkKAAi9i1g");
	var mask_5_graphics_327 = new cjs.Graphics().p("AnQG9QjAi4AAkFIAAAAQAAkEDAi4IAAAAQDBi5EPAAIAAAAQEQAADBC5IAAAAQDAC4AAEEIAAAAQAAEFjAC4IAAAAQjBC5kQAAIAAAAQkPAAjBi5g");
	var mask_5_graphics_328 = new cjs.Graphics().p("AnYHFQjEi8AAkJIAAAAQAAkIDEi8IAAAAQDEi8EUAAIAAAAQEVAADEC8IAAAAQDEC8AAEIIAAAAQAAEJjEC8IAAAAQjEC8kVAAIAAAAQkUAAjEi8g");
	var mask_5_graphics_329 = new cjs.Graphics().p("AngHNQjIi/AAkOIAAAAQAAkNDIi/IAAAAQDHi/EZAAIAAAAQEaAADHC/IAAAAQDIC/AAENIAAAAQAAEOjIC/IAAAAQjHC/kaAAIAAAAQkZAAjHi/g");
	var mask_5_graphics_330 = new cjs.Graphics().p("AnoHUQjLjCAAkSIAAAAQAAkRDLjDIAAAAQDLjCEdAAIAAAAQEeAADLDCIAAAAQDLDDAAERIAAAAQAAESjLDCIAAAAQjLDDkeAAIAAAAQkdAAjLjDg");
	var mask_5_graphics_331 = new cjs.Graphics().p("AnwHcQjNjFAAkXIAAAAQAAkWDNjFIAAAAQDOjFEiAAIAAAAQEjAADODFIAAAAQDNDFAAEWIAAAAQAAEXjNDFIAAAAQjODFkjAAIAAAAQkiAAjOjFg");
	var mask_5_graphics_332 = new cjs.Graphics().p("An3HjQjRjIAAkbIAAAAQAAkaDRjIIAAAAQDRjIEmAAIAAAAQEnAADRDIIAAAAQDRDIAAEaIAAAAQAAEbjRDIIAAAAQjRDIknAAIAAAAQkmAAjRjIg");
	var mask_5_graphics_333 = new cjs.Graphics().p("An+HqQjUjLAAkfIAAAAQAAkeDUjLIAAAAQDUjLEqAAIAAAAQErAADUDLIAAAAQDUDLAAEeIAAAAQAAEfjUDLIAAAAQjUDKkrABIAAAAQkqgBjUjKg");
	var mask_5_graphics_334 = new cjs.Graphics().p("AoFHwQjWjNAAkjIAAAAQAAkiDWjNIAAAAQDXjOEuAAIAAAAQEvAADXDOIAAAAQDWDNAAEiIAAAAQAAEjjWDNIAAAAQjXDOkvAAIAAAAQkuAAjXjOg");
	var mask_5_graphics_335 = new cjs.Graphics().p("AoLH2QjZjQAAkmIAAAAQAAklDZjQIAAAAQDZjQEyAAIAAAAQEzAADZDQIAAAAQDZDQAAElIAAAAQAAEmjZDQIAAAAQjZDQkzAAIAAAAQkyAAjZjQg");
	var mask_5_graphics_336 = new cjs.Graphics().p("AoSH8QjbjSAAkqIAAAAQAAkpDbjSIAAAAQDcjTE2AAIAAAAQE3AADbDTIAAAAQDcDSAAEpIAAAAQAAEqjcDSIAAAAQjbDTk3AAIAAAAQk2AAjcjTg");
	var mask_5_graphics_337 = new cjs.Graphics().p("AoYICQjejVAAktIAAAAQAAksDejVIAAAAQDfjVE5AAIAAAAQE6AADeDVIAAAAQDfDVAAEsIAAAAQAAEtjfDVIAAAAQjeDVk6AAIAAAAQk5AAjfjVg");
	var mask_5_graphics_338 = new cjs.Graphics().p("AodIHQjhjXAAkwIAAAAQAAkvDhjYIAAAAQDgjXE9AAIAAAAQE+AADgDXIAAAAQDhDYAAEvIAAAAQAAEwjhDXIAAAAQjgDYk+AAIAAAAQk9AAjgjYg");
	var mask_5_graphics_339 = new cjs.Graphics().p("AojIMQjijZAAkzIAAAAQAAkyDijaIAAAAQDjjZFAAAIAAAAQFBAADiDZIAAAAQDjDaAAEyIAAAAQAAEzjjDZIAAAAQjiDalBAAIAAAAQlAAAjjjag");
	var mask_5_graphics_340 = new cjs.Graphics().p("AooIRQjljbAAk2IAAAAQAAk1DljcIAAAAQDljbFDAAIAAAAQFEAADkDbIAAAAQDlDcABE1IAAAAQgBE2jlDbIAAAAQjkDclEAAIAAAAQlDAAjljcg");
	var mask_5_graphics_341 = new cjs.Graphics().p("AotIWQjmjdAAk5IAAAAQAAk4DmjdIAAAAQDojdFFAAIAAAAQFGAADnDdIAAAAQDnDdAAE4IAAAAQAAE5jnDdIAAAAQjnDdlGAAIAAAAQlFAAjojdg");
	var mask_5_graphics_342 = new cjs.Graphics().p("AoxIaQjpjfAAk7IAAAAQAAk6DpjgIAAAAQDpjfFIAAIAAAAQFJAADpDfIAAAAQDpDgAAE6IAAAAQAAE7jpDfIAAAAQjpDglJAAIAAAAQlIAAjpjgg");
	var mask_5_graphics_343 = new cjs.Graphics().p("Ao1IeQjrjgAAk+IAAAAQAAk9DrjhIAAAAQDqjgFLAAIAAAAQFMAADqDgIAAAAQDrDhAAE9IAAAAQAAE+jrDgIAAAAQjqDhlMAAIAAAAQlLAAjqjhg");
	var mask_5_graphics_344 = new cjs.Graphics().p("Ao5IiQjtjiABlAIAAAAQgBk/DtjjIAAAAQDsjiFNAAIAAAAQFOAADsDiIAAAAQDsDjAAE/IAAAAQAAFAjsDiIAAAAQjsDjlOAAIAAAAQlNAAjsjjg");
	var mask_5_graphics_345 = new cjs.Graphics().p("Ao9ImQjujkAAlCIAAAAQAAlBDujkIAAAAQDujkFPAAIAAAAQFQAADuDkIAAAAQDuDkAAFBIAAAAQAAFCjuDkIAAAAQjuDklQAAIAAAAQlPAAjujkg");
	var mask_5_graphics_346 = new cjs.Graphics().p("ApBIpQjvjlAAlEIAAAAQAAlDDvjlIAAAAQDwjmFRAAIAAAAQFSAADvDmIAAAAQDwDlAAFDIAAAAQAAFEjwDlIAAAAQjvDmlSAAIAAAAQlRAAjwjmg");
	var mask_5_graphics_347 = new cjs.Graphics().p("ApEIsQjwjmAAlGIAAAAQAAlFDwjmIAAAAQDxjnFTAAIAAAAQFUAADwDnIAAAAQDxDmAAFFIAAAAQAAFGjxDmIAAAAQjwDnlUAAIAAAAQlTAAjxjng");
	var mask_5_graphics_348 = new cjs.Graphics().p("ApHIvQjxjoAAlHIAAAAQAAlGDxjoIAAAAQDyjoFVAAIAAAAQFWAADxDoIAAAAQDyDoAAFGIAAAAQAAFHjyDoIAAAAQjxDolWAAIAAAAQlVAAjyjog");
	var mask_5_graphics_349 = new cjs.Graphics().p("ApJIxQjzjoAAlJIAAAAQAAlIDzjpIAAAAQDzjoFWAAIAAAAQFXAADzDoIAAAAQDzDpAAFIIAAAAQAAFJjzDoIAAAAQjzDplXAAIAAAAQlWAAjzjpg");
	var mask_5_graphics_350 = new cjs.Graphics().p("ApMI0QjzjqAAlKIAAAAQAAlJDzjqIAAAAQD0jpFYAAIAAAAQFZAADzDpIAAAAQD0DqAAFJIAAAAQAAFKj0DqIAAAAQjzDplZAAIAAAAQlYAAj0jpg");
	var mask_5_graphics_351 = new cjs.Graphics().p("ApOI2Qj0jrAAlLIAAAAQAAlKD0jrIAAAAQD1jqFZAAIAAAAQFaAAD0DqIAAAAQD1DrAAFKIAAAAQAAFLj1DrIAAAAQj0DqlaAAIAAAAQlZAAj1jqg");
	var mask_5_graphics_352 = new cjs.Graphics().p("ApPI3Qj2jrAAlMIAAAAQAAlLD2jsIAAAAQD1jrFaAAIAAAAQFbAAD1DrIAAAAQD2DsAAFLIAAAAQAAFMj2DrIAAAAQj1DslbAAIAAAAQlaAAj1jsg");
	var mask_5_graphics_353 = new cjs.Graphics().p("ApRI5Qj2jsAAlNIAAAAQAAlMD2jsIAAAAQD2jsFbAAIAAAAQFcAAD2DsIAAAAQD2DsAAFMIAAAAQAAFNj2DsIAAAAQj2DslcAAIAAAAQlbAAj2jsg");
	var mask_5_graphics_354 = new cjs.Graphics().p("ApSI6Qj3jsAAlOIAAAAQAAlND3jsIAAAAQD2jsFcAAIAAAAQFdAAD2DsIAAAAQD3DsAAFNIAAAAQAAFOj3DsIAAAAQj2DsldAAIAAAAQlcAAj2jsg");
	var mask_5_graphics_355 = new cjs.Graphics().p("ApTI7Qj3jsAAlPIAAAAQAAlOD3jsIAAAAQD3jtFcAAIAAAAQFdAAD3DtIAAAAQD3DsAAFOIAAAAQAAFPj3DsIAAAAQj3DtldAAIAAAAQlcAAj3jtg");
	var mask_5_graphics_356 = new cjs.Graphics().p("ApUI8Qj3jtAAlPIAAAAQAAlOD3jtIAAAAQD3jtFdAAIAAAAQFeAAD3DtIAAAAQD3DtAAFOIAAAAQAAFPj3DtIAAAAQj3DtleAAIAAAAQldAAj3jtg");
	var mask_5_graphics_357 = new cjs.Graphics().p("ApUI8Qj4jtAAlPIAAAAQAAlOD4jtIAAAAQD3jtFdAAIAAAAQFeAAD3DtIAAAAQD4DtAAFOIAAAAQAAFPj4DtIAAAAQj3DtleAAIAAAAQldAAj3jtg");
	var mask_5_graphics_358 = new cjs.Graphics().p("ApUI8Qj4jtAAlPIAAAAQAAlOD4jtIAAAAQD3jtFdAAIAAAAQFeAAD3DtIAAAAQD4DtAAFOIAAAAQAAFPj4DtIAAAAQj3DtleAAIAAAAQldAAj3jtg");

	this.timeline.addTween(cjs.Tween.get(mask_5).to({graphics:null,x:0,y:0}).wait(266).to({graphics:mask_5_graphics_266,x:797.6502,y:494.0001}).wait(1).to({graphics:mask_5_graphics_267,x:797.6506,y:494.0001}).wait(1).to({graphics:mask_5_graphics_268,x:797.652,y:493.9996}).wait(1).to({graphics:mask_5_graphics_269,x:797.6542,y:493.9987}).wait(1).to({graphics:mask_5_graphics_270,x:797.6578,y:493.9983}).wait(1).to({graphics:mask_5_graphics_271,x:797.6619,y:493.9974}).wait(1).to({graphics:mask_5_graphics_272,x:797.6673,y:493.9965}).wait(1).to({graphics:mask_5_graphics_273,x:797.6731,y:493.9951}).wait(1).to({graphics:mask_5_graphics_274,x:797.6808,y:493.9938}).wait(1).to({graphics:mask_5_graphics_275,x:797.6889,y:493.9915}).wait(1).to({graphics:mask_5_graphics_276,x:797.6979,y:493.9897}).wait(1).to({graphics:mask_5_graphics_277,x:797.7078,y:493.9875}).wait(1).to({graphics:mask_5_graphics_278,x:797.7186,y:493.9852}).wait(1).to({graphics:mask_5_graphics_279,x:797.7307,y:493.9825}).wait(1).to({graphics:mask_5_graphics_280,x:797.7433,y:493.9798}).wait(1).to({graphics:mask_5_graphics_281,x:797.7568,y:493.9771}).wait(1).to({graphics:mask_5_graphics_282,x:797.7717,y:493.9735}).wait(1).to({graphics:mask_5_graphics_283,x:797.7874,y:493.9704}).wait(1).to({graphics:mask_5_graphics_284,x:797.8041,y:493.9668}).wait(1).to({graphics:mask_5_graphics_285,x:797.8212,y:493.9627}).wait(1).to({graphics:mask_5_graphics_286,x:797.8401,y:493.9592}).wait(1).to({graphics:mask_5_graphics_287,x:797.8594,y:493.9547}).wait(1).to({graphics:mask_5_graphics_288,x:797.8797,y:493.9506}).wait(1).to({graphics:mask_5_graphics_289,x:797.9008,y:493.9456}).wait(1).to({graphics:mask_5_graphics_290,x:797.9233,y:493.9407}).wait(1).to({graphics:mask_5_graphics_291,x:797.9467,y:493.9357}).wait(1).to({graphics:mask_5_graphics_292,x:797.971,y:493.9303}).wait(1).to({graphics:mask_5_graphics_293,x:797.9962,y:493.9249}).wait(1).to({graphics:mask_5_graphics_294,x:798.0219,y:493.9191}).wait(1).to({graphics:mask_5_graphics_295,x:798.0489,y:493.9137}).wait(1).to({graphics:mask_5_graphics_296,x:798.0772,y:493.9074}).wait(1).to({graphics:mask_5_graphics_297,x:798.106,y:493.9011}).wait(1).to({graphics:mask_5_graphics_298,x:798.1362,y:493.8948}).wait(1).to({graphics:mask_5_graphics_299,x:798.1672,y:493.888}).wait(1).to({graphics:mask_5_graphics_300,x:798.1987,y:493.8808}).wait(1).to({graphics:mask_5_graphics_301,x:798.2311,y:493.8736}).wait(1).to({graphics:mask_5_graphics_302,x:798.2654,y:493.8664}).wait(1).to({graphics:mask_5_graphics_303,x:798.2995,y:493.8593}).wait(1).to({graphics:mask_5_graphics_304,x:798.3351,y:493.8516}).wait(1).to({graphics:mask_5_graphics_305,x:798.372,y:493.8435}).wait(1).to({graphics:mask_5_graphics_306,x:798.4093,y:493.8349}).wait(1).to({graphics:mask_5_graphics_307,x:798.4476,y:493.8269}).wait(1).to({graphics:mask_5_graphics_308,x:798.4872,y:493.8187}).wait(1).to({graphics:mask_5_graphics_309,x:798.5273,y:493.8093}).wait(1).to({graphics:mask_5_graphics_310,x:798.5686,y:493.8007}).wait(1).to({graphics:mask_5_graphics_311,x:798.611,y:493.7917}).wait(1).to({graphics:mask_5_graphics_312,x:798.6541,y:493.7818}).wait(1).to({graphics:mask_5_graphics_313,x:798.6978,y:493.7728}).wait(1).to({graphics:mask_5_graphics_314,x:798.7396,y:493.7638}).wait(1).to({graphics:mask_5_graphics_315,x:798.7806,y:493.7548}).wait(1).to({graphics:mask_5_graphics_316,x:798.8216,y:493.7458}).wait(1).to({graphics:mask_5_graphics_317,x:798.8607,y:493.7377}).wait(1).to({graphics:mask_5_graphics_318,x:798.8989,y:493.7287}).wait(1).to({graphics:mask_5_graphics_319,x:798.9367,y:493.7211}).wait(1).to({graphics:mask_5_graphics_320,x:798.9727,y:493.713}).wait(1).to({graphics:mask_5_graphics_321,x:799.0087,y:493.7054}).wait(1).to({graphics:mask_5_graphics_322,x:799.0434,y:493.6977}).wait(1).to({graphics:mask_5_graphics_323,x:799.0771,y:493.6905}).wait(1).to({graphics:mask_5_graphics_324,x:799.11,y:493.6833}).wait(1).to({graphics:mask_5_graphics_325,x:799.1415,y:493.6765}).wait(1).to({graphics:mask_5_graphics_326,x:799.1725,y:493.6698}).wait(1).to({graphics:mask_5_graphics_327,x:799.2022,y:493.6635}).wait(1).to({graphics:mask_5_graphics_328,x:799.231,y:493.6567}).wait(1).to({graphics:mask_5_graphics_329,x:799.2589,y:493.6509}).wait(1).to({graphics:mask_5_graphics_330,x:799.2859,y:493.645}).wait(1).to({graphics:mask_5_graphics_331,x:799.3125,y:493.6392}).wait(1).to({graphics:mask_5_graphics_332,x:799.3377,y:493.6338}).wait(1).to({graphics:mask_5_graphics_333,x:799.362,y:493.6288}).wait(1).to({graphics:mask_5_graphics_334,x:799.3849,y:493.6234}).wait(1).to({graphics:mask_5_graphics_335,x:799.407,y:493.619}).wait(1).to({graphics:mask_5_graphics_336,x:799.429,y:493.614}).wait(1).to({graphics:mask_5_graphics_337,x:799.4489,y:493.61}).wait(1).to({graphics:mask_5_graphics_338,x:799.4687,y:493.6054}).wait(1).to({graphics:mask_5_graphics_339,x:799.4866,y:493.6014}).wait(1).to({graphics:mask_5_graphics_340,x:799.5046,y:493.5978}).wait(1).to({graphics:mask_5_graphics_341,x:799.5213,y:493.5942}).wait(1).to({graphics:mask_5_graphics_342,x:799.5366,y:493.5906}).wait(1).to({graphics:mask_5_graphics_343,x:799.5514,y:493.5874}).wait(1).to({graphics:mask_5_graphics_344,x:799.5654,y:493.5847}).wait(1).to({graphics:mask_5_graphics_345,x:799.578,y:493.5816}).wait(1).to({graphics:mask_5_graphics_346,x:799.5901,y:493.5793}).wait(1).to({graphics:mask_5_graphics_347,x:799.6009,y:493.5771}).wait(1).to({graphics:mask_5_graphics_348,x:799.6108,y:493.5748}).wait(1).to({graphics:mask_5_graphics_349,x:799.6198,y:493.5726}).wait(1).to({graphics:mask_5_graphics_350,x:799.6279,y:493.5708}).wait(1).to({graphics:mask_5_graphics_351,x:799.6347,y:493.569}).wait(1).to({graphics:mask_5_graphics_352,x:799.641,y:493.5681}).wait(1).to({graphics:mask_5_graphics_353,x:799.6464,y:493.5672}).wait(1).to({graphics:mask_5_graphics_354,x:799.6509,y:493.5658}).wait(1).to({graphics:mask_5_graphics_355,x:799.6541,y:493.5654}).wait(1).to({graphics:mask_5_graphics_356,x:799.6567,y:493.5649}).wait(1).to({graphics:mask_5_graphics_357,x:799.6577,y:493.5645}).wait(1).to({graphics:mask_5_graphics_358,x:799.6581,y:493.0542}).wait(452));

	// Layer_31
	this.instance_7 = new lib.Tween63("synched",0);
	this.instance_7.setTransform(841.35,464.2);
	this.instance_7.alpha = 0.5;
	this.instance_7._off = true;

	this.instance_8 = new lib.Tween64("synched",0);
	this.instance_8.setTransform(841.35,464.2);

	var maskedShapeInstanceList = [this.instance_7,this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_5;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_7}]},266).to({state:[{t:this.instance_8}]},92).wait(452));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(266).to({_off:false},0).to({_off:true,alpha:1},92).wait(452));

	// Layer_8
	this.instance_9 = new lib.Tween18("synched",2);
	this.instance_9.setTransform(227.9,-267.1);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(186).to({_off:false},0).to({startPosition:28},26).wait(598));

	// Layer_6 (mask)
	var mask_6 = new cjs.Shape();
	mask_6._off = true;
	var mask_6_graphics_197 = new cjs.Graphics().p("AgqApQgRgRAAgYIAAAAQAAgXARgRIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQARARAAAXIAAAAQAAAYgRARIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_6_graphics_198 = new cjs.Graphics().p("AgqApQgSgRAAgYIAAAAQAAgXASgRIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQASARAAAXIAAAAQAAAYgSARIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_6_graphics_199 = new cjs.Graphics().p("AgrAqQgSgRAAgZIAAAAQAAgYASgRIAAAAQASgRAZAAIAAAAQAaAAASARIAAAAQASARAAAYIAAAAQAAAZgSARIAAAAQgSARgaAAIAAAAQgZAAgSgRg");
	var mask_6_graphics_200 = new cjs.Graphics().p("AgsArQgTgSAAgZIAAAAQAAgYATgSIAAAAQATgSAZAAIAAAAQAaAAATASIAAAAQATASAAAYIAAAAQAAAZgTASIAAAAQgTASgaAAIAAAAQgZAAgTgSg");
	var mask_6_graphics_201 = new cjs.Graphics().p("AguAtQgTgTAAgaIAAAAQAAgZATgTIAAAAQAUgSAaAAIAAAAQAbAAAUASIAAAAQATATAAAZIAAAAQAAAagTATIAAAAQgUASgbAAIAAAAQgaAAgUgSg");
	var mask_6_graphics_202 = new cjs.Graphics().p("AgwAvQgUgTAAgcIAAAAQAAgbAUgTIAAAAQAUgUAcAAIAAAAQAdAAAUAUIAAAAQAUATAAAbIAAAAQAAAcgUATIAAAAQgUAUgdAAIAAAAQgcAAgUgUg");
	var mask_6_graphics_203 = new cjs.Graphics().p("AgzAyQgVgVAAgdIAAAAQAAgcAVgVIAAAAQAWgUAdAAIAAAAQAeAAAWAUIAAAAQAVAVAAAcIAAAAQAAAdgVAVIAAAAQgWAUgeAAIAAAAQgdAAgWgUg");
	var mask_6_graphics_204 = new cjs.Graphics().p("Ag2A1QgXgWAAgfIAAAAQAAgeAXgWIAAAAQAXgWAfAAIAAAAQAgAAAXAWIAAAAQAXAWAAAeIAAAAQAAAfgXAWIAAAAQgXAWggAAIAAAAQgfAAgXgWg");
	var mask_6_graphics_205 = new cjs.Graphics().p("Ag6A5QgZgYAAghIAAAAQAAggAZgYIAAAAQAYgXAiAAIAAAAQAjAAAYAXIAAAAQAZAYAAAgIAAAAQAAAhgZAYIAAAAQgYAXgjAAIAAAAQgiAAgYgXg");
	var mask_6_graphics_206 = new cjs.Graphics().p("Ag+A9QgbgZAAgkIAAAAQAAgjAbgZIAAAAQAagZAkAAIAAAAQAlAAAaAZIAAAAQAbAZAAAjIAAAAQAAAkgbAZIAAAAQgaAZglAAIAAAAQgkAAgagZg");
	var mask_6_graphics_207 = new cjs.Graphics().p("AhDBBQgdgbABgmIAAAAQgBglAdgbIAAAAQAcgbAnAAIAAAAQAoAAAcAbIAAAAQAcAbAAAlIAAAAQAAAmgcAbIAAAAQgcAbgoAAIAAAAQgnAAgcgbg");
	var mask_6_graphics_208 = new cjs.Graphics().p("AhJBGQgegdAAgpIAAAAQAAgoAegeIAAAAQAfgdAqAAIAAAAQArAAAfAdIAAAAQAeAeAAAoIAAAAQAAApgeAdIAAAAQgfAegrAAIAAAAQgqAAgfgeg");
	var mask_6_graphics_209 = new cjs.Graphics().p("AhOBMQghgfAAgtIAAAAQAAgsAhgfIAAAAQAgggAuAAIAAAAQAvAAAgAgIAAAAQAhAfAAAsIAAAAQAAAtghAfIAAAAQggAggvAAIAAAAQguAAggggg");
	var mask_6_graphics_210 = new cjs.Graphics().p("AhVBSQgjgiAAgwIAAAAQAAgvAjgiIAAAAQAkgiAxAAIAAAAQAyAAAkAiIAAAAQAjAiAAAvIAAAAQAAAwgjAiIAAAAQgkAigyAAIAAAAQgxAAgkgig");
	var mask_6_graphics_211 = new cjs.Graphics().p("AhcBZQgmglAAg0IAAAAQAAgzAmglIAAAAQAnglA1AAIAAAAQA2AAAnAlIAAAAQAmAlAAAzIAAAAQAAA0gmAlIAAAAQgnAlg2AAIAAAAQg1AAgnglg");
	var mask_6_graphics_212 = new cjs.Graphics().p("AhjBgQgqgoAAg4IAAAAQAAg3AqgoIAAAAQApgoA6AAIAAAAQA7AAApAoIAAAAQAqAoAAA3IAAAAQAAA4gqAoIAAAAQgpAog7AAIAAAAQg6AAgpgog");
	var mask_6_graphics_213 = new cjs.Graphics().p("AhrBnQgtgqAAg9IAAAAQAAg8AtgqIAAAAQAtgrA+AAIAAAAQA/AAAtArIAAAAQAtAqAAA8IAAAAQAAA9gtAqIAAAAQgtArg/AAIAAAAQg+AAgtgrg");
	var mask_6_graphics_214 = new cjs.Graphics().p("AhzBvQgxguAAhBIAAAAQAAhAAxgvIAAAAQAwguBDAAIAAAAQBEAAAwAuIAAAAQAxAvAABAIAAAAQAABBgxAuIAAAAQgwAvhEAAIAAAAQhDAAgwgvg");
	var mask_6_graphics_215 = new cjs.Graphics().p("Ah8B4Qg0gyAAhGIAAAAQAAhFA0gyIAAAAQA0gyBIAAIAAAAQBJAAA0AyIAAAAQA0AyAABFIAAAAQAABGg0AyIAAAAQg0AyhJAAIAAAAQhIAAg0gyg");
	var mask_6_graphics_216 = new cjs.Graphics().p("AiGCBQg4g1AAhMIAAAAQAAhLA4g1IAAAAQA4g2BOAAIAAAAQBPAAA4A2IAAAAQA4A1AABLIAAAAQAABMg4A1IAAAAQg4A2hPAAIAAAAQhOAAg4g2g");
	var mask_6_graphics_217 = new cjs.Graphics().p("AiQCLQg8g6AAhRIAAAAQAAhQA8g6IAAAAQA8g5BUAAIAAAAQBVAAA8A5IAAAAQA8A6AABQIAAAAQAABRg8A6IAAAAQg8A5hVAAIAAAAQhUAAg8g5g");
	var mask_6_graphics_218 = new cjs.Graphics().p("AiaCVQhAg+AAhXIAAAAQAAhWBAg+IAAAAQBAg9BaAAIAAAAQBbAABAA9IAAAAQBAA+AABWIAAAAQAABXhAA+IAAAAQhAA9hbAAIAAAAQhaAAhAg9g");
	var mask_6_graphics_219 = new cjs.Graphics().p("AilCfQhFhCAAhdIAAAAQAAhcBFhCIAAAAQBFhCBgAAIAAAAQBhAABFBCIAAAAQBFBCAABcIAAAAQAABdhFBCIAAAAQhFBChhAAIAAAAQhgAAhFhCg");
	var mask_6_graphics_220 = new cjs.Graphics().p("AixCqQhJhGAAhkIAAAAQAAhjBJhGIAAAAQBKhHBnAAIAAAAQBoAABKBHIAAAAQBJBGAABjIAAAAQAABkhJBGIAAAAQhKBHhoAAIAAAAQhnAAhKhHg");
	var mask_6_graphics_221 = new cjs.Graphics().p("Ai9C2QhOhMAAhqIAAAAQAAhpBOhMIAAAAQBPhLBuAAIAAAAQBvAABOBLIAAAAQBPBMAABpIAAAAQAABqhPBMIAAAAQhOBLhvAAIAAAAQhuAAhPhLg");
	var mask_6_graphics_222 = new cjs.Graphics().p("AjJDCQhUhRAAhxIAAAAQAAhwBUhRIAAAAQBUhQB1AAIAAAAQB2AABUBQIAAAAQBUBRAABwIAAAAQAABxhUBRIAAAAQhUBQh2AAIAAAAQh1AAhUhQg");
	var mask_6_graphics_223 = new cjs.Graphics().p("AjWDOQhZhVAAh5IAAAAQAAh4BZhVIAAAAQBZhVB9AAIAAAAQB+AABZBVIAAAAQBZBVAAB4IAAAAQAAB5hZBVIAAAAQhZBVh+AAIAAAAQh9AAhZhVg");
	var mask_6_graphics_224 = new cjs.Graphics().p("AjkDbQhehbAAiAIAAAAQAAh/BehbIAAAAQBfhbCFAAIAAAAQCGAABeBbIAAAAQBfBbAAB/IAAAAQAACAhfBbIAAAAQheBbiGAAIAAAAQiFAAhfhbg");
	var mask_6_graphics_225 = new cjs.Graphics().p("AjyDoQhkhgAAiIIAAAAQAAiHBkhgIAAAAQBlhhCNAAIAAAAQCOAABkBhIAAAAQBlBgAACHIAAAAQAACIhlBgIAAAAQhkBhiOAAIAAAAQiNAAhlhhg");
	var mask_6_graphics_226 = new cjs.Graphics().p("AkAD2QhrhmAAiQIAAAAQAAiPBrhmIAAAAQBqhmCWAAIAAAAQCXAABqBmIAAAAQBrBmAACPIAAAAQAACQhrBmIAAAAQhqBmiXAAIAAAAQiWAAhqhmg");
	var mask_6_graphics_227 = new cjs.Graphics().p("AkPEFQhxhsAAiZIAAAAQAAiYBxhsIAAAAQBxhsCeAAIAAAAQCfAABxBsIAAAAQBxBsAACYIAAAAQAACZhxBsIAAAAQhxBsifAAIAAAAQieAAhxhsg");
	var mask_6_graphics_228 = new cjs.Graphics().p("AkfEUQh3hzAAihIAAAAQAAigB3hzIAAAAQB4hyCnAAIAAAAQCoAAB4ByIAAAAQB3BzAACgIAAAAQAAChh3BzIAAAAQh4ByioAAIAAAAQinAAh4hyg");
	var mask_6_graphics_229 = new cjs.Graphics().p("AkvEjQh9h5AAiqIAAAAQAAipB9h5IAAAAQB+h5CxAAIAAAAQCyAAB+B5IAAAAQB9B5AACpIAAAAQAACqh9B5IAAAAQh+B5iyAAIAAAAQixAAh+h5g");
	var mask_6_graphics_230 = new cjs.Graphics().p("Ak/EzQiFh/AAi0IAAAAQAAizCFh/IAAAAQCEh/C7AAIAAAAQC8AACEB/IAAAAQCFB/AACzIAAAAQAAC0iFB/IAAAAQiEB/i8AAIAAAAQi7AAiEh/g");
	var mask_6_graphics_231 = new cjs.Graphics().p("AlQFDQiMiGAAi9IAAAAQAAi8CMiGIAAAAQCLiGDFAAIAAAAQDGAACLCGIAAAAQCMCGAAC8IAAAAQAAC9iMCGIAAAAQiLCGjGAAIAAAAQjFAAiLiGg");
	var mask_6_graphics_232 = new cjs.Graphics().p("AliFUQiTiNAAjHIAAAAQAAjGCTiNIAAAAQCTiNDPAAIAAAAQDQAACTCNIAAAAQCTCNAADGIAAAAQAADHiTCNIAAAAQiTCNjQAAIAAAAQjPAAiTiNg");
	var mask_6_graphics_233 = new cjs.Graphics().p("Al0FlQibiUAAjRIAAAAQAAjQCbiUIAAAAQCbiUDZAAIAAAAQDaAACbCUIAAAAQCbCUAADQIAAAAQAADRibCUIAAAAQibCUjaAAIAAAAQjZAAibiUg");
	var mask_6_graphics_234 = new cjs.Graphics().p("AmHF3QiiibAAjcIAAAAQAAjbCiibIAAAAQCjicDkAAIAAAAQDlAACiCcIAAAAQCjCbAADbIAAAAQAADcijCbIAAAAQiiCcjlAAIAAAAQjkAAijicg");
	var mask_6_graphics_235 = new cjs.Graphics().p("AmaGJQiqiiAAjnIAAAAQAAjmCqijIAAAAQCqijDwAAIAAAAQDxAACqCjIAAAAQCqCjAADmIAAAAQAADniqCiIAAAAQiqCkjxAAIAAAAQjwAAiqikg");
	var mask_6_graphics_236 = new cjs.Graphics().p("AmtGcQiziqAAjyIAAAAQAAjxCziqIAAAAQCyirD7AAIAAAAQD8AACyCrIAAAAQCzCqAADxIAAAAQAADyizCqIAAAAQiyCrj8AAIAAAAQj7AAiyirg");
	var mask_6_graphics_237 = new cjs.Graphics().p("AnCGwQi6izAAj9IAAAAQAAj8C6izIAAAAQC7iyEHAAIAAAAQEIAAC6CyIAAAAQC7CzAAD8IAAAAQAAD9i7CzIAAAAQi6CykIAAIAAAAQkHAAi7iyg");
	var mask_6_graphics_238 = new cjs.Graphics().p("AnWHDQjDi7AAkIIAAAAQAAkHDDi8IAAAAQDDi6ETAAIAAAAQEUAADDC6IAAAAQDDC8AAEHIAAAAQAAEIjDC7IAAAAQjDC7kUAAIAAAAQkTAAjDi7g");
	var mask_6_graphics_239 = new cjs.Graphics().p("AnrHYQjMjEAAkUIAAAAQAAkTDMjEIAAAAQDMjDEfAAIAAAAQEgAADMDDIAAAAQDMDEAAETIAAAAQAAEUjMDEIAAAAQjMDDkgAAIAAAAQkfAAjMjDg");
	var mask_6_graphics_240 = new cjs.Graphics().p("AoBHsQjVjMAAkgIAAAAQAAkfDVjNIAAAAQDVjLEsAAIAAAAQEtAADVDLIAAAAQDVDNAAEfIAAAAQAAEgjVDMIAAAAQjVDMktAAIAAAAQksAAjVjMg");
	var mask_6_graphics_241 = new cjs.Graphics().p("AoXICQjejVAAktIAAAAQAAksDejVIAAAAQDejUE5AAIAAAAQE6AADeDUIAAAAQDeDVAAEsIAAAAQAAEtjeDVIAAAAQjeDUk6AAIAAAAQk5AAjejUg");
	var mask_6_graphics_242 = new cjs.Graphics().p("AouIXQjnjdAAk6IAAAAQAAk5DnjeIAAAAQDojdFGAAIAAAAQFHAADoDdIAAAAQDnDeAAE5IAAAAQAAE6jnDdIAAAAQjoDelHAAIAAAAQlGAAjojeg");
	var mask_6_graphics_243 = new cjs.Graphics().p("ApFItQjxjmAAlHIAAAAQAAlGDxjnIAAAAQDxjnFUAAIAAAAQFVAADxDnIAAAAQDxDnAAFGIAAAAQAAFHjxDmIAAAAQjxDolVAAIAAAAQlUAAjxjog");
	var mask_6_graphics_244 = new cjs.Graphics().p("ApdJEQj7jwAAlUIAAAAQAAlTD7jwIAAAAQD7jxFiAAIAAAAQFjAAD7DxIAAAAQD7DwAAFTIAAAAQAAFUj7DwIAAAAQj7DxljAAIAAAAQliAAj7jxg");
	var mask_6_graphics_245 = new cjs.Graphics().p("Ap1JbQkFj5AAliIAAAAQAAlgEFj7IAAAAQEFj6FwAAIAAAAQFxAAEFD6IAAAAQEFD7AAFgIAAAAQAAFikFD5IAAAAQkFD7lxAAIAAAAQlwAAkFj7g");
	var mask_6_graphics_246 = new cjs.Graphics().p("AqOJzQkPkEAAlvIAAAAQAAluEPkEIAAAAQEQkEF+AAIAAAAQF/AAEPEEIAAAAQEQEEAAFuIAAAAQAAFvkQEEIAAAAQkPEEl/AAIAAAAQl+AAkQkEg");
	var mask_6_graphics_247 = new cjs.Graphics().p("AqnKLQkZkNAAl+IAAAAQAAl9EZkOIAAAAQEakNGNAAIAAAAQGOAAEaENIAAAAQEZEOAAF9IAAAAQAAF+kZENIAAAAQkaEOmOAAIAAAAQmNAAkakOg");
	var mask_6_graphics_248 = new cjs.Graphics().p("ArBKkQkkkYAAmMIAAAAQAAmLEkkYIAAAAQElkYGcAAIAAAAQGdAAEkEYIAAAAQElEYAAGLIAAAAQAAGMklEYIAAAAQkkEYmdAAIAAAAQmcAAklkYg");
	var mask_6_graphics_249 = new cjs.Graphics().p("ArbK9QkvkiAAmbIAAAAQAAmaEvkiIAAAAQEvkjGsAAIAAAAQGtAAEvEjIAAAAQEvEiAAGaIAAAAQAAGbkvEiIAAAAQkvEjmtAAIAAAAQmsAAkvkjg");
	var mask_6_graphics_250 = new cjs.Graphics().p("Ar2LXQk6ktAAmqIAAAAQAAmpE6ktIAAAAQE7ktG7AAIAAAAQG8AAE6EtIAAAAQE7EtAAGpIAAAAQAAGqk7EtIAAAAQk6Etm8AAIAAAAQm7AAk7ktg");
	var mask_6_graphics_251 = new cjs.Graphics().p("AsRLxQlFk4AAm5IAAAAQAAm4FFk4IAAAAQFGk4HLAAIAAAAQHMAAFGE4IAAAAQFFE4AAG4IAAAAQAAG5lFE4IAAAAQlGE4nMAAIAAAAQnLAAlGk4g");
	var mask_6_graphics_252 = new cjs.Graphics().p("AssMLQlRlDAAnIIAAAAQAAnHFRlDIAAAAQFRlDHbAAIAAAAQHcAAFRFDIAAAAQFRFDAAHHIAAAAQAAHIlRFDIAAAAQlRFDncAAIAAAAQnbAAlRlDg");
	var mask_6_graphics_253 = new cjs.Graphics().p("AtHMlQlclOAAnXIAAAAQAAnWFclOIAAAAQFclNHrAAIAAAAQHsAAFcFNIAAAAQFcFOAAHWIAAAAQAAHXlcFOIAAAAQlcFNnsAAIAAAAQnrAAlclNg");
	var mask_6_graphics_254 = new cjs.Graphics().p("AthM+QlnlYAAnmIAAAAQAAnlFnlYIAAAAQFnlYH6AAIAAAAQH7AAFnFYIAAAAQFnFYAAHlIAAAAQAAHmlnFYIAAAAQlnFYn7AAIAAAAQn6AAlnlYg");
	var mask_6_graphics_255 = new cjs.Graphics().p("At7NWQlxlhAAn1IAAAAQAAn0FxliIAAAAQFyliIJAAIAAAAQIKAAFyFiIAAAAQFxFiAAH0IAAAAQAAH1lxFhIAAAAQlyFjoKAAIAAAAQoJAAlyljg");
	var mask_6_graphics_256 = new cjs.Graphics().p("AuUNuQl8lrAAoDIAAAAQAAoCF8lsIAAAAQF8lsIYAAIAAAAQIZAAF8FsIAAAAQF8FsAAICIAAAAQAAIDl8FrIAAAAQl8FtoZAAIAAAAQoYAAl8ltg");
	var mask_6_graphics_257 = new cjs.Graphics().p("AutOGQmGl1AAoRIAAAAQAAoQGGl2IAAAAQGGl1InAAIAAAAQIoAAGGF1IAAAAQGGF2AAIQIAAAAQAAIRmGF1IAAAAQmGF2ooAAIAAAAQonAAmGl2g");
	var mask_6_graphics_258 = new cjs.Graphics().p("AvFOdQmQl/AAoeIAAAAQAAodGQmAIAAAAQGQl/I1AAIAAAAQI2AAGQF/IAAAAQGQGAAAIdIAAAAQAAIemQF/IAAAAQmQGAo2AAIAAAAQo1AAmQmAg");
	var mask_6_graphics_259 = new cjs.Graphics().p("AvdO0QmamJAAorIAAAAQAAoqGamKIAAAAQGamIJDAAIAAAAQJEAAGZGIIAAAAQGbGKAAIqIAAAAQAAIrmbGJIAAAAQmZGJpEAAIAAAAQpDAAmamJg");
	var mask_6_graphics_260 = new cjs.Graphics().p("Av0PKQmjmSAAo4IAAAAQAAo3GjmTIAAAAQGkmSJQAAIAAAAQJRAAGkGSIAAAAQGjGTAAI3IAAAAQAAI4mjGSIAAAAQmkGTpRAAIAAAAQpQAAmkmTg");
	var mask_6_graphics_261 = new cjs.Graphics().p("AwLPgQmtmbAApFIAAAAQAApEGtmbIAAAAQGtmbJeAAIAAAAQJfAAGsGbIAAAAQGuGbAAJEIAAAAQAAJFmuGbIAAAAQmsGbpfAAIAAAAQpeAAmtmbg");
	var mask_6_graphics_262 = new cjs.Graphics().p("AwhP1Qm2mjAApSIAAAAQAApRG2mkIAAAAQG2mjJrAAIAAAAQJsAAG1GjIAAAAQG3GkAAJRIAAAAQAAJSm3GjIAAAAQm1GkpsAAIAAAAQprAAm2mkg");
	var mask_6_graphics_263 = new cjs.Graphics().p("Aw3QKQm/msAApeIAAAAQAApdG/msIAAAAQHAmtJ3AAIAAAAQJ4AAG/GtIAAAAQHAGsAAJdIAAAAQAAJenAGsIAAAAQm/Gtp4AAIAAAAQp3AAnAmtg");
	var mask_6_graphics_264 = new cjs.Graphics().p("AxMQeQnHm0AApqIAAAAQAAppHHm1IAAAAQHIm0KEAAIAAAAQKFAAHHG0IAAAAQHIG1AAJpIAAAAQAAJqnIG0IAAAAQnHG1qFAAIAAAAQqEAAnIm1g");
	var mask_6_graphics_265 = new cjs.Graphics().p("AxgQyQnRm9AAp1IAAAAQAAp0HRm+IAAAAQHQm8KQAAIAAAAQKRAAHQG8IAAAAQHRG+AAJ0IAAAAQAAJ1nRG9IAAAAQnQG9qRAAIAAAAQqQAAnQm9g");
	var mask_6_graphics_266 = new cjs.Graphics().p("Ax1RFQnYnEAAqBIAAAAQAAqAHYnFIAAAAQHanFKbAAIAAAAQKcAAHZHFIAAAAQHZHFAAKAIAAAAQAAKBnZHEIAAAAQnZHGqcAAIAAAAQqbAAnanGg");
	var mask_6_graphics_267 = new cjs.Graphics().p("AyIRYQnhnMAAqMIAAAAQAAqLHhnNIAAAAQHhnMKnAAIAAAAQKoAAHhHMIAAAAQHhHNAAKLIAAAAQAAKMnhHMIAAAAQnhHNqoAAIAAAAQqnAAnhnNg");
	var mask_6_graphics_268 = new cjs.Graphics().p("AybRqQnpnUAAqWIAAAAQAAqVHpnVIAAAAQHpnUKyAAIAAAAQKzAAHpHUIAAAAQHpHVAAKVIAAAAQAAKWnpHUIAAAAQnpHVqzAAIAAAAQqyAAnpnVg");
	var mask_6_graphics_269 = new cjs.Graphics().p("AyuR8QnwnbAAqhIAAAAQAAqgHwncIAAAAQHxnbK9AAIAAAAQK+AAHwHbIAAAAQHxHcAAKgIAAAAQAAKhnxHbIAAAAQnwHcq+AAIAAAAQq9AAnxncg");
	var mask_6_graphics_270 = new cjs.Graphics().p("AzASOQn4njAAqrIAAAAQAAqqH4njIAAAAQH4njLIAAIAAAAQLJAAH3HjIAAAAQH5HjAAKqIAAAAQAAKrn5HjIAAAAQn3HjrJAAIAAAAQrIAAn4njg");
	var mask_6_graphics_271 = new cjs.Graphics().p("AzSSeQn/npAAq1IAAAAQAAq0H/nqIAAAAQIAnqLSAAIAAAAQLTAAH/HqIAAAAQIAHqAAK0IAAAAQAAK1oAHpIAAAAQn/HrrTAAIAAAAQrSAAoAnrg");
	var mask_6_graphics_272 = new cjs.Graphics().p("AzjSvQoGnxAAq+IAAAAQAAq9IGnxIAAAAQIHnxLcAAIAAAAQLdAAIGHxIAAAAQIHHxAAK9IAAAAQAAK+oHHxIAAAAQoGHxrdAAIAAAAQrcAAoHnxg");
	var mask_6_graphics_273 = new cjs.Graphics().p("AzzS/QoNn3AArIIAAAAQAArHINn3IAAAAQINn3LmAAIAAAAQLnAAINH3IAAAAQINH3AALHIAAAAQAALIoNH3IAAAAQoNH3rnAAIAAAAQrmAAoNn3g");
	var mask_6_graphics_274 = new cjs.Graphics().p("A0DTOQoUn9AArRIAAAAQAArQIUn+IAAAAQIUn9LvAAIAAAAQLwAAIUH9IAAAAQIUH+AALQIAAAAQAALRoUH9IAAAAQoUH+rwAAIAAAAQrvAAoUn+g");
	var mask_6_graphics_275 = new cjs.Graphics().p("A0TTdQoaoEAArZIAAAAQAArYIaoFIAAAAQIboDL4AAIAAAAQL5AAIaIDIAAAAQIbIFAALYIAAAAQAALZobIEIAAAAQoaIEr5AAIAAAAQr4AAoboEg");
	var mask_6_graphics_276 = new cjs.Graphics().p("A0iTrQogoJAAriIAAAAQAArhIgoKIAAAAQIhoJMBAAIAAAAQMCAAIgIJIAAAAQIhIKAALhIAAAAQAALiohIJIAAAAQogIKsCAAIAAAAQsBAAohoKg");
	var mask_6_graphics_277 = new cjs.Graphics().p("A0wT5QonoPAArqIAAAAQAArpInoQIAAAAQInoPMJAAIAAAAQMKAAInIPIAAAAQInIQAALpIAAAAQAALqonIPIAAAAQonIQsKAAIAAAAQsJAAonoQg");
	var mask_6_graphics_278 = new cjs.Graphics().p("A0+UHQotoVAAryIAAAAQAArxItoVIAAAAQIsoVMSAAIAAAAQMTAAIsIVIAAAAQItIVAALxIAAAAQAALyotIVIAAAAQosIVsTAAIAAAAQsSAAosoVg");
	var mask_6_graphics_279 = new cjs.Graphics().p("A1MUUQoyobAAr5IAAAAQAAr4IyobIAAAAQIyoaMaAAIAAAAQMbAAIxIaIAAAAQIzIbAAL4IAAAAQAAL5ozIbIAAAAQoxIasbAAIAAAAQsaAAoyoag");
	var mask_6_graphics_280 = new cjs.Graphics().p("A1ZUgQo3ofAAsBIAAAAQAAsAI3ogIAAAAQI4ofMhAAIAAAAQMiAAI3IfIAAAAQI4IgAAMAIAAAAQAAMBo4IfIAAAAQo3IgsiAAIAAAAQshAAo4ogg");
	var mask_6_graphics_281 = new cjs.Graphics().p("A1lUsQo9okAAsIIAAAAQAAsHI9olIAAAAQI8okMpAAIAAAAQMqAAI8IkIAAAAQI9IlAAMHIAAAAQAAMIo9IkIAAAAQo8IlsqAAIAAAAQspAAo8olg");
	var mask_6_graphics_282 = new cjs.Graphics().p("A1xU3QpCopAAsOIAAAAQAAsNJCoqIAAAAQJBopMwAAIAAAAQMxAAJBIpIAAAAQJCIqAAMNIAAAAQAAMOpCIpIAAAAQpBIqsxAAIAAAAQswAApBoqg");
	var mask_6_graphics_283 = new cjs.Graphics().p("A19VCQpGotAAsVIAAAAQAAsUJGouIAAAAQJHouM2AAIAAAAQM3AAJGIuIAAAAQJHIuAAMUIAAAAQAAMVpHItIAAAAQpGIvs3AAIAAAAQs2AApHovg");
	var mask_6_graphics_284 = new cjs.Graphics().p("A2IVNQpKoyAAsbIAAAAQAAsaJKozIAAAAQJLoyM9AAIAAAAQM+AAJKIyIAAAAQJLIzAAMaIAAAAQAAMbpLIyIAAAAQpKIzs+AAIAAAAQs9AApLozg");
	var mask_6_graphics_285 = new cjs.Graphics().p("A2SVXQpPo2AAshIAAAAQAAsgJPo3IAAAAQJPo2NDAAIAAAAQNEAAJPI2IAAAAQJPI3AAMgIAAAAQAAMhpPI2IAAAAQpPI3tEAAIAAAAQtDAApPo3g");
	var mask_6_graphics_286 = new cjs.Graphics().p("A2cVgQpTo6AAsmIAAAAQAAslJTo7IAAAAQJTo6NJAAIAAAAQNKAAJTI6IAAAAQJTI7AAMlIAAAAQAAMmpTI6IAAAAQpTI7tKAAIAAAAQtJAApTo7g");
	var mask_6_graphics_287 = new cjs.Graphics().p("A2mVqQpWo+AAssIAAAAQAAsrJWo+IAAAAQJYo+NOAAIAAAAQNPAAJXI+IAAAAQJXI+AAMrIAAAAQAAMspXI+IAAAAQpXI+tPAAIAAAAQtOAApYo+g");
	var mask_6_graphics_288 = new cjs.Graphics().p("A2vVyQpapBAAsxIAAAAQAAswJapCIAAAAQJcpBNTAAIAAAAQNUAAJbJBIAAAAQJbJCAAMwIAAAAQAAMxpbJBIAAAAQpbJCtUAAIAAAAQtTAApcpCg");
	var mask_6_graphics_289 = new cjs.Graphics().p("A23V6QpepFAAs1IAAAAQAAs0JepGIAAAAQJfpENYAAIAAAAQNZAAJeJEIAAAAQJfJGAAM0IAAAAQAAM1pfJFIAAAAQpeJFtZAAIAAAAQtYAApfpFg");
	var mask_6_graphics_290 = new cjs.Graphics().p("A2/WCQphpIAAs6IAAAAQAAs5JhpIIAAAAQJipINdAAIAAAAQNeAAJhJIIAAAAQJiJIAAM5IAAAAQAAM6piJIIAAAAQphJIteAAIAAAAQtdAApipIg");
	var mask_6_graphics_291 = new cjs.Graphics().p("A3GWJQplpLAAs+IAAAAQAAs9JlpLIAAAAQJlpLNhAAIAAAAQNiAAJlJLIAAAAQJlJLAAM9IAAAAQAAM+plJLIAAAAQplJLtiAAIAAAAQthAAplpLg");
	var mask_6_graphics_292 = new cjs.Graphics().p("A3NWPQpnpNAAtCIAAAAQAAtBJnpOIAAAAQJopNNlAAIAAAAQNmAAJnJNIAAAAQJoJOAANBIAAAAQAANCpoJNIAAAAQpnJOtmAAIAAAAQtlAApopOg");
	var mask_6_graphics_293 = new cjs.Graphics().p("A3UWVQpppQAAtFIAAAAQAAtEJppRIAAAAQJrpQNpAAIAAAAQNqAAJqJQIAAAAQJqJRAANEIAAAAQAANFpqJQIAAAAQpqJRtqAAIAAAAQtpAAprpRg");
	var mask_6_graphics_294 = new cjs.Graphics().p("A3ZWbQptpSAAtJIAAAAQAAtIJtpTIAAAAQJtpSNsAAIAAAAQNtAAJtJSIAAAAQJtJTAANIIAAAAQAANJptJSIAAAAQptJTttAAIAAAAQtsAAptpTg");
	var mask_6_graphics_295 = new cjs.Graphics().p("A3fWgQpupUAAtMIAAAAQAAtLJupVIAAAAQJvpUNwAAIAAAAQNxAAJuJUIAAAAQJvJVAANLIAAAAQAANMpvJUIAAAAQpuJVtxAAIAAAAQtwAApvpVg");
	var mask_6_graphics_296 = new cjs.Graphics().p("A3kWlQpwpXAAtOIAAAAQAAtNJwpYIAAAAQJypWNyAAIAAAAQNzAAJxJWIAAAAQJxJYAANNIAAAAQAANOpxJXIAAAAQpxJXtzAAIAAAAQtyAApypXg");
	var mask_6_graphics_297 = new cjs.Graphics().p("A3oWpQpypYAAtRIAAAAQAAtQJypZIAAAAQJzpYN1AAIAAAAQN2AAJyJYIAAAAQJzJZAANQIAAAAQAANRpzJYIAAAAQpyJZt2AAIAAAAQt1AApzpZg");
	var mask_6_graphics_298 = new cjs.Graphics().p("A3sWtQp0paAAtTIAAAAQAAtSJ0paIAAAAQJ1paN3AAIAAAAQN4AAJ0JaIAAAAQJ1JaAANSIAAAAQAANTp1JaIAAAAQp0Jat4AAIAAAAQt3AAp1pag");
	var mask_6_graphics_299 = new cjs.Graphics().p("A3vWwQp1pbAAtVIAAAAQAAtUJ1pcIAAAAQJ2paN5AAIAAAAQN6AAJ1JaIAAAAQJ2JcAANUIAAAAQAANVp2JbIAAAAQp1Jbt6AAIAAAAQt5AAp2pbg");
	var mask_6_graphics_300 = new cjs.Graphics().p("A3yWyQp2pcAAtWIAAAAQAAtVJ2pdIAAAAQJ3pcN7AAIAAAAQN8AAJ2JcIAAAAQJ3JdAANVIAAAAQAANWp3JcIAAAAQp2Jdt8AAIAAAAQt7AAp3pdg");
	var mask_6_graphics_301 = new cjs.Graphics().p("A30W1Qp3pdAAtYIAAAAQAAtXJ3pdIAAAAQJ4pdN8AAIAAAAQN9AAJ3JdIAAAAQJ4JdAANXIAAAAQAANYp4JdIAAAAQp3Jdt9AAIAAAAQt8AAp4pdg");
	var mask_6_graphics_302 = new cjs.Graphics().p("A32W2Qp4pdAAtZIAAAAQAAtYJ4peIAAAAQJ5peN9AAIAAAAQN+AAJ4JeIAAAAQJ5JeAANYIAAAAQAANZp5JdIAAAAQp4Jft+AAIAAAAQt9AAp5pfg");
	var mask_6_graphics_303 = new cjs.Graphics().p("A33W4Qp5pfAAtZIAAAAQAAtYJ5pfIAAAAQJ5peN+AAIAAAAQN/AAJ4JeIAAAAQJ6JfAANYIAAAAQAANZp6JfIAAAAQp4Jet/AAIAAAAQt+AAp5peg");
	var mask_6_graphics_304 = new cjs.Graphics().p("A34W4Qp5peAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+ABIAAAAQN/gBJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JeIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_6_graphics_305 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ5pfN/AAIAAAAQOAAAJ5JfIAAAAQJ5JfAANZIAAAAQAANap5JfIAAAAQp5JfuAAAIAAAAQt/AAp5pfg");

	this.timeline.addTween(cjs.Tween.get(mask_6).to({graphics:null,x:0,y:0}).wait(197).to({graphics:mask_6_graphics_197,x:700.0006,y:250.8503}).wait(1).to({graphics:mask_6_graphics_198,x:700.0006,y:250.8502}).wait(1).to({graphics:mask_6_graphics_199,x:700.0006,y:250.8502}).wait(1).to({graphics:mask_6_graphics_200,x:700.0006,y:250.8507}).wait(1).to({graphics:mask_6_graphics_201,x:700.0006,y:250.8502}).wait(1).to({graphics:mask_6_graphics_202,x:700.0006,y:250.8507}).wait(1).to({graphics:mask_6_graphics_203,x:700.0006,y:250.8507}).wait(1).to({graphics:mask_6_graphics_204,x:700.0006,y:250.8502}).wait(1).to({graphics:mask_6_graphics_205,x:700.0006,y:250.8502}).wait(1).to({graphics:mask_6_graphics_206,x:700.0011,y:250.8502}).wait(1).to({graphics:mask_6_graphics_207,x:700.0011,y:250.8503}).wait(1).to({graphics:mask_6_graphics_208,x:700.0011,y:250.8502}).wait(1).to({graphics:mask_6_graphics_209,x:700.0011,y:250.8507}).wait(1).to({graphics:mask_6_graphics_210,x:700.0011,y:250.8507}).wait(1).to({graphics:mask_6_graphics_211,x:700.0011,y:250.8507}).wait(1).to({graphics:mask_6_graphics_212,x:700.0016,y:250.8507}).wait(1).to({graphics:mask_6_graphics_213,x:700.0015,y:250.8507}).wait(1).to({graphics:mask_6_graphics_214,x:700.002,y:250.8511}).wait(1).to({graphics:mask_6_graphics_215,x:700.0015,y:250.8507}).wait(1).to({graphics:mask_6_graphics_216,x:700.002,y:250.8507}).wait(1).to({graphics:mask_6_graphics_217,x:700.002,y:250.8511}).wait(1).to({graphics:mask_6_graphics_218,x:700.0024,y:250.8511}).wait(1).to({graphics:mask_6_graphics_219,x:700.0024,y:250.8511}).wait(1).to({graphics:mask_6_graphics_220,x:700.0024,y:250.8516}).wait(1).to({graphics:mask_6_graphics_221,x:700.0024,y:250.8511}).wait(1).to({graphics:mask_6_graphics_222,x:700.0024,y:250.8512}).wait(1).to({graphics:mask_6_graphics_223,x:700.0029,y:250.8516}).wait(1).to({graphics:mask_6_graphics_224,x:700.0029,y:250.8516}).wait(1).to({graphics:mask_6_graphics_225,x:700.0034,y:250.8516}).wait(1).to({graphics:mask_6_graphics_226,x:700.0038,y:250.8516}).wait(1).to({graphics:mask_6_graphics_227,x:700.0033,y:250.852}).wait(1).to({graphics:mask_6_graphics_228,x:700.0038,y:250.8521}).wait(1).to({graphics:mask_6_graphics_229,x:700.0042,y:250.852}).wait(1).to({graphics:mask_6_graphics_230,x:700.0042,y:250.852}).wait(1).to({graphics:mask_6_graphics_231,x:700.0047,y:250.8525}).wait(1).to({graphics:mask_6_graphics_232,x:700.0052,y:250.8525}).wait(1).to({graphics:mask_6_graphics_233,x:700.0051,y:250.8525}).wait(1).to({graphics:mask_6_graphics_234,x:700.0056,y:250.8525}).wait(1).to({graphics:mask_6_graphics_235,x:700.0056,y:250.8529}).wait(1).to({graphics:mask_6_graphics_236,x:700.006,y:250.8534}).wait(1).to({graphics:mask_6_graphics_237,x:700.006,y:250.8534}).wait(1).to({graphics:mask_6_graphics_238,x:700.0065,y:250.8534}).wait(1).to({graphics:mask_6_graphics_239,x:700.0069,y:250.8534}).wait(1).to({graphics:mask_6_graphics_240,x:700.0069,y:250.8534}).wait(1).to({graphics:mask_6_graphics_241,x:700.0074,y:250.8539}).wait(1).to({graphics:mask_6_graphics_242,x:700.0078,y:250.8543}).wait(1).to({graphics:mask_6_graphics_243,x:700.0083,y:250.8538}).wait(1).to({graphics:mask_6_graphics_244,x:700.0083,y:250.8543}).wait(1).to({graphics:mask_6_graphics_245,x:700.0087,y:250.8543}).wait(1).to({graphics:mask_6_graphics_246,x:700.0092,y:250.8548}).wait(1).to({graphics:mask_6_graphics_247,x:700.0096,y:250.8548}).wait(1).to({graphics:mask_6_graphics_248,x:700.0101,y:250.8547}).wait(1).to({graphics:mask_6_graphics_249,x:700.0106,y:250.8552}).wait(1).to({graphics:mask_6_graphics_250,x:700.0105,y:250.8556}).wait(1).to({graphics:mask_6_graphics_251,x:700.011,y:250.8556}).wait(1).to({graphics:mask_6_graphics_252,x:700.0114,y:250.8556}).wait(1).to({graphics:mask_6_graphics_253,x:700.0119,y:250.8561}).wait(1).to({graphics:mask_6_graphics_254,x:700.0119,y:250.8561}).wait(1).to({graphics:mask_6_graphics_255,x:700.0124,y:250.8565}).wait(1).to({graphics:mask_6_graphics_256,x:700.0128,y:250.8565}).wait(1).to({graphics:mask_6_graphics_257,x:700.0128,y:250.8565}).wait(1).to({graphics:mask_6_graphics_258,x:700.0137,y:250.857}).wait(1).to({graphics:mask_6_graphics_259,x:700.0137,y:250.857}).wait(1).to({graphics:mask_6_graphics_260,x:700.0141,y:250.8574}).wait(1).to({graphics:mask_6_graphics_261,x:700.0146,y:250.8574}).wait(1).to({graphics:mask_6_graphics_262,x:700.0146,y:250.8574}).wait(1).to({graphics:mask_6_graphics_263,x:700.015,y:250.8579}).wait(1).to({graphics:mask_6_graphics_264,x:700.0155,y:250.8579}).wait(1).to({graphics:mask_6_graphics_265,x:700.0159,y:250.8583}).wait(1).to({graphics:mask_6_graphics_266,x:700.0155,y:250.8583}).wait(1).to({graphics:mask_6_graphics_267,x:700.0159,y:250.8583}).wait(1).to({graphics:mask_6_graphics_268,x:700.0168,y:250.8583}).wait(1).to({graphics:mask_6_graphics_269,x:700.0168,y:250.8583}).wait(1).to({graphics:mask_6_graphics_270,x:700.0168,y:250.8588}).wait(1).to({graphics:mask_6_graphics_271,x:700.0173,y:250.8588}).wait(1).to({graphics:mask_6_graphics_272,x:700.0173,y:250.8588}).wait(1).to({graphics:mask_6_graphics_273,x:700.0177,y:250.8588}).wait(1).to({graphics:mask_6_graphics_274,x:700.0177,y:250.8592}).wait(1).to({graphics:mask_6_graphics_275,x:700.0182,y:250.8593}).wait(1).to({graphics:mask_6_graphics_276,x:700.0186,y:250.8593}).wait(1).to({graphics:mask_6_graphics_277,x:700.0186,y:250.8597}).wait(1).to({graphics:mask_6_graphics_278,x:700.0187,y:250.8597}).wait(1).to({graphics:mask_6_graphics_279,x:700.0186,y:250.8597}).wait(1).to({graphics:mask_6_graphics_280,x:700.0191,y:250.8601}).wait(1).to({graphics:mask_6_graphics_281,x:700.0191,y:250.8602}).wait(1).to({graphics:mask_6_graphics_282,x:700.0191,y:250.8597}).wait(1).to({graphics:mask_6_graphics_283,x:700.0195,y:250.8602}).wait(1).to({graphics:mask_6_graphics_284,x:700.0196,y:250.8601}).wait(1).to({graphics:mask_6_graphics_285,x:700.0195,y:250.8602}).wait(1).to({graphics:mask_6_graphics_286,x:700.02,y:250.8602}).wait(1).to({graphics:mask_6_graphics_287,x:700.02,y:250.8601}).wait(1).to({graphics:mask_6_graphics_288,x:700.0204,y:250.8602}).wait(1).to({graphics:mask_6_graphics_289,x:700.0204,y:250.8602}).wait(1).to({graphics:mask_6_graphics_290,x:700.0209,y:250.8606}).wait(1).to({graphics:mask_6_graphics_291,x:700.0204,y:250.8606}).wait(1).to({graphics:mask_6_graphics_292,x:700.0204,y:250.8606}).wait(1).to({graphics:mask_6_graphics_293,x:700.0204,y:250.8606}).wait(1).to({graphics:mask_6_graphics_294,x:700.0205,y:250.8611}).wait(1).to({graphics:mask_6_graphics_295,x:700.0209,y:250.8606}).wait(1).to({graphics:mask_6_graphics_296,x:700.0209,y:250.8606}).wait(1).to({graphics:mask_6_graphics_297,x:700.0209,y:250.861}).wait(1).to({graphics:mask_6_graphics_298,x:700.0213,y:250.8606}).wait(1).to({graphics:mask_6_graphics_299,x:700.0209,y:250.861}).wait(1).to({graphics:mask_6_graphics_300,x:700.0213,y:250.8606}).wait(1).to({graphics:mask_6_graphics_301,x:700.0209,y:250.8611}).wait(1).to({graphics:mask_6_graphics_302,x:700.0213,y:250.861}).wait(1).to({graphics:mask_6_graphics_303,x:700.0213,y:250.8611}).wait(1).to({graphics:mask_6_graphics_304,x:700.0213,y:250.861}).wait(1).to({graphics:mask_6_graphics_305,x:700.0213,y:250.8606}).wait(505));

	// Layer_30
	this.instance_10 = new lib.Tween65("synched",0);
	this.instance_10.setTransform(681.75,220.95);
	this.instance_10.alpha = 0.5;
	this.instance_10._off = true;

	this.instance_11 = new lib.Tween66("synched",0);
	this.instance_11.setTransform(681.75,220.95);

	var maskedShapeInstanceList = [this.instance_10,this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_6;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_10}]},197).to({state:[{t:this.instance_11}]},108).wait(505));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(197).to({_off:false},0).to({_off:true,alpha:1},108).wait(505));

	// Layer_6 (mask)
	var mask_7 = new cjs.Shape();
	mask_7._off = true;
	var mask_7_graphics_167 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_7_graphics_168 = new cjs.Graphics().p("AgjAiQgPgOAAgUIAAAAQAAgTAPgPIAAAAQAPgOAUAAIAAAAQAVAAAPAOIAAAAQAPAPAAATIAAAAQAAAUgPAOIAAAAQgPAPgVAAIAAAAQgUAAgPgPg");
	var mask_7_graphics_169 = new cjs.Graphics().p("Ag1A1QgXgWAAgfIAAAAQAAgeAXgWIAAAAQAWgVAfAAIAAAAQAgAAAWAVIAAAAQAXAWAAAeIAAAAQAAAfgXAWIAAAAQgWAVggAAIAAAAQgfAAgWgVg");
	var mask_7_graphics_170 = new cjs.Graphics().p("AhIBHQgfgeAAgpIAAAAQAAgoAfgeIAAAAQAegdAqAAIAAAAQArAAAeAdIAAAAQAfAeAAAoIAAAAQAAApgfAeIAAAAQgeAdgrAAIAAAAQgqAAgegdg");
	var mask_7_graphics_171 = new cjs.Graphics().p("AhbBZQgmglAAg0IAAAAQAAgzAmglIAAAAQAmglA1AAIAAAAQA2AAAmAlIAAAAQAmAlAAAzIAAAAQAAA0gmAlIAAAAQgmAlg2AAIAAAAQg1AAgmglg");
	var mask_7_graphics_172 = new cjs.Graphics().p("AhuBsQgugtAAg/IAAAAQAAg+AugtIAAAAQAugsBAAAIAAAAQBBAAAuAsIAAAAQAuAtAAA+IAAAAQAAA/guAtIAAAAQguAshBAAIAAAAQhAAAgugsg");
	var mask_7_graphics_173 = new cjs.Graphics().p("AiBB+Qg2g0AAhKIAAAAQAAhJA2g0IAAAAQA2g0BLAAIAAAAQBMAAA2A0IAAAAQA2A0AABJIAAAAQAABKg2A0IAAAAQg2A0hMAAIAAAAQhLAAg2g0g");
	var mask_7_graphics_174 = new cjs.Graphics().p("AiUCRQg+g8AAhVIAAAAQAAhUA+g8IAAAAQA+g8BWAAIAAAAQBYAAA9A8IAAAAQA+A8AABUIAAAAQAABVg+A8IAAAAQg9A8hYAAIAAAAQhWAAg+g8g");
	var mask_7_graphics_175 = new cjs.Graphics().p("AioCjQhFhDAAhgIAAAAQAAhfBFhDIAAAAQBGhEBiAAIAAAAQBjAABGBEIAAAAQBFBDAABfIAAAAQAABghFBDIAAAAQhGBEhjAAIAAAAQhiAAhGhEg");
	var mask_7_graphics_176 = new cjs.Graphics().p("Ai7C2QhOhLAAhrIAAAAQAAhqBOhLIAAAAQBOhMBtAAIAAAAQBuAABOBMIAAAAQBOBLAABqIAAAAQAABrhOBLIAAAAQhOBMhuAAIAAAAQhtAAhOhMg");
	var mask_7_graphics_177 = new cjs.Graphics().p("AjODJQhWhTAAh2IAAAAQAAh1BWhTIAAAAQBWhTB4AAIAAAAQB5AABWBTIAAAAQBWBTAAB1IAAAAQAAB2hWBTIAAAAQhWBTh5AAIAAAAQh4AAhWhTg");
	var mask_7_graphics_178 = new cjs.Graphics().p("AjhDcQhehbAAiBIAAAAQAAiABehbIAAAAQBdhbCEAAIAAAAQCFAABdBbIAAAAQBeBbAACAIAAAAQAACBheBbIAAAAQhdBbiFAAIAAAAQiEAAhdhbg");
	var mask_7_graphics_179 = new cjs.Graphics().p("Aj1DuQhmhiAAiMIAAAAQAAiLBmhiIAAAAQBmhjCPAAIAAAAQCQAABmBjIAAAAQBmBiAACLIAAAAQAACMhmBiIAAAAQhmBjiQAAIAAAAQiPAAhmhjg");
	var mask_7_graphics_180 = new cjs.Graphics().p("AkIEBQhuhqAAiXIAAAAQAAiWBuhqIAAAAQBuhqCaAAIAAAAQCbAABuBqIAAAAQBuBqAACWIAAAAQAACXhuBqIAAAAQhuBqibAAIAAAAQiaAAhuhqg");
	var mask_7_graphics_181 = new cjs.Graphics().p("AkbEUQh2hzAAihIAAAAQAAigB2hzIAAAAQB2hyClAAIAAAAQCmAAB2ByIAAAAQB2BzAACgIAAAAQAAChh2BzIAAAAQh2ByimAAIAAAAQilAAh2hyg");
	var mask_7_graphics_182 = new cjs.Graphics().p("AkuEmQh+h6AAisIAAAAQAAirB+h6IAAAAQB9h6CxAAIAAAAQCyAAB9B6IAAAAQB+B6AACrIAAAAQAACsh+B6IAAAAQh9B6iyAAIAAAAQixAAh9h6g");
	var mask_7_graphics_183 = new cjs.Graphics().p("AlBE5QiGiCAAi3IAAAAQAAi2CGiCIAAAAQCFiBC8AAIAAAAQC9AACFCBIAAAAQCGCCAAC2IAAAAQAAC3iGCCIAAAAQiFCBi9AAIAAAAQi8AAiFiBg");
	var mask_7_graphics_184 = new cjs.Graphics().p("AlUFLQiOiJAAjCIAAAAQAAjBCOiJIAAAAQCNiJDHAAIAAAAQDIAACNCJIAAAAQCOCJAADBIAAAAQAADCiOCJIAAAAQiNCJjIAAIAAAAQjHAAiNiJg");
	var mask_7_graphics_185 = new cjs.Graphics().p("AlnFdQiViQAAjNIAAAAQAAjMCViQIAAAAQCViRDSAAIAAAAQDTAACVCRIAAAAQCVCQAADMIAAAAQAADNiVCQIAAAAQiVCRjTAAIAAAAQjSAAiViRg");
	var mask_7_graphics_186 = new cjs.Graphics().p("Al6FvQidiYAAjXIAAAAQAAjWCdiZIAAAAQCdiYDdAAIAAAAQDeAACdCYIAAAAQCdCZAADWIAAAAQAADXidCYIAAAAQidCZjeAAIAAAAQjdAAidiZg");
	var mask_7_graphics_187 = new cjs.Graphics().p("AmMGBQilifAAjiIAAAAQAAjhCligIAAAAQCkifDoAAIAAAAQDpAACkCfIAAAAQClCgAADhIAAAAQAADiilCfIAAAAQikCgjpAAIAAAAQjoAAikigg");
	var mask_7_graphics_188 = new cjs.Graphics().p("AmfGTQisinAAjsIAAAAQAAjrCsinIAAAAQCsinDzAAIAAAAQD0AACsCnIAAAAQCsCnAADrIAAAAQAADsisCnIAAAAQisCnj0AAIAAAAQjzAAising");
	var mask_7_graphics_189 = new cjs.Graphics().p("AmxGlQi0iuAAj3IAAAAQAAj2C0iuIAAAAQC0iuD9AAIAAAAQD+AAC0CuIAAAAQC0CuAAD2IAAAAQAAD3i0CuIAAAAQi0Cuj+AAIAAAAQj9AAi0iug");
	var mask_7_graphics_190 = new cjs.Graphics().p("AnDG2Qi7i1AAkBIAAAAQAAkAC7i2IAAAAQC7i1EIAAIAAAAQEJAAC7C1IAAAAQC7C2AAEAIAAAAQAAEBi7C1IAAAAQi7C2kJAAIAAAAQkIAAi7i2g");
	var mask_7_graphics_191 = new cjs.Graphics().p("AnVHIQjDi9AAkLIAAAAQAAkKDDi9IAAAAQDDi9ESAAIAAAAQETAADDC9IAAAAQDDC9AAEKIAAAAQAAELjDC9IAAAAQjDC9kTAAIAAAAQkSAAjDi9g");
	var mask_7_graphics_192 = new cjs.Graphics().p("AnnHZQjJjEAAkVIAAAAQAAkUDJjEIAAAAQDKjEEdAAIAAAAQEeAADJDEIAAAAQDKDEAAEUIAAAAQAAEVjKDEIAAAAQjJDEkeAAIAAAAQkdAAjKjEg");
	var mask_7_graphics_193 = new cjs.Graphics().p("An4HqQjRjLAAkfIAAAAQAAkeDRjLIAAAAQDRjLEnAAIAAAAQEoAADRDLIAAAAQDRDLAAEeIAAAAQAAEfjRDLIAAAAQjRDLkoAAIAAAAQknAAjRjLg");
	var mask_7_graphics_194 = new cjs.Graphics().p("AoJH6QjYjRAAkpIAAAAQAAkoDYjSIAAAAQDYjRExAAIAAAAQEyAADYDRIAAAAQDYDSAAEoIAAAAQAAEpjYDRIAAAAQjYDSkyAAIAAAAQkxAAjYjSg");
	var mask_7_graphics_195 = new cjs.Graphics().p("AoaILQjfjZAAkyIAAAAQAAkxDfjZIAAAAQDfjZE7AAIAAAAQE8AADfDZIAAAAQDfDZAAExIAAAAQAAEyjfDZIAAAAQjfDZk8AAIAAAAQk7AAjfjZg");
	var mask_7_graphics_196 = new cjs.Graphics().p("AorIbQjmjfAAk8IAAAAQAAk7DmjfIAAAAQDmjgFFAAIAAAAQFGAADmDgIAAAAQDmDfAAE7IAAAAQAAE8jmDfIAAAAQjmDglGAAIAAAAQlFAAjmjgg");
	var mask_7_graphics_197 = new cjs.Graphics().p("Ao7IrQjtjmAAlFIAAAAQAAlEDtjmIAAAAQDtjmFOAAIAAAAQFPAADtDmIAAAAQDtDmAAFEIAAAAQAAFFjtDmIAAAAQjtDmlPAAIAAAAQlOAAjtjmg");
	var mask_7_graphics_198 = new cjs.Graphics().p("ApMI7QjzjtAAlOIAAAAQAAlNDzjtIAAAAQD0jtFYAAIAAAAQFZAADzDtIAAAAQD0DtAAFNIAAAAQAAFOj0DtIAAAAQjzDtlZAAIAAAAQlYAAj0jtg");
	var mask_7_graphics_199 = new cjs.Graphics().p("ApcJKQj6jzAAlXIAAAAQAAlXD6jzIAAAAQD7jyFhAAIAAAAQFiAAD6DyIAAAAQD7DzAAFXIAAAAQAAFXj7DzIAAAAQj6DzliAAIAAAAQlhAAj7jzg");
	var mask_7_graphics_200 = new cjs.Graphics().p("AprJaQkBj6AAlgIAAAAQAAlfEBj6IAAAAQEBj5FqAAIAAAAQFrAAEBD5IAAAAQEBD6AAFfIAAAAQAAFgkBD6IAAAAQkBD5lrAAIAAAAQlqAAkBj5g");
	var mask_7_graphics_201 = new cjs.Graphics().p("Ap7JoQkHj/AAlpIAAAAQAAloEHkAIAAAAQEIj/FzAAIAAAAQF0AAEHD/IAAAAQEIEAAAFoIAAAAQAAFpkID/IAAAAQkHEAl0AAIAAAAQlzAAkIkAg");
	var mask_7_graphics_202 = new cjs.Graphics().p("AqKJ3QkNkFAAlyIAAAAQAAlxENkFIAAAAQEOkGF8AAIAAAAQF9AAENEGIAAAAQEOEFAAFxIAAAAQAAFykOEFIAAAAQkNEGl9AAIAAAAQl8AAkOkGg");
	var mask_7_graphics_203 = new cjs.Graphics().p("AqZKFQkTkLAAl6IAAAAQAAl5ETkMIAAAAQEUkLGFAAIAAAAQGGAAETELIAAAAQEUEMAAF5IAAAAQAAF6kUELIAAAAQkTEMmGAAIAAAAQmFAAkUkMg");
	var mask_7_graphics_204 = new cjs.Graphics().p("AqnKUQkakSAAmCIAAAAQAAmBEakSIAAAAQEakRGNAAIAAAAQGOAAEaERIAAAAQEaESAAGBIAAAAQAAGCkaESIAAAAQkaERmOAAIAAAAQmNAAkakRg");
	var mask_7_graphics_205 = new cjs.Graphics().p("Aq1KhQkgkWAAmLIAAAAQAAmJEgkYIAAAAQEfkXGWAAIAAAAQGXAAEfEXIAAAAQEgEYAAGJIAAAAQAAGLkgEWIAAAAQkfEYmXAAIAAAAQmWAAkfkYg");
	var mask_7_graphics_206 = new cjs.Graphics().p("ArDKvQklkdAAmSIAAAAQAAmRElkdIAAAAQElkdGeAAIAAAAQGfAAElEdIAAAAQElEdAAGRIAAAAQAAGSklEdIAAAAQklEdmfAAIAAAAQmeAAklkdg");
	var mask_7_graphics_207 = new cjs.Graphics().p("ArRK8QkrkiAAmaIAAAAQAAmZErkiIAAAAQErkiGmAAIAAAAQGnAAEqEiIAAAAQEsEiAAGZIAAAAQAAGaksEiIAAAAQkqEimnAAIAAAAQmmAAkrkig");
	var mask_7_graphics_208 = new cjs.Graphics().p("AreLJQkwknAAmiIAAAAQAAmhEwknIAAAAQExkoGtAAIAAAAQGuAAExEoIAAAAQEwEnAAGhIAAAAQAAGikwEnIAAAAQkxEomuAAIAAAAQmtAAkxkog");
	var mask_7_graphics_209 = new cjs.Graphics().p("ArrLWQk2ktAAmpIAAAAQAAmoE2ktIAAAAQE2ktG1AAIAAAAQG2AAE2EtIAAAAQE2EtAAGoIAAAAQAAGpk2EtIAAAAQk2Etm2AAIAAAAQm1AAk2ktg");
	var mask_7_graphics_210 = new cjs.Graphics().p("Ar4LiQk7kyAAmwIAAAAQAAmvE7kyIAAAAQE7kyG9AAIAAAAQG+AAE7EyIAAAAQE7EyAAGvIAAAAQAAGwk7EyIAAAAQk7Eym+AAIAAAAQm9AAk7kyg");
	var mask_7_graphics_211 = new cjs.Graphics().p("AsELuQlAk3AAm3IAAAAQAAm2FAk3IAAAAQFAk3HEAAIAAAAQHFAAFAE3IAAAAQFAE3AAG2IAAAAQAAG3lAE3IAAAAQlAE3nFAAIAAAAQnEAAlAk3g");
	var mask_7_graphics_212 = new cjs.Graphics().p("AsRL6QlFk8AAm+IAAAAQAAm9FFk8IAAAAQFGk8HLAAIAAAAQHMAAFFE8IAAAAQFGE8AAG9IAAAAQAAG+lGE8IAAAAQlFE8nMAAIAAAAQnLAAlGk8g");
	var mask_7_graphics_213 = new cjs.Graphics().p("AscMFQlKlAAAnFIAAAAQAAnEFKlBIAAAAQFKlAHSAAIAAAAQHTAAFKFAIAAAAQFKFBAAHEIAAAAQAAHFlKFAIAAAAQlKFBnTAAIAAAAQnSAAlKlBg");
	var mask_7_graphics_214 = new cjs.Graphics().p("AsoMRQlPlFAAnMIAAAAQAAnLFPlFIAAAAQFPlFHZAAIAAAAQHaAAFOFFIAAAAQFQFFAAHLIAAAAQAAHMlQFFIAAAAQlOFFnaAAIAAAAQnZAAlPlFg");
	var mask_7_graphics_215 = new cjs.Graphics().p("AszMbQlUlJAAnSIAAAAQAAnRFUlKIAAAAQFUlJHfAAIAAAAQHgAAFUFJIAAAAQFUFKAAHRIAAAAQAAHSlUFJIAAAAQlUFKngAAIAAAAQnfAAlUlKg");
	var mask_7_graphics_216 = new cjs.Graphics().p("As+MmQlYlOAAnYIAAAAQAAnXFYlOIAAAAQFYlOHmAAIAAAAQHnAAFYFOIAAAAQFYFOAAHXIAAAAQAAHYlYFOIAAAAQlYFOnnAAIAAAAQnmAAlYlOg");
	var mask_7_graphics_217 = new cjs.Graphics().p("AtJMwQlclSAAneIAAAAQAAndFclTIAAAAQFdlSHsAAIAAAAQHtAAFcFSIAAAAQFdFTAAHdIAAAAQAAHeldFSIAAAAQlcFTntAAIAAAAQnsAAldlTg");
	var mask_7_graphics_218 = new cjs.Graphics().p("AtTM6QlhlWAAnkIAAAAQAAnjFhlXIAAAAQFhlWHyAAIAAAAQHzAAFhFWIAAAAQFhFXAAHjIAAAAQAAHklhFWIAAAAQlhFXnzAAIAAAAQnyAAlhlXg");
	var mask_7_graphics_219 = new cjs.Graphics().p("AtdNEQlllaAAnqIAAAAQAAnpFllbIAAAAQFllaH4AAIAAAAQH5AAFlFaIAAAAQFlFbAAHpIAAAAQAAHqllFaIAAAAQllFbn5AAIAAAAQn4AAlllbg");
	var mask_7_graphics_220 = new cjs.Graphics().p("AtnNOQlplfAAnvIAAAAQAAnuFplfIAAAAQFpleH+AAIAAAAQH/AAFoFeIAAAAQFqFfAAHuIAAAAQAAHvlqFfIAAAAQloFen/AAIAAAAQn+AAlpleg");
	var mask_7_graphics_221 = new cjs.Graphics().p("AtwNXQltliAAn1IAAAAQAAn0FtliIAAAAQFtliIDAAIAAAAQIEAAFtFiIAAAAQFtFiAAH0IAAAAQAAH1ltFiIAAAAQltFioEAAIAAAAQoDAAltlig");
	var mask_7_graphics_222 = new cjs.Graphics().p("At5NgQlxlmAAn6IAAAAQAAn5FxlmIAAAAQFxlmIIAAIAAAAQIJAAFxFmIAAAAQFxFmAAH5IAAAAQAAH6lxFmIAAAAQlxFmoJAAIAAAAQoIAAlxlmg");
	var mask_7_graphics_223 = new cjs.Graphics().p("AuCNoQl1lpAAn/IAAAAQAAn+F1lqIAAAAQF0lpIOAAIAAAAQIPAAF0FpIAAAAQF1FqAAH+IAAAAQAAH/l1FpIAAAAQl0FqoPAAIAAAAQoOAAl0lqg");
	var mask_7_graphics_224 = new cjs.Graphics().p("AuLNxQl4ltAAoEIAAAAQAAoDF4ltIAAAAQF4ltITAAIAAAAQIUAAF4FtIAAAAQF4FtAAIDIAAAAQAAIEl4FtIAAAAQl4FtoUAAIAAAAQoTAAl4ltg");
	var mask_7_graphics_225 = new cjs.Graphics().p("AuTN5Ql8lwAAoJIAAAAQAAoIF8lwIAAAAQF7lwIYAAIAAAAQIZAAF7FwIAAAAQF8FwAAIIIAAAAQAAIJl8FwIAAAAQl7FwoZAAIAAAAQoYAAl7lwg");
	var mask_7_graphics_226 = new cjs.Graphics().p("AubOBQl/l0AAoNIAAAAQAAoMF/l0IAAAAQF/lzIcAAIAAAAQIdAAF/FzIAAAAQF/F0AAIMIAAAAQAAINl/F0IAAAAQl/FzodAAIAAAAQocAAl/lzg");
	var mask_7_graphics_227 = new cjs.Graphics().p("AujOIQmCl2AAoSIAAAAQAAoRGCl3IAAAAQGCl2IhAAIAAAAQIiAAGCF2IAAAAQGCF3AAIRIAAAAQAAISmCF2IAAAAQmCF3oiAAIAAAAQohAAmCl3g");
	var mask_7_graphics_228 = new cjs.Graphics().p("AurOQQmFl6AAoWIAAAAQAAoVGFl6IAAAAQGGl5IlAAIAAAAQImAAGFF5IAAAAQGGF6AAIVIAAAAQAAIWmGF6IAAAAQmFF5omAAIAAAAQolAAmGl5g");
	var mask_7_graphics_229 = new cjs.Graphics().p("AuyOXQmIl9AAoaIAAAAQAAoZGIl9IAAAAQGIl8IqAAIAAAAQIrAAGIF8IAAAAQGIF9AAIZIAAAAQAAIamIF9IAAAAQmIF8orAAIAAAAQoqAAmIl8g");
	var mask_7_graphics_230 = new cjs.Graphics().p("Au5OdQmLl/AAoeIAAAAQAAodGLmAIAAAAQGLl/IuAAIAAAAQIvAAGLF/IAAAAQGLGAAAIdIAAAAQAAIemLF/IAAAAQmLGAovAAIAAAAQouAAmLmAg");
	var mask_7_graphics_231 = new cjs.Graphics().p("AvAOkQmNmCAAoiIAAAAQAAohGNmCIAAAAQGOmCIyAAIAAAAQIzAAGNGCIAAAAQGOGCAAIhIAAAAQAAIimOGCIAAAAQmNGCozAAIAAAAQoyAAmOmCg");
	var mask_7_graphics_232 = new cjs.Graphics().p("AvGOqQmRmEAAomIAAAAQAAolGRmFIAAAAQGRmEI1AAIAAAAQI2AAGRGEIAAAAQGRGFAAIlIAAAAQAAImmRGEIAAAAQmRGFo2AAIAAAAQo1AAmRmFg");
	var mask_7_graphics_233 = new cjs.Graphics().p("AvMOwQmTmHAAopIAAAAQAAooGTmIIAAAAQGTmHI5AAIAAAAQI6AAGTGHIAAAAQGTGIAAIoIAAAAQAAIpmTGHIAAAAQmTGIo6AAIAAAAQo5AAmTmIg");
	var mask_7_graphics_234 = new cjs.Graphics().p("AvSO2QmWmJAAotIAAAAQAAosGWmJIAAAAQGVmKI9AAIAAAAQI+AAGVGKIAAAAQGWGJAAIsIAAAAQAAItmWGJIAAAAQmVGKo+AAIAAAAQo9AAmVmKg");
	var mask_7_graphics_235 = new cjs.Graphics().p("AvYO8QmYmMAAowIAAAAQAAovGYmMIAAAAQGYmMJAAAIAAAAQJBAAGYGMIAAAAQGYGMAAIvIAAAAQAAIwmYGMIAAAAQmYGMpBAAIAAAAQpAAAmYmMg");
	var mask_7_graphics_236 = new cjs.Graphics().p("AvePBQmamOAAozIAAAAQAAoyGamOIAAAAQGbmOJDAAIAAAAQJEAAGaGOIAAAAQGbGOAAIyIAAAAQAAIzmbGOIAAAAQmaGOpEAAIAAAAQpDAAmbmOg");
	var mask_7_graphics_237 = new cjs.Graphics().p("AvjPGQmcmQAAo2IAAAAQAAo1GcmQIAAAAQGdmQJGAAIAAAAQJHAAGcGQIAAAAQGdGQAAI1IAAAAQAAI2mdGQIAAAAQmcGQpHAAIAAAAQpGAAmdmQg");
	var mask_7_graphics_238 = new cjs.Graphics().p("AvoPLQmemSAAo5IAAAAQAAo4GemSIAAAAQGfmSJJAAIAAAAQJKAAGeGSIAAAAQGfGSAAI4IAAAAQAAI5mfGSIAAAAQmeGSpKAAIAAAAQpJAAmfmSg");
	var mask_7_graphics_239 = new cjs.Graphics().p("AvtPPQmgmUAAo7IAAAAQAAo6GgmVIAAAAQGhmUJMAAIAAAAQJNAAGgGUIAAAAQGhGVAAI6IAAAAQAAI7mhGUIAAAAQmgGVpNAAIAAAAQpMAAmhmVg");
	var mask_7_graphics_240 = new cjs.Graphics().p("AvxPUQmimWAAo+IAAAAQAAo9GimWIAAAAQGimWJPAAIAAAAQJQAAGiGWIAAAAQGiGWAAI9IAAAAQAAI+miGWIAAAAQmiGWpQAAIAAAAQpPAAmimWg");
	var mask_7_graphics_241 = new cjs.Graphics().p("Av1PYQmkmYAApAIAAAAQAAo/GkmYIAAAAQGkmYJRAAIAAAAQJSAAGkGYIAAAAQGkGYAAI/IAAAAQAAJAmkGYIAAAAQmkGYpSAAIAAAAQpRAAmkmYg");
	var mask_7_graphics_242 = new cjs.Graphics().p("Av6PcQmlmZAApDIAAAAQAApCGlmZIAAAAQGnmaJTAAIAAAAQJUAAGmGaIAAAAQGmGZAAJCIAAAAQAAJDmmGZIAAAAQmmGapUAAIAAAAQpTAAmnmag");
	var mask_7_graphics_243 = new cjs.Graphics().p("Av9PgQmombAApFIAAAAQAApEGombIAAAAQGnmbJWAAIAAAAQJXAAGnGbIAAAAQGoGbAAJEIAAAAQAAJFmoGbIAAAAQmnGbpXAAIAAAAQpWAAmnmbg");
	var mask_7_graphics_244 = new cjs.Graphics().p("AwBPjQmpmcAApHIAAAAQAApGGpmdIAAAAQGpmcJYAAIAAAAQJZAAGpGcIAAAAQGpGdAAJGIAAAAQAAJHmpGcIAAAAQmpGdpZAAIAAAAQpYAAmpmdg");
	var mask_7_graphics_245 = new cjs.Graphics().p("AwEPnQmrmeAApJIAAAAQAApIGrmeIAAAAQGqmeJaAAIAAAAQJbAAGqGeIAAAAQGrGeAAJIIAAAAQAAJJmrGeIAAAAQmqGepbAAIAAAAQpaAAmqmeg");

	this.timeline.addTween(cjs.Tween.get(mask_7).to({graphics:null,x:0,y:0}).wait(167).to({graphics:mask_7_graphics_167,x:469.7001,y:202.2003}).wait(1).to({graphics:mask_7_graphics_168,x:469.2537,y:201.1482}).wait(1).to({graphics:mask_7_graphics_169,x:468.8032,y:200.088}).wait(1).to({graphics:mask_7_graphics_170,x:468.3492,y:199.0192}).wait(1).to({graphics:mask_7_graphics_171,x:467.8929,y:197.9442}).wait(1).to({graphics:mask_7_graphics_172,x:467.4335,y:196.8633}).wait(1).to({graphics:mask_7_graphics_173,x:466.9722,y:195.777}).wait(1).to({graphics:mask_7_graphics_174,x:466.5091,y:194.6871}).wait(1).to({graphics:mask_7_graphics_175,x:466.0452,y:193.5936}).wait(1).to({graphics:mask_7_graphics_176,x:465.5799,y:192.4987}).wait(1).to({graphics:mask_7_graphics_177,x:465.1137,y:191.4021}).wait(1).to({graphics:mask_7_graphics_178,x:464.6479,y:190.3055}).wait(1).to({graphics:mask_7_graphics_179,x:464.1826,y:189.2097}).wait(1).to({graphics:mask_7_graphics_180,x:463.7182,y:188.1157}).wait(1).to({graphics:mask_7_graphics_181,x:463.2552,y:187.0245}).wait(1).to({graphics:mask_7_graphics_182,x:462.7926,y:185.9373}).wait(1).to({graphics:mask_7_graphics_183,x:462.3331,y:184.8546}).wait(1).to({graphics:mask_7_graphics_184,x:461.8759,y:183.7777}).wait(1).to({graphics:mask_7_graphics_185,x:461.4205,y:182.7067}).wait(1).to({graphics:mask_7_graphics_186,x:460.9692,y:181.6434}).wait(1).to({graphics:mask_7_graphics_187,x:460.521,y:180.5881}).wait(1).to({graphics:mask_7_graphics_188,x:460.0768,y:179.5419}).wait(1).to({graphics:mask_7_graphics_189,x:459.6367,y:178.5056}).wait(1).to({graphics:mask_7_graphics_190,x:459.2007,y:177.4795}).wait(1).to({graphics:mask_7_graphics_191,x:458.7696,y:176.4643}).wait(1).to({graphics:mask_7_graphics_192,x:458.3434,y:175.4613}).wait(1).to({graphics:mask_7_graphics_193,x:457.9231,y:174.4704}).wait(1).to({graphics:mask_7_graphics_194,x:457.5078,y:173.4925}).wait(1).to({graphics:mask_7_graphics_195,x:457.0983,y:172.5282}).wait(1).to({graphics:mask_7_graphics_196,x:456.6946,y:171.5778}).wait(1).to({graphics:mask_7_graphics_197,x:456.2968,y:170.6418}).wait(1).to({graphics:mask_7_graphics_198,x:455.9058,y:169.7202}).wait(1).to({graphics:mask_7_graphics_199,x:455.5206,y:168.8144}).wait(1).to({graphics:mask_7_graphics_200,x:455.1422,y:167.9238}).wait(1).to({graphics:mask_7_graphics_201,x:454.7709,y:167.0494}).wait(1).to({graphics:mask_7_graphics_202,x:454.4064,y:166.1908}).wait(1).to({graphics:mask_7_graphics_203,x:454.0486,y:165.3484}).wait(1).to({graphics:mask_7_graphics_204,x:453.6981,y:164.5231}).wait(1).to({graphics:mask_7_graphics_205,x:453.3543,y:163.714}).wait(1).to({graphics:mask_7_graphics_206,x:453.0181,y:162.9221}).wait(1).to({graphics:mask_7_graphics_207,x:452.6883,y:162.1467}).wait(1).to({graphics:mask_7_graphics_208,x:452.3665,y:161.388}).wait(1).to({graphics:mask_7_graphics_209,x:452.0515,y:160.6473}).wait(1).to({graphics:mask_7_graphics_210,x:451.7442,y:159.9232}).wait(1).to({graphics:mask_7_graphics_211,x:451.444,y:159.2163}).wait(1).to({graphics:mask_7_graphics_212,x:451.1515,y:158.5264}).wait(1).to({graphics:mask_7_graphics_213,x:450.8653,y:157.8541}).wait(1).to({graphics:mask_7_graphics_214,x:450.5872,y:157.1985}).wait(1).to({graphics:mask_7_graphics_215,x:450.3159,y:156.5604}).wait(1).to({graphics:mask_7_graphics_216,x:450.0522,y:155.9385}).wait(1).to({graphics:mask_7_graphics_217,x:449.7948,y:155.3337}).wait(1).to({graphics:mask_7_graphics_218,x:449.5455,y:154.7455}).wait(1).to({graphics:mask_7_graphics_219,x:449.3029,y:154.1745}).wait(1).to({graphics:mask_7_graphics_220,x:449.0671,y:153.6201}).wait(1).to({graphics:mask_7_graphics_221,x:448.8385,y:153.0814}).wait(1).to({graphics:mask_7_graphics_222,x:448.6167,y:152.5594}).wait(1).to({graphics:mask_7_graphics_223,x:448.402,y:152.0532}).wait(1).to({graphics:mask_7_graphics_224,x:448.1937,y:151.5632}).wait(1).to({graphics:mask_7_graphics_225,x:447.9921,y:151.0893}).wait(1).to({graphics:mask_7_graphics_226,x:447.7977,y:150.6308}).wait(1).to({graphics:mask_7_graphics_227,x:447.6091,y:150.1875}).wait(1).to({graphics:mask_7_graphics_228,x:447.4278,y:149.76}).wait(1).to({graphics:mask_7_graphics_229,x:447.2523,y:149.3473}).wait(1).to({graphics:mask_7_graphics_230,x:447.0835,y:148.9495}).wait(1).to({graphics:mask_7_graphics_231,x:446.9211,y:148.5666}).wait(1).to({graphics:mask_7_graphics_232,x:446.765,y:148.1985}).wait(1).to({graphics:mask_7_graphics_233,x:446.6142,y:147.8448}).wait(1).to({graphics:mask_7_graphics_234,x:446.4702,y:147.505}).wait(1).to({graphics:mask_7_graphics_235,x:446.332,y:147.1797}).wait(1).to({graphics:mask_7_graphics_236,x:446.1997,y:146.8683}).wait(1).to({graphics:mask_7_graphics_237,x:446.0733,y:146.5699}).wait(1).to({graphics:mask_7_graphics_238,x:445.9518,y:146.2856}).wait(1).to({graphics:mask_7_graphics_239,x:445.837,y:146.0146}).wait(1).to({graphics:mask_7_graphics_240,x:445.7272,y:145.7563}).wait(1).to({graphics:mask_7_graphics_241,x:445.6233,y:145.5115}).wait(1).to({graphics:mask_7_graphics_242,x:445.5247,y:145.2793}).wait(1).to({graphics:mask_7_graphics_243,x:445.4316,y:145.0593}).wait(1).to({graphics:mask_7_graphics_244,x:445.3434,y:144.8523}).wait(1).to({graphics:mask_7_graphics_245,x:445.2142,y:144.6574}).wait(565));

	// Layer_29
	this.instance_12 = new lib.Tween62("synched",0);
	this.instance_12.setTransform(467.95,128.65);
	this.instance_12.alpha = 0.5;
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_7;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(167).to({_off:false},0).to({alpha:1},78).wait(565));

	// Layer_6 (mask)
	var mask_8 = new cjs.Shape();
	mask_8._off = true;
	var mask_8_graphics_162 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_8_graphics_163 = new cjs.Graphics().p("AgnAnQgRgQAAgXIAAAAQAAgWARgQIAAAAQAQgQAXAAIAAAAQAYAAAQAQIAAAAQARAQAAAWIAAAAQAAAXgRAQIAAAAQgQAQgYAAIAAAAQgXAAgQgQg");
	var mask_8_graphics_164 = new cjs.Graphics().p("Ag+A9QgbgZAAgkIAAAAQAAgjAbgZIAAAAQAagaAkAAIAAAAQAlAAAaAaIAAAAQAbAZAAAjIAAAAQAAAkgbAZIAAAAQgaAaglAAIAAAAQgkAAgagag");
	var mask_8_graphics_165 = new cjs.Graphics().p("AhWBUQgkgjAAgxIAAAAQAAgwAkgjIAAAAQAkgjAyAAIAAAAQAzAAAkAjIAAAAQAkAjAAAwIAAAAQAAAxgkAjIAAAAQgkAjgzAAIAAAAQgyAAgkgjg");
	var mask_8_graphics_166 = new cjs.Graphics().p("AhtBrQgugsAAg/IAAAAQAAg+AugsIAAAAQAtgsBAAAIAAAAQBBAAAtAsIAAAAQAuAsAAA+IAAAAQAAA/guAsIAAAAQgtAshBAAIAAAAQhAAAgtgsg");
	var mask_8_graphics_167 = new cjs.Graphics().p("AiFCCQg3g2AAhMIAAAAQAAhLA3g2IAAAAQA4g1BNAAIAAAAQBOAAA4A1IAAAAQA3A2AABLIAAAAQAABMg3A2IAAAAQg4A1hOAAIAAAAQhNAAg4g1g");
	var mask_8_graphics_168 = new cjs.Graphics().p("AidCZQhBhAAAhZIAAAAQAAhYBBhAIAAAAQBCg/BbAAIAAAAQBcAABCA/IAAAAQBBBAAABYIAAAAQAABZhBBAIAAAAQhCA/hcAAIAAAAQhbAAhCg/g");
	var mask_8_graphics_169 = new cjs.Graphics().p("Ai0CwQhMhJAAhnIAAAAQAAhmBMhJIAAAAQBLhJBpAAIAAAAQBqAABLBJIAAAAQBMBJAABmIAAAAQAABnhMBJIAAAAQhLBJhqAAIAAAAQhpAAhLhJg");
	var mask_8_graphics_170 = new cjs.Graphics().p("AjMDHQhVhSAAh1IAAAAQAAh0BVhSIAAAAQBVhSB3AAIAAAAQB4AABVBSIAAAAQBVBSAAB0IAAAAQAAB1hVBSIAAAAQhVBSh4AAIAAAAQh3AAhVhSg");
	var mask_8_graphics_171 = new cjs.Graphics().p("AjkDeQhfhcAAiCIAAAAQAAiBBfhcIAAAAQBfhcCFAAIAAAAQCGAABfBcIAAAAQBfBcAACBIAAAAQAACChfBcIAAAAQhfBciGAAIAAAAQiFAAhfhcg");
	var mask_8_graphics_172 = new cjs.Graphics().p("Aj8D1QhphlAAiQIAAAAQAAiPBphlIAAAAQBphmCTAAIAAAAQCUAABpBmIAAAAQBpBlAACPIAAAAQAACQhpBlIAAAAQhpBmiUAAIAAAAQiTAAhphmg");
	var mask_8_graphics_173 = new cjs.Graphics().p("AkUEMQhyhvAAidIAAAAQAAicByhvIAAAAQBzhvChAAIAAAAQCiAABzBvIAAAAQByBvAACcIAAAAQAACdhyBvIAAAAQhzBviiAAIAAAAQihAAhzhvg");
	var mask_8_graphics_174 = new cjs.Graphics().p("AkrEjQh9h4AAirIAAAAQAAiqB9h4IAAAAQB8h5CvAAIAAAAQCwAAB8B5IAAAAQB9B4AACqIAAAAQAACrh9B4IAAAAQh8B5iwAAIAAAAQivAAh8h5g");
	var mask_8_graphics_175 = new cjs.Graphics().p("AlDE6QiGiCAAi4IAAAAQAAi3CGiCIAAAAQCGiCC9AAIAAAAQC+AACGCCIAAAAQCGCCAAC3IAAAAQAAC4iGCCIAAAAQiGCCi+AAIAAAAQi9AAiGiCg");
	var mask_8_graphics_176 = new cjs.Graphics().p("AlaFRQiQiMAAjFIAAAAQAAjECQiMIAAAAQCQiLDKAAIAAAAQDLAACQCLIAAAAQCQCMAADEIAAAAQAADFiQCMIAAAAQiQCLjLAAIAAAAQjKAAiQiLg");
	var mask_8_graphics_177 = new cjs.Graphics().p("AlxFnQiaiVAAjSIAAAAQAAjRCaiVIAAAAQCZiVDYAAIAAAAQDZAACZCVIAAAAQCaCVAADRIAAAAQAADSiaCVIAAAAQiZCVjZAAIAAAAQjYAAiZiVg");
	var mask_8_graphics_178 = new cjs.Graphics().p("AmIF9QijieAAjfIAAAAQAAjeCjieIAAAAQCjieDlAAIAAAAQDmAACjCeIAAAAQCjCeAADeIAAAAQAADfijCeIAAAAQijCejmAAIAAAAQjlAAijieg");
	var mask_8_graphics_179 = new cjs.Graphics().p("AmfGTQisinAAjsIAAAAQAAjrCsinIAAAAQCtinDyAAIAAAAQDzAACtCnIAAAAQCsCnAADrIAAAAQAADsisCnIAAAAQitCnjzAAIAAAAQjyAAiting");
	var mask_8_graphics_180 = new cjs.Graphics().p("Am1GpQi1iwAAj5IAAAAQAAj4C1iwIAAAAQC1iwEAAAIAAAAQEBAAC1CwIAAAAQC1CwAAD4IAAAAQAAD5i1CwIAAAAQi1CwkBAAIAAAAQkAAAi1iwg");
	var mask_8_graphics_181 = new cjs.Graphics().p("AnLG+Qi/i5AAkFIAAAAQAAkEC/i5IAAAAQC/i5EMAAIAAAAQENAAC/C5IAAAAQC/C5AAEEIAAAAQAAEFi/C5IAAAAQi/C5kNAAIAAAAQkMAAi/i5g");
	var mask_8_graphics_182 = new cjs.Graphics().p("AnhHTQjHjBAAkSIAAAAQAAkRDHjCIAAAAQDIjBEZAAIAAAAQEaAADIDBIAAAAQDHDCAAERIAAAAQAAESjHDBIAAAAQjIDCkaAAIAAAAQkZAAjIjCg");
	var mask_8_graphics_183 = new cjs.Graphics().p("An2HoQjRjKAAkeIAAAAQAAkdDRjKIAAAAQDQjKEmAAIAAAAQEnAADQDKIAAAAQDRDKAAEdIAAAAQAAEejRDKIAAAAQjQDKknAAIAAAAQkmAAjQjKg");
	var mask_8_graphics_184 = new cjs.Graphics().p("AoLH8QjZjSAAkqIAAAAQAAkpDZjTIAAAAQDZjSEyAAIAAAAQEzAADZDSIAAAAQDZDTAAEpIAAAAQAAEqjZDSIAAAAQjZDTkzAAIAAAAQkyAAjZjTg");
	var mask_8_graphics_185 = new cjs.Graphics().p("AogIQQjhjaAAk2IAAAAQAAk1DhjbIAAAAQDijaE+AAIAAAAQE/AADiDaIAAAAQDhDbAAE1IAAAAQAAE2jhDaIAAAAQjiDbk/AAIAAAAQk+AAjijbg");
	var mask_8_graphics_186 = new cjs.Graphics().p("Ao0IkQjqjjAAlBIAAAAQAAlADqjjIAAAAQDqjjFKAAIAAAAQFLAADqDjIAAAAQDqDjAAFAIAAAAQAAFBjqDjIAAAAQjqDjlLAAIAAAAQlKAAjqjjg");
	var mask_8_graphics_187 = new cjs.Graphics().p("ApII3QjyjrAAlMIAAAAQAAlLDyjrIAAAAQDzjrFVAAIAAAAQFWAADyDrIAAAAQDzDrAAFLIAAAAQAAFMjzDrIAAAAQjyDrlWAAIAAAAQlVAAjzjrg");
	var mask_8_graphics_188 = new cjs.Graphics().p("ApbJKQj6jzAAlXIAAAAQAAlWD6jzIAAAAQD6jzFhAAIAAAAQFiAAD6DzIAAAAQD6DzAAFWIAAAAQAAFXj6DzIAAAAQj6DzliAAIAAAAQlhAAj6jzg");
	var mask_8_graphics_189 = new cjs.Graphics().p("ApuJcQkCj6AAliIAAAAQAAlhECj7IAAAAQECj6FsAAIAAAAQFtAAECD6IAAAAQECD7AAFhIAAAAQAAFikCD6IAAAAQkCD7ltAAIAAAAQlsAAkCj7g");
	var mask_8_graphics_190 = new cjs.Graphics().p("AqAJuQkKkCAAlsIAAAAQAAlrEKkCIAAAAQEJkCF3AAIAAAAQF4AAEJECIAAAAQEKECAAFrIAAAAQAAFskKECIAAAAQkJECl4AAIAAAAQl3AAkJkCg");
	var mask_8_graphics_191 = new cjs.Graphics().p("AqSKAQkRkJAAl3IAAAAQAAl2ERkJIAAAAQERkJGBAAIAAAAQGCAAEREJIAAAAQEREJAAF2IAAAAQAAF3kREJIAAAAQkREJmCAAIAAAAQmBAAkRkJg");
	var mask_8_graphics_192 = new cjs.Graphics().p("AqkKRQkYkQAAmBIAAAAQAAmAEYkQIAAAAQEZkQGLAAIAAAAQGMAAEZEQIAAAAQEYEQAAGAIAAAAQAAGBkYEQIAAAAQkZEQmMAAIAAAAQmLAAkZkQg");
	var mask_8_graphics_193 = new cjs.Graphics().p("Aq1KhQkfkXAAmKIAAAAQAAmJEfkXIAAAAQEgkXGVAAIAAAAQGWAAEgEXIAAAAQEfEXAAGJIAAAAQAAGKkfEXIAAAAQkgEXmWAAIAAAAQmVAAkgkXg");
	var mask_8_graphics_194 = new cjs.Graphics().p("ArGKxQkmkdAAmUIAAAAQAAmTEmkeIAAAAQEnkdGfAAIAAAAQGgAAEmEdIAAAAQEnEeAAGTIAAAAQAAGUknEdIAAAAQkmEemgAAIAAAAQmfAAknkeg");
	var mask_8_graphics_195 = new cjs.Graphics().p("ArWLBQkskkAAmdIAAAAQAAmcEskkIAAAAQEtkkGpAAIAAAAQGqAAEsEkIAAAAQEtEkAAGcIAAAAQAAGdktEkIAAAAQksEkmqAAIAAAAQmpAAktkkg");
	var mask_8_graphics_196 = new cjs.Graphics().p("ArlLQQk0kqAAmmIAAAAQAAmlE0kqIAAAAQEzkqGyAAIAAAAQGzAAEzEqIAAAAQE0EqAAGlIAAAAQAAGmk0EqIAAAAQkzEqmzAAIAAAAQmyAAkzkqg");
	var mask_8_graphics_197 = new cjs.Graphics().p("Ar0LfQk6kxAAmuIAAAAQAAmtE6kxIAAAAQE5kwG7AAIAAAAQG8AAE5EwIAAAAQE6ExAAGtIAAAAQAAGuk6ExIAAAAQk5Ewm8AAIAAAAQm7AAk5kwg");
	var mask_8_graphics_198 = new cjs.Graphics().p("AsDLtQlAk2AAm3IAAAAQAAm2FAk2IAAAAQFAk2HDAAIAAAAQHEAAFAE2IAAAAQFAE2AAG2IAAAAQAAG3lAE2IAAAAQlAE2nEAAIAAAAQnDAAlAk2g");
	var mask_8_graphics_199 = new cjs.Graphics().p("AsRL7QlGk8AAm/IAAAAQAAm+FGk8IAAAAQFGk8HLAAIAAAAQHMAAFGE8IAAAAQFGE8AAG+IAAAAQAAG/lGE8IAAAAQlGE8nMAAIAAAAQnLAAlGk8g");
	var mask_8_graphics_200 = new cjs.Graphics().p("AsfMIQlLlBAAnHIAAAAQAAnGFLlBIAAAAQFMlCHTAAIAAAAQHUAAFMFCIAAAAQFLFBAAHGIAAAAQAAHHlLFBIAAAAQlMFCnUAAIAAAAQnTAAlMlCg");
	var mask_8_graphics_201 = new cjs.Graphics().p("AssMVQlRlHAAnOIAAAAQAAnNFRlHIAAAAQFRlHHbAAIAAAAQHcAAFRFHIAAAAQFRFHAAHNIAAAAQAAHOlRFHIAAAAQlRFHncAAIAAAAQnbAAlRlHg");
	var mask_8_graphics_202 = new cjs.Graphics().p("As5MhQlWlMAAnVIAAAAQAAnUFWlNIAAAAQFWlLHjAAIAAAAQHkAAFWFLIAAAAQFWFNAAHUIAAAAQAAHVlWFMIAAAAQlWFMnkAAIAAAAQnjAAlWlMg");
	var mask_8_graphics_203 = new cjs.Graphics().p("AtFMtQlblRAAncIAAAAQAAnbFblSIAAAAQFblQHqAAIAAAAQHrAAFbFQIAAAAQFbFSAAHbIAAAAQAAHclbFRIAAAAQlbFRnrAAIAAAAQnqAAlblRg");
	var mask_8_graphics_204 = new cjs.Graphics().p("AtRM5QlglWAAnjIAAAAQAAniFglWIAAAAQFglWHxAAIAAAAQHyAAFgFWIAAAAQFgFWAAHiIAAAAQAAHjlgFWIAAAAQlgFWnyAAIAAAAQnxAAlglWg");
	var mask_8_graphics_205 = new cjs.Graphics().p("AtdNEQlklaAAnqIAAAAQAAnpFklaIAAAAQFllaH4AAIAAAAQH5AAFkFaIAAAAQFlFaAAHpIAAAAQAAHqllFaIAAAAQlkFan5AAIAAAAQn4AAlllag");
	var mask_8_graphics_206 = new cjs.Graphics().p("AtoNOQlpleAAnwIAAAAQAAnvFplfIAAAAQFqleH+AAIAAAAQH/AAFpFeIAAAAQFqFfAAHvIAAAAQAAHwlqFeIAAAAQlpFfn/AAIAAAAQn+AAlqlfg");
	var mask_8_graphics_207 = new cjs.Graphics().p("AtyNZQluljAAn2IAAAAQAAn1FuljIAAAAQFuljIEAAIAAAAQIFAAFuFjIAAAAQFuFjAAH1IAAAAQAAH2luFjIAAAAQluFjoFAAIAAAAQoEAAluljg");
	var mask_8_graphics_208 = new cjs.Graphics().p("At8NiQlylmAAn8IAAAAQAAn7FylnIAAAAQFylnIKAAIAAAAQILAAFyFnIAAAAQFyFnAAH7IAAAAQAAH8lyFmIAAAAQlyFooLAAIAAAAQoKAAlylog");
	var mask_8_graphics_209 = new cjs.Graphics().p("AuGNsQl2lrAAoBIAAAAQAAoAF2lrIAAAAQF2lrIQAAIAAAAQIRAAF1FrIAAAAQF3FrAAIAIAAAAQAAIBl3FrIAAAAQl1FroRAAIAAAAQoQAAl2lrg");
	var mask_8_graphics_210 = new cjs.Graphics().p("AuPN1Ql6lvAAoGIAAAAQAAoFF6lvIAAAAQF6lvIVAAIAAAAQIWAAF6FvIAAAAQF6FvAAIFIAAAAQAAIGl6FvIAAAAQl6FvoWAAIAAAAQoVAAl6lvg");
	var mask_8_graphics_211 = new cjs.Graphics().p("AuYN9Ql9lyAAoLIAAAAQAAoKF9lzIAAAAQF+lyIaAAIAAAAQIbAAF9FyIAAAAQF+FzAAIKIAAAAQAAILl+FyIAAAAQl9FzobAAIAAAAQoaAAl+lzg");
	var mask_8_graphics_212 = new cjs.Graphics().p("AugOFQmBl1AAoQIAAAAQAAoPGBl2IAAAAQGBl1IfAAIAAAAQIgAAGBF1IAAAAQGBF2AAIPIAAAAQAAIQmBF1IAAAAQmBF2ogAAIAAAAQofAAmBl2g");
	var mask_8_graphics_213 = new cjs.Graphics().p("AuoONQmEl4AAoVIAAAAQAAoUGEl5IAAAAQGEl4IkAAIAAAAQIlAAGEF4IAAAAQGEF5AAIUIAAAAQAAIVmEF4IAAAAQmEF5olAAIAAAAQokAAmEl5g");
	var mask_8_graphics_214 = new cjs.Graphics().p("AuwOVQmHl8AAoZIAAAAQAAoYGHl8IAAAAQGIl8IoAAIAAAAQIpAAGHF8IAAAAQGIF8AAIYIAAAAQAAIZmIF8IAAAAQmHF8opAAIAAAAQooAAmIl8g");
	var mask_8_graphics_215 = new cjs.Graphics().p("Au3OcQmKl/AAodIAAAAQAAocGKl/IAAAAQGKl+ItAAIAAAAQIuAAGKF+IAAAAQGKF/AAIcIAAAAQAAIdmKF/IAAAAQmKF+ouAAIAAAAQotAAmKl+g");
	var mask_8_graphics_216 = new cjs.Graphics().p("Au+OiQmNmBAAohIAAAAQAAogGNmCIAAAAQGNmBIxAAIAAAAQIyAAGMGBIAAAAQGOGCAAIgIAAAAQAAIhmOGBIAAAAQmMGCoyAAIAAAAQoxAAmNmCg");
	var mask_8_graphics_217 = new cjs.Graphics().p("AvEOoQmQmDAAolIAAAAQAAokGQmEIAAAAQGQmEI0AAIAAAAQI1AAGQGEIAAAAQGQGEAAIkIAAAAQAAIlmQGDIAAAAQmQGFo1AAIAAAAQo0AAmQmFg");
	var mask_8_graphics_218 = new cjs.Graphics().p("AvKOuQmSmGAAooIAAAAQAAonGSmHIAAAAQGSmGI4AAIAAAAQI5AAGSGGIAAAAQGSGHAAInIAAAAQAAIomSGGIAAAAQmSGHo5AAIAAAAQo4AAmSmHg");
	var mask_8_graphics_219 = new cjs.Graphics().p("AvQO0QmVmJAAorIAAAAQAAoqGVmJIAAAAQGVmJI7AAIAAAAQI8AAGVGJIAAAAQGVGJAAIqIAAAAQAAIrmVGJIAAAAQmVGJo8AAIAAAAQo7AAmVmJg");
	var mask_8_graphics_220 = new cjs.Graphics().p("AvVO5QmXmLAAouIAAAAQAAotGXmLIAAAAQGXmLI+AAIAAAAQI/AAGXGLIAAAAQGXGLAAItIAAAAQAAIumXGLIAAAAQmXGLo/AAIAAAAQo+AAmXmLg");
	var mask_8_graphics_221 = new cjs.Graphics().p("AvaO+QmZmNAAoxIAAAAQAAowGZmNIAAAAQGZmNJBAAIAAAAQJCAAGZGNIAAAAQGZGNAAIwIAAAAQAAIxmZGNIAAAAQmZGNpCAAIAAAAQpBAAmZmNg");
	var mask_8_graphics_222 = new cjs.Graphics().p("AvfPCQmbmOAAo0IAAAAQAAozGbmPIAAAAQGbmOJEAAIAAAAQJFAAGbGOIAAAAQGbGPAAIzIAAAAQAAI0mbGOIAAAAQmbGPpFAAIAAAAQpEAAmbmPg");
	var mask_8_graphics_223 = new cjs.Graphics().p("AvjPGQmdmQAAo2IAAAAQAAo1GdmRIAAAAQGdmQJGAAIAAAAQJHAAGdGQIAAAAQGdGRAAI1IAAAAQAAI2mdGQIAAAAQmdGRpHAAIAAAAQpGAAmdmRg");

	this.timeline.addTween(cjs.Tween.get(mask_8).to({graphics:null,x:0,y:0}).wait(162).to({graphics:mask_8_graphics_162,x:718.9002,y:350.4501}).wait(1).to({graphics:mask_8_graphics_163,x:718.8853,y:350.4505}).wait(1).to({graphics:mask_8_graphics_164,x:718.87,y:350.4505}).wait(1).to({graphics:mask_8_graphics_165,x:718.8543,y:350.451}).wait(1).to({graphics:mask_8_graphics_166,x:718.8385,y:350.451}).wait(1).to({graphics:mask_8_graphics_167,x:718.8232,y:350.451}).wait(1).to({graphics:mask_8_graphics_168,x:718.8075,y:350.4514}).wait(1).to({graphics:mask_8_graphics_169,x:718.7917,y:350.4514}).wait(1).to({graphics:mask_8_graphics_170,x:718.776,y:350.4519}).wait(1).to({graphics:mask_8_graphics_171,x:718.7602,y:350.4514}).wait(1).to({graphics:mask_8_graphics_172,x:718.7449,y:350.4519}).wait(1).to({graphics:mask_8_graphics_173,x:718.7287,y:350.4523}).wait(1).to({graphics:mask_8_graphics_174,x:718.713,y:350.4519}).wait(1).to({graphics:mask_8_graphics_175,x:718.6977,y:350.4523}).wait(1).to({graphics:mask_8_graphics_176,x:718.6824,y:350.4523}).wait(1).to({graphics:mask_8_graphics_177,x:718.6671,y:350.4528}).wait(1).to({graphics:mask_8_graphics_178,x:718.6518,y:350.4528}).wait(1).to({graphics:mask_8_graphics_179,x:718.6369,y:350.4532}).wait(1).to({graphics:mask_8_graphics_180,x:718.6221,y:350.4532}).wait(1).to({graphics:mask_8_graphics_181,x:718.6077,y:350.4537}).wait(1).to({graphics:mask_8_graphics_182,x:718.5928,y:350.4532}).wait(1).to({graphics:mask_8_graphics_183,x:718.5793,y:350.4537}).wait(1).to({graphics:mask_8_graphics_184,x:718.5654,y:350.4537}).wait(1).to({graphics:mask_8_graphics_185,x:718.5519,y:350.4541}).wait(1).to({graphics:mask_8_graphics_186,x:718.5379,y:350.4541}).wait(1).to({graphics:mask_8_graphics_187,x:718.5249,y:350.4541}).wait(1).to({graphics:mask_8_graphics_188,x:718.5128,y:350.4546}).wait(1).to({graphics:mask_8_graphics_189,x:718.4997,y:350.4546}).wait(1).to({graphics:mask_8_graphics_190,x:718.488,y:350.4546}).wait(1).to({graphics:mask_8_graphics_191,x:718.4758,y:350.4546}).wait(1).to({graphics:mask_8_graphics_192,x:718.4646,y:350.455}).wait(1).to({graphics:mask_8_graphics_193,x:718.4533,y:350.455}).wait(1).to({graphics:mask_8_graphics_194,x:718.4421,y:350.455}).wait(1).to({graphics:mask_8_graphics_195,x:718.4317,y:350.4555}).wait(1).to({graphics:mask_8_graphics_196,x:718.4214,y:350.4555}).wait(1).to({graphics:mask_8_graphics_197,x:718.4115,y:350.4555}).wait(1).to({graphics:mask_8_graphics_198,x:718.4016,y:350.4559}).wait(1).to({graphics:mask_8_graphics_199,x:718.3921,y:350.4559}).wait(1).to({graphics:mask_8_graphics_200,x:718.3831,y:350.4559}).wait(1).to({graphics:mask_8_graphics_201,x:718.3741,y:350.4559}).wait(1).to({graphics:mask_8_graphics_202,x:718.3661,y:350.4559}).wait(1).to({graphics:mask_8_graphics_203,x:718.3575,y:350.4559}).wait(1).to({graphics:mask_8_graphics_204,x:718.3498,y:350.4564}).wait(1).to({graphics:mask_8_graphics_205,x:718.3422,y:350.4559}).wait(1).to({graphics:mask_8_graphics_206,x:718.335,y:350.4559}).wait(1).to({graphics:mask_8_graphics_207,x:718.3278,y:350.4564}).wait(1).to({graphics:mask_8_graphics_208,x:718.3215,y:350.4564}).wait(1).to({graphics:mask_8_graphics_209,x:718.3147,y:350.4564}).wait(1).to({graphics:mask_8_graphics_210,x:718.3089,y:350.4564}).wait(1).to({graphics:mask_8_graphics_211,x:718.303,y:350.4564}).wait(1).to({graphics:mask_8_graphics_212,x:718.2976,y:350.4568}).wait(1).to({graphics:mask_8_graphics_213,x:718.2922,y:350.4569}).wait(1).to({graphics:mask_8_graphics_214,x:718.2873,y:350.4568}).wait(1).to({graphics:mask_8_graphics_215,x:718.2828,y:350.4568}).wait(1).to({graphics:mask_8_graphics_216,x:718.2778,y:350.4569}).wait(1).to({graphics:mask_8_graphics_217,x:718.2738,y:350.4568}).wait(1).to({graphics:mask_8_graphics_218,x:718.2697,y:350.4573}).wait(1).to({graphics:mask_8_graphics_219,x:718.2657,y:350.4568}).wait(1).to({graphics:mask_8_graphics_220,x:718.2625,y:350.4568}).wait(1).to({graphics:mask_8_graphics_221,x:718.2594,y:350.4573}).wait(1).to({graphics:mask_8_graphics_222,x:718.2563,y:350.4573}).wait(1).to({graphics:mask_8_graphics_223,x:718.164,y:350.4573}).wait(587));

	// Layer_28
	this.instance_13 = new lib.Tween60("synched",0);
	this.instance_13.setTransform(778.45,300.5);
	this.instance_13.alpha = 0.5;
	this.instance_13._off = true;

	var maskedShapeInstanceList = [this.instance_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_8;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(162).to({_off:false},0).to({alpha:1},61).wait(587));

	// Layer_6 (mask)
	var mask_9 = new cjs.Shape();
	mask_9._off = true;
	var mask_9_graphics_341 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_9_graphics_342 = new cjs.Graphics().p("AgiAhQgOgNAAgUIAAAAQAAgTAOgNIAAAAQAPgOATAAIAAAAQAUAAAPAOIAAAAQAOANAAATIAAAAQAAAUgOANIAAAAQgPAOgUAAIAAAAQgTAAgPgOg");
	var mask_9_graphics_343 = new cjs.Graphics().p("AgzAzQgWgVAAgeIAAAAQAAgdAWgVIAAAAQAVgUAeAAIAAAAQAfAAAVAUIAAAAQAWAVAAAdIAAAAQAAAegWAVIAAAAQgVAUgfAAIAAAAQgeAAgVgUg");
	var mask_9_graphics_344 = new cjs.Graphics().p("AhFBEQgdgcAAgoIAAAAQAAgnAdgcIAAAAQAdgcAoAAIAAAAQApAAAdAcIAAAAQAdAcAAAnIAAAAQAAAogdAcIAAAAQgdAcgpAAIAAAAQgoAAgdgcg");
	var mask_9_graphics_345 = new cjs.Graphics().p("AhXBVQgkgjAAgyIAAAAQAAgxAkgjIAAAAQAlgjAyAAIAAAAQAzAAAlAjIAAAAQAkAjAAAxIAAAAQAAAygkAjIAAAAQglAjgzAAIAAAAQgyAAglgjg");
	var mask_9_graphics_346 = new cjs.Graphics().p("AhpBmQgsgqAAg8IAAAAQAAg7AsgqIAAAAQAsgrA9AAIAAAAQA+AAAsArIAAAAQAsAqAAA7IAAAAQAAA8gsAqIAAAAQgsArg+AAIAAAAQg9AAgsgrg");
	var mask_9_graphics_347 = new cjs.Graphics().p("Ah7B4QgzgyAAhGIAAAAQAAhFAzgyIAAAAQAzgyBIAAIAAAAQBJAAAzAyIAAAAQAzAyAABFIAAAAQAABGgzAyIAAAAQgzAyhJAAIAAAAQhIAAgzgyg");
	var mask_9_graphics_348 = new cjs.Graphics().p("AiNCJQg7g4AAhRIAAAAQAAhQA7g5IAAAAQA7g4BSAAIAAAAQBTAAA7A4IAAAAQA7A5AABQIAAAAQAABRg7A4IAAAAQg7A5hTAAIAAAAQhSAAg7g5g");
	var mask_9_graphics_349 = new cjs.Graphics().p("AifCbQhChAAAhbIAAAAQAAhaBChAIAAAAQBChABdAAIAAAAQBeAABCBAIAAAAQBCBAAABaIAAAAQAABbhCBAIAAAAQhCBAheAAIAAAAQhdAAhChAg");
	var mask_9_graphics_350 = new cjs.Graphics().p("AixCtQhKhIAAhlIAAAAQAAhkBKhIIAAAAQBKhHBnAAIAAAAQBoAABKBHIAAAAQBKBIAABkIAAAAQAABlhKBIIAAAAQhKBHhoAAIAAAAQhnAAhKhHg");
	var mask_9_graphics_351 = new cjs.Graphics().p("AjDC+QhShOAAhwIAAAAQAAhvBShOIAAAAQBRhPByAAIAAAAQBzAABRBPIAAAAQBSBOAABvIAAAAQAABwhSBOIAAAAQhRBPhzAAIAAAAQhyAAhRhPg");
	var mask_9_graphics_352 = new cjs.Graphics().p("AjWDQQhYhWAAh6IAAAAQAAh5BYhWIAAAAQBZhWB9AAIAAAAQB+AABYBWIAAAAQBZBWAAB5IAAAAQAAB6hZBWIAAAAQhYBWh+AAIAAAAQh9AAhZhWg");
	var mask_9_graphics_353 = new cjs.Graphics().p("AjoDiQhgheAAiEIAAAAQAAiDBgheIAAAAQBhhdCHAAIAAAAQCIAABhBdIAAAAQBgBeAACDIAAAAQAACEhgBeIAAAAQhhBdiIAAIAAAAQiHAAhhhdg");
	var mask_9_graphics_354 = new cjs.Graphics().p("Aj6DzQhohlAAiOIAAAAQAAiNBohlIAAAAQBohlCSAAIAAAAQCTAABoBlIAAAAQBoBlAACNIAAAAQAACOhoBlIAAAAQhoBliTAAIAAAAQiSAAhohlg");
	var mask_9_graphics_355 = new cjs.Graphics().p("AkMEFQhvhsAAiZIAAAAQAAiYBvhsIAAAAQBvhsCdAAIAAAAQCeAABvBsIAAAAQBvBsAACYIAAAAQAACZhvBsIAAAAQhvBsieAAIAAAAQidAAhvhsg");
	var mask_9_graphics_356 = new cjs.Graphics().p("AkeEWQh3hzAAijIAAAAQAAiiB3hzIAAAAQB3h0CnAAIAAAAQCoAAB3B0IAAAAQB3BzAACiIAAAAQAACjh3BzIAAAAQh3B0ioAAIAAAAQinAAh3h0g");
	var mask_9_graphics_357 = new cjs.Graphics().p("AkwEoQh+h7AAitIAAAAQAAisB+h7IAAAAQB+h6CyAAIAAAAQCzAAB+B6IAAAAQB+B7AACsIAAAAQAACth+B7IAAAAQh+B6izAAIAAAAQiyAAh+h6g");
	var mask_9_graphics_358 = new cjs.Graphics().p("AlCE5QiGiCAAi3IAAAAQAAi2CGiCIAAAAQCGiCC8AAIAAAAQC9AACGCCIAAAAQCGCCAAC2IAAAAQAAC3iGCCIAAAAQiGCCi9AAIAAAAQi8AAiGiCg");
	var mask_9_graphics_359 = new cjs.Graphics().p("AlUFKQiNiIAAjCIAAAAQAAjACNiJIAAAAQCOiJDGAAIAAAAQDHAACNCJIAAAAQCOCJAADAIAAAAQAADCiOCIIAAAAQiNCJjHAAIAAAAQjGAAiOiJg");
	var mask_9_graphics_360 = new cjs.Graphics().p("AllFbQiViPAAjMIAAAAQAAjLCViQIAAAAQCUiPDRAAIAAAAQDSAACUCPIAAAAQCVCQAADLIAAAAQAADMiVCPIAAAAQiUCQjSAAIAAAAQjRAAiUiQg");
	var mask_9_graphics_361 = new cjs.Graphics().p("Al3FsQibiXAAjVIAAAAQAAjUCbiYIAAAAQCciWDbAAIAAAAQDcAACcCWIAAAAQCbCYAADUIAAAAQAADVibCXIAAAAQicCXjcAAIAAAAQjbAAiciXg");
	var mask_9_graphics_362 = new cjs.Graphics().p("AmIF9QijieAAjfIAAAAQAAjeCjieIAAAAQCjieDlAAIAAAAQDmAACjCeIAAAAQCjCeAADeIAAAAQAADfijCeIAAAAQijCejmAAIAAAAQjlAAijieg");
	var mask_9_graphics_363 = new cjs.Graphics().p("AmZGOQiqilAAjpIAAAAQAAjoCqilIAAAAQCqilDvAAIAAAAQDwAACqClIAAAAQCqClAADoIAAAAQAADpiqClIAAAAQiqCljwAAIAAAAQjvAAiqilg");
	var mask_9_graphics_364 = new cjs.Graphics().p("AmqGeQixirAAjzIAAAAQAAjyCxisIAAAAQCxirD5AAIAAAAQD6AACxCrIAAAAQCxCsAADyIAAAAQAADzixCrIAAAAQixCsj6AAIAAAAQj5AAixisg");
	var mask_9_graphics_365 = new cjs.Graphics().p("Am7GvQi4izAAj8IAAAAQAAj7C4izIAAAAQC4iyEDAAIAAAAQEEAAC4CyIAAAAQC4CzAAD7IAAAAQAAD8i4CzIAAAAQi4CykEAAIAAAAQkDAAi4iyg");
	var mask_9_graphics_366 = new cjs.Graphics().p("AnMG/Qi/i5AAkGIAAAAQAAkFC/i5IAAAAQC/i5ENAAIAAAAQEOAAC/C5IAAAAQC/C5AAEFIAAAAQAAEGi/C5IAAAAQi/C5kOAAIAAAAQkNAAi/i5g");
	var mask_9_graphics_367 = new cjs.Graphics().p("AncHPQjGjAAAkPIAAAAQAAkODGjAIAAAAQDGjAEWAAIAAAAQEXAADGDAIAAAAQDGDAAAEOIAAAAQAAEPjGDAIAAAAQjGDAkXAAIAAAAQkWAAjGjAg");
	var mask_9_graphics_368 = new cjs.Graphics().p("AnsHfQjNjHAAkYIAAAAQAAkXDNjHIAAAAQDMjGEgAAIAAAAQEhAADMDGIAAAAQDNDHAAEXIAAAAQAAEYjNDHIAAAAQjMDGkhAAIAAAAQkgAAjMjGg");
	var mask_9_graphics_369 = new cjs.Graphics().p("An8HuQjTjNAAkhIAAAAQAAkgDTjNIAAAAQDTjNEpAAIAAAAQEqAADTDNIAAAAQDTDNAAEgIAAAAQAAEhjTDNIAAAAQjTDNkqAAIAAAAQkpAAjTjNg");
	var mask_9_graphics_370 = new cjs.Graphics().p("AoMH9QjajTAAkqIAAAAQAAkpDajUIAAAAQDZjTEzAAIAAAAQE0AADZDTIAAAAQDaDUAAEpIAAAAQAAEqjaDTIAAAAQjZDUk0AAIAAAAQkzAAjZjUg");
	var mask_9_graphics_371 = new cjs.Graphics().p("AocIMQjgjZAAkzIAAAAQAAkyDgjaIAAAAQDgjZE8AAIAAAAQE9AADgDZIAAAAQDgDaAAEyIAAAAQAAEzjgDZIAAAAQjgDak9AAIAAAAQk8AAjgjag");
	var mask_9_graphics_372 = new cjs.Graphics().p("AorIbQjmjfAAk8IAAAAQAAk7DmjgIAAAAQDmjfFFAAIAAAAQFGAADmDfIAAAAQDmDgAAE7IAAAAQAAE8jmDfIAAAAQjmDglGAAIAAAAQlFAAjmjgg");
	var mask_9_graphics_373 = new cjs.Graphics().p("Ao6IqQjsjmAAlEIAAAAQAAlDDsjmIAAAAQDtjmFNAAIAAAAQFOAADtDmIAAAAQDsDmAAFDIAAAAQAAFEjsDmIAAAAQjtDmlOAAIAAAAQlNAAjtjmg");
	var mask_9_graphics_374 = new cjs.Graphics().p("ApJI4QjyjrAAlNIAAAAQAAlMDyjrIAAAAQDzjsFWAAIAAAAQFXAADzDsIAAAAQDyDrAAFMIAAAAQAAFNjyDrIAAAAQjzDslXAAIAAAAQlWAAjzjsg");
	var mask_9_graphics_375 = new cjs.Graphics().p("ApXJGQj5jxAAlVIAAAAQAAlUD5jyIAAAAQD4jxFfAAIAAAAQFgAAD4DxIAAAAQD5DyAAFUIAAAAQAAFVj5DxIAAAAQj4DylgAAIAAAAQlfAAj4jyg");
	var mask_9_graphics_376 = new cjs.Graphics().p("ApmJUQj+j3AAldIAAAAQAAlcD+j3IAAAAQD/j3FnAAIAAAAQFoAAD+D3IAAAAQD/D3AAFcIAAAAQAAFdj/D3IAAAAQj+D3loAAIAAAAQlnAAj/j3g");
	var mask_9_graphics_377 = new cjs.Graphics().p("Ap0JiQkEj9AAllIAAAAQAAlkEEj9IAAAAQEFj8FvAAIAAAAQFwAAEED8IAAAAQEFD9AAFkIAAAAQAAFlkFD9IAAAAQkED8lwAAIAAAAQlvAAkFj8g");
	var mask_9_graphics_378 = new cjs.Graphics().p("AqBJvQkKkCAAltIAAAAQAAlsEKkCIAAAAQEKkCF3AAIAAAAQF4AAEKECIAAAAQEKECAAFsIAAAAQAAFtkKECIAAAAQkKECl4AAIAAAAQl3AAkKkCg");
	var mask_9_graphics_379 = new cjs.Graphics().p("AqPJ8QkPkHAAl1IAAAAQAAl0EPkHIAAAAQEQkIF/AAIAAAAQGAAAEPEIIAAAAQEQEHAAF0IAAAAQAAF1kQEHIAAAAQkPEImAAAIAAAAQl/AAkQkIg");
	var mask_9_graphics_380 = new cjs.Graphics().p("AqcKJQkVkNAAl8IAAAAQAAl7EVkNIAAAAQEVkNGHAAIAAAAQGIAAEVENIAAAAQEVENAAF7IAAAAQAAF8kVENIAAAAQkVENmIAAIAAAAQmHAAkVkNg");
	var mask_9_graphics_381 = new cjs.Graphics().p("AqpKVQkakSAAmDIAAAAQAAmCEakTIAAAAQEbkRGOAAIAAAAQGPAAEaERIAAAAQEbETAAGCIAAAAQAAGDkbESIAAAAQkaESmPAAIAAAAQmOAAkbkSg");
	var mask_9_graphics_382 = new cjs.Graphics().p("Aq1KhQkgkWAAmLIAAAAQAAmKEgkXIAAAAQEfkXGWAAIAAAAQGXAAEfEXIAAAAQEgEXAAGKIAAAAQAAGLkgEWIAAAAQkfEYmXAAIAAAAQmWAAkfkYg");
	var mask_9_graphics_383 = new cjs.Graphics().p("ArCKtQkkkbAAmSIAAAAQAAmREkkcIAAAAQElkbGdAAIAAAAQGeAAEkEbIAAAAQElEcAAGRIAAAAQAAGSklEbIAAAAQkkEcmeAAIAAAAQmdAAklkcg");
	var mask_9_graphics_384 = new cjs.Graphics().p("ArOK5QkpkhAAmYIAAAAQAAmXEpkhIAAAAQEqkhGkAAIAAAAQGlAAEpEhIAAAAQEqEhAAGXIAAAAQAAGYkqEhIAAAAQkpEhmlAAIAAAAQmkAAkqkhg");
	var mask_9_graphics_385 = new cjs.Graphics().p("ArZLEQkvklAAmfIAAAAQAAmeEvkmIAAAAQEuklGrAAIAAAAQGsAAEuElIAAAAQEvEmAAGeIAAAAQAAGfkvElIAAAAQkuEmmsAAIAAAAQmrAAkukmg");
	var mask_9_graphics_386 = new cjs.Graphics().p("ArlLPQkzkpAAmmIAAAAQAAmlEzkqIAAAAQE0kqGxAAIAAAAQGyAAEzEqIAAAAQE0EqAAGlIAAAAQAAGmk0EpIAAAAQkzErmyAAIAAAAQmxAAk0krg");
	var mask_9_graphics_387 = new cjs.Graphics().p("ArwLaQk4kuAAmsIAAAAQAAmrE4kvIAAAAQE4kuG4AAIAAAAQG5AAE4EuIAAAAQE4EvAAGrIAAAAQAAGsk4EuIAAAAQk4Evm5AAIAAAAQm4AAk4kvg");
	var mask_9_graphics_388 = new cjs.Graphics().p("Ar7LlQk8kzAAmyIAAAAQAAmxE8kzIAAAAQE9kzG+AAIAAAAQG/AAE8EzIAAAAQE9EzAAGxIAAAAQAAGyk9EzIAAAAQk8Ezm/AAIAAAAQm+AAk9kzg");
	var mask_9_graphics_389 = new cjs.Graphics().p("AsFLvQlBk3AAm4IAAAAQAAm3FBk3IAAAAQFBk4HEAAIAAAAQHFAAFBE4IAAAAQFBE3AAG3IAAAAQAAG4lBE3IAAAAQlBE4nFAAIAAAAQnEAAlBk4g");
	var mask_9_graphics_390 = new cjs.Graphics().p("AsQL5QlFk7AAm+IAAAAQAAm9FFk7IAAAAQFFk8HLAAIAAAAQHMAAFEE8IAAAAQFGE7AAG9IAAAAQAAG+lGE7IAAAAQlEE8nMAAIAAAAQnLAAlFk8g");
	var mask_9_graphics_391 = new cjs.Graphics().p("AsaMDQlJk/AAnEIAAAAQAAnDFJk/IAAAAQFKk/HQAAIAAAAQHRAAFJE/IAAAAQFKE/AAHDIAAAAQAAHElKE/IAAAAQlJE/nRAAIAAAAQnQAAlKk/g");
	var mask_9_graphics_392 = new cjs.Graphics().p("AsjMMQlNlDAAnJIAAAAQAAnIFNlEIAAAAQFNlDHWAAIAAAAQHXAAFNFDIAAAAQFNFEAAHIIAAAAQAAHJlNFDIAAAAQlNFEnXAAIAAAAQnWAAlNlEg");
	var mask_9_graphics_393 = new cjs.Graphics().p("AstMVQlRlGAAnPIAAAAQAAnOFRlHIAAAAQFRlHHcAAIAAAAQHdAAFRFHIAAAAQFRFHAAHOIAAAAQAAHPlRFGIAAAAQlRFIndAAIAAAAQncAAlRlIg");
	var mask_9_graphics_394 = new cjs.Graphics().p("As2MeQlVlKAAnUIAAAAQAAnTFVlLIAAAAQFVlKHhAAIAAAAQHiAAFVFKIAAAAQFVFLAAHTIAAAAQAAHUlVFKIAAAAQlVFLniAAIAAAAQnhAAlVlLg");
	var mask_9_graphics_395 = new cjs.Graphics().p("As/MnQlZlOAAnZIAAAAQAAnYFZlOIAAAAQFZlPHmAAIAAAAQHnAAFZFPIAAAAQFZFOAAHYIAAAAQAAHZlZFOIAAAAQlZFPnnAAIAAAAQnmAAlZlPg");
	var mask_9_graphics_396 = new cjs.Graphics().p("AtIMvQlclRAAneIAAAAQAAndFclSIAAAAQFdlSHrAAIAAAAQHsAAFcFSIAAAAQFdFSAAHdIAAAAQAAHeldFRIAAAAQlcFTnsAAIAAAAQnrAAldlTg");
	var mask_9_graphics_397 = new cjs.Graphics().p("AtQM4QlglVAAnjIAAAAQAAniFglVIAAAAQFglVHwAAIAAAAQHxAAFgFVIAAAAQFgFVAAHiIAAAAQAAHjlgFVIAAAAQlgFVnxAAIAAAAQnwAAlglVg");
	var mask_9_graphics_398 = new cjs.Graphics().p("AtYNAQljlZAAnnIAAAAQAAnmFjlZIAAAAQFjlYH1AAIAAAAQH2AAFjFYIAAAAQFjFZAAHmIAAAAQAAHnljFZIAAAAQljFYn2AAIAAAAQn1AAljlYg");
	var mask_9_graphics_399 = new cjs.Graphics().p("AtgNHQlmlbAAnsIAAAAQAAnrFmlcIAAAAQFmlbH6AAIAAAAQH7AAFmFbIAAAAQFmFcAAHrIAAAAQAAHslmFbIAAAAQlmFcn7AAIAAAAQn6AAlmlcg");
	var mask_9_graphics_400 = new cjs.Graphics().p("AtoNPQlplfAAnwIAAAAQAAnvFplfIAAAAQFqlfH+AAIAAAAQH/AAFpFfIAAAAQFqFfAAHvIAAAAQAAHwlqFfIAAAAQlpFfn/AAIAAAAQn+AAlqlfg");
	var mask_9_graphics_401 = new cjs.Graphics().p("AtvNWQlsliAAn0IAAAAQAAnzFsliIAAAAQFtliICAAIAAAAQIDAAFtFiIAAAAQFsFiAAHzIAAAAQAAH0lsFiIAAAAQltFioDAAIAAAAQoCAAltlig");
	var mask_9_graphics_402 = new cjs.Graphics().p("At2NdQlvllAAn4IAAAAQAAn3FvllIAAAAQFvlkIHAAIAAAAQIIAAFvFkIAAAAQFvFlAAH3IAAAAQAAH4lvFlIAAAAQlvFkoIAAIAAAAQoHAAlvlkg");
	var mask_9_graphics_403 = new cjs.Graphics().p("At9NjQlylnAAn8IAAAAQAAn7FyloIAAAAQFylnILAAIAAAAQIMAAFyFnIAAAAQFyFoAAH7IAAAAQAAH8lyFnIAAAAQlyFooMAAIAAAAQoLAAlylog");
	var mask_9_graphics_404 = new cjs.Graphics().p("AuENqQl0lqAAoAIAAAAQAAn/F0lqIAAAAQF2lqIOAAIAAAAQIPAAF1FqIAAAAQF1FqAAH/IAAAAQAAIAl1FqIAAAAQl1FqoPAAIAAAAQoOAAl2lqg");
	var mask_9_graphics_405 = new cjs.Graphics().p("AuKNwQl3ltAAoDIAAAAQAAoCF3ltIAAAAQF4ltISAAIAAAAQITAAF4FtIAAAAQF3FtAAICIAAAAQAAIDl3FtIAAAAQl4FtoTAAIAAAAQoSAAl4ltg");
	var mask_9_graphics_406 = new cjs.Graphics().p("AuQN2Ql6lvAAoHIAAAAQAAoGF6lvIAAAAQF6lvIWAAIAAAAQIXAAF6FvIAAAAQF6FvAAIGIAAAAQAAIHl6FvIAAAAQl6FvoXAAIAAAAQoWAAl6lvg");
	var mask_9_graphics_407 = new cjs.Graphics().p("AuWN7Ql8lxAAoKIAAAAQAAoJF8lyIAAAAQF9lxIZAAIAAAAQIaAAF9FxIAAAAQF8FyAAIJIAAAAQAAIKl8FxIAAAAQl9FyoaAAIAAAAQoZAAl9lyg");
	var mask_9_graphics_408 = new cjs.Graphics().p("AucOBQl+l0AAoNIAAAAQAAoMF+l0IAAAAQGAl0IcAAIAAAAQIdAAF/F0IAAAAQF/F0AAIMIAAAAQAAINl/F0IAAAAQl/F0odAAIAAAAQocAAmAl0g");
	var mask_9_graphics_409 = new cjs.Graphics().p("AuhOGQmBl1AAoRIAAAAQAAoQGBl2IAAAAQGBl1IgAAIAAAAQIhAAGBF1IAAAAQGBF2AAIQIAAAAQAAIRmBF1IAAAAQmBF2ohAAIAAAAQogAAmBl2g");
	var mask_9_graphics_410 = new cjs.Graphics().p("AumOLQmDl4AAoTIAAAAQAAoSGDl5IAAAAQGDl3IjAAIAAAAQIkAAGDF3IAAAAQGDF5AAISIAAAAQAAITmDF4IAAAAQmDF4okAAIAAAAQojAAmDl4g");
	var mask_9_graphics_411 = new cjs.Graphics().p("AurOQQmFl6AAoWIAAAAQAAoVGFl6IAAAAQGFl6ImAAIAAAAQInAAGFF6IAAAAQGFF6AAIVIAAAAQAAIWmFF6IAAAAQmFF6onAAIAAAAQomAAmFl6g");
	var mask_9_graphics_412 = new cjs.Graphics().p("AuwOUQmHl7AAoZIAAAAQAAoYGHl8IAAAAQGIl7IoAAIAAAAQIpAAGHF7IAAAAQGIF8AAIYIAAAAQAAIZmIF7IAAAAQmHF8opAAIAAAAQooAAmIl8g");
	var mask_9_graphics_413 = new cjs.Graphics().p("Au0OZQmJl+AAobIAAAAQAAoaGJl+IAAAAQGJl+IrAAIAAAAQIsAAGJF+IAAAAQGJF+AAIaIAAAAQAAIbmJF+IAAAAQmJF+osAAIAAAAQorAAmJl+g");
	var mask_9_graphics_414 = new cjs.Graphics().p("Au5OdQmKl/AAoeIAAAAQAAodGKl/IAAAAQGMmAItAAIAAAAQIuAAGLGAIAAAAQGLF/AAIdIAAAAQAAIemLF/IAAAAQmLF/ouABIAAAAQotgBmMl/g");
	var mask_9_graphics_415 = new cjs.Graphics().p("Au9OhQmMmBAAogIAAAAQAAofGMmBIAAAAQGNmBIwAAIAAAAQIxAAGMGBIAAAAQGNGBAAIfIAAAAQAAIgmNGBIAAAAQmMGBoxAAIAAAAQowAAmNmBg");
	var mask_9_graphics_416 = new cjs.Graphics().p("AvBOlQmOmDAAoiIAAAAQAAohGOmDIAAAAQGPmCIyAAIAAAAQIzAAGOGCIAAAAQGPGDAAIhIAAAAQAAIimPGDIAAAAQmOGCozAAIAAAAQoyAAmPmCg");
	var mask_9_graphics_417 = new cjs.Graphics().p("AvEOoQmQmEAAokIAAAAQAAojGQmFIAAAAQGQmDI0AAIAAAAQI1AAGQGDIAAAAQGQGFAAIjIAAAAQAAIkmQGEIAAAAQmQGEo1AAIAAAAQo0AAmQmEg");
	var mask_9_graphics_418 = new cjs.Graphics().p("AvIOsQmRmGAAomIAAAAQAAolGRmGIAAAAQGSmFI2AAIAAAAQI3AAGRGFIAAAAQGSGGAAIlIAAAAQAAImmSGGIAAAAQmRGFo3AAIAAAAQo2AAmSmFg");
	var mask_9_graphics_419 = new cjs.Graphics().p("AvLOvQmSmHAAooIAAAAQAAonGSmHIAAAAQGTmHI4AAIAAAAQI5AAGSGHIAAAAQGTGHAAInIAAAAQAAIomTGHIAAAAQmSGHo5AAIAAAAQo4AAmTmHg");

	this.timeline.addTween(cjs.Tween.get(mask_9).to({graphics:null,x:0,y:0}).wait(341).to({graphics:mask_9_graphics_341,x:210.3503,y:175.95}).wait(1).to({graphics:mask_9_graphics_342,x:210.3502,y:175.9504}).wait(1).to({graphics:mask_9_graphics_343,x:210.3507,y:175.9504}).wait(1).to({graphics:mask_9_graphics_344,x:210.3512,y:175.9504}).wait(1).to({graphics:mask_9_graphics_345,x:210.3511,y:175.9504}).wait(1).to({graphics:mask_9_graphics_346,x:210.3516,y:175.9509}).wait(1).to({graphics:mask_9_graphics_347,x:210.3521,y:175.9509}).wait(1).to({graphics:mask_9_graphics_348,x:210.3521,y:175.9509}).wait(1).to({graphics:mask_9_graphics_349,x:210.3521,y:175.9509}).wait(1).to({graphics:mask_9_graphics_350,x:210.3525,y:175.9513}).wait(1).to({graphics:mask_9_graphics_351,x:210.3525,y:175.9513}).wait(1).to({graphics:mask_9_graphics_352,x:210.353,y:175.9513}).wait(1).to({graphics:mask_9_graphics_353,x:210.353,y:175.9518}).wait(1).to({graphics:mask_9_graphics_354,x:210.3539,y:175.9518}).wait(1).to({graphics:mask_9_graphics_355,x:210.3534,y:175.9518}).wait(1).to({graphics:mask_9_graphics_356,x:210.3543,y:175.9518}).wait(1).to({graphics:mask_9_graphics_357,x:210.3543,y:175.9522}).wait(1).to({graphics:mask_9_graphics_358,x:210.3543,y:175.9522}).wait(1).to({graphics:mask_9_graphics_359,x:210.3547,y:175.9522}).wait(1).to({graphics:mask_9_graphics_360,x:210.3547,y:175.9527}).wait(1).to({graphics:mask_9_graphics_361,x:210.3552,y:175.9527}).wait(1).to({graphics:mask_9_graphics_362,x:210.3552,y:175.9531}).wait(1).to({graphics:mask_9_graphics_363,x:210.3557,y:175.9531}).wait(1).to({graphics:mask_9_graphics_364,x:210.3561,y:175.9532}).wait(1).to({graphics:mask_9_graphics_365,x:210.3565,y:175.9531}).wait(1).to({graphics:mask_9_graphics_366,x:210.3561,y:175.9532}).wait(1).to({graphics:mask_9_graphics_367,x:210.357,y:175.9536}).wait(1).to({graphics:mask_9_graphics_368,x:210.3565,y:175.9536}).wait(1).to({graphics:mask_9_graphics_369,x:210.357,y:175.9536}).wait(1).to({graphics:mask_9_graphics_370,x:210.357,y:175.9536}).wait(1).to({graphics:mask_9_graphics_371,x:210.3574,y:175.9536}).wait(1).to({graphics:mask_9_graphics_372,x:210.3579,y:175.954}).wait(1).to({graphics:mask_9_graphics_373,x:210.3579,y:175.954}).wait(1).to({graphics:mask_9_graphics_374,x:210.3579,y:175.9545}).wait(1).to({graphics:mask_9_graphics_375,x:210.3583,y:175.9545}).wait(1).to({graphics:mask_9_graphics_376,x:210.3588,y:175.9545}).wait(1).to({graphics:mask_9_graphics_377,x:210.3588,y:175.9545}).wait(1).to({graphics:mask_9_graphics_378,x:210.3588,y:175.9545}).wait(1).to({graphics:mask_9_graphics_379,x:210.3592,y:175.955}).wait(1).to({graphics:mask_9_graphics_380,x:210.3597,y:175.9549}).wait(1).to({graphics:mask_9_graphics_381,x:210.3592,y:175.9549}).wait(1).to({graphics:mask_9_graphics_382,x:210.3597,y:175.9554}).wait(1).to({graphics:mask_9_graphics_383,x:210.3597,y:175.9549}).wait(1).to({graphics:mask_9_graphics_384,x:210.3601,y:175.9549}).wait(1).to({graphics:mask_9_graphics_385,x:210.3601,y:175.9549}).wait(1).to({graphics:mask_9_graphics_386,x:210.3601,y:175.9554}).wait(1).to({graphics:mask_9_graphics_387,x:210.3606,y:175.9554}).wait(1).to({graphics:mask_9_graphics_388,x:210.3606,y:175.9554}).wait(1).to({graphics:mask_9_graphics_389,x:210.361,y:175.9558}).wait(1).to({graphics:mask_9_graphics_390,x:210.3611,y:175.9558}).wait(1).to({graphics:mask_9_graphics_391,x:210.361,y:175.9559}).wait(1).to({graphics:mask_9_graphics_392,x:210.361,y:175.9558}).wait(1).to({graphics:mask_9_graphics_393,x:210.3611,y:175.9563}).wait(1).to({graphics:mask_9_graphics_394,x:210.3615,y:175.9558}).wait(1).to({graphics:mask_9_graphics_395,x:210.362,y:175.9558}).wait(1).to({graphics:mask_9_graphics_396,x:210.3615,y:175.9563}).wait(1).to({graphics:mask_9_graphics_397,x:210.3619,y:175.9563}).wait(1).to({graphics:mask_9_graphics_398,x:210.3619,y:175.9563}).wait(1).to({graphics:mask_9_graphics_399,x:210.3619,y:175.9563}).wait(1).to({graphics:mask_9_graphics_400,x:210.3619,y:175.9563}).wait(1).to({graphics:mask_9_graphics_401,x:210.3624,y:175.9563}).wait(1).to({graphics:mask_9_graphics_402,x:210.3624,y:175.9563}).wait(1).to({graphics:mask_9_graphics_403,x:210.3624,y:175.9563}).wait(1).to({graphics:mask_9_graphics_404,x:210.3628,y:175.9563}).wait(1).to({graphics:mask_9_graphics_405,x:210.3628,y:175.9567}).wait(1).to({graphics:mask_9_graphics_406,x:210.3624,y:175.9563}).wait(1).to({graphics:mask_9_graphics_407,x:210.3628,y:175.9563}).wait(1).to({graphics:mask_9_graphics_408,x:210.3629,y:175.9567}).wait(1).to({graphics:mask_9_graphics_409,x:210.3628,y:175.9568}).wait(1).to({graphics:mask_9_graphics_410,x:210.3633,y:175.9567}).wait(1).to({graphics:mask_9_graphics_411,x:210.3629,y:175.9567}).wait(1).to({graphics:mask_9_graphics_412,x:210.3633,y:175.9568}).wait(1).to({graphics:mask_9_graphics_413,x:210.3633,y:175.9568}).wait(1).to({graphics:mask_9_graphics_414,x:210.3633,y:175.9572}).wait(1).to({graphics:mask_9_graphics_415,x:210.3633,y:175.9572}).wait(1).to({graphics:mask_9_graphics_416,x:210.3638,y:175.9567}).wait(1).to({graphics:mask_9_graphics_417,x:210.3633,y:175.9572}).wait(1).to({graphics:mask_9_graphics_418,x:210.3633,y:175.9572}).wait(1).to({graphics:mask_9_graphics_419,x:210.3633,y:175.9572}).wait(391));

	// Layer_26
	this.instance_14 = new lib.Tween57("synched",0);
	this.instance_14.setTransform(147.9,190.8);
	this.instance_14.alpha = 0.5;
	this.instance_14._off = true;

	this.instance_15 = new lib.Tween58("synched",0);
	this.instance_15.setTransform(147.9,190.8);

	var maskedShapeInstanceList = [this.instance_14,this.instance_15];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_9;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_14}]},341).to({state:[{t:this.instance_15}]},78).wait(391));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(341).to({_off:false},0).to({_off:true,alpha:1},78).wait(391));

	// Layer_6 (mask)
	var mask_10 = new cjs.Shape();
	mask_10._off = true;
	var mask_10_graphics_263 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_10_graphics_264 = new cjs.Graphics().p("AgcAcQgMgMAAgQIAAAAQAAgPAMgMIAAAAQAMgMAQAAIAAAAQARAAAMAMIAAAAQAMAMAAAPIAAAAQAAAQgMAMIAAAAQgMAMgRAAIAAAAQgQAAgMgMg");
	var mask_10_graphics_265 = new cjs.Graphics().p("AgoAoQgRgRAAgXIAAAAQAAgWARgRIAAAAQARgQAXAAIAAAAQAYAAARAQIAAAAQARARAAAWIAAAAQAAAXgRARIAAAAQgRAQgYAAIAAAAQgXAAgRgQg");
	var mask_10_graphics_266 = new cjs.Graphics().p("Ag0AzQgWgVAAgeIAAAAQAAgdAWgVIAAAAQAWgWAeAAIAAAAQAfAAAWAWIAAAAQAWAVAAAdIAAAAQAAAegWAVIAAAAQgWAWgfAAIAAAAQgeAAgWgWg");
	var mask_10_graphics_267 = new cjs.Graphics().p("AhAA/QgbgaAAglIAAAAQAAgkAbgaIAAAAQAbgaAlAAIAAAAQAmAAAbAaIAAAAQAbAaAAAkIAAAAQAAAlgbAaIAAAAQgbAagmAAIAAAAQglAAgbgag");
	var mask_10_graphics_268 = new cjs.Graphics().p("AhNBLQgggfAAgsIAAAAQAAgrAggfIAAAAQAhgfAsAAIAAAAQAtAAAgAfIAAAAQAhAfAAArIAAAAQAAAsghAfIAAAAQggAfgtAAIAAAAQgsAAghgfg");
	var mask_10_graphics_269 = new cjs.Graphics().p("AhZBXQglgkAAgzIAAAAQAAgyAlgkIAAAAQAlgkA0AAIAAAAQA1AAAlAkIAAAAQAlAkAAAyIAAAAQAAAzglAkIAAAAQglAkg1AAIAAAAQg0AAglgkg");
	var mask_10_graphics_270 = new cjs.Graphics().p("AhlBjQgqgpAAg6IAAAAQAAg5AqgpIAAAAQAqgpA7AAIAAAAQA8AAAqApIAAAAQAqApAAA5IAAAAQAAA6gqApIAAAAQgqApg8AAIAAAAQg7AAgqgpg");
	var mask_10_graphics_271 = new cjs.Graphics().p("AhxBvQgwguAAhBIAAAAQAAhAAwguIAAAAQAvguBCAAIAAAAQBDAAAvAuIAAAAQAwAuAABAIAAAAQAABBgwAuIAAAAQgvAuhDAAIAAAAQhCAAgvgug");
	var mask_10_graphics_272 = new cjs.Graphics().p("Ah+B7Qg0gzAAhIIAAAAQAAhHA0gzIAAAAQA1gzBJAAIAAAAQBKAAA1AzIAAAAQA0AzAABHIAAAAQAABIg0AzIAAAAQg1AzhKAAIAAAAQhJAAg1gzg");
	var mask_10_graphics_273 = new cjs.Graphics().p("AiKCHQg6g4AAhPIAAAAQAAhOA6g4IAAAAQA6g4BQAAIAAAAQBRAAA6A4IAAAAQA6A4AABOIAAAAQAABPg6A4IAAAAQg6A4hRAAIAAAAQhQAAg6g4g");
	var mask_10_graphics_274 = new cjs.Graphics().p("AiWCTQg/g9AAhWIAAAAQAAhVA/g9IAAAAQA+g9BYAAIAAAAQBZAAA+A9IAAAAQA/A9AABVIAAAAQAABWg/A9IAAAAQg+A9hZAAIAAAAQhYAAg+g9g");
	var mask_10_graphics_275 = new cjs.Graphics().p("AijCfQhEhCAAhdIAAAAQAAhcBEhCIAAAAQBEhCBfAAIAAAAQBgAABEBCIAAAAQBEBCAABcIAAAAQAABdhEBCIAAAAQhEBChgAAIAAAAQhfAAhEhCg");
	var mask_10_graphics_276 = new cjs.Graphics().p("AivCrQhJhHAAhkIAAAAQAAhjBJhHIAAAAQBJhHBmAAIAAAAQBnAABJBHIAAAAQBJBHAABjIAAAAQAABkhJBHIAAAAQhJBHhnAAIAAAAQhmAAhJhHg");
	var mask_10_graphics_277 = new cjs.Graphics().p("Ai8C3QhOhMAAhrIAAAAQAAhqBOhMIAAAAQBOhMBuAAIAAAAQBvAABOBMIAAAAQBOBMAABqIAAAAQAABrhOBMIAAAAQhOBMhvAAIAAAAQhuAAhOhMg");
	var mask_10_graphics_278 = new cjs.Graphics().p("AjIDDQhThRAAhyIAAAAQAAhxBThRIAAAAQBThRB1AAIAAAAQB2AABTBRIAAAAQBTBRAABxIAAAAQAAByhTBRIAAAAQhTBRh2AAIAAAAQh1AAhThRg");
	var mask_10_graphics_279 = new cjs.Graphics().p("AjVDPQhYhWAAh5IAAAAQAAh4BYhWIAAAAQBZhWB8AAIAAAAQB9AABZBWIAAAAQBYBWAAB4IAAAAQAAB5hYBWIAAAAQhZBWh9AAIAAAAQh8AAhZhWg");
	var mask_10_graphics_280 = new cjs.Graphics().p("AjhDbQhehbAAiAIAAAAQAAh/BehbIAAAAQBehbCDAAIAAAAQCEAABeBbIAAAAQBeBbAAB/IAAAAQAACAheBbIAAAAQheBbiEAAIAAAAQiDAAhehbg");
	var mask_10_graphics_281 = new cjs.Graphics().p("AjtDnQhjhgAAiHIAAAAQAAiGBjhgIAAAAQBihgCLAAIAAAAQCMAABiBgIAAAAQBjBgAACGIAAAAQAACHhjBgIAAAAQhiBgiMAAIAAAAQiLAAhihgg");
	var mask_10_graphics_282 = new cjs.Graphics().p("Aj6DzQhohlAAiOIAAAAQAAiNBohlIAAAAQBohlCSAAIAAAAQCTAABoBlIAAAAQBoBlAACNIAAAAQAACOhoBlIAAAAQhoBliTAAIAAAAQiSAAhohlg");
	var mask_10_graphics_283 = new cjs.Graphics().p("AkGD/QhthpAAiWIAAAAQAAiVBthpIAAAAQBthqCZAAIAAAAQCaAABtBqIAAAAQBtBpAACVIAAAAQAACWhtBpIAAAAQhtBqiaAAIAAAAQiZAAhthqg");
	var mask_10_graphics_284 = new cjs.Graphics().p("AkTELQhyhuAAidIAAAAQAAicByhuIAAAAQBzhvCgAAIAAAAQChAABzBvIAAAAQByBuAACcIAAAAQAACdhyBuIAAAAQhzBvihAAIAAAAQigAAhzhvg");
	var mask_10_graphics_285 = new cjs.Graphics().p("AkfEXQh3hzAAikIAAAAQAAijB3hzIAAAAQB3h0CoAAIAAAAQCpAAB3B0IAAAAQB3BzAACjIAAAAQAACkh3BzIAAAAQh3B0ipAAIAAAAQioAAh3h0g");
	var mask_10_graphics_286 = new cjs.Graphics().p("AkrEjQh9h4AAirIAAAAQAAiqB9h4IAAAAQB8h5CvAAIAAAAQCwAAB8B5IAAAAQB9B4AACqIAAAAQAACrh9B4IAAAAQh8B5iwAAIAAAAQivAAh8h5g");
	var mask_10_graphics_287 = new cjs.Graphics().p("Ak4EvQiBh9AAiyIAAAAQAAixCBh9IAAAAQCCh+C2AAIAAAAQC3AACBB+IAAAAQCCB9AACxIAAAAQAACyiCB9IAAAAQiBB+i3AAIAAAAQi2AAiCh+g");
	var mask_10_graphics_288 = new cjs.Graphics().p("AlEE7QiGiDAAi4IAAAAQAAi3CGiDIAAAAQCHiCC9AAIAAAAQC+AACHCCIAAAAQCGCDAAC3IAAAAQAAC4iGCDIAAAAQiHCCi+AAIAAAAQi9AAiHiCg");
	var mask_10_graphics_289 = new cjs.Graphics().p("AlQFHQiLiIAAi/IAAAAQAAi+CLiIIAAAAQCMiHDEAAIAAAAQDFAACMCHIAAAAQCLCIAAC+IAAAAQAAC/iLCIIAAAAQiMCHjFAAIAAAAQjEAAiMiHg");
	var mask_10_graphics_290 = new cjs.Graphics().p("AlcFSQiQiMAAjGIAAAAQAAjFCQiNIAAAAQCRiMDLAAIAAAAQDMAACRCMIAAAAQCQCNAADFIAAAAQAADGiQCMIAAAAQiRCNjMAAIAAAAQjLAAiRiNg");
	var mask_10_graphics_291 = new cjs.Graphics().p("AloFeQiWiRAAjNIAAAAQAAjMCWiRIAAAAQCWiRDSAAIAAAAQDTAACWCRIAAAAQCWCRAADMIAAAAQAADNiWCRIAAAAQiWCRjTAAIAAAAQjSAAiWiRg");
	var mask_10_graphics_292 = new cjs.Graphics().p("Al0FqQiaiWAAjUIAAAAQAAjTCaiWIAAAAQCbiWDZAAIAAAAQDaAACbCWIAAAAQCaCWAADTIAAAAQAADUiaCWIAAAAQibCWjaAAIAAAAQjZAAibiWg");
	var mask_10_graphics_293 = new cjs.Graphics().p("AmAF1QifiaAAjbIAAAAQAAjaCfiaIAAAAQCgibDgAAIAAAAQDhAACgCbIAAAAQCfCaAADaIAAAAQAADbifCaIAAAAQigCbjhAAIAAAAQjgAAigibg");
	var mask_10_graphics_294 = new cjs.Graphics().p("AmMGBQikigAAjhIAAAAQAAjgCkigIAAAAQClifDnAAIAAAAQDoAAClCfIAAAAQCkCgAADgIAAAAQAADhikCgIAAAAQilCfjoAAIAAAAQjnAAilifg");
	var mask_10_graphics_295 = new cjs.Graphics().p("AmYGMQipikAAjoIAAAAQAAjnCpikIAAAAQCqikDuAAIAAAAQDvAACpCkIAAAAQCqCkAADnIAAAAQAADoiqCkIAAAAQipCkjvAAIAAAAQjuAAiqikg");
	var mask_10_graphics_296 = new cjs.Graphics().p("AmjGXQiuioAAjvIAAAAQAAjuCuipIAAAAQCuioD1AAIAAAAQD2AACuCoIAAAAQCuCpAADuIAAAAQAADviuCoIAAAAQiuCpj2AAIAAAAQj1AAiuipg");
	var mask_10_graphics_297 = new cjs.Graphics().p("AmvGjQiziuAAj1IAAAAQAAj0CziuIAAAAQCzitD8AAIAAAAQD9AACzCtIAAAAQCzCuAAD0IAAAAQAAD1izCuIAAAAQizCtj9AAIAAAAQj8AAizitg");
	var mask_10_graphics_298 = new cjs.Graphics().p("Am6GuQi4iyAAj8IAAAAQAAj7C4iyIAAAAQC3iyEDAAIAAAAQEEAAC3CyIAAAAQC4CyAAD7IAAAAQAAD8i4CyIAAAAQi3CykEAAIAAAAQkDAAi3iyg");
	var mask_10_graphics_299 = new cjs.Graphics().p("AnGG5Qi8i3AAkCIAAAAQAAkBC8i3IAAAAQC9i3EJAAIAAAAQEKAAC8C3IAAAAQC9C3AAEBIAAAAQAAECi9C3IAAAAQi8C3kKAAIAAAAQkJAAi9i3g");
	var mask_10_graphics_300 = new cjs.Graphics().p("AnRHEQjBi7AAkJIAAAAQAAkIDBi7IAAAAQDBi7EQAAIAAAAQERAADBC7IAAAAQDBC7AAEIIAAAAQAAEJjBC7IAAAAQjBC7kRAAIAAAAQkQAAjBi7g");
	var mask_10_graphics_301 = new cjs.Graphics().p("AncHPQjGjAAAkPIAAAAQAAkODGjAIAAAAQDGjAEWAAIAAAAQEXAADGDAIAAAAQDGDAAAEOIAAAAQAAEPjGDAIAAAAQjGDAkXAAIAAAAQkWAAjGjAg");
	var mask_10_graphics_302 = new cjs.Graphics().p("AnnHaQjLjFAAkVIAAAAQAAkUDLjFIAAAAQDKjEEdAAIAAAAQEeAADKDEIAAAAQDLDFAAEUIAAAAQAAEVjLDFIAAAAQjKDEkeAAIAAAAQkdAAjKjEg");
	var mask_10_graphics_303 = new cjs.Graphics().p("AnyHkQjPjIAAkcIAAAAQAAkbDPjJIAAAAQDPjIEjAAIAAAAQEkAADPDIIAAAAQDPDJAAEbIAAAAQAAEcjPDIIAAAAQjPDJkkAAIAAAAQkjAAjPjJg");
	var mask_10_graphics_304 = new cjs.Graphics().p("An9HvQjUjNAAkiIAAAAQAAkhDUjNIAAAAQDTjNEqAAIAAAAQErAADTDNIAAAAQDUDNAAEhIAAAAQAAEijUDNIAAAAQjTDNkrAAIAAAAQkqAAjTjNg");
	var mask_10_graphics_305 = new cjs.Graphics().p("AoIH5QjYjRAAkoIAAAAQAAknDYjSIAAAAQDYjREwAAIAAAAQExAADYDRIAAAAQDYDSAAEnIAAAAQAAEojYDRIAAAAQjYDSkxAAIAAAAQkwAAjYjSg");
	var mask_10_graphics_306 = new cjs.Graphics().p("AoTIEQjcjWAAkuIAAAAQAAktDcjWIAAAAQDdjWE2AAIAAAAQE3AADdDWIAAAAQDcDWAAEtIAAAAQAAEujcDWIAAAAQjdDWk3AAIAAAAQk2AAjdjWg");
	var mask_10_graphics_307 = new cjs.Graphics().p("AodIOQjhjaAAk0IAAAAQAAkzDhjaIAAAAQDgjaE9AAIAAAAQE+AADgDaIAAAAQDhDaAAEzIAAAAQAAE0jhDaIAAAAQjgDak+AAIAAAAQk9AAjgjag");
	var mask_10_graphics_308 = new cjs.Graphics().p("AooIYQjljeAAk6IAAAAQAAk5DljeIAAAAQDljfFDAAIAAAAQFEAADlDfIAAAAQDlDeAAE5IAAAAQAAE6jlDeIAAAAQjlDflEAAIAAAAQlDAAjljfg");
	var mask_10_graphics_309 = new cjs.Graphics().p("AoyIiQjpjiAAlAIAAAAQAAk/DpjiIAAAAQDpjjFJAAIAAAAQFKAADpDjIAAAAQDpDiAAE/IAAAAQAAFAjpDiIAAAAQjpDjlKAAIAAAAQlJAAjpjjg");
	var mask_10_graphics_310 = new cjs.Graphics().p("Ao8IsQjujmAAlGIAAAAQAAlFDujmIAAAAQDtjnFPAAIAAAAQFQAADtDnIAAAAQDuDmAAFFIAAAAQAAFGjuDmIAAAAQjtDnlQAAIAAAAQlPAAjtjng");
	var mask_10_graphics_311 = new cjs.Graphics().p("ApHI2QjxjqAAlMIAAAAQAAlLDxjqIAAAAQDyjrFVAAIAAAAQFWAADxDrIAAAAQDyDqAAFLIAAAAQAAFMjyDqIAAAAQjxDrlWAAIAAAAQlVAAjyjrg");
	var mask_10_graphics_312 = new cjs.Graphics().p("ApRJAQj1jvAAlRIAAAAQAAlQD1jvIAAAAQD2juFbAAIAAAAQFcAAD1DuIAAAAQD2DvAAFQIAAAAQAAFRj2DvIAAAAQj1DulcAAIAAAAQlbAAj2jug");
	var mask_10_graphics_313 = new cjs.Graphics().p("ApaJJQj6jyAAlXIAAAAQAAlWD6jyIAAAAQD6jzFgAAIAAAAQFhAAD6DzIAAAAQD6DyAAFWIAAAAQAAFXj6DyIAAAAQj6DzlhAAIAAAAQlgAAj6jzg");
	var mask_10_graphics_314 = new cjs.Graphics().p("ApkJTQj+j3AAlcIAAAAQAAlbD+j3IAAAAQD+j2FmAAIAAAAQFnAAD+D2IAAAAQD+D3AAFbIAAAAQAAFcj+D3IAAAAQj+D2lnAAIAAAAQlmAAj+j2g");
	var mask_10_graphics_315 = new cjs.Graphics().p("ApuJcQkCj6AAliIAAAAQAAlhECj6IAAAAQECj6FsAAIAAAAQFtAAEBD6IAAAAQEDD6AAFhIAAAAQAAFikDD6IAAAAQkBD6ltAAIAAAAQlsAAkCj6g");
	var mask_10_graphics_316 = new cjs.Graphics().p("Ap3JlQkGj+AAlnIAAAAQAAlmEGj+IAAAAQEGj+FxAAIAAAAQFyAAEGD+IAAAAQEGD+AAFmIAAAAQAAFnkGD+IAAAAQkGD+lyAAIAAAAQlxAAkGj+g");
	var mask_10_graphics_317 = new cjs.Graphics().p("AqBJuQkJkBAAltIAAAAQAAlsEJkCIAAAAQEKkBF3AAIAAAAQF4AAEJEBIAAAAQEKECAAFsIAAAAQAAFtkKEBIAAAAQkJECl4AAIAAAAQl3AAkKkCg");
	var mask_10_graphics_318 = new cjs.Graphics().p("AqKJ3QkNkFAAlyIAAAAQAAlxENkGIAAAAQEOkFF8AAIAAAAQF9AAENEFIAAAAQEOEGAAFxIAAAAQAAFykOEFIAAAAQkNEGl9AAIAAAAQl8AAkOkGg");
	var mask_10_graphics_319 = new cjs.Graphics().p("AqTKAQkRkJAAl3IAAAAQAAl2ERkJIAAAAQESkJGBAAIAAAAQGCAAESEJIAAAAQEREJAAF2IAAAAQAAF3kREJIAAAAQkSEJmCAAIAAAAQmBAAkSkJg");
	var mask_10_graphics_320 = new cjs.Graphics().p("AqcKJQkVkNAAl8IAAAAQAAl7EVkNIAAAAQEVkNGHAAIAAAAQGIAAEVENIAAAAQEVENAAF7IAAAAQAAF8kVENIAAAAQkVENmIAAIAAAAQmHAAkVkNg");
	var mask_10_graphics_321 = new cjs.Graphics().p("AqlKRQkYkQAAmBIAAAAQAAmAEYkRIAAAAQEZkQGMAAIAAAAQGNAAEYEQIAAAAQEZERAAGAIAAAAQAAGBkZEQIAAAAQkYERmNAAIAAAAQmMAAkZkRg");
	var mask_10_graphics_322 = new cjs.Graphics().p("AqtKaQkckUAAmGIAAAAQAAmFEckUIAAAAQEckUGRAAIAAAAQGSAAEcEUIAAAAQEcEUAAGFIAAAAQAAGGkcEUIAAAAQkcEUmSAAIAAAAQmRAAkckUg");
	var mask_10_graphics_323 = new cjs.Graphics().p("Aq2KiQkgkXAAmLIAAAAQAAmKEgkXIAAAAQEgkXGWAAIAAAAQGXAAEgEXIAAAAQEgEXAAGKIAAAAQAAGLkgEXIAAAAQkgEXmXAAIAAAAQmWAAkgkXg");
	var mask_10_graphics_324 = new cjs.Graphics().p("Aq+KqQkkkaAAmQIAAAAQAAmPEkkbIAAAAQEjkaGbAAIAAAAQGcAAEjEaIAAAAQEkEbAAGPIAAAAQAAGQkkEaIAAAAQkjEbmcAAIAAAAQmbAAkjkbg");
	var mask_10_graphics_325 = new cjs.Graphics().p("ArHKyQkmkeAAmUIAAAAQAAmTEmkfIAAAAQEnkdGgAAIAAAAQGhAAEmEdIAAAAQEnEfAAGTIAAAAQAAGUknEeIAAAAQkmEemhAAIAAAAQmgAAknkeg");
	var mask_10_graphics_326 = new cjs.Graphics().p("ArPK6QkqkhAAmZIAAAAQAAmYEqkiIAAAAQEqkhGlAAIAAAAQGmAAEpEhIAAAAQErEiAAGYIAAAAQAAGZkrEhIAAAAQkpEimmAAIAAAAQmlAAkqkig");
	var mask_10_graphics_327 = new cjs.Graphics().p("ArXLCQktkkAAmeIAAAAQAAmdEtkkIAAAAQEuklGpAAIAAAAQGqAAEuElIAAAAQEtEkAAGdIAAAAQAAGektEkIAAAAQkuElmqAAIAAAAQmpAAkuklg");
	var mask_10_graphics_328 = new cjs.Graphics().p("ArfLKQkwkoAAmiIAAAAQAAmhEwkoIAAAAQExkoGuAAIAAAAQGvAAEwEoIAAAAQExEoAAGhIAAAAQAAGikxEoIAAAAQkwEomvAAIAAAAQmuAAkxkog");
	var mask_10_graphics_329 = new cjs.Graphics().p("ArnLRQkzkqAAmnIAAAAQAAmmEzkrIAAAAQE1kqGyAAIAAAAQGzAAE0EqIAAAAQE0ErAAGmIAAAAQAAGnk0EqIAAAAQk0ErmzAAIAAAAQmyAAk1krg");
	var mask_10_graphics_330 = new cjs.Graphics().p("AruLZQk3kuAAmrIAAAAQAAmqE3kuIAAAAQE3kuG3AAIAAAAQG4AAE3EuIAAAAQE3EuAAGqIAAAAQAAGrk3EuIAAAAQk3Eum4AAIAAAAQm3AAk3kug");
	var mask_10_graphics_331 = new cjs.Graphics().p("Ar2LgQk6kxAAmvIAAAAQAAmuE6kxIAAAAQE7kxG7AAIAAAAQG8AAE6ExIAAAAQE7ExAAGuIAAAAQAAGvk7ExIAAAAQk6Exm8AAIAAAAQm7AAk7kxg");
	var mask_10_graphics_332 = new cjs.Graphics().p("Ar9LnQk9k0AAmzIAAAAQAAmyE9k0IAAAAQE9k0HAAAIAAAAQHBAAE9E0IAAAAQE9E0AAGyIAAAAQAAGzk9E0IAAAAQk9E0nBAAIAAAAQnAAAk9k0g");
	var mask_10_graphics_333 = new cjs.Graphics().p("AsELuQlAk3AAm3IAAAAQAAm2FAk3IAAAAQFAk3HEAAIAAAAQHFAAFAE3IAAAAQFAE3AAG2IAAAAQAAG3lAE3IAAAAQlAE3nFAAIAAAAQnEAAlAk3g");
	var mask_10_graphics_334 = new cjs.Graphics().p("AsLL1QlDk6AAm7IAAAAQAAm6FDk6IAAAAQFDk6HIAAIAAAAQHJAAFDE6IAAAAQFDE6AAG6IAAAAQAAG7lDE6IAAAAQlDE6nJAAIAAAAQnIAAlDk6g");
	var mask_10_graphics_335 = new cjs.Graphics().p("AsSL8QlGk9AAm/IAAAAQAAm+FGk9IAAAAQFGk8HMAAIAAAAQHNAAFGE8IAAAAQFGE9AAG+IAAAAQAAG/lGE9IAAAAQlGE8nNAAIAAAAQnMAAlGk8g");
	var mask_10_graphics_336 = new cjs.Graphics().p("AsZMCQlJk/AAnDIAAAAQAAnCFJlAIAAAAQFJk/HQAAIAAAAQHRAAFJE/IAAAAQFJFAAAHCIAAAAQAAHDlJE/IAAAAQlJFAnRAAIAAAAQnQAAlJlAg");
	var mask_10_graphics_337 = new cjs.Graphics().p("AsgMJQlLlCAAnHIAAAAQAAnGFLlCIAAAAQFMlCHUAAIAAAAQHVAAFMFCIAAAAQFLFCAAHGIAAAAQAAHHlLFCIAAAAQlMFCnVAAIAAAAQnUAAlMlCg");
	var mask_10_graphics_338 = new cjs.Graphics().p("AsnMPQlOlEAAnLIAAAAQAAnKFOlFIAAAAQFPlEHYAAIAAAAQHZAAFOFEIAAAAQFPFFAAHKIAAAAQAAHLlPFEIAAAAQlOFFnZAAIAAAAQnYAAlPlFg");
	var mask_10_graphics_339 = new cjs.Graphics().p("AstMVQlRlGAAnPIAAAAQAAnOFRlHIAAAAQFRlHHcAAIAAAAQHdAAFRFHIAAAAQFRFHAAHOIAAAAQAAHPlRFGIAAAAQlRFIndAAIAAAAQncAAlRlIg");
	var mask_10_graphics_340 = new cjs.Graphics().p("AszMcQlUlKAAnSIAAAAQAAnRFUlKIAAAAQFUlKHfAAIAAAAQHgAAFUFKIAAAAQFUFKAAHRIAAAAQAAHSlUFKIAAAAQlUFKngAAIAAAAQnfAAlUlKg");
	var mask_10_graphics_341 = new cjs.Graphics().p("As5MiQlXlMAAnWIAAAAQAAnVFXlMIAAAAQFWlMHjAAIAAAAQHkAAFWFMIAAAAQFXFMAAHVIAAAAQAAHWlXFMIAAAAQlWFMnkAAIAAAAQnjAAlWlMg");
	var mask_10_graphics_342 = new cjs.Graphics().p("AtAMoQlYlPAAnZIAAAAQAAnYFYlPIAAAAQFZlOHnAAIAAAAQHoAAFYFOIAAAAQFZFPAAHYIAAAAQAAHZlZFPIAAAAQlYFOnoAAIAAAAQnnAAlZlOg");
	var mask_10_graphics_343 = new cjs.Graphics().p("AtFMtQlclRAAncIAAAAQAAnbFclSIAAAAQFblRHqAAIAAAAQHrAAFbFRIAAAAQFcFSAAHbIAAAAQAAHclcFRIAAAAQlbFSnrAAIAAAAQnqAAlblSg");
	var mask_10_graphics_344 = new cjs.Graphics().p("AtLMzQlelTAAngIAAAAQAAnfFelTIAAAAQFelUHtAAIAAAAQHuAAFeFUIAAAAQFeFTAAHfIAAAAQAAHgleFTIAAAAQleFUnuAAIAAAAQntAAlelUg");
	var mask_10_graphics_345 = new cjs.Graphics().p("AtRM4QlglVAAnjIAAAAQAAniFglWIAAAAQFglVHxAAIAAAAQHyAAFgFVIAAAAQFgFWAAHiIAAAAQAAHjlgFVIAAAAQlgFWnyAAIAAAAQnxAAlglWg");
	var mask_10_graphics_346 = new cjs.Graphics().p("AtXM+QlilYAAnmIAAAAQAAnlFilYIAAAAQFjlYH0AAIAAAAQH1AAFiFYIAAAAQFjFYAAHlIAAAAQAAHmljFYIAAAAQliFYn1AAIAAAAQn0AAljlYg");
	var mask_10_graphics_347 = new cjs.Graphics().p("AtcNDQlklaAAnpIAAAAQAAnoFklbIAAAAQFllZH3AAIAAAAQH4AAFlFZIAAAAQFkFbAAHoIAAAAQAAHplkFaIAAAAQllFan4AAIAAAAQn3AAlllag");
	var mask_10_graphics_348 = new cjs.Graphics().p("AthNIQlnlcAAnsIAAAAQAAnrFnldIAAAAQFnlcH6AAIAAAAQH7AAFnFcIAAAAQFnFdAAHrIAAAAQAAHslnFcIAAAAQlnFdn7AAIAAAAQn6AAlnldg");
	var mask_10_graphics_349 = new cjs.Graphics().p("AtnNNQloleAAnvIAAAAQAAnuFolfIAAAAQFqleH9AAIAAAAQH+AAFpFeIAAAAQFpFfAAHuIAAAAQAAHvlpFeIAAAAQlpFfn+AAIAAAAQn9AAlqlfg");
	var mask_10_graphics_350 = new cjs.Graphics().p("AtsNSQlrlgAAnyIAAAAQAAnxFrlhIAAAAQFslgIAAAIAAAAQIBAAFrFgIAAAAQFsFhAAHxIAAAAQAAHylsFgIAAAAQlrFhoBAAIAAAAQoAAAlslhg");
	var mask_10_graphics_351 = new cjs.Graphics().p("AtxNXQltliAAn1IAAAAQAAn0FtljIAAAAQFuliIDAAIAAAAQIEAAFtFiIAAAAQFuFjAAH0IAAAAQAAH1luFiIAAAAQltFjoEAAIAAAAQoDAAluljg");
	var mask_10_graphics_352 = new cjs.Graphics().p("At1NcQlvlkAAn4IAAAAQAAn3FvlkIAAAAQFvlkIGAAIAAAAQIHAAFvFkIAAAAQFvFkAAH3IAAAAQAAH4lvFkIAAAAQlvFkoHAAIAAAAQoGAAlvlkg");
	var mask_10_graphics_353 = new cjs.Graphics().p("At6NgQlxlmAAn6IAAAAQAAn5FxlnIAAAAQFxlmIJAAIAAAAQIKAAFxFmIAAAAQFxFnAAH5IAAAAQAAH6lxFmIAAAAQlxFnoKAAIAAAAQoJAAlxlng");
	var mask_10_graphics_354 = new cjs.Graphics().p("At/NlQlzloAAn9IAAAAQAAn8FzloIAAAAQFzloIMAAIAAAAQINAAFyFoIAAAAQF0FoAAH8IAAAAQAAH9l0FoIAAAAQlyFooNAAIAAAAQoMAAlzlog");
	var mask_10_graphics_355 = new cjs.Graphics().p("AuDNpQl1lpAAoAIAAAAQAAn/F1lqIAAAAQF1lpIOAAIAAAAQIPAAF1FpIAAAAQF1FqAAH/IAAAAQAAIAl1FpIAAAAQl1FqoPAAIAAAAQoOAAl1lqg");
	var mask_10_graphics_356 = new cjs.Graphics().p("AuINtQl2lrAAoCIAAAAQAAoBF2lsIAAAAQF3lrIRAAIAAAAQISAAF2FrIAAAAQF3FsAAIBIAAAAQAAICl3FrIAAAAQl2FsoSAAIAAAAQoRAAl3lsg");
	var mask_10_graphics_357 = new cjs.Graphics().p("AuMNyQl4ltAAoFIAAAAQAAoEF4ltIAAAAQF5ltITAAIAAAAQIUAAF5FtIAAAAQF4FtAAIEIAAAAQAAIFl4FtIAAAAQl5FtoUAAIAAAAQoTAAl5ltg");
	var mask_10_graphics_358 = new cjs.Graphics().p("AuQN2Ql6lvAAoHIAAAAQAAoGF6lvIAAAAQF6lvIWAAIAAAAQIXAAF6FvIAAAAQF6FvAAIGIAAAAQAAIHl6FvIAAAAQl6FvoXAAIAAAAQoWAAl6lvg");
	var mask_10_graphics_359 = new cjs.Graphics().p("AuUN6Ql8lxAAoJIAAAAQAAoIF8lxIAAAAQF8lwIYAAIAAAAQIZAAF8FwIAAAAQF8FxAAIIIAAAAQAAIJl8FxIAAAAQl8FwoZAAIAAAAQoYAAl8lwg");
	var mask_10_graphics_360 = new cjs.Graphics().p("AuYN9Ql9lyAAoLIAAAAQAAoKF9lzIAAAAQF+lyIaAAIAAAAQIbAAF+FyIAAAAQF9FzAAIKIAAAAQAAILl9FyIAAAAQl+FzobAAIAAAAQoaAAl+lzg");
	var mask_10_graphics_361 = new cjs.Graphics().p("AucOBQl/lzAAoOIAAAAQAAoNF/l0IAAAAQF/lzIdAAIAAAAQIeAAF+FzIAAAAQGAF0AAINIAAAAQAAIOmAFzIAAAAQl+F0oeAAIAAAAQodAAl/l0g");
	var mask_10_graphics_362 = new cjs.Graphics().p("AugOFQmAl1AAoQIAAAAQAAoPGAl1IAAAAQGBl1IfAAIAAAAQIgAAGAF1IAAAAQGBF1AAIPIAAAAQAAIQmBF1IAAAAQmAF1ogAAIAAAAQofAAmBl1g");
	var mask_10_graphics_363 = new cjs.Graphics().p("AujOIQmCl2AAoSIAAAAQAAoRGCl3IAAAAQGCl2IhAAIAAAAQIiAAGCF2IAAAAQGCF3AAIRIAAAAQAAISmCF2IAAAAQmCF3oiAAIAAAAQohAAmCl3g");
	var mask_10_graphics_364 = new cjs.Graphics().p("AunOMQmDl4AAoUIAAAAQAAoTGDl4IAAAAQGEl4IjAAIAAAAQIkAAGDF4IAAAAQGEF4AAITIAAAAQAAIUmEF4IAAAAQmDF4okAAIAAAAQojAAmEl4g");
	var mask_10_graphics_365 = new cjs.Graphics().p("AuqOPQmFl5AAoWIAAAAQAAoVGFl5IAAAAQGFl6IlAAIAAAAQImAAGFF6IAAAAQGFF5AAIVIAAAAQAAIWmFF5IAAAAQmFF6omAAIAAAAQolAAmFl6g");
	var mask_10_graphics_366 = new cjs.Graphics().p("AutOSQmGl6AAoYIAAAAQAAoXGGl7IAAAAQGGl6InAAIAAAAQIoAAGGF6IAAAAQGGF7AAIXIAAAAQAAIYmGF6IAAAAQmGF7ooAAIAAAAQonAAmGl7g");
	var mask_10_graphics_367 = new cjs.Graphics().p("AuxOVQmHl8AAoZIAAAAQAAoYGHl9IAAAAQGIl7IpAAIAAAAQIqAAGHF7IAAAAQGIF9AAIYIAAAAQAAIZmIF8IAAAAQmHF8oqAAIAAAAQopAAmIl8g");
	var mask_10_graphics_368 = new cjs.Graphics().p("Au0OYQmIl9AAobIAAAAQAAoaGIl+IAAAAQGKl9IqAAIAAAAQIsAAGIF9IAAAAQGJF+AAIaIAAAAQAAIbmJF9IAAAAQmIF+osAAIAAAAQoqAAmKl+g");
	var mask_10_graphics_369 = new cjs.Graphics().p("Au3ObQmKl+AAodIAAAAQAAocGKl+IAAAAQGLl/IsAAIAAAAQItAAGKF/IAAAAQGLF+AAIcIAAAAQAAIdmLF+IAAAAQmKF/otAAIAAAAQosAAmLl/g");
	var mask_10_graphics_370 = new cjs.Graphics().p("Au5OeQmMmAAAoeIAAAAQAAodGMmAIAAAAQGLmAIuAAIAAAAQIvAAGLGAIAAAAQGMGAAAIdIAAAAQAAIemMGAIAAAAQmLGAovAAIAAAAQouAAmLmAg");
	var mask_10_graphics_371 = new cjs.Graphics().p("Au8OhQmMmBAAogIAAAAQAAofGMmBIAAAAQGMmBIwAAIAAAAQIxAAGMGBIAAAAQGMGBAAIfIAAAAQAAIgmMGBIAAAAQmMGBoxAAIAAAAQowAAmMmBg");
	var mask_10_graphics_372 = new cjs.Graphics().p("Au/OjQmNmBAAoiIAAAAQAAohGNmCIAAAAQGOmBIxAAIAAAAQIyAAGNGBIAAAAQGOGCAAIhIAAAAQAAIimOGBIAAAAQmNGCoyAAIAAAAQoxAAmOmCg");
	var mask_10_graphics_373 = new cjs.Graphics().p("AvCOmQmOmDAAojIAAAAQAAoiGOmDIAAAAQGPmDIzAAIAAAAQI0AAGOGDIAAAAQGPGDAAIiIAAAAQAAIjmPGDIAAAAQmOGDo0AAIAAAAQozAAmPmDg");
	var mask_10_graphics_374 = new cjs.Graphics().p("AvEOoQmPmEAAokIAAAAQAAojGPmEIAAAAQGQmEI0AAIAAAAQI1AAGQGEIAAAAQGPGEAAIjIAAAAQAAIkmPGEIAAAAQmQGEo1AAIAAAAQo0AAmQmEg");
	var mask_10_graphics_375 = new cjs.Graphics().p("AvGOqQmRmEAAomIAAAAQAAolGRmFIAAAAQGRmEI1AAIAAAAQI2AAGRGEIAAAAQGRGFAAIlIAAAAQAAImmRGEIAAAAQmRGFo2AAIAAAAQo1AAmRmFg");
	var mask_10_graphics_376 = new cjs.Graphics().p("AvJOtQmRmGAAonIAAAAQAAomGRmGIAAAAQGSmGI3AAIAAAAQI4AAGRGGIAAAAQGSGGAAImIAAAAQAAInmSGGIAAAAQmRGGo4AAIAAAAQo3AAmSmGg");
	var mask_10_graphics_377 = new cjs.Graphics().p("AvLOvQmSmHAAooIAAAAQAAonGSmHIAAAAQGTmHI4AAIAAAAQI5AAGSGHIAAAAQGTGHAAInIAAAAQAAIomTGHIAAAAQmSGHo5AAIAAAAQo4AAmTmHg");

	this.timeline.addTween(cjs.Tween.get(mask_10).to({graphics:null,x:0,y:0}).wait(263).to({graphics:mask_10_graphics_263,x:85.6003,y:389.9003}).wait(1).to({graphics:mask_10_graphics_264,x:86.2506,y:388.417}).wait(1).to({graphics:mask_10_graphics_265,x:86.9049,y:386.9253}).wait(1).to({graphics:mask_10_graphics_266,x:87.5624,y:385.4254}).wait(1).to({graphics:mask_10_graphics_267,x:88.2234,y:383.9184}).wait(1).to({graphics:mask_10_graphics_268,x:88.8871,y:382.4046}).wait(1).to({graphics:mask_10_graphics_269,x:89.5541,y:380.8845}).wait(1).to({graphics:mask_10_graphics_270,x:90.2227,y:379.3581}).wait(1).to({graphics:mask_10_graphics_271,x:90.8946,y:377.8272}).wait(1).to({graphics:mask_10_graphics_272,x:91.5678,y:376.2918}).wait(1).to({graphics:mask_10_graphics_273,x:92.2428,y:374.7528}).wait(1).to({graphics:mask_10_graphics_274,x:92.9191,y:373.2102}).wait(1).to({graphics:mask_10_graphics_275,x:93.5964,y:371.6653}).wait(1).to({graphics:mask_10_graphics_276,x:94.2745,y:370.1187}).wait(1).to({graphics:mask_10_graphics_277,x:94.9531,y:368.5711}).wait(1).to({graphics:mask_10_graphics_278,x:95.6322,y:367.0222}).wait(1).to({graphics:mask_10_graphics_279,x:96.3112,y:365.4742}).wait(1).to({graphics:mask_10_graphics_280,x:96.9898,y:363.9267}).wait(1).to({graphics:mask_10_graphics_281,x:97.6675,y:362.3809}).wait(1).to({graphics:mask_10_graphics_282,x:98.3452,y:360.837}).wait(1).to({graphics:mask_10_graphics_283,x:99.0207,y:359.2957}).wait(1).to({graphics:mask_10_graphics_284,x:99.6952,y:357.7581}).wait(1).to({graphics:mask_10_graphics_285,x:100.368,y:356.224}).wait(1).to({graphics:mask_10_graphics_286,x:101.0385,y:354.694}).wait(1).to({graphics:mask_10_graphics_287,x:101.7068,y:353.1699}).wait(1).to({graphics:mask_10_graphics_288,x:102.3727,y:351.6516}).wait(1).to({graphics:mask_10_graphics_289,x:103.0356,y:350.1391}).wait(1).to({graphics:mask_10_graphics_290,x:103.6957,y:348.6339}).wait(1).to({graphics:mask_10_graphics_291,x:104.3527,y:347.1363}).wait(1).to({graphics:mask_10_graphics_292,x:105.0061,y:345.6463}).wait(1).to({graphics:mask_10_graphics_293,x:105.6555,y:344.1654}).wait(1).to({graphics:mask_10_graphics_294,x:106.3012,y:342.6935}).wait(1).to({graphics:mask_10_graphics_295,x:106.9425,y:341.2305}).wait(1).to({graphics:mask_10_graphics_296,x:107.5797,y:339.7775}).wait(1).to({graphics:mask_10_graphics_297,x:108.212,y:338.3356}).wait(1).to({graphics:mask_10_graphics_298,x:108.8397,y:336.9046}).wait(1).to({graphics:mask_10_graphics_299,x:109.4625,y:335.4845}).wait(1).to({graphics:mask_10_graphics_300,x:110.0799,y:334.0759}).wait(1).to({graphics:mask_10_graphics_301,x:110.6919,y:332.6801}).wait(1).to({graphics:mask_10_graphics_302,x:111.2989,y:331.2967}).wait(1).to({graphics:mask_10_graphics_303,x:111.8997,y:329.9256}).wait(1).to({graphics:mask_10_graphics_304,x:112.495,y:328.5684}).wait(1).to({graphics:mask_10_graphics_305,x:113.0845,y:327.2242}).wait(1).to({graphics:mask_10_graphics_306,x:113.6677,y:325.894}).wait(1).to({graphics:mask_10_graphics_307,x:114.2451,y:324.5778}).wait(1).to({graphics:mask_10_graphics_308,x:114.8157,y:323.2764}).wait(1).to({graphics:mask_10_graphics_309,x:115.3804,y:321.9889}).wait(1).to({graphics:mask_10_graphics_310,x:115.9384,y:320.7168}).wait(1).to({graphics:mask_10_graphics_311,x:116.4892,y:319.4595}).wait(1).to({graphics:mask_10_graphics_312,x:117.0342,y:318.2175}).wait(1).to({graphics:mask_10_graphics_313,x:117.5719,y:316.9912}).wait(1).to({graphics:mask_10_graphics_314,x:118.1029,y:315.7803}).wait(1).to({graphics:mask_10_graphics_315,x:118.6272,y:314.5846}).wait(1).to({graphics:mask_10_graphics_316,x:119.1442,y:313.4052}).wait(1).to({graphics:mask_10_graphics_317,x:119.6541,y:312.242}).wait(1).to({graphics:mask_10_graphics_318,x:120.1577,y:311.0949}).wait(1).to({graphics:mask_10_graphics_319,x:120.6536,y:309.964}).wait(1).to({graphics:mask_10_graphics_320,x:121.1418,y:308.8494}).wait(1).to({graphics:mask_10_graphics_321,x:121.6238,y:307.7509}).wait(1).to({graphics:mask_10_graphics_322,x:122.098,y:306.6691}).wait(1).to({graphics:mask_10_graphics_323,x:122.5656,y:305.6035}).wait(1).to({graphics:mask_10_graphics_324,x:123.0255,y:304.555}).wait(1).to({graphics:mask_10_graphics_325,x:123.4782,y:303.5223}).wait(1).to({graphics:mask_10_graphics_326,x:123.9237,y:302.5067}).wait(1).to({graphics:mask_10_graphics_327,x:124.3615,y:301.5076}).wait(1).to({graphics:mask_10_graphics_328,x:124.7926,y:300.5248}).wait(1).to({graphics:mask_10_graphics_329,x:125.2161,y:299.5587}).wait(1).to({graphics:mask_10_graphics_330,x:125.6328,y:298.6092}).wait(1).to({graphics:mask_10_graphics_331,x:126.0418,y:297.6759}).wait(1).to({graphics:mask_10_graphics_332,x:126.4441,y:296.7592}).wait(1).to({graphics:mask_10_graphics_333,x:126.8383,y:295.8588}).wait(1).to({graphics:mask_10_graphics_334,x:127.2262,y:294.975}).wait(1).to({graphics:mask_10_graphics_335,x:127.6069,y:294.1078}).wait(1).to({graphics:mask_10_graphics_336,x:127.98,y:293.256}).wait(1).to({graphics:mask_10_graphics_337,x:128.3463,y:292.4212}).wait(1).to({graphics:mask_10_graphics_338,x:128.7049,y:291.6022}).wait(1).to({graphics:mask_10_graphics_339,x:129.0573,y:290.7994}).wait(1).to({graphics:mask_10_graphics_340,x:129.4024,y:290.0124}).wait(1).to({graphics:mask_10_graphics_341,x:129.7404,y:289.2411}).wait(1).to({graphics:mask_10_graphics_342,x:130.0716,y:288.486}).wait(1).to({graphics:mask_10_graphics_343,x:130.396,y:287.7466}).wait(1).to({graphics:mask_10_graphics_344,x:130.7137,y:287.0226}).wait(1).to({graphics:mask_10_graphics_345,x:131.0238,y:286.3147}).wait(1).to({graphics:mask_10_graphics_346,x:131.328,y:285.6213}).wait(1).to({graphics:mask_10_graphics_347,x:131.625,y:284.9436}).wait(1).to({graphics:mask_10_graphics_348,x:131.9157,y:284.2812}).wait(1).to({graphics:mask_10_graphics_349,x:132.1997,y:283.6336}).wait(1).to({graphics:mask_10_graphics_350,x:132.4768,y:283.0014}).wait(1).to({graphics:mask_10_graphics_351,x:132.7477,y:282.384}).wait(1).to({graphics:mask_10_graphics_352,x:133.0123,y:281.781}).wait(1).to({graphics:mask_10_graphics_353,x:133.2698,y:281.1933}).wait(1).to({graphics:mask_10_graphics_354,x:133.5213,y:280.6196}).wait(1).to({graphics:mask_10_graphics_355,x:133.767,y:280.0602}).wait(1).to({graphics:mask_10_graphics_356,x:134.0055,y:279.5157}).wait(1).to({graphics:mask_10_graphics_357,x:134.2381,y:278.9842}).wait(1).to({graphics:mask_10_graphics_358,x:134.465,y:278.4681}).wait(1).to({graphics:mask_10_graphics_359,x:134.685,y:277.9654}).wait(1).to({graphics:mask_10_graphics_360,x:134.8996,y:277.4763}).wait(1).to({graphics:mask_10_graphics_361,x:135.108,y:277.0006}).wait(1).to({graphics:mask_10_graphics_362,x:135.3105,y:276.5394}).wait(1).to({graphics:mask_10_graphics_363,x:135.5076,y:276.0912}).wait(1).to({graphics:mask_10_graphics_364,x:135.6979,y:275.6565}).wait(1).to({graphics:mask_10_graphics_365,x:135.8829,y:275.2344}).wait(1).to({graphics:mask_10_graphics_366,x:136.062,y:274.8258}).wait(1).to({graphics:mask_10_graphics_367,x:136.2352,y:274.4307}).wait(1).to({graphics:mask_10_graphics_368,x:136.4031,y:274.0473}).wait(1).to({graphics:mask_10_graphics_369,x:136.5655,y:273.6774}).wait(1).to({graphics:mask_10_graphics_370,x:136.7226,y:273.3201}).wait(1).to({graphics:mask_10_graphics_371,x:136.8733,y:272.9749}).wait(1).to({graphics:mask_10_graphics_372,x:137.0196,y:272.6424}).wait(1).to({graphics:mask_10_graphics_373,x:137.16,y:272.322}).wait(1).to({graphics:mask_10_graphics_374,x:137.2954,y:272.0137}).wait(1).to({graphics:mask_10_graphics_375,x:137.4251,y:271.7177}).wait(1).to({graphics:mask_10_graphics_376,x:137.5497,y:271.4333}).wait(1).to({graphics:mask_10_graphics_377,x:137.3634,y:270.8073}).wait(433));

	// Layer_25
	this.instance_16 = new lib.Tween56("synched",0);
	this.instance_16.setTransform(148.15,283.25);
	this.instance_16.alpha = 0.5;
	this.instance_16._off = true;

	var maskedShapeInstanceList = [this.instance_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_10;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(263).to({_off:false},0).to({alpha:1},114).wait(433));

	// Layer_6 (mask)
	var mask_11 = new cjs.Shape();
	mask_11._off = true;
	var mask_11_graphics_219 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_11_graphics_220 = new cjs.Graphics().p("AgeAeQgNgNAAgRIAAAAQAAgQANgNIAAAAQANgMARAAIAAAAQASAAANAMIAAAAQANANAAAQIAAAAQAAARgNANIAAAAQgNAMgSAAIAAAAQgRAAgNgMg");
	var mask_11_graphics_221 = new cjs.Graphics().p("AgrArQgTgSAAgZIAAAAQAAgYATgSIAAAAQASgSAZAAIAAAAQAaAAASASIAAAAQATASAAAYIAAAAQAAAZgTASIAAAAQgSASgaAAIAAAAQgZAAgSgSg");
	var mask_11_graphics_222 = new cjs.Graphics().p("Ag5A4QgYgXAAghIAAAAQAAggAYgXIAAAAQAYgYAhAAIAAAAQAiAAAYAYIAAAAQAYAXAAAgIAAAAQAAAhgYAXIAAAAQgYAYgiAAIAAAAQghAAgYgYg");
	var mask_11_graphics_223 = new cjs.Graphics().p("AhHBGQgegdAAgpIAAAAQAAgoAegdIAAAAQAegdApABIAAAAQAqgBAeAdIAAAAQAeAdAAAoIAAAAQAAApgeAdIAAAAQgeAcgqAAIAAAAQgpAAgegcg");
	var mask_11_graphics_224 = new cjs.Graphics().p("AhVBTQgjgiAAgxIAAAAQAAgwAjgiIAAAAQAkgjAxAAIAAAAQAyAAAkAjIAAAAQAjAiAAAwIAAAAQAAAxgjAiIAAAAQgkAjgyAAIAAAAQgxAAgkgjg");
	var mask_11_graphics_225 = new cjs.Graphics().p("AhjBhQgpgoAAg5IAAAAQAAg4ApgoIAAAAQAqgoA5AAIAAAAQA6AAAqAoIAAAAQApAoAAA4IAAAAQAAA5gpAoIAAAAQgqAog6AAIAAAAQg5AAgqgog");
	var mask_11_graphics_226 = new cjs.Graphics().p("AhxBuQgvguAAhAIAAAAQAAhAAvgtIAAAAQAvguBCAAIAAAAQBDAAAvAuIAAAAQAvAtAABAIAAAAQAABAgvAuIAAAAQgvAuhDAAIAAAAQhCAAgvgug");
	var mask_11_graphics_227 = new cjs.Graphics().p("Ah/B8Qg1g0AAhIIAAAAQAAhHA1g0IAAAAQA1gzBKAAIAAAAQBLAAA1AzIAAAAQA1A0AABHIAAAAQAABIg1A0IAAAAQg1AzhLAAIAAAAQhKAAg1gzg");
	var mask_11_graphics_228 = new cjs.Graphics().p("AiNCJQg6g5AAhQIAAAAQAAhPA6g5IAAAAQA7g5BSAAIAAAAQBTAAA7A5IAAAAQA6A5AABPIAAAAQAABQg6A5IAAAAQg7A5hTAAIAAAAQhSAAg7g5g");
	var mask_11_graphics_229 = new cjs.Graphics().p("AibCXQhAg/AAhYIAAAAQAAhXBAg/IAAAAQBBg/BaAAIAAAAQBbAABBA/IAAAAQBAA/AABXIAAAAQAABYhAA/IAAAAQhBA/hbAAIAAAAQhaAAhBg/g");
	var mask_11_graphics_230 = new cjs.Graphics().p("AipClQhGhFAAhgIAAAAQAAhfBGhFIAAAAQBGhEBjAAIAAAAQBkAABGBEIAAAAQBGBFAABfIAAAAQAABghGBFIAAAAQhGBEhkAAIAAAAQhjAAhGhEg");
	var mask_11_graphics_231 = new cjs.Graphics().p("Ai3CyQhMhJAAhpIAAAAQAAhnBMhKIAAAAQBMhKBrAAIAAAAQBsAABMBKIAAAAQBMBKAABnIAAAAQAABphMBJIAAAAQhMBKhsAAIAAAAQhrAAhMhKg");
	var mask_11_graphics_232 = new cjs.Graphics().p("AjFDAQhShPAAhxIAAAAQAAhwBShPIAAAAQBShQBzAAIAAAAQB0AABSBQIAAAAQBSBPAABwIAAAAQAABxhSBPIAAAAQhSBQh0AAIAAAAQhzAAhShQg");
	var mask_11_graphics_233 = new cjs.Graphics().p("AjTDOQhYhVAAh5IAAAAQAAh4BYhVIAAAAQBYhVB7AAIAAAAQB8AABYBVIAAAAQBYBVAAB4IAAAAQAAB5hYBVIAAAAQhYBVh8AAIAAAAQh7AAhYhVg");
	var mask_11_graphics_234 = new cjs.Graphics().p("AjiDcQhdhbAAiBIAAAAQAAiABdhbIAAAAQBehbCEAAIAAAAQCFAABdBbIAAAAQBeBbAACAIAAAAQAACBheBbIAAAAQhdBbiFAAIAAAAQiEAAhehbg");
	var mask_11_graphics_235 = new cjs.Graphics().p("AjwDpQhjhgAAiJIAAAAQAAiIBjhgIAAAAQBkhhCMAAIAAAAQCNAABkBhIAAAAQBjBgAACIIAAAAQAACJhjBgIAAAAQhkBhiNAAIAAAAQiMAAhkhhg");
	var mask_11_graphics_236 = new cjs.Graphics().p("Aj+D3QhphmAAiRIAAAAQAAiQBphmIAAAAQBqhmCUAAIAAAAQCVAABqBmIAAAAQBpBmAACQIAAAAQAACRhpBmIAAAAQhqBmiVAAIAAAAQiUAAhqhmg");
	var mask_11_graphics_237 = new cjs.Graphics().p("AkMEFQhvhsAAiZIAAAAQAAiYBvhsIAAAAQBvhsCdAAIAAAAQCeAABvBsIAAAAQBvBsAACYIAAAAQAACZhvBsIAAAAQhvBsieAAIAAAAQidAAhvhsg");
	var mask_11_graphics_238 = new cjs.Graphics().p("AkaESQh1hxAAihIAAAAQAAigB1hyIAAAAQB1hxClAAIAAAAQCmAAB1BxIAAAAQB1ByAACgIAAAAQAAChh1BxIAAAAQh1ByimAAIAAAAQilAAh1hyg");
	var mask_11_graphics_239 = new cjs.Graphics().p("AkoEgQh7h3AAipIAAAAQAAioB7h3IAAAAQB7h4CtAAIAAAAQCuAAB7B4IAAAAQB7B3AACoIAAAAQAACph7B3IAAAAQh7B4iuAAIAAAAQitAAh7h4g");
	var mask_11_graphics_240 = new cjs.Graphics().p("Ak2EuQiBh9AAixIAAAAQAAiwCBh9IAAAAQCBh9C1AAIAAAAQC2AACBB9IAAAAQCBB9AACwIAAAAQAACxiBB9IAAAAQiBB9i2AAIAAAAQi1AAiBh9g");
	var mask_11_graphics_241 = new cjs.Graphics().p("AlEE7QiHiCAAi5IAAAAQAAi4CHiDIAAAAQCGiCC+AAIAAAAQC/AACGCCIAAAAQCHCDAAC4IAAAAQAAC5iHCCIAAAAQiGCDi/AAIAAAAQi+AAiGiDg");
	var mask_11_graphics_242 = new cjs.Graphics().p("AlSFJQiNiIAAjBIAAAAQAAjACNiIIAAAAQCMiJDGAAIAAAAQDHAACMCJIAAAAQCNCIAADAIAAAAQAADBiNCIIAAAAQiMCJjHAAIAAAAQjGAAiMiJg");
	var mask_11_graphics_243 = new cjs.Graphics().p("AlgFXQiTiOAAjJIAAAAQAAjICTiOIAAAAQCSiODOAAIAAAAQDPAACSCOIAAAAQCTCOAADIIAAAAQAADJiTCOIAAAAQiSCOjPAAIAAAAQjOAAiSiOg");
	var mask_11_graphics_244 = new cjs.Graphics().p("AluFkQiYiTAAjRIAAAAQAAjQCYiTIAAAAQCYiUDWAAIAAAAQDXAACYCUIAAAAQCYCTAADQIAAAAQAADRiYCTIAAAAQiYCUjXAAIAAAAQjWAAiYiUg");
	var mask_11_graphics_245 = new cjs.Graphics().p("Al8FyQieiZAAjZIAAAAQAAjYCeiZIAAAAQCeiZDeAAIAAAAQDfAACeCZIAAAAQCeCZAADYIAAAAQAADZieCZIAAAAQieCZjfAAIAAAAQjeAAieiZg");
	var mask_11_graphics_246 = new cjs.Graphics().p("AmKF/QijifAAjgIAAAAQAAjfCjifIAAAAQCkifDmAAIAAAAQDnAACkCfIAAAAQCjCfAADfIAAAAQAADgijCfIAAAAQikCfjnAAIAAAAQjmAAikifg");
	var mask_11_graphics_247 = new cjs.Graphics().p("AmYGMQipikAAjoIAAAAQAAjnCpikIAAAAQCqilDuAAIAAAAQDvAACqClIAAAAQCpCkAADnIAAAAQAADoipCkIAAAAQiqCljvAAIAAAAQjuAAiqilg");
	var mask_11_graphics_248 = new cjs.Graphics().p("AmlGaQiviqAAjwIAAAAQAAjvCviqIAAAAQCvipD2AAIAAAAQD3AACvCpIAAAAQCvCqAADvIAAAAQAADwivCqIAAAAQivCpj3AAIAAAAQj2AAivipg");
	var mask_11_graphics_249 = new cjs.Graphics().p("AmzGnQi0ivAAj4IAAAAQAAj3C0ivIAAAAQC1ivD+AAIAAAAQD/AAC1CvIAAAAQC0CvAAD3IAAAAQAAD4i0CvIAAAAQi1Cvj/AAIAAAAQj+AAi1ivg");
	var mask_11_graphics_250 = new cjs.Graphics().p("AnAG0Qi7i1AAj/IAAAAQAAj+C7i1IAAAAQC6i1EGAAIAAAAQEHAAC6C1IAAAAQC7C1AAD+IAAAAQAAD/i7C1IAAAAQi6C1kHAAIAAAAQkGAAi6i1g");
	var mask_11_graphics_251 = new cjs.Graphics().p("AnOHBQjAi6AAkHIAAAAQAAkGDAi6IAAAAQDAi6EOAAIAAAAQEPAADAC6IAAAAQDAC6AAEGIAAAAQAAEHjAC6IAAAAQjAC6kPAAIAAAAQkOAAjAi6g");
	var mask_11_graphics_252 = new cjs.Graphics().p("AnbHOQjFi/AAkPIAAAAQAAkODFi/IAAAAQDFi/EWAAIAAAAQEXAADFC/IAAAAQDFC/AAEOIAAAAQAAEPjFC/IAAAAQjFC/kXAAIAAAAQkWAAjFi/g");
	var mask_11_graphics_253 = new cjs.Graphics().p("AnpHbQjKjFAAkWIAAAAQAAkVDKjFIAAAAQDLjFEeAAIAAAAQEfAADKDFIAAAAQDLDFAAEVIAAAAQAAEWjLDFIAAAAQjKDFkfAAIAAAAQkeAAjLjFg");
	var mask_11_graphics_254 = new cjs.Graphics().p("An2HnQjQjJAAkeIAAAAQAAkdDQjKIAAAAQDRjKElAAIAAAAQEmAADQDKIAAAAQDRDKAAEdIAAAAQAAEejRDJIAAAAQjQDLkmAAIAAAAQklAAjRjLg");
	var mask_11_graphics_255 = new cjs.Graphics().p("AoDH0QjVjPAAklIAAAAQAAkkDVjPIAAAAQDWjPEtAAIAAAAQEuAADVDPIAAAAQDWDPAAEkIAAAAQAAEljWDPIAAAAQjVDPkuAAIAAAAQktAAjWjPg");
	var mask_11_graphics_256 = new cjs.Graphics().p("AoQIBQjbjVAAksIAAAAQAAkrDbjVIAAAAQDbjUE1AAIAAAAQE2AADaDUIAAAAQDcDVAAErIAAAAQAAEsjcDVIAAAAQjaDUk2AAIAAAAQk1AAjbjUg");
	var mask_11_graphics_257 = new cjs.Graphics().p("AodINQjgjZAAk0IAAAAQAAkzDgjZIAAAAQDhjaE8AAIAAAAQE9AADgDaIAAAAQDhDZAAEzIAAAAQAAE0jhDZIAAAAQjgDak9AAIAAAAQk8AAjhjag");
	var mask_11_graphics_258 = new cjs.Graphics().p("AopIaQjmjfAAk7IAAAAQAAk6DmjfIAAAAQDljeFEAAIAAAAQFFAADlDeIAAAAQDmDfAAE6IAAAAQAAE7jmDfIAAAAQjlDelFAAIAAAAQlEAAjljeg");
	var mask_11_graphics_259 = new cjs.Graphics().p("Ao2ImQjrjkAAlCIAAAAQAAlBDrjkIAAAAQDrjkFLAAIAAAAQFMAADrDkIAAAAQDrDkAAFBIAAAAQAAFCjrDkIAAAAQjrDklMAAIAAAAQlLAAjrjkg");
	var mask_11_graphics_260 = new cjs.Graphics().p("ApCIyQjwjpAAlJIAAAAQAAlIDwjpIAAAAQDwjpFSAAIAAAAQFTAADwDpIAAAAQDwDpAAFIIAAAAQAAFJjwDpIAAAAQjwDplTAAIAAAAQlSAAjwjpg");
	var mask_11_graphics_261 = new cjs.Graphics().p("ApPI+Qj1juAAlQIAAAAQAAlPD1juIAAAAQD1juFaAAIAAAAQFbAAD0DuIAAAAQD2DuAAFPIAAAAQAAFQj2DuIAAAAQj0DulbAAIAAAAQlaAAj1jug");
	var mask_11_graphics_262 = new cjs.Graphics().p("ApbJKQj6jzAAlXIAAAAQAAlWD6jzIAAAAQD6jzFhAAIAAAAQFiAAD6DzIAAAAQD6DzAAFWIAAAAQAAFXj6DzIAAAAQj6DzliAAIAAAAQlhAAj6jzg");
	var mask_11_graphics_263 = new cjs.Graphics().p("ApnJWQj/j4AAleIAAAAQAAldD/j4IAAAAQD/j3FoAAIAAAAQFpAAD/D3IAAAAQD/D4AAFdIAAAAQAAFej/D4IAAAAQj/D3lpAAIAAAAQloAAj/j3g");
	var mask_11_graphics_264 = new cjs.Graphics().p("ApzJhQkEj8AAllIAAAAQAAlkEEj9IAAAAQEEj8FvAAIAAAAQFwAAEED8IAAAAQEED9AAFkIAAAAQAAFlkED8IAAAAQkED9lwAAIAAAAQlvAAkEj9g");
	var mask_11_graphics_265 = new cjs.Graphics().p("Ap/JtQkJkBAAlsIAAAAQAAlrEJkBIAAAAQEJkBF2AAIAAAAQF3AAEJEBIAAAAQEJEBAAFrIAAAAQAAFskJEBIAAAAQkJEBl3AAIAAAAQl2AAkJkBg");
	var mask_11_graphics_266 = new cjs.Graphics().p("AqLJ4QkOkGAAlyIAAAAQAAlxEOkGIAAAAQEOkGF9AAIAAAAQF+AAEOEGIAAAAQEOEGAAFxIAAAAQAAFykOEGIAAAAQkOEGl+AAIAAAAQl9AAkOkGg");
	var mask_11_graphics_267 = new cjs.Graphics().p("AqWKDQkTkKAAl5IAAAAQAAl4ETkLIAAAAQETkKGDAAIAAAAQGFAAESEKIAAAAQETELAAF4IAAAAQAAF5kTEKIAAAAQkSELmFAAIAAAAQmDAAkTkLg");
	var mask_11_graphics_268 = new cjs.Graphics().p("AqiKPQkXkQAAl/IAAAAQAAl+EXkQIAAAAQEYkPGKAAIAAAAQGLAAEYEPIAAAAQEXEQAAF+IAAAAQAAF/kXEQIAAAAQkYEPmLAAIAAAAQmKAAkYkPg");
	var mask_11_graphics_269 = new cjs.Graphics().p("AqtKaQkckUAAmGIAAAAQAAmFEckUIAAAAQEckUGRAAIAAAAQGSAAEcEUIAAAAQEcEUAAGFIAAAAQAAGGkcEUIAAAAQkcEUmSAAIAAAAQmRAAkckUg");
	var mask_11_graphics_270 = new cjs.Graphics().p("Aq4KkQkhkYAAmMIAAAAQAAmLEhkZIAAAAQEhkYGXAAIAAAAQGYAAEhEYIAAAAQEhEZAAGLIAAAAQAAGMkhEYIAAAAQkhEZmYAAIAAAAQmXAAkhkZg");
	var mask_11_graphics_271 = new cjs.Graphics().p("ArEKvQklkcAAmTIAAAAQAAmSElkdIAAAAQEmkcGeAAIAAAAQGfAAElEcIAAAAQEmEdAAGSIAAAAQAAGTkmEcIAAAAQklEdmfAAIAAAAQmeAAkmkdg");
	var mask_11_graphics_272 = new cjs.Graphics().p("ArOK6QkqkhAAmZIAAAAQAAmYEqkhIAAAAQEqkhGkAAIAAAAQGlAAEqEhIAAAAQEqEhAAGYIAAAAQAAGZkqEhIAAAAQkqEhmlAAIAAAAQmkAAkqkhg");
	var mask_11_graphics_273 = new cjs.Graphics().p("ArZLEQkuklAAmfIAAAAQAAmeEukmIAAAAQEuklGrAAIAAAAQGsAAEuElIAAAAQEuEmAAGeIAAAAQAAGfkuElIAAAAQkuEmmsAAIAAAAQmrAAkukmg");
	var mask_11_graphics_274 = new cjs.Graphics().p("ArkLPQkzkqAAmlIAAAAQAAmkEzkqIAAAAQEzkpGxAAIAAAAQGyAAEzEpIAAAAQEzEqAAGkIAAAAQAAGlkzEqIAAAAQkzEpmyAAIAAAAQmxAAkzkpg");
	var mask_11_graphics_275 = new cjs.Graphics().p("AruLZQk3kuAAmrIAAAAQAAmqE3kuIAAAAQE3kuG3AAIAAAAQG4AAE3EuIAAAAQE3EuAAGqIAAAAQAAGrk3EuIAAAAQk3Eum4AAIAAAAQm3AAk3kug");
	var mask_11_graphics_276 = new cjs.Graphics().p("Ar5LjQk7kyAAmxIAAAAQAAmwE7kyIAAAAQE8kyG9AAIAAAAQG+AAE7EyIAAAAQE8EyAAGwIAAAAQAAGxk8EyIAAAAQk7Eym+AAIAAAAQm9AAk8kyg");
	var mask_11_graphics_277 = new cjs.Graphics().p("AsDLtQk/k2AAm3IAAAAQAAm2E/k2IAAAAQFAk2HDAAIAAAAQHEAAFAE2IAAAAQE/E2AAG2IAAAAQAAG3k/E2IAAAAQlAE2nEAAIAAAAQnDAAlAk2g");
	var mask_11_graphics_278 = new cjs.Graphics().p("AsNL2QlEk6AAm8IAAAAQAAm7FEk7IAAAAQFEk6HJAAIAAAAQHKAAFEE6IAAAAQFEE7AAG7IAAAAQAAG8lEE6IAAAAQlEE7nKAAIAAAAQnJAAlEk7g");
	var mask_11_graphics_279 = new cjs.Graphics().p("AsXMAQlIk+AAnCIAAAAQAAnBFIk+IAAAAQFIk+HPAAIAAAAQHQAAFHE+IAAAAQFJE+AAHBIAAAAQAAHClJE+IAAAAQlHE+nQAAIAAAAQnPAAlIk+g");
	var mask_11_graphics_280 = new cjs.Graphics().p("AshMJQlLlCAAnHIAAAAQAAnGFLlDIAAAAQFNlCHUAAIAAAAQHVAAFMFCIAAAAQFMFDAAHGIAAAAQAAHHlMFCIAAAAQlMFDnVAAIAAAAQnUAAlNlDg");
	var mask_11_graphics_281 = new cjs.Graphics().p("AsqMTQlQlGAAnNIAAAAQAAnMFQlGIAAAAQFQlGHaAAIAAAAQHbAAFQFGIAAAAQFQFGAAHMIAAAAQAAHNlQFGIAAAAQlQFGnbAAIAAAAQnaAAlQlGg");
	var mask_11_graphics_282 = new cjs.Graphics().p("As0McQlTlKAAnSIAAAAQAAnRFTlKIAAAAQFUlKHgAAIAAAAQHhAAFTFKIAAAAQFUFKAAHRIAAAAQAAHSlUFKIAAAAQlTFKnhAAIAAAAQngAAlUlKg");
	var mask_11_graphics_283 = new cjs.Graphics().p("As9MlQlYlNAAnYIAAAAQAAnXFYlNIAAAAQFYlOHlAAIAAAAQHmAAFYFOIAAAAQFYFNAAHXIAAAAQAAHYlYFNIAAAAQlYFOnmAAIAAAAQnlAAlYlOg");
	var mask_11_graphics_284 = new cjs.Graphics().p("AtGMuQlblRAAndIAAAAQAAncFblRIAAAAQFclRHqAAIAAAAQHrAAFcFRIAAAAQFbFRAAHcIAAAAQAAHdlbFRIAAAAQlcFRnrAAIAAAAQnqAAlclRg");
	var mask_11_graphics_285 = new cjs.Graphics().p("AtPM3QlflVAAniIAAAAQAAnhFflVIAAAAQFflVHwAAIAAAAQHxAAFfFVIAAAAQFfFVAAHhIAAAAQAAHilfFVIAAAAQlfFVnxAAIAAAAQnwAAlflVg");
	var mask_11_graphics_286 = new cjs.Graphics().p("AtYM/QljlYAAnnIAAAAQAAnmFjlZIAAAAQFjlYH1AAIAAAAQH2AAFjFYIAAAAQFjFZAAHmIAAAAQAAHnljFYIAAAAQljFZn2AAIAAAAQn1AAljlZg");
	var mask_11_graphics_287 = new cjs.Graphics().p("AthNIQlmlcAAnsIAAAAQAAnrFmlcIAAAAQFnlcH6AAIAAAAQH7AAFmFcIAAAAQFnFcAAHrIAAAAQAAHslnFcIAAAAQlmFcn7AAIAAAAQn6AAlnlcg");
	var mask_11_graphics_288 = new cjs.Graphics().p("AtpNQQlqlfAAnxIAAAAQAAnwFqlfIAAAAQFqlgH/AAIAAAAQIAAAFqFgIAAAAQFqFfAAHwIAAAAQAAHxlqFfIAAAAQlqFgoAAAIAAAAQn/AAlqlgg");
	var mask_11_graphics_289 = new cjs.Graphics().p("AtyNYQltliAAn2IAAAAQAAn1FtljIAAAAQFuliIEAAIAAAAQIFAAFtFiIAAAAQFuFjAAH1IAAAAQAAH2luFiIAAAAQltFjoFAAIAAAAQoEAAluljg");
	var mask_11_graphics_290 = new cjs.Graphics().p("At6NgQlxlmAAn6IAAAAQAAn5FxlnIAAAAQFxllIJAAIAAAAQIKAAFxFlIAAAAQFxFnAAH5IAAAAQAAH6lxFmIAAAAQlxFmoKAAIAAAAQoJAAlxlmg");
	var mask_11_graphics_291 = new cjs.Graphics().p("AuCNoQl0lpAAn/IAAAAQAAn+F0lqIAAAAQF1lpINAAIAAAAQIPAAF0FpIAAAAQF0FqAAH+IAAAAQAAH/l0FpIAAAAQl0FqoPAAIAAAAQoNAAl1lqg");
	var mask_11_graphics_292 = new cjs.Graphics().p("AuKNwQl4ltAAoDIAAAAQAAoCF4ltIAAAAQF4ltISAAIAAAAQITAAF4FtIAAAAQF4FtAAICIAAAAQAAIDl4FtIAAAAQl4FtoTAAIAAAAQoSAAl4ltg");
	var mask_11_graphics_293 = new cjs.Graphics().p("AuSN3Ql7lvAAoIIAAAAQAAoHF7lwIAAAAQF7lvIXAAIAAAAQIYAAF6FvIAAAAQF8FwAAIHIAAAAQAAIIl8FvIAAAAQl6FwoYAAIAAAAQoXAAl7lwg");
	var mask_11_graphics_294 = new cjs.Graphics().p("AuaN/Ql9lzAAoMIAAAAQAAoLF9lzIAAAAQF/lzIbAAIAAAAQIcAAF+FzIAAAAQF+FzAAILIAAAAQAAIMl+FzIAAAAQl+FzocAAIAAAAQobAAl/lzg");
	var mask_11_graphics_295 = new cjs.Graphics().p("AuhOGQmBl1AAoRIAAAAQAAoQGBl2IAAAAQGBl1IgAAIAAAAQIhAAGBF1IAAAAQGBF2AAIQIAAAAQAAIRmBF1IAAAAQmBF2ohAAIAAAAQogAAmBl2g");
	var mask_11_graphics_296 = new cjs.Graphics().p("AupONQmEl4AAoVIAAAAQAAoUGEl5IAAAAQGFl4IkAAIAAAAQIlAAGEF4IAAAAQGFF5AAIUIAAAAQAAIVmFF4IAAAAQmEF5olAAIAAAAQokAAmFl5g");
	var mask_11_graphics_297 = new cjs.Graphics().p("AuwOUQmHl7AAoZIAAAAQAAoYGHl8IAAAAQGIl7IoAAIAAAAQIpAAGHF7IAAAAQGIF8AAIYIAAAAQAAIZmIF7IAAAAQmHF8opAAIAAAAQooAAmIl8g");
	var mask_11_graphics_298 = new cjs.Graphics().p("Au3ObQmKl+AAodIAAAAQAAocGKl/IAAAAQGLl+IsAAIAAAAQItAAGKF+IAAAAQGLF/AAIcIAAAAQAAIdmLF+IAAAAQmKF/otAAIAAAAQosAAmLl/g");
	var mask_11_graphics_299 = new cjs.Graphics().p("Au+OiQmNmBAAohIAAAAQAAogGNmBIAAAAQGOmCIwAAIAAAAQIxAAGNGCIAAAAQGOGBAAIgIAAAAQAAIhmOGBIAAAAQmNGCoxAAIAAAAQowAAmOmCg");
	var mask_11_graphics_300 = new cjs.Graphics().p("AvFOpQmPmEAAolIAAAAQAAokGPmEIAAAAQGRmEI0AAIAAAAQI1AAGQGEIAAAAQGQGEAAIkIAAAAQAAIlmQGEIAAAAQmQGEo1AAIAAAAQo0AAmRmEg");
	var mask_11_graphics_301 = new cjs.Graphics().p("AvLOvQmTmGAAopIAAAAQAAooGTmHIAAAAQGTmGI4AAIAAAAQI5AAGTGGIAAAAQGTGHAAIoIAAAAQAAIpmTGGIAAAAQmTGHo5AAIAAAAQo4AAmTmHg");
	var mask_11_graphics_302 = new cjs.Graphics().p("AvSO1QmVmJAAosIAAAAQAAorGVmKIAAAAQGWmJI8AAIAAAAQI9AAGVGJIAAAAQGWGKAAIrIAAAAQAAIsmWGJIAAAAQmVGKo9AAIAAAAQo8AAmWmKg");
	var mask_11_graphics_303 = new cjs.Graphics().p("AvYO8QmYmMAAowIAAAAQAAovGYmMIAAAAQGYmMJAAAIAAAAQJBAAGYGMIAAAAQGYGMAAIvIAAAAQAAIwmYGMIAAAAQmYGMpBAAIAAAAQpAAAmYmMg");
	var mask_11_graphics_304 = new cjs.Graphics().p("AvfPCQmamPAAozIAAAAQAAoyGamPIAAAAQGbmPJEAAIAAAAQJFAAGaGPIAAAAQGbGPAAIyIAAAAQAAIzmbGPIAAAAQmaGPpFAAIAAAAQpEAAmbmPg");
	var mask_11_graphics_305 = new cjs.Graphics().p("AvlPIQmdmRAAo3IAAAAQAAo2GdmRIAAAAQGemRJHAAIAAAAQJIAAGdGRIAAAAQGeGRAAI2IAAAAQAAI3meGRIAAAAQmdGRpIAAIAAAAQpHAAmemRg");
	var mask_11_graphics_306 = new cjs.Graphics().p("AvrPOQmfmUAAo6IAAAAQAAo5GfmUIAAAAQGgmTJLAAIAAAAQJMAAGfGTIAAAAQGgGUAAI5IAAAAQAAI6mgGUIAAAAQmfGTpMAAIAAAAQpLAAmgmTg");
	var mask_11_graphics_307 = new cjs.Graphics().p("AvxPTQmhmVAAo+IAAAAQAAo9GhmWIAAAAQGjmVJOAAIAAAAQJPAAGiGVIAAAAQGiGWAAI9IAAAAQAAI+miGVIAAAAQmiGWpPAAIAAAAQpOAAmjmWg");
	var mask_11_graphics_308 = new cjs.Graphics().p("Av2PZQmkmYAApBIAAAAQAApAGkmYIAAAAQGkmYJSAAIAAAAQJTAAGkGYIAAAAQGkGYAAJAIAAAAQAAJBmkGYIAAAAQmkGYpTAAIAAAAQpSAAmkmYg");
	var mask_11_graphics_309 = new cjs.Graphics().p("Av8PeQmmmaAApEIAAAAQAApDGmmbIAAAAQGnmaJVAAIAAAAQJWAAGmGaIAAAAQGnGbAAJDIAAAAQAAJEmnGaIAAAAQmmGbpWAAIAAAAQpVAAmnmbg");
	var mask_11_graphics_310 = new cjs.Graphics().p("AwBPjQmpmcAApHIAAAAQAApGGpmdIAAAAQGpmcJYAAIAAAAQJZAAGpGcIAAAAQGpGdAAJGIAAAAQAAJHmpGcIAAAAQmpGdpZAAIAAAAQpYAAmpmdg");
	var mask_11_graphics_311 = new cjs.Graphics().p("AwHPpQmrmfAApKIAAAAQAApJGrmfIAAAAQGsmfJbAAIAAAAQJcAAGrGfIAAAAQGsGfAAJJIAAAAQAAJKmsGfIAAAAQmrGfpcAAIAAAAQpbAAmsmfg");
	var mask_11_graphics_312 = new cjs.Graphics().p("AwMPuQmtmhAApNIAAAAQAApMGtmhIAAAAQGumhJeAAIAAAAQJfAAGtGhIAAAAQGuGhAAJMIAAAAQAAJNmuGhIAAAAQmtGhpfAAIAAAAQpeAAmumhg");
	var mask_11_graphics_313 = new cjs.Graphics().p("AwRPzQmvmjAApQIAAAAQAApPGvmjIAAAAQGwmjJhAAIAAAAQJiAAGvGjIAAAAQGwGjAAJPIAAAAQAAJQmwGjIAAAAQmvGjpiAAIAAAAQphAAmwmjg");
	var mask_11_graphics_314 = new cjs.Graphics().p("AwWP3QmxmkAApTIAAAAQAApSGxmlIAAAAQGymkJkAAIAAAAQJlAAGxGkIAAAAQGyGlAAJSIAAAAQAAJTmyGkIAAAAQmxGlplAAIAAAAQpkAAmymlg");
	var mask_11_graphics_315 = new cjs.Graphics().p("AwbP8QmzmmAApWIAAAAQAApVGzmnIAAAAQG0mmJnAAIAAAAQJoAAGzGmIAAAAQG0GnAAJVIAAAAQAAJWm0GmIAAAAQmzGnpoAAIAAAAQpnAAm0mng");
	var mask_11_graphics_316 = new cjs.Graphics().p("AwfQBQm2mpAApYIAAAAQAApXG2mpIAAAAQG1moJqAAIAAAAQJrAAG1GoIAAAAQG2GpAAJXIAAAAQAAJYm2GpIAAAAQm1GoprAAIAAAAQpqAAm1mog");
	var mask_11_graphics_317 = new cjs.Graphics().p("AwkQFQm3mqAApbIAAAAQAApaG3mrIAAAAQG4mqJsAAIAAAAQJtAAG3GqIAAAAQG4GrAAJaIAAAAQAAJbm4GqIAAAAQm3GrptAAIAAAAQpsAAm4mrg");
	var mask_11_graphics_318 = new cjs.Graphics().p("AwoQJQm5msAApdIAAAAQAApcG5mtIAAAAQG5msJvAAIAAAAQJwAAG5GsIAAAAQG5GtAAJcIAAAAQAAJdm5GsIAAAAQm5GtpwAAIAAAAQpvAAm5mtg");
	var mask_11_graphics_319 = new cjs.Graphics().p("AwtQNQm6mtAApgIAAAAQAApfG6muIAAAAQG8muJxAAIAAAAQJyAAG7GuIAAAAQG7GuAAJfIAAAAQAAJgm7GtIAAAAQm7GvpyAAIAAAAQpxAAm8mvg");
	var mask_11_graphics_320 = new cjs.Graphics().p("AwxQSQm8mwAApiIAAAAQAAphG8mwIAAAAQG9mvJ0AAIAAAAQJ1AAG8GvIAAAAQG9GwAAJhIAAAAQAAJim9GwIAAAAQm8Gvp1AAIAAAAQp0AAm9mvg");
	var mask_11_graphics_321 = new cjs.Graphics().p("Aw1QWQm+mxAAplIAAAAQAApkG+mxIAAAAQG/mxJ2AAIAAAAQJ3AAG+GxIAAAAQG/GxAAJkIAAAAQAAJlm/GxIAAAAQm+Gxp3AAIAAAAQp2AAm/mxg");
	var mask_11_graphics_322 = new cjs.Graphics().p("Aw5QZQnAmyAApnIAAAAQAApmHAmzIAAAAQHAmyJ5AAIAAAAQJ5AAHAGyIAAAAQHBGzAAJmIAAAAQAAJnnBGyIAAAAQnAGzp5AAIAAAAQp5AAnAmzg");
	var mask_11_graphics_323 = new cjs.Graphics().p("Aw9QdQnBm0AAppIAAAAQAApoHBm1IAAAAQHCm0J7AAIAAAAQJ8AAHBG0IAAAAQHCG1AAJoIAAAAQAAJpnCG0IAAAAQnBG1p8AAIAAAAQp7AAnCm1g");
	var mask_11_graphics_324 = new cjs.Graphics().p("AxAQhQnDm2AAprIAAAAQAApqHDm2IAAAAQHDm2J9AAIAAAAQJ+AAHDG2IAAAAQHDG2AAJqIAAAAQAAJrnDG2IAAAAQnDG2p+AAIAAAAQp9AAnDm2g");
	var mask_11_graphics_325 = new cjs.Graphics().p("AxEQkQnEm3AAptIAAAAQAApsHEm4IAAAAQHFm3J/AAIAAAAQKAAAHEG3IAAAAQHFG4AAJsIAAAAQAAJtnFG3IAAAAQnEG4qAAAIAAAAQp/AAnFm4g");
	var mask_11_graphics_326 = new cjs.Graphics().p("AxHQoQnGm5AApvIAAAAQAApuHGm5IAAAAQHGm5KBAAIAAAAQKCAAHGG5IAAAAQHGG5AAJuIAAAAQAAJvnGG5IAAAAQnGG5qCAAIAAAAQqBAAnGm5g");
	var mask_11_graphics_327 = new cjs.Graphics().p("AxLQrQnHm6AApxIAAAAQAApwHHm6IAAAAQHIm6KDAAIAAAAQKEAAHHG6IAAAAQHIG6AAJwIAAAAQAAJxnIG6IAAAAQnHG6qEAAIAAAAQqDAAnIm6g");
	var mask_11_graphics_328 = new cjs.Graphics().p("AxOQuQnJm7AApzIAAAAQAApyHJm7IAAAAQHJm8KFAAIAAAAQKGAAHJG8IAAAAQHJG7AAJyIAAAAQAAJznJG7IAAAAQnJG8qGAAIAAAAQqFAAnJm8g");
	var mask_11_graphics_329 = new cjs.Graphics().p("AxRQxQnKm8AAp1IAAAAQAAp0HKm9IAAAAQHKm8KHAAIAAAAQKIAAHKG8IAAAAQHKG9AAJ0IAAAAQAAJ1nKG8IAAAAQnKG9qIAAIAAAAQqHAAnKm9g");
	var mask_11_graphics_330 = new cjs.Graphics().p("AxUQ0QnLm+AAp2IAAAAQAAp1HLm+IAAAAQHLm+KJAAIAAAAQKKAAHLG+IAAAAQHLG+AAJ1IAAAAQAAJ2nLG+IAAAAQnLG+qKAAIAAAAQqJAAnLm+g");
	var mask_11_graphics_331 = new cjs.Graphics().p("AxXQ3QnNm/AAp4IAAAAQAAp3HNm/IAAAAQHNm/KKAAIAAAAQKLAAHNG/IAAAAQHNG/AAJ3IAAAAQAAJ4nNG/IAAAAQnNG/qLAAIAAAAQqKAAnNm/g");
	var mask_11_graphics_332 = new cjs.Graphics().p("AxaQ6QnOnAAAp6IAAAAQAAp5HOnAIAAAAQHOnAKMAAIAAAAQKNAAHNHAIAAAAQHPHAAAJ5IAAAAQAAJ6nPHAIAAAAQnNHAqNAAIAAAAQqMAAnOnAg");
	var mask_11_graphics_333 = new cjs.Graphics().p("AxdQ8QnOnBAAp7IAAAAQAAp6HOnCIAAAAQHPnBKOAAIAAAAQKPAAHOHBIAAAAQHPHCAAJ6IAAAAQAAJ7nPHBIAAAAQnOHCqPAAIAAAAQqOAAnPnCg");
	var mask_11_graphics_334 = new cjs.Graphics().p("AxfQ/QnQnCAAp9IAAAAQAAp8HQnCIAAAAQHQnCKPAAIAAAAQKQAAHQHCIAAAAQHQHCAAJ8IAAAAQAAJ9nQHCIAAAAQnQHCqQAAIAAAAQqPAAnQnCg");
	var mask_11_graphics_335 = new cjs.Graphics().p("AxiRBQnRnDAAp+IAAAAQAAp9HRnEIAAAAQHSnDKQAAIAAAAQKRAAHRHDIAAAAQHSHEAAJ9IAAAAQAAJ+nSHDIAAAAQnRHEqRAAIAAAAQqQAAnSnEg");

	this.timeline.addTween(cjs.Tween.get(mask_11).to({graphics:null,x:0,y:0}).wait(219).to({graphics:mask_11_graphics_219,x:294.6001,y:303.8503}).wait(1).to({graphics:mask_11_graphics_220,x:294.6186,y:303.8499}).wait(1).to({graphics:mask_11_graphics_221,x:294.6375,y:303.8508}).wait(1).to({graphics:mask_11_graphics_222,x:294.6564,y:303.8508}).wait(1).to({graphics:mask_11_graphics_223,x:294.6753,y:303.8508}).wait(1).to({graphics:mask_11_graphics_224,x:294.6942,y:303.8508}).wait(1).to({graphics:mask_11_graphics_225,x:294.7135,y:303.8508}).wait(1).to({graphics:mask_11_graphics_226,x:294.7325,y:303.8512}).wait(1).to({graphics:mask_11_graphics_227,x:294.7518,y:303.8512}).wait(1).to({graphics:mask_11_graphics_228,x:294.7711,y:303.8517}).wait(1).to({graphics:mask_11_graphics_229,x:294.7905,y:303.8517}).wait(1).to({graphics:mask_11_graphics_230,x:294.8098,y:303.8517}).wait(1).to({graphics:mask_11_graphics_231,x:294.8292,y:303.8517}).wait(1).to({graphics:mask_11_graphics_232,x:294.8485,y:303.8521}).wait(1).to({graphics:mask_11_graphics_233,x:294.8683,y:303.8526}).wait(1).to({graphics:mask_11_graphics_234,x:294.8877,y:303.8526}).wait(1).to({graphics:mask_11_graphics_235,x:294.907,y:303.8526}).wait(1).to({graphics:mask_11_graphics_236,x:294.9268,y:303.8526}).wait(1).to({graphics:mask_11_graphics_237,x:294.9457,y:303.8526}).wait(1).to({graphics:mask_11_graphics_238,x:294.9651,y:303.853}).wait(1).to({graphics:mask_11_graphics_239,x:294.9849,y:303.8535}).wait(1).to({graphics:mask_11_graphics_240,x:295.0042,y:303.8535}).wait(1).to({graphics:mask_11_graphics_241,x:295.0236,y:303.8535}).wait(1).to({graphics:mask_11_graphics_242,x:295.0425,y:303.8535}).wait(1).to({graphics:mask_11_graphics_243,x:295.0618,y:303.8539}).wait(1).to({graphics:mask_11_graphics_244,x:295.0807,y:303.8544}).wait(1).to({graphics:mask_11_graphics_245,x:295.0996,y:303.8544}).wait(1).to({graphics:mask_11_graphics_246,x:295.119,y:303.8544}).wait(1).to({graphics:mask_11_graphics_247,x:295.1379,y:303.8549}).wait(1).to({graphics:mask_11_graphics_248,x:295.1563,y:303.8548}).wait(1).to({graphics:mask_11_graphics_249,x:295.1752,y:303.8549}).wait(1).to({graphics:mask_11_graphics_250,x:295.1941,y:303.8549}).wait(1).to({graphics:mask_11_graphics_251,x:295.2121,y:303.8553}).wait(1).to({graphics:mask_11_graphics_252,x:295.2306,y:303.8553}).wait(1).to({graphics:mask_11_graphics_253,x:295.2486,y:303.8558}).wait(1).to({graphics:mask_11_graphics_254,x:295.2666,y:303.8557}).wait(1).to({graphics:mask_11_graphics_255,x:295.2846,y:303.8557}).wait(1).to({graphics:mask_11_graphics_256,x:295.3026,y:303.8562}).wait(1).to({graphics:mask_11_graphics_257,x:295.3202,y:303.8562}).wait(1).to({graphics:mask_11_graphics_258,x:295.3377,y:303.8562}).wait(1).to({graphics:mask_11_graphics_259,x:295.3548,y:303.8562}).wait(1).to({graphics:mask_11_graphics_260,x:295.3719,y:303.8562}).wait(1).to({graphics:mask_11_graphics_261,x:295.389,y:303.8566}).wait(1).to({graphics:mask_11_graphics_262,x:295.4061,y:303.8571}).wait(1).to({graphics:mask_11_graphics_263,x:295.4227,y:303.8571}).wait(1).to({graphics:mask_11_graphics_264,x:295.4394,y:303.8571}).wait(1).to({graphics:mask_11_graphics_265,x:295.4556,y:303.8571}).wait(1).to({graphics:mask_11_graphics_266,x:295.4718,y:303.8571}).wait(1).to({graphics:mask_11_graphics_267,x:295.4875,y:303.8571}).wait(1).to({graphics:mask_11_graphics_268,x:295.5033,y:303.8575}).wait(1).to({graphics:mask_11_graphics_269,x:295.5191,y:303.8575}).wait(1).to({graphics:mask_11_graphics_270,x:295.5339,y:303.8576}).wait(1).to({graphics:mask_11_graphics_271,x:295.5496,y:303.8575}).wait(1).to({graphics:mask_11_graphics_272,x:295.5645,y:303.858}).wait(1).to({graphics:mask_11_graphics_273,x:295.5794,y:303.858}).wait(1).to({graphics:mask_11_graphics_274,x:295.5937,y:303.858}).wait(1).to({graphics:mask_11_graphics_275,x:295.6082,y:303.8585}).wait(1).to({graphics:mask_11_graphics_276,x:295.6226,y:303.8584}).wait(1).to({graphics:mask_11_graphics_277,x:295.6365,y:303.8589}).wait(1).to({graphics:mask_11_graphics_278,x:295.65,y:303.8584}).wait(1).to({graphics:mask_11_graphics_279,x:295.6639,y:303.8589}).wait(1).to({graphics:mask_11_graphics_280,x:295.6775,y:303.8589}).wait(1).to({graphics:mask_11_graphics_281,x:295.6905,y:303.8589}).wait(1).to({graphics:mask_11_graphics_282,x:295.7035,y:303.8593}).wait(1).to({graphics:mask_11_graphics_283,x:295.7166,y:303.8589}).wait(1).to({graphics:mask_11_graphics_284,x:295.7292,y:303.8594}).wait(1).to({graphics:mask_11_graphics_285,x:295.7413,y:303.8593}).wait(1).to({graphics:mask_11_graphics_286,x:295.7535,y:303.8594}).wait(1).to({graphics:mask_11_graphics_287,x:295.7652,y:303.8598}).wait(1).to({graphics:mask_11_graphics_288,x:295.7773,y:303.8598}).wait(1).to({graphics:mask_11_graphics_289,x:295.7886,y:303.8598}).wait(1).to({graphics:mask_11_graphics_290,x:295.8003,y:303.8598}).wait(1).to({graphics:mask_11_graphics_291,x:295.8111,y:303.8603}).wait(1).to({graphics:mask_11_graphics_292,x:295.8219,y:303.8602}).wait(1).to({graphics:mask_11_graphics_293,x:295.8327,y:303.8602}).wait(1).to({graphics:mask_11_graphics_294,x:295.8435,y:303.8602}).wait(1).to({graphics:mask_11_graphics_295,x:295.8539,y:303.8602}).wait(1).to({graphics:mask_11_graphics_296,x:295.8637,y:303.8607}).wait(1).to({graphics:mask_11_graphics_297,x:295.8736,y:303.8602}).wait(1).to({graphics:mask_11_graphics_298,x:295.884,y:303.8607}).wait(1).to({graphics:mask_11_graphics_299,x:295.893,y:303.8607}).wait(1).to({graphics:mask_11_graphics_300,x:295.9024,y:303.8607}).wait(1).to({graphics:mask_11_graphics_301,x:295.9115,y:303.8607}).wait(1).to({graphics:mask_11_graphics_302,x:295.9205,y:303.8611}).wait(1).to({graphics:mask_11_graphics_303,x:295.9295,y:303.8607}).wait(1).to({graphics:mask_11_graphics_304,x:295.9384,y:303.8611}).wait(1).to({graphics:mask_11_graphics_305,x:295.9461,y:303.8612}).wait(1).to({graphics:mask_11_graphics_306,x:295.9546,y:303.8612}).wait(1).to({graphics:mask_11_graphics_307,x:295.9627,y:303.8611}).wait(1).to({graphics:mask_11_graphics_308,x:295.9708,y:303.8616}).wait(1).to({graphics:mask_11_graphics_309,x:295.9785,y:303.8616}).wait(1).to({graphics:mask_11_graphics_310,x:295.9861,y:303.8616}).wait(1).to({graphics:mask_11_graphics_311,x:295.9929,y:303.8616}).wait(1).to({graphics:mask_11_graphics_312,x:296.0001,y:303.8611}).wait(1).to({graphics:mask_11_graphics_313,x:296.0073,y:303.8616}).wait(1).to({graphics:mask_11_graphics_314,x:296.014,y:303.8616}).wait(1).to({graphics:mask_11_graphics_315,x:296.0204,y:303.862}).wait(1).to({graphics:mask_11_graphics_316,x:296.0271,y:303.8616}).wait(1).to({graphics:mask_11_graphics_317,x:296.0334,y:303.8616}).wait(1).to({graphics:mask_11_graphics_318,x:296.0392,y:303.862}).wait(1).to({graphics:mask_11_graphics_319,x:296.0455,y:303.862}).wait(1).to({graphics:mask_11_graphics_320,x:296.0509,y:303.862}).wait(1).to({graphics:mask_11_graphics_321,x:296.0563,y:303.862}).wait(1).to({graphics:mask_11_graphics_322,x:296.0622,y:303.862}).wait(1).to({graphics:mask_11_graphics_323,x:296.0671,y:303.862}).wait(1).to({graphics:mask_11_graphics_324,x:296.0721,y:303.862}).wait(1).to({graphics:mask_11_graphics_325,x:296.0775,y:303.862}).wait(1).to({graphics:mask_11_graphics_326,x:296.0824,y:303.8621}).wait(1).to({graphics:mask_11_graphics_327,x:296.0865,y:303.862}).wait(1).to({graphics:mask_11_graphics_328,x:296.0915,y:303.8625}).wait(1).to({graphics:mask_11_graphics_329,x:296.0955,y:303.8625}).wait(1).to({graphics:mask_11_graphics_330,x:296.0995,y:303.8625}).wait(1).to({graphics:mask_11_graphics_331,x:296.1036,y:303.8625}).wait(1).to({graphics:mask_11_graphics_332,x:296.1077,y:303.8625}).wait(1).to({graphics:mask_11_graphics_333,x:296.1112,y:303.8625}).wait(1).to({graphics:mask_11_graphics_334,x:296.1148,y:303.8625}).wait(1).to({graphics:mask_11_graphics_335,x:295.8156,y:303.6582}).wait(475));

	// Layer_23
	this.instance_17 = new lib.Tween53("synched",0);
	this.instance_17.setTransform(280.15,239.95);
	this.instance_17.alpha = 0.5;
	this.instance_17._off = true;

	this.instance_18 = new lib.Tween54("synched",0);
	this.instance_18.setTransform(280.15,239.95);

	var maskedShapeInstanceList = [this.instance_17,this.instance_18];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_11;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_17}]},219).to({state:[{t:this.instance_18}]},116).wait(475));
	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(219).to({_off:false},0).to({_off:true,alpha:1},116).wait(475));

	// Layer_6 (mask)
	var mask_12 = new cjs.Shape();
	mask_12._off = true;
	var mask_12_graphics_154 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_12_graphics_155 = new cjs.Graphics().p("AgaAaQgMgLAAgPIAAAAQAAgOAMgLIAAAAQALgLAPAAIAAAAQAQAAALALIAAAAQAMALAAAOIAAAAQAAAPgMALIAAAAQgLALgQAAIAAAAQgPAAgLgLg");
	var mask_12_graphics_156 = new cjs.Graphics().p("AglAkQgPgPAAgVIAAAAQAAgUAPgPIAAAAQAQgPAVAAIAAAAQAWAAAQAPIAAAAQAPAPAAAUIAAAAQAAAVgPAPIAAAAQgQAPgWAAIAAAAQgVAAgQgPg");
	var mask_12_graphics_157 = new cjs.Graphics().p("AgvAuQgUgTAAgbIAAAAQAAgaAUgTIAAAAQAUgTAbAAIAAAAQAcAAAUATIAAAAQAUATAAAaIAAAAQAAAbgUATIAAAAQgUATgcAAIAAAAQgbAAgUgTg");
	var mask_12_graphics_158 = new cjs.Graphics().p("Ag5A4QgYgXAAghIAAAAQAAggAYgXIAAAAQAYgXAhAAIAAAAQAiAAAYAXIAAAAQAYAXAAAgIAAAAQAAAhgYAXIAAAAQgYAXgiAAIAAAAQghAAgYgXg");
	var mask_12_graphics_159 = new cjs.Graphics().p("AhDBCQgdgbAAgnIAAAAQAAgmAdgbIAAAAQAcgcAnAAIAAAAQAoAAAcAcIAAAAQAdAbAAAmIAAAAQAAAngdAbIAAAAQgcAcgoAAIAAAAQgnAAgcgcg");
	var mask_12_graphics_160 = new cjs.Graphics().p("AhOBMQgggfAAgtIAAAAQAAgsAggfIAAAAQAhggAtAAIAAAAQAuAAAhAgIAAAAQAgAfAAAsIAAAAQAAAtggAfIAAAAQghAgguAAIAAAAQgtAAghggg");
	var mask_12_graphics_161 = new cjs.Graphics().p("AhYBWQglgjAAgzIAAAAQAAgyAlgjIAAAAQAlgkAzAAIAAAAQA0AAAlAkIAAAAQAlAjAAAyIAAAAQAAAzglAjIAAAAQglAkg0AAIAAAAQgzAAglgkg");
	var mask_12_graphics_162 = new cjs.Graphics().p("AhjBhQgpgoAAg5IAAAAQAAg4ApgoIAAAAQAqgoA5AAIAAAAQA6AAAqAoIAAAAQApAoAAA4IAAAAQAAA5gpAoIAAAAQgqAog6AAIAAAAQg5AAgqgog");
	var mask_12_graphics_163 = new cjs.Graphics().p("AhtBrQgugsAAg/IAAAAQAAg+AugsIAAAAQAtgsBAAAIAAAAQBBAAAtAsIAAAAQAuAsAAA+IAAAAQAAA/guAsIAAAAQgtAshBAAIAAAAQhAAAgtgsg");
	var mask_12_graphics_164 = new cjs.Graphics().p("Ah4B1QgygxAAhEIAAAAQAAhDAygxIAAAAQAygwBGAAIAAAAQBHAAAyAwIAAAAQAyAxAABDIAAAAQAABEgyAxIAAAAQgyAwhHAAIAAAAQhGAAgygwg");
	var mask_12_graphics_165 = new cjs.Graphics().p("AiCB/Qg3g1AAhKIAAAAQAAhJA3g1IAAAAQA2g1BMAAIAAAAQBNAAA2A1IAAAAQA3A1AABJIAAAAQAABKg3A1IAAAAQg2A1hNAAIAAAAQhMAAg2g1g");
	var mask_12_graphics_166 = new cjs.Graphics().p("AiNCJQg6g5AAhQIAAAAQAAhPA6g5IAAAAQA7g5BSAAIAAAAQBTAAA7A5IAAAAQA6A5AABPIAAAAQAABQg6A5IAAAAQg7A5hTAAIAAAAQhSAAg7g5g");
	var mask_12_graphics_167 = new cjs.Graphics().p("AiXCUQg/g+AAhWIAAAAQAAhVA/g+IAAAAQA/g9BYAAIAAAAQBZAAA/A9IAAAAQA/A+AABVIAAAAQAABWg/A+IAAAAQg/A9hZAAIAAAAQhYAAg/g9g");
	var mask_12_graphics_168 = new cjs.Graphics().p("AiiCeQhDhCAAhcIAAAAQAAhbBDhCIAAAAQBEhBBeAAIAAAAQBfAABEBBIAAAAQBDBCAABbIAAAAQAABchDBCIAAAAQhEBBhfAAIAAAAQheAAhEhBg");
	var mask_12_graphics_169 = new cjs.Graphics().p("AisCoQhIhGAAhiIAAAAQAAhhBIhGIAAAAQBHhGBlAAIAAAAQBmAABHBGIAAAAQBIBGAABhIAAAAQAABihIBGIAAAAQhHBGhmAAIAAAAQhlAAhHhGg");
	var mask_12_graphics_170 = new cjs.Graphics().p("Ai3CyQhMhKAAhoIAAAAQAAhnBMhKIAAAAQBMhKBrAAIAAAAQBsAABMBKIAAAAQBMBKAABnIAAAAQAABohMBKIAAAAQhMBKhsAAIAAAAQhrAAhMhKg");
	var mask_12_graphics_171 = new cjs.Graphics().p("AjCC9QhQhOAAhvIAAAAQAAhuBQhOIAAAAQBRhOBxAAIAAAAQByAABRBOIAAAAQBQBOAABuIAAAAQAABvhQBOIAAAAQhRBOhyAAIAAAAQhxAAhRhOg");
	var mask_12_graphics_172 = new cjs.Graphics().p("AjMDHQhVhSAAh1IAAAAQAAh0BVhSIAAAAQBVhSB3AAIAAAAQB4AABVBSIAAAAQBVBSAAB0IAAAAQAAB1hVBSIAAAAQhVBSh4AAIAAAAQh3AAhVhSg");
	var mask_12_graphics_173 = new cjs.Graphics().p("AjXDRQhZhWAAh7IAAAAQAAh6BZhWIAAAAQBahXB9AAIAAAAQB+AABaBXIAAAAQBZBWAAB6IAAAAQAAB7hZBWIAAAAQhaBXh+AAIAAAAQh9AAhahXg");
	var mask_12_graphics_174 = new cjs.Graphics().p("AjhDbQhehbAAiAIAAAAQAAiABehaIAAAAQBdhbCEAAIAAAAQCFAABdBbIAAAAQBeBaAACAIAAAAQAACAheBbIAAAAQhdBbiFAAIAAAAQiEAAhdhbg");
	var mask_12_graphics_175 = new cjs.Graphics().p("AjsDmQhihgAAiGIAAAAQAAiFBihgIAAAAQBihfCKAAIAAAAQCLAABiBfIAAAAQBiBgAACFIAAAAQAACGhiBgIAAAAQhiBfiLAAIAAAAQiKAAhihfg");
	var mask_12_graphics_176 = new cjs.Graphics().p("Aj2DwQhnhkAAiMIAAAAQAAiLBnhkIAAAAQBmhjCQAAIAAAAQCRAABmBjIAAAAQBnBkAACLIAAAAQAACMhnBkIAAAAQhmBjiRAAIAAAAQiQAAhmhjg");
	var mask_12_graphics_177 = new cjs.Graphics().p("AkBD6QhqhoAAiSIAAAAQAAiRBqhoIAAAAQBrhnCWAAIAAAAQCXAABrBnIAAAAQBqBoAACRIAAAAQAACShqBoIAAAAQhrBniXAAIAAAAQiWAAhrhng");
	var mask_12_graphics_178 = new cjs.Graphics().p("AkLEEQhvhsAAiYIAAAAQAAiXBvhsIAAAAQBvhsCcAAIAAAAQCdAABvBsIAAAAQBvBsAACXIAAAAQAACYhvBsIAAAAQhvBsidAAIAAAAQicAAhvhsg");
	var mask_12_graphics_179 = new cjs.Graphics().p("AkWEOQhzhwAAieIAAAAQAAidBzhwIAAAAQB0hwCiAAIAAAAQCjAABzBwIAAAAQB0BwAACdIAAAAQAACeh0BwIAAAAQhzBwijAAIAAAAQiiAAh0hwg");
	var mask_12_graphics_180 = new cjs.Graphics().p("AkgEYQh3h0AAikIAAAAQAAijB3h0IAAAAQB4h0CoAAIAAAAQCpAAB4B0IAAAAQB3B0AACjIAAAAQAACkh3B0IAAAAQh4B0ipAAIAAAAQioAAh4h0g");
	var mask_12_graphics_181 = new cjs.Graphics().p("AkqEiQh8h4AAiqIAAAAQAAipB8h4IAAAAQB8h4CuAAIAAAAQCvAAB8B4IAAAAQB8B4AACpIAAAAQAACqh8B4IAAAAQh8B4ivAAIAAAAQiuAAh8h4g");
	var mask_12_graphics_182 = new cjs.Graphics().p("Ak0EsQiBh8AAiwIAAAAQAAivCBh8IAAAAQCAh8C0AAIAAAAQC1AACAB8IAAAAQCBB8AACvIAAAAQAACwiBB8IAAAAQiAB8i1AAIAAAAQi0AAiAh8g");
	var mask_12_graphics_183 = new cjs.Graphics().p("Ak/E2QiEiAAAi2IAAAAQAAi1CEiAIAAAAQCFiAC6AAIAAAAQC7AACFCAIAAAAQCECAAAC1IAAAAQAAC2iECAIAAAAQiFCAi7AAIAAAAQi6AAiFiAg");
	var mask_12_graphics_184 = new cjs.Graphics().p("AlJFAQiIiFAAi7IAAAAQAAi6CIiFIAAAAQCJiEDAAAIAAAAQDBAACJCEIAAAAQCICFAAC6IAAAAQAAC7iICFIAAAAQiJCEjBAAIAAAAQjAAAiJiEg");
	var mask_12_graphics_185 = new cjs.Graphics().p("AlTFKQiNiJAAjBIAAAAQAAjACNiJIAAAAQCNiIDGAAIAAAAQDHAACNCIIAAAAQCNCJAADAIAAAAQAADBiNCJIAAAAQiNCIjHAAIAAAAQjGAAiNiIg");
	var mask_12_graphics_186 = new cjs.Graphics().p("AldFTQiRiMAAjHIAAAAQAAjGCRiMIAAAAQCRiNDMAAIAAAAQDNAACRCNIAAAAQCRCMAADGIAAAAQAADHiRCMIAAAAQiRCNjNAAIAAAAQjMAAiRiNg");
	var mask_12_graphics_187 = new cjs.Graphics().p("AlnFdQiViRAAjMIAAAAQAAjLCViRIAAAAQCViRDSAAIAAAAQDTAACVCRIAAAAQCVCRAADLIAAAAQAADMiVCRIAAAAQiVCRjTAAIAAAAQjSAAiViRg");
	var mask_12_graphics_188 = new cjs.Graphics().p("AlxFnQiZiVAAjSIAAAAQAAjRCZiVIAAAAQCZiUDYAAIAAAAQDZAACZCUIAAAAQCZCVAADRIAAAAQAADSiZCVIAAAAQiZCUjZAAIAAAAQjYAAiZiUg");
	var mask_12_graphics_189 = new cjs.Graphics().p("Al7FwQidiYAAjYIAAAAQAAjXCdiYIAAAAQCeiZDdAAIAAAAQDeAACdCZIAAAAQCeCYAADXIAAAAQAADYieCYIAAAAQidCZjeAAIAAAAQjdAAieiZg");
	var mask_12_graphics_190 = new cjs.Graphics().p("AmEF6QiiidAAjdIAAAAQAAjcCiidIAAAAQChicDjAAIAAAAQDkAAChCcIAAAAQCiCdAADcIAAAAQAADdiiCdIAAAAQihCcjkAAIAAAAQjjAAihicg");
	var mask_12_graphics_191 = new cjs.Graphics().p("AmOGDQiligAAjjIAAAAQAAjiCligIAAAAQCligDpAAIAAAAQDqAAClCgIAAAAQClCgAADiIAAAAQAADjilCgIAAAAQilCgjqAAIAAAAQjpAAiligg");
	var mask_12_graphics_192 = new cjs.Graphics().p("AmYGMQipikAAjoIAAAAQAAjnCpikIAAAAQCqilDuAAIAAAAQDvAACpClIAAAAQCqCkAADnIAAAAQAADoiqCkIAAAAQipCljvAAIAAAAQjuAAiqilg");
	var mask_12_graphics_193 = new cjs.Graphics().p("AmhGVQitinAAjuIAAAAQAAjtCtioIAAAAQCtioD0AAIAAAAQD1AACtCoIAAAAQCtCoAADtIAAAAQAADuitCnIAAAAQitCpj1AAIAAAAQj0AAitipg");
	var mask_12_graphics_194 = new cjs.Graphics().p("AmrGfQixisAAjzIAAAAQAAjyCxisIAAAAQCyirD5AAIAAAAQD6AACxCrIAAAAQCyCsAADyIAAAAQAADziyCsIAAAAQixCrj6AAIAAAAQj5AAiyirg");
	var mask_12_graphics_195 = new cjs.Graphics().p("Am0GoQi1iwAAj4IAAAAQAAj3C1iwIAAAAQC1ivD/AAIAAAAQEAAAC1CvIAAAAQC1CwAAD3IAAAAQAAD4i1CwIAAAAQi1CvkAAAIAAAAQj/AAi1ivg");
	var mask_12_graphics_196 = new cjs.Graphics().p("Am9GxQi5i0AAj9IAAAAQAAj8C5i0IAAAAQC5izEEAAIAAAAQEFAAC5CzIAAAAQC5C0AAD8IAAAAQAAD9i5C0IAAAAQi5CzkFAAIAAAAQkEAAi5izg");
	var mask_12_graphics_197 = new cjs.Graphics().p("AnGG5Qi9i2AAkDIAAAAQAAkCC9i3IAAAAQC8i3EKAAIAAAAQELAAC8C3IAAAAQC9C3AAECIAAAAQAAEDi9C2IAAAAQi8C4kLAAIAAAAQkKAAi8i4g");
	var mask_12_graphics_198 = new cjs.Graphics().p("AnPHCQjBi6AAkIIAAAAQAAkHDBi7IAAAAQDAi6EPAAIAAAAQEQAADAC6IAAAAQDBC7AAEHIAAAAQAAEIjBC6IAAAAQjAC7kQAAIAAAAQkPAAjAi7g");
	var mask_12_graphics_199 = new cjs.Graphics().p("AnYHLQjEi+AAkNIAAAAQAAkMDEi+IAAAAQDEi+EUAAIAAAAQEVAADEC+IAAAAQDEC+AAEMIAAAAQAAENjEC+IAAAAQjEC+kVAAIAAAAQkUAAjEi+g");
	var mask_12_graphics_200 = new cjs.Graphics().p("AnhHUQjIjCAAkSIAAAAQAAkRDIjCIAAAAQDIjBEZAAIAAAAQEaAADIDBIAAAAQDIDCAAERIAAAAQAAESjIDCIAAAAQjIDBkaAAIAAAAQkZAAjIjBg");
	var mask_12_graphics_201 = new cjs.Graphics().p("AnqHcQjLjFAAkXIAAAAQAAkWDLjFIAAAAQDMjGEeAAIAAAAQEfAADMDGIAAAAQDLDFAAEWIAAAAQAAEXjLDFIAAAAQjMDGkfAAIAAAAQkeAAjMjGg");
	var mask_12_graphics_202 = new cjs.Graphics().p("AnzHlQjOjJAAkcIAAAAQAAkbDOjJIAAAAQDPjIEkAAIAAAAQElAADODIIAAAAQDPDJAAEbIAAAAQAAEcjPDJIAAAAQjODIklAAIAAAAQkkAAjPjIg");
	var mask_12_graphics_203 = new cjs.Graphics().p("An7HtQjTjMAAkhIAAAAQAAkgDTjMIAAAAQDSjMEpAAIAAAAQEqAADSDMIAAAAQDTDMAAEgIAAAAQAAEhjTDMIAAAAQjSDMkqAAIAAAAQkpAAjSjMg");
	var mask_12_graphics_204 = new cjs.Graphics().p("AoEH1QjWjPAAkmIAAAAQAAklDWjPIAAAAQDWjQEuAAIAAAAQEvAADVDQIAAAAQDXDPAAElIAAAAQAAEmjXDPIAAAAQjVDQkvAAIAAAAQkuAAjWjQg");
	var mask_12_graphics_205 = new cjs.Graphics().p("AoMH9QjZjTAAkqIAAAAQAAkpDZjTIAAAAQDajTEyAAIAAAAQEzAADaDTIAAAAQDZDTAAEpIAAAAQAAEqjZDTIAAAAQjaDTkzAAIAAAAQkyAAjajTg");
	var mask_12_graphics_206 = new cjs.Graphics().p("AoUIFQjdjWAAkvIAAAAQAAkuDdjWIAAAAQDdjXE3AAIAAAAQE4AADdDXIAAAAQDdDWAAEuIAAAAQAAEvjdDWIAAAAQjdDXk4AAIAAAAQk3AAjdjXg");
	var mask_12_graphics_207 = new cjs.Graphics().p("AocINQjhjZAAk0IAAAAQAAkzDhjZIAAAAQDgjaE8AAIAAAAQE9AADgDaIAAAAQDhDZAAEzIAAAAQAAE0jhDZIAAAAQjgDak9AAIAAAAQk8AAjgjag");
	var mask_12_graphics_208 = new cjs.Graphics().p("AokIVQjkjdAAk4IAAAAQAAk3DkjdIAAAAQDjjdFBAAIAAAAQFCAADjDdIAAAAQDkDdAAE3IAAAAQAAE4jkDdIAAAAQjjDdlCAAIAAAAQlBAAjjjdg");
	var mask_12_graphics_209 = new cjs.Graphics().p("AosIdQjnjgAAk9IAAAAQAAk8DnjgIAAAAQDnjgFFAAIAAAAQFGAADnDgIAAAAQDnDgAAE8IAAAAQAAE9jnDgIAAAAQjnDglGAAIAAAAQlFAAjnjgg");
	var mask_12_graphics_210 = new cjs.Graphics().p("Ao0IkQjqjjAAlBIAAAAQAAlADqjjIAAAAQDqjjFKAAIAAAAQFLAADqDjIAAAAQDqDjAAFAIAAAAQAAFBjqDjIAAAAQjqDjlLAAIAAAAQlKAAjqjjg");
	var mask_12_graphics_211 = new cjs.Graphics().p("Ao8IsQjtjmAAlGIAAAAQAAlFDtjmIAAAAQDtjmFPAAIAAAAQFQAADtDmIAAAAQDtDmAAFFIAAAAQAAFGjtDmIAAAAQjtDmlQAAIAAAAQlPAAjtjmg");
	var mask_12_graphics_212 = new cjs.Graphics().p("ApEIzQjwjpAAlKIAAAAQAAlJDwjpIAAAAQDxjqFTAAIAAAAQFUAADwDqIAAAAQDxDpAAFJIAAAAQAAFKjxDpIAAAAQjwDqlUAAIAAAAQlTAAjxjqg");
	var mask_12_graphics_213 = new cjs.Graphics().p("ApLI6Qj0jsAAlOIAAAAQAAlND0jtIAAAAQD0jsFXAAIAAAAQFYAAD0DsIAAAAQD0DtAAFNIAAAAQAAFOj0DsIAAAAQj0DtlYAAIAAAAQlXAAj0jtg");
	var mask_12_graphics_214 = new cjs.Graphics().p("ApSJCQj3jwAAlSIAAAAQAAlRD3jwIAAAAQD2jvFcAAIAAAAQFdAAD2DvIAAAAQD3DwAAFRIAAAAQAAFSj3DwIAAAAQj2DvldAAIAAAAQlcAAj2jvg");
	var mask_12_graphics_215 = new cjs.Graphics().p("ApaJJQj5jzAAlWIAAAAQAAlVD5jzIAAAAQD6jyFgAAIAAAAQFhAAD5DyIAAAAQD6DzAAFVIAAAAQAAFWj6DzIAAAAQj5DylhAAIAAAAQlgAAj6jyg");
	var mask_12_graphics_216 = new cjs.Graphics().p("AphJQQj8j1AAlbIAAAAQAAlaD8j1IAAAAQD9j1FkAAIAAAAQFlAAD9D1IAAAAQD8D1AAFaIAAAAQAAFbj8D1IAAAAQj9D1llAAIAAAAQlkAAj9j1g");
	var mask_12_graphics_217 = new cjs.Graphics().p("ApoJWQj/j3AAlfIAAAAQAAleD/j4IAAAAQEAj4FoAAIAAAAQFpAAEAD4IAAAAQD/D4AAFeIAAAAQAAFfj/D3IAAAAQkAD5lpAAIAAAAQloAAkAj5g");
	var mask_12_graphics_218 = new cjs.Graphics().p("ApvJdQkCj6AAljIAAAAQAAliECj6IAAAAQEDj7FsAAIAAAAQFtAAEDD7IAAAAQECD6AAFiIAAAAQAAFjkCD6IAAAAQkDD7ltAAIAAAAQlsAAkDj7g");
	var mask_12_graphics_219 = new cjs.Graphics().p("Ap2JkQkFj+AAlmIAAAAQAAllEFj+IAAAAQEGj9FwAAIAAAAQFxAAEFD9IAAAAQEGD+AAFlIAAAAQAAFmkGD+IAAAAQkFD9lxAAIAAAAQlwAAkGj9g");
	var mask_12_graphics_220 = new cjs.Graphics().p("Ap9JqQkHkAAAlqIAAAAQAAlpEHkBIAAAAQEJkAF0AAIAAAAQF1AAEIEAIAAAAQEIEBAAFpIAAAAQAAFqkIEAIAAAAQkIEBl1AAIAAAAQl0AAkJkBg");
	var mask_12_graphics_221 = new cjs.Graphics().p("AqDJxQkLkDAAluIAAAAQAAltELkDIAAAAQELkDF4AAIAAAAQF5AAELEDIAAAAQELEDAAFtIAAAAQAAFukLEDIAAAAQkLEDl5AAIAAAAQl4AAkLkDg");
	var mask_12_graphics_222 = new cjs.Graphics().p("AqKJ3QkNkFAAlyIAAAAQAAlxENkFIAAAAQEOkGF8AAIAAAAQF9AAENEGIAAAAQEOEFAAFxIAAAAQAAFykOEFIAAAAQkNEGl9AAIAAAAQl8AAkOkGg");
	var mask_12_graphics_223 = new cjs.Graphics().p("AqQJ9QkQkIAAl1IAAAAQAAl0EQkJIAAAAQEQkHGAAAIAAAAQGBAAEQEHIAAAAQEQEJAAF0IAAAAQAAF1kQEIIAAAAQkQEImBAAIAAAAQmAAAkQkIg");
	var mask_12_graphics_224 = new cjs.Graphics().p("AqWKDQkTkKAAl5IAAAAQAAl4ETkLIAAAAQETkKGDAAIAAAAQGEAAETEKIAAAAQETELAAF4IAAAAQAAF5kTEKIAAAAQkTELmEAAIAAAAQmDAAkTkLg");
	var mask_12_graphics_225 = new cjs.Graphics().p("AqcKJQkWkNAAl8IAAAAQAAl7EWkOIAAAAQEVkNGHAAIAAAAQGIAAEVENIAAAAQEWEOAAF7IAAAAQAAF8kWENIAAAAQkVEOmIAAIAAAAQmHAAkVkOg");
	var mask_12_graphics_226 = new cjs.Graphics().p("AqjKPQkXkPAAmAIAAAAQAAl/EXkQIAAAAQEYkPGLAAIAAAAQGMAAEXEPIAAAAQEYEQAAF/IAAAAQAAGAkYEPIAAAAQkXEQmMAAIAAAAQmLAAkYkQg");
	var mask_12_graphics_227 = new cjs.Graphics().p("AqoKVQkbkSAAmDIAAAAQAAmCEbkSIAAAAQEakSGOAAIAAAAQGPAAEaESIAAAAQEbESAAGCIAAAAQAAGDkbESIAAAAQkaESmPAAIAAAAQmOAAkakSg");
	var mask_12_graphics_228 = new cjs.Graphics().p("AquKbQkdkUAAmHIAAAAQAAmGEdkUIAAAAQEdkUGRAAIAAAAQGSAAEdEUIAAAAQEdEUAAGGIAAAAQAAGHkdEUIAAAAQkdEUmSAAIAAAAQmRAAkdkUg");
	var mask_12_graphics_229 = new cjs.Graphics().p("Aq0KgQkfkWAAmKIAAAAQAAmJEfkXIAAAAQEfkWGVAAIAAAAQGWAAEfEWIAAAAQEfEXAAGJIAAAAQAAGKkfEWIAAAAQkfEXmWAAIAAAAQmVAAkfkXg");
	var mask_12_graphics_230 = new cjs.Graphics().p("Aq6KmQkhkZAAmNIAAAAQAAmMEhkZIAAAAQEikZGYAAIAAAAQGZAAEhEZIAAAAQEiEZAAGMIAAAAQAAGNkiEZIAAAAQkhEZmZAAIAAAAQmYAAkikZg");
	var mask_12_graphics_231 = new cjs.Graphics().p("Aq/KrQkkkbAAmQIAAAAQAAmPEkkbIAAAAQEkkbGbAAIAAAAQGcAAEkEbIAAAAQEkEbAAGPIAAAAQAAGQkkEbIAAAAQkkEbmcAAIAAAAQmbAAkkkbg");
	var mask_12_graphics_232 = new cjs.Graphics().p("ArFKwQklkdAAmTIAAAAQAAmSElkeIAAAAQEmkdGfAAIAAAAQGgAAElEdIAAAAQEmEeAAGSIAAAAQAAGTkmEdIAAAAQklEemgAAIAAAAQmfAAkmkeg");
	var mask_12_graphics_233 = new cjs.Graphics().p("ArKK1QkokfAAmWIAAAAQAAmVEokgIAAAAQEokfGiAAIAAAAQGjAAEoEfIAAAAQEoEgAAGVIAAAAQAAGWkoEfIAAAAQkoEgmjAAIAAAAQmiAAkokgg");
	var mask_12_graphics_234 = new cjs.Graphics().p("ArPK6QkqkhAAmZIAAAAQAAmYEqkiIAAAAQEqkhGlAAIAAAAQGmAAEqEhIAAAAQEqEiAAGYIAAAAQAAGZkqEhIAAAAQkqEimmAAIAAAAQmlAAkqkig");
	var mask_12_graphics_235 = new cjs.Graphics().p("ArUK/QkskjAAmcIAAAAQAAmbEskkIAAAAQEskjGoAAIAAAAQGpAAEsEjIAAAAQEsEkAAGbIAAAAQAAGcksEjIAAAAQksEkmpAAIAAAAQmoAAkskkg");
	var mask_12_graphics_236 = new cjs.Graphics().p("ArZLEQkuklAAmfIAAAAQAAmeEukmIAAAAQEuklGrAAIAAAAQGsAAEuElIAAAAQEuEmAAGeIAAAAQAAGfkuElIAAAAQkuEmmsAAIAAAAQmrAAkukmg");
	var mask_12_graphics_237 = new cjs.Graphics().p("AreLJQkwknAAmiIAAAAQAAmhEwknIAAAAQExkoGtAAIAAAAQGuAAExEoIAAAAQEwEnAAGhIAAAAQAAGikwEnIAAAAQkxEomuAAIAAAAQmtAAkxkog");
	var mask_12_graphics_238 = new cjs.Graphics().p("ArjLOQkykqAAmkIAAAAQAAmjEykqIAAAAQEzkpGwAAIAAAAQGxAAEzEpIAAAAQEyEqAAGjIAAAAQAAGkkyEqIAAAAQkzEpmxAAIAAAAQmwAAkzkpg");
	var mask_12_graphics_239 = new cjs.Graphics().p("AroLSQk0krAAmnIAAAAQAAmmE0ksIAAAAQE1krGzAAIAAAAQG0AAE0ErIAAAAQE1EsAAGmIAAAAQAAGnk1ErIAAAAQk0Esm0AAIAAAAQmzAAk1ksg");
	var mask_12_graphics_240 = new cjs.Graphics().p("ArsLXQk2ktAAmqIAAAAQAAmpE2ktIAAAAQE2ktG2AAIAAAAQG3AAE2EtIAAAAQE2EtAAGpIAAAAQAAGqk2EtIAAAAQk2Etm3AAIAAAAQm2AAk2ktg");
	var mask_12_graphics_241 = new cjs.Graphics().p("ArxLbQk4kvAAmsIAAAAQAAmrE4kvIAAAAQE5kvG4AAIAAAAQG5AAE4EvIAAAAQE5EvAAGrIAAAAQAAGsk5EvIAAAAQk4Evm5AAIAAAAQm4AAk5kvg");
	var mask_12_graphics_242 = new cjs.Graphics().p("Ar1LfQk6kwAAmvIAAAAQAAmuE6kxIAAAAQE6kwG7AAIAAAAQG8AAE6EwIAAAAQE6ExAAGuIAAAAQAAGvk6EwIAAAAQk6Exm8AAIAAAAQm7AAk6kxg");
	var mask_12_graphics_243 = new cjs.Graphics().p("Ar5LjQk8kyAAmxIAAAAQAAmwE8kzIAAAAQE8kyG9AAIAAAAQG+AAE8EyIAAAAQE8EzAAGwIAAAAQAAGxk8EyIAAAAQk8Ezm+AAIAAAAQm9AAk8kzg");
	var mask_12_graphics_244 = new cjs.Graphics().p("Ar9LnQk+kzAAm0IAAAAQAAmzE+k0IAAAAQE9k0HAAAIAAAAQHBAAE9E0IAAAAQE+E0AAGzIAAAAQAAG0k+EzIAAAAQk9E1nBAAIAAAAQnAAAk9k1g");
	var mask_12_graphics_245 = new cjs.Graphics().p("AsBLrQk/k1AAm2IAAAAQAAm1E/k2IAAAAQE/k1HCAAIAAAAQHDAAE/E1IAAAAQE/E2AAG1IAAAAQAAG2k/E1IAAAAQk/E2nDAAIAAAAQnCAAk/k2g");
	var mask_12_graphics_246 = new cjs.Graphics().p("AsFLvQlBk3AAm4IAAAAQAAm3FBk4IAAAAQFAk3HFAAIAAAAQHGAAFAE3IAAAAQFBE4AAG3IAAAAQAAG4lBE3IAAAAQlAE4nGAAIAAAAQnFAAlAk4g");
	var mask_12_graphics_247 = new cjs.Graphics().p("AsJLzQlDk5AAm6IAAAAQAAm5FDk5IAAAAQFCk5HHAAIAAAAQHIAAFCE5IAAAAQFDE5AAG5IAAAAQAAG6lDE5IAAAAQlCE5nIAAIAAAAQnHAAlCk5g");
	var mask_12_graphics_248 = new cjs.Graphics().p("AsNL3QlEk7AAm8IAAAAQAAm7FEk7IAAAAQFEk6HJAAIAAAAQHKAAFEE6IAAAAQFEE7AAG7IAAAAQAAG8lEE7IAAAAQlEE6nKAAIAAAAQnJAAlEk6g");
	var mask_12_graphics_249 = new cjs.Graphics().p("AsRL6QlFk7AAm/IAAAAQAAm+FFk8IAAAAQFGk7HLAAIAAAAQHMAAFFE7IAAAAQFGE8AAG+IAAAAQAAG/lGE7IAAAAQlFE8nMAAIAAAAQnLAAlGk8g");
	var mask_12_graphics_250 = new cjs.Graphics().p("AsUL+QlHk9AAnBIAAAAQAAnAFHk9IAAAAQFHk9HNAAIAAAAQHOAAFHE9IAAAAQFHE9AAHAIAAAAQAAHBlHE9IAAAAQlHE9nOAAIAAAAQnNAAlHk9g");
	var mask_12_graphics_251 = new cjs.Graphics().p("AsYMBQlIk+AAnDIAAAAQAAnCFIk+IAAAAQFJk/HPAAIAAAAQHQAAFJE/IAAAAQFIE+AAHCIAAAAQAAHDlIE+IAAAAQlJE/nQAAIAAAAQnPAAlJk/g");
	var mask_12_graphics_252 = new cjs.Graphics().p("AsbMEQlKlAAAnEIAAAAQAAnEFKlAIAAAAQFKlAHRAAIAAAAQHSAAFKFAIAAAAQFKFAAAHEIAAAAQAAHElKFAIAAAAQlKFBnSAAIAAAAQnRAAlKlBg");
	var mask_12_graphics_253 = new cjs.Graphics().p("AsfMIQlLlCAAnGIAAAAQAAnFFLlCIAAAAQFMlBHTAAIAAAAQHUAAFLFBIAAAAQFMFCAAHFIAAAAQAAHGlMFCIAAAAQlLFBnUAAIAAAAQnTAAlMlBg");
	var mask_12_graphics_254 = new cjs.Graphics().p("AsiMLQlMlDAAnIIAAAAQAAnHFMlDIAAAAQFNlDHVAAIAAAAQHWAAFMFDIAAAAQFNFDAAHHIAAAAQAAHIlNFDIAAAAQlMFDnWAAIAAAAQnVAAlNlDg");
	var mask_12_graphics_255 = new cjs.Graphics().p("AslMOQlOlEAAnKIAAAAQAAnJFOlEIAAAAQFOlEHXAAIAAAAQHYAAFOFEIAAAAQFOFEAAHJIAAAAQAAHKlOFEIAAAAQlOFEnYAAIAAAAQnXAAlOlEg");
	var mask_12_graphics_256 = new cjs.Graphics().p("AsoMRQlPlFAAnMIAAAAQAAnLFPlFIAAAAQFPlFHZAAIAAAAQHaAAFPFFIAAAAQFPFFAAHLIAAAAQAAHMlPFFIAAAAQlPFFnaAAIAAAAQnZAAlPlFg");
	var mask_12_graphics_257 = new cjs.Graphics().p("AsrMUQlQlHAAnNIAAAAQAAnMFQlHIAAAAQFRlGHaAAIAAAAQHbAAFRFGIAAAAQFQFHAAHMIAAAAQAAHNlQFHIAAAAQlRFGnbAAIAAAAQnaAAlRlGg");
	var mask_12_graphics_258 = new cjs.Graphics().p("AsuMWQlRlHAAnPIAAAAQAAnOFRlIIAAAAQFSlHHcAAIAAAAQHdAAFRFHIAAAAQFSFIAAHOIAAAAQAAHPlSFHIAAAAQlRFIndAAIAAAAQncAAlSlIg");
	var mask_12_graphics_259 = new cjs.Graphics().p("AsxMZQlSlIAAnRIAAAAQAAnQFSlIIAAAAQFTlJHeAAIAAAAQHfAAFSFJIAAAAQFTFIAAHQIAAAAQAAHRlTFIIAAAAQlSFJnfAAIAAAAQneAAlTlJg");
	var mask_12_graphics_260 = new cjs.Graphics().p("AszMcQlUlKAAnSIAAAAQAAnRFUlKIAAAAQFUlJHfgBIAAAAQHgABFUFJIAAAAQFUFKAAHRIAAAAQAAHSlUFKIAAAAQlUFKngAAIAAAAQnfAAlUlKg");
	var mask_12_graphics_261 = new cjs.Graphics().p("As2MeQlUlKAAnUIAAAAQAAnTFUlLIAAAAQFVlKHhAAIAAAAQHiAAFUFKIAAAAQFVFLAAHTIAAAAQAAHUlVFKIAAAAQlUFLniAAIAAAAQnhAAlVlLg");
	var mask_12_graphics_262 = new cjs.Graphics().p("As4MhQlWlMAAnVIAAAAQAAnUFWlMIAAAAQFWlMHiAAIAAAAQHjAAFWFMIAAAAQFWFMAAHUIAAAAQAAHVlWFMIAAAAQlWFMnjAAIAAAAQniAAlWlMg");
	var mask_12_graphics_263 = new cjs.Graphics().p("As7MjQlWlNAAnWIAAAAQAAnVFWlNIAAAAQFXlNHkAAIAAAAQHlAAFWFNIAAAAQFXFNAAHVIAAAAQAAHWlXFNIAAAAQlWFNnlAAIAAAAQnkAAlXlNg");
	var mask_12_graphics_264 = new cjs.Graphics().p("As9MlQlYlNAAnYIAAAAQAAnXFYlOIAAAAQFYlNHlAAIAAAAQHmAAFYFNIAAAAQFYFOAAHXIAAAAQAAHYlYFNIAAAAQlYFOnmAAIAAAAQnlAAlYlOg");
	var mask_12_graphics_265 = new cjs.Graphics().p("As/MnQlZlOAAnZIAAAAQAAnYFZlPIAAAAQFZlOHmAAIAAAAQHnAAFZFOIAAAAQFZFPAAHYIAAAAQAAHZlZFOIAAAAQlZFPnnAAIAAAAQnmAAlZlPg");
	var mask_12_graphics_266 = new cjs.Graphics().p("AtCMqQlZlQAAnaIAAAAQAAnZFZlQIAAAAQFalPHoAAIAAAAQHpAAFZFPIAAAAQFaFQAAHZIAAAAQAAHalaFQIAAAAQlZFPnpAAIAAAAQnoAAlalPg");
	var mask_12_graphics_267 = new cjs.Graphics().p("AtEMsQlalRAAnbIAAAAQAAnaFalRIAAAAQFblQHpAAIAAAAQHqAAFaFQIAAAAQFbFRAAHaIAAAAQAAHblbFRIAAAAQlaFQnqAAIAAAAQnpAAlblQg");
	var mask_12_graphics_268 = new cjs.Graphics().p("AtGMuQlblRAAndIAAAAQAAncFblRIAAAAQFclRHqAAIAAAAQHrAAFbFRIAAAAQFcFRAAHcIAAAAQAAHdlcFRIAAAAQlbFRnrAAIAAAAQnqAAlclRg");
	var mask_12_graphics_269 = new cjs.Graphics().p("AtIMvQlclRAAneIAAAAQAAndFclSIAAAAQFdlRHrAAIAAAAQHsAAFcFRIAAAAQFdFSAAHdIAAAAQAAHeldFRIAAAAQlcFSnsAAIAAAAQnrAAldlSg");
	var mask_12_graphics_270 = new cjs.Graphics().p("AtKMxQlclSAAnfIAAAAQAAneFclTIAAAAQFelSHsAAIAAAAQHtAAFdFSIAAAAQFdFTAAHeIAAAAQAAHfldFSIAAAAQldFTntAAIAAAAQnsAAlelTg");

	this.timeline.addTween(cjs.Tween.get(mask_12).to({graphics:null,x:0,y:0}).wait(154).to({graphics:mask_12_graphics_154,x:369.8001,y:350.05}).wait(1).to({graphics:mask_12_graphics_155,x:369.9482,y:349.1788}).wait(1).to({graphics:mask_12_graphics_156,x:370.0971,y:348.3018}).wait(1).to({graphics:mask_12_graphics_157,x:370.2465,y:347.4211}).wait(1).to({graphics:mask_12_graphics_158,x:370.3968,y:346.5355}).wait(1).to({graphics:mask_12_graphics_159,x:370.5475,y:345.6463}).wait(1).to({graphics:mask_12_graphics_160,x:370.6992,y:344.7531}).wait(1).to({graphics:mask_12_graphics_161,x:370.8517,y:343.8562}).wait(1).to({graphics:mask_12_graphics_162,x:371.0038,y:342.9571}).wait(1).to({graphics:mask_12_graphics_163,x:371.1568,y:342.0553}).wait(1).to({graphics:mask_12_graphics_164,x:371.3107,y:341.1513}).wait(1).to({graphics:mask_12_graphics_165,x:371.4642,y:340.245}).wait(1).to({graphics:mask_12_graphics_166,x:371.6185,y:339.3373}).wait(1).to({graphics:mask_12_graphics_167,x:371.7724,y:338.4288}).wait(1).to({graphics:mask_12_graphics_168,x:371.9272,y:337.5193}).wait(1).to({graphics:mask_12_graphics_169,x:372.0811,y:336.6099}).wait(1).to({graphics:mask_12_graphics_170,x:372.2359,y:335.6995}).wait(1).to({graphics:mask_12_graphics_171,x:372.3903,y:334.7901}).wait(1).to({graphics:mask_12_graphics_172,x:372.5446,y:333.8815}).wait(1).to({graphics:mask_12_graphics_173,x:372.6981,y:332.9734}).wait(1).to({graphics:mask_12_graphics_174,x:372.852,y:332.0676}).wait(1).to({graphics:mask_12_graphics_175,x:373.0059,y:331.1626}).wait(1).to({graphics:mask_12_graphics_176,x:373.1589,y:330.2604}).wait(1).to({graphics:mask_12_graphics_177,x:373.3114,y:329.3604}).wait(1).to({graphics:mask_12_graphics_178,x:373.464,y:328.4635}).wait(1).to({graphics:mask_12_graphics_179,x:373.6156,y:327.5694}).wait(1).to({graphics:mask_12_graphics_180,x:373.7668,y:326.6793}).wait(1).to({graphics:mask_12_graphics_181,x:373.9171,y:325.7928}).wait(1).to({graphics:mask_12_graphics_182,x:374.067,y:324.9108}).wait(1).to({graphics:mask_12_graphics_183,x:374.2159,y:324.0324}).wait(1).to({graphics:mask_12_graphics_184,x:374.364,y:323.1598}).wait(1).to({graphics:mask_12_graphics_185,x:374.5116,y:322.2918}).wait(1).to({graphics:mask_12_graphics_186,x:374.6579,y:321.4287}).wait(1).to({graphics:mask_12_graphics_187,x:374.8032,y:320.5719}).wait(1).to({graphics:mask_12_graphics_188,x:374.9476,y:319.7209}).wait(1).to({graphics:mask_12_graphics_189,x:375.0912,y:318.8758}).wait(1).to({graphics:mask_12_graphics_190,x:375.2338,y:318.0375}).wait(1).to({graphics:mask_12_graphics_191,x:375.3747,y:317.2054}).wait(1).to({graphics:mask_12_graphics_192,x:375.5151,y:316.3801}).wait(1).to({graphics:mask_12_graphics_193,x:375.6537,y:315.5625}).wait(1).to({graphics:mask_12_graphics_194,x:375.7914,y:314.752}).wait(1).to({graphics:mask_12_graphics_195,x:375.9277,y:313.9488}).wait(1).to({graphics:mask_12_graphics_196,x:376.0623,y:313.1532}).wait(1).to({graphics:mask_12_graphics_197,x:376.196,y:312.3652}).wait(1).to({graphics:mask_12_graphics_198,x:376.3287,y:311.5858}).wait(1).to({graphics:mask_12_graphics_199,x:376.4597,y:310.8145}).wait(1).to({graphics:mask_12_graphics_200,x:376.5892,y:310.0509}).wait(1).to({graphics:mask_12_graphics_201,x:376.7171,y:309.2967}).wait(1).to({graphics:mask_12_graphics_202,x:376.8439,y:308.5501}).wait(1).to({graphics:mask_12_graphics_203,x:376.9686,y:307.813}).wait(1).to({graphics:mask_12_graphics_204,x:377.0923,y:307.0845}).wait(1).to({graphics:mask_12_graphics_205,x:377.2148,y:306.3645}).wait(1).to({graphics:mask_12_graphics_206,x:377.3349,y:305.6539}).wait(1).to({graphics:mask_12_graphics_207,x:377.4546,y:304.9524}).wait(1).to({graphics:mask_12_graphics_208,x:377.5716,y:304.2603}).wait(1).to({graphics:mask_12_graphics_209,x:377.6877,y:303.5772}).wait(1).to({graphics:mask_12_graphics_210,x:377.802,y:302.904}).wait(1).to({graphics:mask_12_graphics_211,x:377.9149,y:302.2393}).wait(1).to({graphics:mask_12_graphics_212,x:378.0261,y:301.5841}).wait(1).to({graphics:mask_12_graphics_213,x:378.1354,y:300.9389}).wait(1).to({graphics:mask_12_graphics_214,x:378.2439,y:300.303}).wait(1).to({graphics:mask_12_graphics_215,x:378.3501,y:299.6761}).wait(1).to({graphics:mask_12_graphics_216,x:378.4549,y:299.0592}).wait(1).to({graphics:mask_12_graphics_217,x:378.5575,y:298.4517}).wait(1).to({graphics:mask_12_graphics_218,x:378.6592,y:297.8536}).wait(1).to({graphics:mask_12_graphics_219,x:378.7591,y:297.2655}).wait(1).to({graphics:mask_12_graphics_220,x:378.8573,y:296.6868}).wait(1).to({graphics:mask_12_graphics_221,x:378.954,y:296.118}).wait(1).to({graphics:mask_12_graphics_222,x:379.049,y:295.5582}).wait(1).to({graphics:mask_12_graphics_223,x:379.1421,y:295.0083}).wait(1).to({graphics:mask_12_graphics_224,x:379.2339,y:294.4674}).wait(1).to({graphics:mask_12_graphics_225,x:379.3239,y:293.936}).wait(1).to({graphics:mask_12_graphics_226,x:379.4126,y:293.4144}).wait(1).to({graphics:mask_12_graphics_227,x:379.4994,y:292.9023}).wait(1).to({graphics:mask_12_graphics_228,x:379.5849,y:292.3996}).wait(1).to({graphics:mask_12_graphics_229,x:379.6686,y:291.906}).wait(1).to({graphics:mask_12_graphics_230,x:379.7505,y:291.4223}).wait(1).to({graphics:mask_12_graphics_231,x:379.8315,y:290.9471}).wait(1).to({graphics:mask_12_graphics_232,x:379.9107,y:290.4817}).wait(1).to({graphics:mask_12_graphics_233,x:379.9877,y:290.0254}).wait(1).to({graphics:mask_12_graphics_234,x:380.0637,y:289.5781}).wait(1).to({graphics:mask_12_graphics_235,x:380.1379,y:289.1403}).wait(1).to({graphics:mask_12_graphics_236,x:380.2108,y:288.7105}).wait(1).to({graphics:mask_12_graphics_237,x:380.2824,y:288.2907}).wait(1).to({graphics:mask_12_graphics_238,x:380.3521,y:287.8794}).wait(1).to({graphics:mask_12_graphics_239,x:380.4205,y:287.4771}).wait(1).to({graphics:mask_12_graphics_240,x:380.4872,y:287.0838}).wait(1).to({graphics:mask_12_graphics_241,x:380.5524,y:286.6986}).wait(1).to({graphics:mask_12_graphics_242,x:380.6163,y:286.3228}).wait(1).to({graphics:mask_12_graphics_243,x:380.6788,y:285.9552}).wait(1).to({graphics:mask_12_graphics_244,x:380.7396,y:285.5961}).wait(1).to({graphics:mask_12_graphics_245,x:380.799,y:285.2455}).wait(1).to({graphics:mask_12_graphics_246,x:380.857,y:284.9035}).wait(1).to({graphics:mask_12_graphics_247,x:380.9137,y:284.5701}).wait(1).to({graphics:mask_12_graphics_248,x:380.9691,y:284.2447}).wait(1).to({graphics:mask_12_graphics_249,x:381.0226,y:283.9275}).wait(1).to({graphics:mask_12_graphics_250,x:381.0753,y:283.6188}).wait(1).to({graphics:mask_12_graphics_251,x:381.1261,y:283.3177}).wait(1).to({graphics:mask_12_graphics_252,x:381.1761,y:283.0253}).wait(1).to({graphics:mask_12_graphics_253,x:381.2242,y:282.7399}).wait(1).to({graphics:mask_12_graphics_254,x:381.2715,y:282.4627}).wait(1).to({graphics:mask_12_graphics_255,x:381.3169,y:282.1936}).wait(1).to({graphics:mask_12_graphics_256,x:381.3615,y:281.9322}).wait(1).to({graphics:mask_12_graphics_257,x:381.4042,y:281.6784}).wait(1).to({graphics:mask_12_graphics_258,x:381.4461,y:281.4327}).wait(1).to({graphics:mask_12_graphics_259,x:381.487,y:281.1942}).wait(1).to({graphics:mask_12_graphics_260,x:381.5257,y:280.9629}).wait(1).to({graphics:mask_12_graphics_261,x:381.564,y:280.7392}).wait(1).to({graphics:mask_12_graphics_262,x:381.6004,y:280.5228}).wait(1).to({graphics:mask_12_graphics_263,x:381.636,y:280.3135}).wait(1).to({graphics:mask_12_graphics_264,x:381.6702,y:280.1119}).wait(1).to({graphics:mask_12_graphics_265,x:381.7035,y:279.9166}).wait(1).to({graphics:mask_12_graphics_266,x:381.7355,y:279.7294}).wait(1).to({graphics:mask_12_graphics_267,x:381.766,y:279.5485}).wait(1).to({graphics:mask_12_graphics_268,x:381.7957,y:279.3748}).wait(1).to({graphics:mask_12_graphics_269,x:381.8241,y:279.2079}).wait(1).to({graphics:mask_12_graphics_270,x:381.6616,y:278.856}).wait(540));

	// Layer_22
	this.instance_19 = new lib.Tween51("synched",0);
	this.instance_19.setTransform(382.15,276.25);
	this.instance_19.alpha = 0.5;
	this.instance_19._off = true;

	this.instance_20 = new lib.Tween52("synched",0);
	this.instance_20.setTransform(382.15,276.25);

	var maskedShapeInstanceList = [this.instance_19,this.instance_20];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_12;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_19}]},154).to({state:[{t:this.instance_20}]},116).wait(540));
	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(154).to({_off:false},0).to({_off:true,alpha:1},116).wait(540));

	// Layer_8
	this.instance_21 = new lib.Tween18("synched",2);
	this.instance_21.setTransform(773.8,433.85,0.6872,0.6872,0,0,0,472.2,518.1);
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(154).to({_off:false},0).wait(656));

	// Layer_6 (mask)
	var mask_13 = new cjs.Shape();
	mask_13._off = true;
	var mask_13_graphics_175 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_13_graphics_176 = new cjs.Graphics().p("AgjAjQgPgPAAgUIAAAAQAAgTAPgPIAAAAQAPgOAUAAIAAAAQAVAAAPAOIAAAAQAPAPAAATIAAAAQAAAUgPAPIAAAAQgPAOgVAAIAAAAQgUAAgPgOg");
	var mask_13_graphics_177 = new cjs.Graphics().p("Ag2A1QgXgWAAgfIAAAAQAAgeAXgWIAAAAQAXgWAfAAIAAAAQAgAAAXAWIAAAAQAXAWAAAeIAAAAQAAAfgXAWIAAAAQgXAWggAAIAAAAQgfAAgXgWg");
	var mask_13_graphics_178 = new cjs.Graphics().p("AhKBHQgegdAAgqIAAAAQAAgpAegdIAAAAQAfgeArAAIAAAAQAsAAAfAeIAAAAQAeAdAAApIAAAAQAAAqgeAdIAAAAQgfAegsAAIAAAAQgrAAgfgeg");
	var mask_13_graphics_179 = new cjs.Graphics().p("AhdBaQgnglAAg1IAAAAQAAg0AnglIAAAAQAnglA2AAIAAAAQA3AAAnAlIAAAAQAnAlAAA0IAAAAQAAA1gnAlIAAAAQgnAlg3AAIAAAAQg2AAgnglg");
	var mask_13_graphics_180 = new cjs.Graphics().p("AhxBtQgvgtAAhAIAAAAQAAg/AvgtIAAAAQAwgtBBAAIAAAAQBCAAAwAtIAAAAQAvAtAAA/IAAAAQAABAgvAtIAAAAQgwAthCAAIAAAAQhBAAgwgtg");
	var mask_13_graphics_181 = new cjs.Graphics().p("AiECAQg3g1AAhLIAAAAQAAhKA3g1IAAAAQA3g0BNAAIAAAAQBOAAA3A0IAAAAQA3A1AABKIAAAAQAABLg3A1IAAAAQg3A0hOAAIAAAAQhNAAg3g0g");
	var mask_13_graphics_182 = new cjs.Graphics().p("AiYCSQg/g8AAhWIAAAAQAAhVA/g8IAAAAQA/g9BZAAIAAAAQBaAAA/A9IAAAAQA/A8AABVIAAAAQAABWg/A8IAAAAQg/A9haAAIAAAAQhZAAg/g9g");
	var mask_13_graphics_183 = new cjs.Graphics().p("AisClQhHhEAAhhIAAAAQAAhgBHhEIAAAAQBIhFBkAAIAAAAQBlAABHBFIAAAAQBIBEAABgIAAAAQAABhhIBEIAAAAQhHBFhlAAIAAAAQhkAAhIhFg");
	var mask_13_graphics_184 = new cjs.Graphics().p("Ai/C4QhQhMAAhsIAAAAQAAhrBQhMIAAAAQBPhMBwAAIAAAAQBxAABPBMIAAAAQBQBMAABrIAAAAQAABshQBMIAAAAQhPBMhxAAIAAAAQhwAAhPhMg");
	var mask_13_graphics_185 = new cjs.Graphics().p("AjTDLQhYhUAAh3IAAAAQAAh2BYhUIAAAAQBYhUB7AAIAAAAQB8AABYBUIAAAAQBYBUAAB2IAAAAQAAB3hYBUIAAAAQhYBUh8AAIAAAAQh7AAhYhUg");
	var mask_13_graphics_186 = new cjs.Graphics().p("AjmDeQhghcAAiCIAAAAQAAiBBghcIAAAAQBfhcCHAAIAAAAQCHAABgBcIAAAAQBgBcAACBIAAAAQAACChgBcIAAAAQhgBciHAAIAAAAQiHAAhfhcg");
	var mask_13_graphics_187 = new cjs.Graphics().p("Aj6DwQhohjAAiNIAAAAQAAiMBohjIAAAAQBohkCSAAIAAAAQCTAABoBkIAAAAQBoBjAACMIAAAAQAACNhoBjIAAAAQhoBkiTAAIAAAAQiSAAhohkg");
	var mask_13_graphics_188 = new cjs.Graphics().p("AkNEDQhwhrAAiYIAAAAQAAiXBwhrIAAAAQBwhrCdAAIAAAAQCeAABwBrIAAAAQBwBrAACXIAAAAQAACYhwBrIAAAAQhwBrieAAIAAAAQidAAhwhrg");
	var mask_13_graphics_189 = new cjs.Graphics().p("AkgEVQh4hzAAiiIAAAAQAAihB4hzIAAAAQB4hzCoAAIAAAAQCpAAB4BzIAAAAQB4BzAAChIAAAAQAACih4BzIAAAAQh4BzipAAIAAAAQioAAh4hzg");
	var mask_13_graphics_190 = new cjs.Graphics().p("AkzEnQiAh6AAitIAAAAQAAisCAh6IAAAAQCAh7CzAAIAAAAQC1AAB/B7IAAAAQCAB6AACsIAAAAQAACtiAB6IAAAAQh/B7i1AAIAAAAQizAAiAh7g");
	var mask_13_graphics_191 = new cjs.Graphics().p("AlGE5QiHiCAAi3IAAAAQAAi2CHiCIAAAAQCIiCC+AAIAAAAQC/AACICCIAAAAQCHCCAAC2IAAAAQAAC3iHCCIAAAAQiICCi/AAIAAAAQi+AAiIiCg");
	var mask_13_graphics_192 = new cjs.Graphics().p("AlYFLQiPiJAAjCIAAAAQAAjBCPiJIAAAAQCPiJDJAAIAAAAQDKAACPCJIAAAAQCPCJAADBIAAAAQAADCiPCJIAAAAQiPCJjKAAIAAAAQjJAAiPiJg");
	var mask_13_graphics_193 = new cjs.Graphics().p("AlrFcQiWiQAAjMIAAAAQAAjLCWiQIAAAAQCXiRDUAAIAAAAQDVAACXCRIAAAAQCWCQAADLIAAAAQAADMiWCQIAAAAQiXCRjVAAIAAAAQjUAAiXiRg");
	var mask_13_graphics_194 = new cjs.Graphics().p("Al9FtQieiXAAjWIAAAAQAAjVCeiYIAAAAQCfiXDeAAIAAAAQDfAACeCXIAAAAQCfCYAADVIAAAAQAADWifCXIAAAAQieCYjfAAIAAAAQjeAAifiYg");
	var mask_13_graphics_195 = new cjs.Graphics().p("AmOF+QimieAAjgIAAAAQAAjfCmifIAAAAQClieDpAAIAAAAQDqAAClCeIAAAAQCmCfAADfIAAAAQAADgimCeIAAAAQilCfjqAAIAAAAQjpAAilifg");
	var mask_13_graphics_196 = new cjs.Graphics().p("AmgGPQisilAAjqIAAAAQAAjpCsilIAAAAQCtilDzAAIAAAAQD0AACsClIAAAAQCtClAADpIAAAAQAADqitClIAAAAQisClj0AAIAAAAQjzAAitilg");
	var mask_13_graphics_197 = new cjs.Graphics().p("AmxGfQizisAAjzIAAAAQAAjyCzisIAAAAQC0isD9AAIAAAAQD+AACzCsIAAAAQC0CsAADyIAAAAQAADzi0CsIAAAAQizCsj+AAIAAAAQj9AAi0isg");
	var mask_13_graphics_198 = new cjs.Graphics().p("AnBGvQi6iyAAj9IAAAAQAAj8C6iyIAAAAQC6izEHAAIAAAAQEIAAC6CzIAAAAQC6CyAAD8IAAAAQAAD9i6CyIAAAAQi6CzkIAAIAAAAQkHAAi6izg");
	var mask_13_graphics_199 = new cjs.Graphics().p("AnRG/QjBi5AAkGIAAAAQAAkFDBi5IAAAAQDBi5EQAAIAAAAQERAADBC5IAAAAQDBC5AAEFIAAAAQAAEGjBC5IAAAAQjBC5kRAAIAAAAQkQAAjBi5g");
	var mask_13_graphics_200 = new cjs.Graphics().p("AnhHOQjIi/AAkPIAAAAQAAkODIi/IAAAAQDIi/EZAAIAAAAQEaAADIC/IAAAAQDIC/AAEOIAAAAQAAEPjIC/IAAAAQjIC/kaAAIAAAAQkZAAjIi/g");
	var mask_13_graphics_201 = new cjs.Graphics().p("AnxHdQjOjGAAkXIAAAAQAAkWDOjGIAAAAQDPjFEiAAIAAAAQEjAADPDFIAAAAQDODGAAEWIAAAAQAAEXjODGIAAAAQjPDFkjAAIAAAAQkiAAjPjFg");
	var mask_13_graphics_202 = new cjs.Graphics().p("AoAHrQjUjLAAkgIAAAAQAAkfDUjLIAAAAQDVjMErAAIAAAAQEsAADVDMIAAAAQDUDLAAEfIAAAAQAAEgjUDLIAAAAQjVDMksAAIAAAAQkrAAjVjMg");
	var mask_13_graphics_203 = new cjs.Graphics().p("AoPH5QjajRAAkoIAAAAQAAknDajSIAAAAQDbjRE0AAIAAAAQE1AADaDRIAAAAQDbDSAAEnIAAAAQAAEojbDRIAAAAQjaDSk1AAIAAAAQk0AAjbjSg");
	var mask_13_graphics_204 = new cjs.Graphics().p("AodIHQjgjXAAkwIAAAAQAAkvDgjXIAAAAQDhjXE8AAIAAAAQE9AADhDXIAAAAQDgDXAAEvIAAAAQAAEwjgDXIAAAAQjhDXk9AAIAAAAQk8AAjhjXg");
	var mask_13_graphics_205 = new cjs.Graphics().p("AorIUQjmjcAAk4IAAAAQAAk3DmjdIAAAAQDnjcFEAAIAAAAQFFAADmDcIAAAAQDnDdAAE3IAAAAQAAE4jnDcIAAAAQjmDdlFAAIAAAAQlEAAjnjdg");
	var mask_13_graphics_206 = new cjs.Graphics().p("Ao4IhQjsjiAAk/IAAAAQAAk+DsjiIAAAAQDsjiFMAAIAAAAQFNAADsDiIAAAAQDsDiAAE+IAAAAQAAE/jsDiIAAAAQjsDilNAAIAAAAQlMAAjsjig");
	var mask_13_graphics_207 = new cjs.Graphics().p("ApFIuQjxjnAAlHIAAAAQAAlGDxjnIAAAAQDxjnFUAAIAAAAQFVAADxDnIAAAAQDxDnAAFGIAAAAQAAFHjxDnIAAAAQjxDnlVAAIAAAAQlUAAjxjng");
	var mask_13_graphics_208 = new cjs.Graphics().p("ApSI6Qj2jsAAlOIAAAAQAAlND2jsIAAAAQD3jsFbAAIAAAAQFcAAD3DsIAAAAQD2DsAAFNIAAAAQAAFOj2DsIAAAAQj3DslcAAIAAAAQlbAAj3jsg");
	var mask_13_graphics_209 = new cjs.Graphics().p("ApeJFQj7jwAAlVIAAAAQAAlUD7jxIAAAAQD7jxFjAAIAAAAQFkAAD7DxIAAAAQD7DxAAFUIAAAAQAAFVj7DwIAAAAQj7DylkAAIAAAAQljAAj7jyg");
	var mask_13_graphics_210 = new cjs.Graphics().p("ApqJRQkAj2AAlbIAAAAQAAlaEAj2IAAAAQEBj2FpAAIAAAAQFqAAEBD2IAAAAQEAD2AAFaIAAAAQAAFbkAD2IAAAAQkBD2lqAAIAAAAQlpAAkBj2g");
	var mask_13_graphics_211 = new cjs.Graphics().p("Ap1JcQkFj6AAliIAAAAQAAlhEFj6IAAAAQEFj6FwAAIAAAAQFxAAEFD6IAAAAQEFD6AAFhIAAAAQAAFikFD6IAAAAQkFD6lxAAIAAAAQlwAAkFj6g");
	var mask_13_graphics_212 = new cjs.Graphics().p("AqAJmQkKj+AAloIAAAAQAAlnEKj/IAAAAQEJj+F3AAIAAAAQF4AAEJD+IAAAAQEKD/AAFnIAAAAQAAFokKD+IAAAAQkJD/l4AAIAAAAQl3AAkJj/g");
	var mask_13_graphics_213 = new cjs.Graphics().p("AqLJwQkOkCAAluIAAAAQAAltEOkDIAAAAQEOkCF9AAIAAAAQF+AAEOECIAAAAQEOEDAAFtIAAAAQAAFukOECIAAAAQkOEDl+AAIAAAAQl9AAkOkDg");
	var mask_13_graphics_214 = new cjs.Graphics().p("AqVJ6QkSkGAAl0IAAAAQAAlzESkHIAAAAQESkGGDAAIAAAAQGEAAESEGIAAAAQESEHAAFzIAAAAQAAF0kSEGIAAAAQkSEHmEAAIAAAAQmDAAkSkHg");
	var mask_13_graphics_215 = new cjs.Graphics().p("AqfKEQkWkLAAl5IAAAAQAAl4EWkLIAAAAQEWkKGJAAIAAAAQGKAAEWEKIAAAAQEWELAAF4IAAAAQAAF5kWELIAAAAQkWEKmKAAIAAAAQmJAAkWkKg");
	var mask_13_graphics_216 = new cjs.Graphics().p("AqoKNQkakPAAl+IAAAAQAAl9EakPIAAAAQEakOGOAAIAAAAQGPAAEaEOIAAAAQEaEPAAF9IAAAAQAAF+kaEPIAAAAQkaEOmPAAIAAAAQmOAAkakOg");
	var mask_13_graphics_217 = new cjs.Graphics().p("AqxKVQkekSAAmDIAAAAQAAmCEekTIAAAAQEekRGTAAIAAAAQGUAAEeERIAAAAQEeETAAGCIAAAAQAAGDkeESIAAAAQkeESmUAAIAAAAQmTAAkekSg");
	var mask_13_graphics_218 = new cjs.Graphics().p("Aq6KeQkhkWAAmIIAAAAQAAmHEhkWIAAAAQEikVGYAAIAAAAQGZAAEiEVIAAAAQEhEWAAGHIAAAAQAAGIkhEWIAAAAQkiEVmZAAIAAAAQmYAAkikVg");
	var mask_13_graphics_219 = new cjs.Graphics().p("ArCKlQklkYAAmNIAAAAQAAmMElkZIAAAAQElkYGdAAIAAAAQGeAAElEYIAAAAQElEZAAGMIAAAAQAAGNklEYIAAAAQklEZmeAAIAAAAQmdAAklkZg");
	var mask_13_graphics_220 = new cjs.Graphics().p("ArKKtQkokcAAmRIAAAAQAAmQEokcIAAAAQEokcGiAAIAAAAQGjAAEoEcIAAAAQEoEcAAGQIAAAAQAAGRkoEcIAAAAQkoEcmjAAIAAAAQmiAAkokcg");
	var mask_13_graphics_221 = new cjs.Graphics().p("ArSK0QkrkeAAmWIAAAAQAAmVErkfIAAAAQEskeGmAAIAAAAQGnAAErEeIAAAAQEsEfAAGVIAAAAQAAGWksEeIAAAAQkrEfmnAAIAAAAQmmAAkskfg");
	var mask_13_graphics_222 = new cjs.Graphics().p("ArZK7QkukhAAmaIAAAAQAAmZEukhIAAAAQEvkiGqAAIAAAAQGrAAEvEiIAAAAQEuEhAAGZIAAAAQAAGakuEhIAAAAQkvEimrAAIAAAAQmqAAkvkig");
	var mask_13_graphics_223 = new cjs.Graphics().p("ArgLCQkxklAAmdIAAAAQAAmcExklIAAAAQEykkGuAAIAAAAQGvAAExEkIAAAAQEyElAAGcIAAAAQAAGdkyElIAAAAQkxEkmvAAIAAAAQmuAAkykkg");
	var mask_13_graphics_224 = new cjs.Graphics().p("ArmLIQk0knAAmhIAAAAQAAmgE0knIAAAAQE0knGyAAIAAAAQGzAAE0EnIAAAAQE0EnAAGgIAAAAQAAGhk0EnIAAAAQk0EnmzAAIAAAAQmyAAk0kng");
	var mask_13_graphics_225 = new cjs.Graphics().p("ArsLOQk2kqAAmkIAAAAQAAmjE2kqIAAAAQE2kpG2AAIAAAAQG3AAE2EpIAAAAQE2EqAAGjIAAAAQAAGkk2EqIAAAAQk2Epm3AAIAAAAQm2AAk2kpg");
	var mask_13_graphics_226 = new cjs.Graphics().p("AryLTQk5krAAmoIAAAAQAAmnE5krIAAAAQE5ksG5AAIAAAAQG6AAE5EsIAAAAQE5ErAAGnIAAAAQAAGok5ErIAAAAQk5Esm6AAIAAAAQm5AAk5ksg");
	var mask_13_graphics_227 = new cjs.Graphics().p("Ar3LYQk7ktAAmrIAAAAQAAmqE7kuIAAAAQE7ktG8AAIAAAAQG9AAE7EtIAAAAQE7EuAAGqIAAAAQAAGrk7EtIAAAAQk7Eum9AAIAAAAQm8AAk7kug");
	var mask_13_graphics_228 = new cjs.Graphics().p("Ar9LdQk8kvAAmuIAAAAQAAmtE8kwIAAAAQE+kvG/AAIAAAAQHAAAE9EvIAAAAQE9EwAAGtIAAAAQAAGuk9EvIAAAAQk9EwnAAAIAAAAQm/AAk+kwg");
	var mask_13_graphics_229 = new cjs.Graphics().p("AsBLiQk/kyAAmwIAAAAQAAmvE/kyIAAAAQE/kyHCAAIAAAAQHDAAE/EyIAAAAQE/EyAAGvIAAAAQAAGwk/EyIAAAAQk/EynDAAIAAAAQnCAAk/kyg");
	var mask_13_graphics_230 = new cjs.Graphics().p("AsGLmQlBkzAAmzIAAAAQAAmyFBkzIAAAAQFBk0HFAAIAAAAQHGAAFAE0IAAAAQFCEzAAGyIAAAAQAAGzlCEzIAAAAQlAE0nGAAIAAAAQnFAAlBk0g");
	var mask_13_graphics_231 = new cjs.Graphics().p("AsKLqQlCk1AAm1IAAAAQAAm0FCk1IAAAAQFDk1HHAAIAAAAQHIAAFDE1IAAAAQFCE1AAG0IAAAAQAAG1lCE1IAAAAQlDE1nIAAIAAAAQnHAAlDk1g");
	var mask_13_graphics_232 = new cjs.Graphics().p("AsOLuQlEk3AAm3IAAAAQAAm2FEk3IAAAAQFFk3HJAAIAAAAQHKAAFEE3IAAAAQFFE3AAG2IAAAAQAAG3lFE3IAAAAQlEE3nKAAIAAAAQnJAAlFk3g");
	var mask_13_graphics_233 = new cjs.Graphics().p("AsRLxQlGk4AAm5IAAAAQAAm4FGk5IAAAAQFFk3HMAAIAAAAQHNAAFFE3IAAAAQFGE5AAG4IAAAAQAAG5lGE4IAAAAQlFE4nNAAIAAAAQnMAAlFk4g");
	var mask_13_graphics_234 = new cjs.Graphics().p("AsVL0QlHk5AAm7IAAAAQAAm6FHk6IAAAAQFIk5HNAAIAAAAQHOAAFHE5IAAAAQFIE6AAG6IAAAAQAAG7lIE5IAAAAQlHE6nOAAIAAAAQnNAAlIk6g");
	var mask_13_graphics_235 = new cjs.Graphics().p("AsYL3QlIk6AAm9IAAAAQAAm8FIk7IAAAAQFJk6HPAAIAAAAQHQAAFIE6IAAAAQFJE7AAG8IAAAAQAAG9lJE6IAAAAQlIE7nQAAIAAAAQnPAAlJk7g");
	var mask_13_graphics_236 = new cjs.Graphics().p("AsaL6QlKk8AAm+IAAAAQAAm9FKk8IAAAAQFJk8HRAAIAAAAQHSAAFJE8IAAAAQFKE8AAG9IAAAAQAAG+lKE8IAAAAQlJE8nSAAIAAAAQnRAAlJk8g");
	var mask_13_graphics_237 = new cjs.Graphics().p("AsdL8QlKk8AAnAIAAAAQAAm/FKk8IAAAAQFLk9HSAAIAAAAQHTAAFKE9IAAAAQFLE8AAG/IAAAAQAAHAlLE8IAAAAQlKE9nTAAIAAAAQnSAAlLk9g");
	var mask_13_graphics_238 = new cjs.Graphics().p("AsfL+QlLk9AAnBIAAAAQAAnAFLk9IAAAAQFMk+HTAAIAAAAQHUAAFME+IAAAAQFLE9AAHAIAAAAQAAHBlLE9IAAAAQlME+nUAAIAAAAQnTAAlMk+g");
	var mask_13_graphics_239 = new cjs.Graphics().p("AshMAQlMk+AAnCIAAAAQAAnBFMk+IAAAAQFMk+HVAAIAAAAQHWAAFLE+IAAAAQFNE+AAHBIAAAAQAAHClNE+IAAAAQlLE+nWAAIAAAAQnVAAlMk+g");
	var mask_13_graphics_240 = new cjs.Graphics().p("AsiMCQlNk/AAnDIAAAAQAAnCFNk/IAAAAQFNk/HVAAIAAAAQHWAAFNE/IAAAAQFNE/AAHCIAAAAQAAHDlNE/IAAAAQlNE/nWAAIAAAAQnVAAlNk/g");
	var mask_13_graphics_241 = new cjs.Graphics().p("AskMDQlNk/AAnEIAAAAQAAnDFNk/IAAAAQFOk/HWAAIAAAAQHXAAFNE/IAAAAQFOE/AAHDIAAAAQAAHElOE/IAAAAQlNE/nXAAIAAAAQnWAAlOk/g");
	var mask_13_graphics_242 = new cjs.Graphics().p("AslMEQlOlAAAnEIAAAAQAAnDFOlAIAAAAQFOlAHXAAIAAAAQHYAAFOFAIAAAAQFOFAAAHDIAAAAQAAHElOFAIAAAAQlOFAnYAAIAAAAQnXAAlOlAg");

	this.timeline.addTween(cjs.Tween.get(mask_13).to({graphics:null,x:0,y:0}).wait(175).to({graphics:mask_13_graphics_175,x:773.3002,y:433.6002}).wait(1).to({graphics:mask_13_graphics_176,x:773.6674,y:432.8752}).wait(1).to({graphics:mask_13_graphics_177,x:774.0392,y:432.1427}).wait(1).to({graphics:mask_13_graphics_178,x:774.414,y:431.4033}).wait(1).to({graphics:mask_13_graphics_179,x:774.7915,y:430.6585}).wait(1).to({graphics:mask_13_graphics_180,x:775.1713,y:429.9097}).wait(1).to({graphics:mask_13_graphics_181,x:775.5525,y:429.1578}).wait(1).to({graphics:mask_13_graphics_182,x:775.935,y:428.4036}).wait(1).to({graphics:mask_13_graphics_183,x:776.3175,y:427.6489}).wait(1).to({graphics:mask_13_graphics_184,x:776.7,y:426.8947}).wait(1).to({graphics:mask_13_graphics_185,x:777.0816,y:426.1423}).wait(1).to({graphics:mask_13_graphics_186,x:777.4614,y:425.3931}).wait(1).to({graphics:mask_13_graphics_187,x:777.8389,y:424.6479}).wait(1).to({graphics:mask_13_graphics_188,x:778.2147,y:423.9076}).wait(1).to({graphics:mask_13_graphics_189,x:778.5864,y:423.1746}).wait(1).to({graphics:mask_13_graphics_190,x:778.9545,y:422.4478}).wait(1).to({graphics:mask_13_graphics_191,x:779.3185,y:421.7301}).wait(1).to({graphics:mask_13_graphics_192,x:779.6776,y:421.0213}).wait(1).to({graphics:mask_13_graphics_193,x:780.0322,y:420.323}).wait(1).to({graphics:mask_13_graphics_194,x:780.3806,y:419.6358}).wait(1).to({graphics:mask_13_graphics_195,x:780.7234,y:418.9599}).wait(1).to({graphics:mask_13_graphics_196,x:781.0596,y:418.2966}).wait(1).to({graphics:mask_13_graphics_197,x:781.389,y:417.6459}).wait(1).to({graphics:mask_13_graphics_198,x:781.7121,y:417.0092}).wait(1).to({graphics:mask_13_graphics_199,x:782.028,y:416.3864}).wait(1).to({graphics:mask_13_graphics_200,x:782.3367,y:415.7775}).wait(1).to({graphics:mask_13_graphics_201,x:782.6378,y:415.1844}).wait(1).to({graphics:mask_13_graphics_202,x:782.9311,y:414.6052}).wait(1).to({graphics:mask_13_graphics_203,x:783.2164,y:414.0423}).wait(1).to({graphics:mask_13_graphics_204,x:783.4941,y:413.4942}).wait(1).to({graphics:mask_13_graphics_205,x:783.7641,y:412.9623}).wait(1).to({graphics:mask_13_graphics_206,x:784.026,y:412.4457}).wait(1).to({graphics:mask_13_graphics_207,x:784.2798,y:411.9449}).wait(1).to({graphics:mask_13_graphics_208,x:784.5255,y:411.4606}).wait(1).to({graphics:mask_13_graphics_209,x:784.7631,y:410.9913}).wait(1).to({graphics:mask_13_graphics_210,x:784.993,y:410.5386}).wait(1).to({graphics:mask_13_graphics_211,x:785.2149,y:410.1012}).wait(1).to({graphics:mask_13_graphics_212,x:785.4286,y:409.6791}).wait(1).to({graphics:mask_13_graphics_213,x:785.6348,y:409.2728}).wait(1).to({graphics:mask_13_graphics_214,x:785.8327,y:408.8822}).wait(1).to({graphics:mask_13_graphics_215,x:786.0231,y:408.5064}).wait(1).to({graphics:mask_13_graphics_216,x:786.2058,y:408.1455}).wait(1).to({graphics:mask_13_graphics_217,x:786.3813,y:407.7999}).wait(1).to({graphics:mask_13_graphics_218,x:786.5491,y:407.4687}).wait(1).to({graphics:mask_13_graphics_219,x:786.7098,y:407.1528}).wait(1).to({graphics:mask_13_graphics_220,x:786.8628,y:406.8504}).wait(1).to({graphics:mask_13_graphics_221,x:787.009,y:406.562}).wait(1).to({graphics:mask_13_graphics_222,x:787.1481,y:406.2879}).wait(1).to({graphics:mask_13_graphics_223,x:787.2804,y:406.0273}).wait(1).to({graphics:mask_13_graphics_224,x:787.4055,y:405.7803}).wait(1).to({graphics:mask_13_graphics_225,x:787.5238,y:405.5463}).wait(1).to({graphics:mask_13_graphics_226,x:787.6364,y:405.3253}).wait(1).to({graphics:mask_13_graphics_227,x:787.7416,y:405.1165}).wait(1).to({graphics:mask_13_graphics_228,x:787.8411,y:404.9212}).wait(1).to({graphics:mask_13_graphics_229,x:787.9338,y:404.7377}).wait(1).to({graphics:mask_13_graphics_230,x:788.0211,y:404.5657}).wait(1).to({graphics:mask_13_graphics_231,x:788.1021,y:404.4064}).wait(1).to({graphics:mask_13_graphics_232,x:788.1772,y:404.2589}).wait(1).to({graphics:mask_13_graphics_233,x:788.2461,y:404.1216}).wait(1).to({graphics:mask_13_graphics_234,x:788.3095,y:403.9969}).wait(1).to({graphics:mask_13_graphics_235,x:788.368,y:403.8822}).wait(1).to({graphics:mask_13_graphics_236,x:788.4203,y:403.7787}).wait(1).to({graphics:mask_13_graphics_237,x:788.4675,y:403.6855}).wait(1).to({graphics:mask_13_graphics_238,x:788.5098,y:403.6027}).wait(1).to({graphics:mask_13_graphics_239,x:788.5462,y:403.5303}).wait(1).to({graphics:mask_13_graphics_240,x:788.5782,y:403.4673}).wait(1).to({graphics:mask_13_graphics_241,x:788.6052,y:403.4146}).wait(1).to({graphics:mask_13_graphics_242,x:788.0112,y:402.7558}).wait(568));

	// Layer_15
	this.instance_22 = new lib.Tween32("synched",0);
	this.instance_22.setTransform(787.7,408.95);
	this.instance_22.alpha = 0.5;
	this.instance_22._off = true;

	this.instance_23 = new lib.Tween33("synched",0);
	this.instance_23.setTransform(787.7,408.95);

	var maskedShapeInstanceList = [this.instance_22,this.instance_23];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_13;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_22}]},175).to({state:[{t:this.instance_23}]},67).wait(568));
	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(175).to({_off:false},0).to({_off:true,alpha:1},67).wait(568));

	// Layer_8
	this.instance_24 = new lib.Tween18("synched",2);
	this.instance_24.setTransform(140.6,426.65,0.7336,0.7336,0,0,0,471.9,518);
	this.instance_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(232).to({_off:false},0).wait(578));

	// Layer_6 (mask)
	var mask_14 = new cjs.Shape();
	mask_14._off = true;
	var mask_14_graphics_232 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_14_graphics_233 = new cjs.Graphics().p("AgfAfQgNgNAAgSIAAAAQAAgRANgNIAAAAQANgNASAAIAAAAQATAAANANIAAAAQANANAAARIAAAAQAAASgNANIAAAAQgNANgTAAIAAAAQgSAAgNgNg");
	var mask_14_graphics_234 = new cjs.Graphics().p("AguAtQgTgTAAgaIAAAAQAAgZATgTIAAAAQAUgTAaAAIAAAAQAbAAAUATIAAAAQATATAAAZIAAAAQAAAagTATIAAAAQgUATgbAAIAAAAQgaAAgUgTg");
	var mask_14_graphics_235 = new cjs.Graphics().p("Ag9A8QgZgZAAgjIAAAAQAAgiAZgZIAAAAQAagYAjAAIAAAAQAkAAAaAYIAAAAQAZAZAAAiIAAAAQAAAjgZAZIAAAAQgaAYgkAAIAAAAQgjAAgagYg");
	var mask_14_graphics_236 = new cjs.Graphics().p("AhMBKQgfgfAAgrIAAAAQAAgqAfgfIAAAAQAggfAsAAIAAAAQAtAAAgAfIAAAAQAfAfAAAqIAAAAQAAArgfAfIAAAAQggAfgtAAIAAAAQgsAAgggfg");
	var mask_14_graphics_237 = new cjs.Graphics().p("AhbBZQgmglAAg0IAAAAQAAgzAmglIAAAAQAmglA1AAIAAAAQA2AAAmAlIAAAAQAmAlAAAzIAAAAQAAA0gmAlIAAAAQgmAlg2AAIAAAAQg1AAgmglg");
	var mask_14_graphics_238 = new cjs.Graphics().p("AhqBnQgsgqAAg9IAAAAQAAg8AsgqIAAAAQAsgrA+AAIAAAAQA/AAAsArIAAAAQAsAqAAA8IAAAAQAAA9gsAqIAAAAQgsArg/AAIAAAAQg+AAgsgrg");
	var mask_14_graphics_239 = new cjs.Graphics().p("Ah5B2QgygxAAhFIAAAAQAAhEAygxIAAAAQAzgxBGAAIAAAAQBHAAAzAxIAAAAQAyAxAABEIAAAAQAABFgyAxIAAAAQgzAxhHAAIAAAAQhGAAgzgxg");
	var mask_14_graphics_240 = new cjs.Graphics().p("AiICFQg5g3AAhOIAAAAQAAhNA5g3IAAAAQA5g3BPAAIAAAAQBQAAA5A3IAAAAQA5A3AABNIAAAAQAABOg5A3IAAAAQg5A3hQAAIAAAAQhPAAg5g3g");
	var mask_14_graphics_241 = new cjs.Graphics().p("AiXCUQg/g+AAhWIAAAAQAAhVA/g+IAAAAQA/g9BYAAIAAAAQBZAAA/A9IAAAAQA/A+AABVIAAAAQAABWg/A+IAAAAQg/A9hZAAIAAAAQhYAAg/g9g");
	var mask_14_graphics_242 = new cjs.Graphics().p("AinCiQhFhDAAhfIAAAAQAAheBFhEIAAAAQBGhDBhAAIAAAAQBiAABGBDIAAAAQBFBEAABeIAAAAQAABfhFBDIAAAAQhGBEhiAAIAAAAQhhAAhGhEg");
	var mask_14_graphics_243 = new cjs.Graphics().p("Ai2CxQhMhJAAhoIAAAAQAAhnBMhJIAAAAQBMhKBqAAIAAAAQBrAABMBKIAAAAQBMBJAABnIAAAAQAABohMBJIAAAAQhMBKhrAAIAAAAQhqAAhMhKg");
	var mask_14_graphics_244 = new cjs.Graphics().p("AjFDAQhShPAAhxIAAAAQAAhwBShPIAAAAQBShQBzAAIAAAAQB0AABSBQIAAAAQBSBPAABwIAAAAQAABxhSBPIAAAAQhSBQh0AAIAAAAQhzAAhShQg");
	var mask_14_graphics_245 = new cjs.Graphics().p("AjVDPQhYhWAAh5IAAAAQAAh4BYhWIAAAAQBZhWB8AAIAAAAQB9AABZBWIAAAAQBYBWAAB4IAAAAQAAB5hYBWIAAAAQhZBWh9AAIAAAAQh8AAhZhWg");
	var mask_14_graphics_246 = new cjs.Graphics().p("AjkDeQhfhcAAiCIAAAAQAAiBBfhcIAAAAQBfhcCFAAIAAAAQCGAABfBcIAAAAQBfBcAACBIAAAAQAACChfBcIAAAAQhfBciGAAIAAAAQiFAAhfhcg");
	var mask_14_graphics_247 = new cjs.Graphics().p("AjzDtQhmhiAAiLIAAAAQAAiKBmhiIAAAAQBlhiCOAAIAAAAQCPAABlBiIAAAAQBmBiAACKIAAAAQAACLhmBiIAAAAQhlBiiPAAIAAAAQiOAAhlhig");
	var mask_14_graphics_248 = new cjs.Graphics().p("AkDD8QhrhoAAiUIAAAAQAAiTBrhoIAAAAQBshoCXAAIAAAAQCYAABsBoIAAAAQBrBoAACTIAAAAQAACUhrBoIAAAAQhsBoiYAAIAAAAQiXAAhshog");
	var mask_14_graphics_249 = new cjs.Graphics().p("AkSELQhyhvAAicIAAAAQAAibByhvIAAAAQByhuCgAAIAAAAQChAAByBuIAAAAQByBvAACbIAAAAQAACchyBvIAAAAQhyBuihAAIAAAAQigAAhyhug");
	var mask_14_graphics_250 = new cjs.Graphics().p("AkiEaQh4h1AAilIAAAAQAAikB4h1IAAAAQB5h0CpAAIAAAAQCqAAB4B0IAAAAQB5B1AACkIAAAAQAAClh5B1IAAAAQh4B0iqAAIAAAAQipAAh5h0g");
	var mask_14_graphics_251 = new cjs.Graphics().p("AkxEpQh+h7AAiuIAAAAQAAitB+h7IAAAAQB/h6CyAAIAAAAQCzAAB/B6IAAAAQB+B7AACtIAAAAQAACuh+B7IAAAAQh/B6izAAIAAAAQiyAAh/h6g");
	var mask_14_graphics_252 = new cjs.Graphics().p("AlAE3QiFiBAAi2IAAAAQAAi1CFiCIAAAAQCFiAC7AAIAAAAQC8AACFCAIAAAAQCFCCAAC1IAAAAQAAC2iFCBIAAAAQiFCBi8AAIAAAAQi7AAiFiBg");
	var mask_14_graphics_253 = new cjs.Graphics().p("AlPFGQiMiHAAi/IAAAAQAAi+CMiHIAAAAQCLiHDEAAIAAAAQDFAACLCHIAAAAQCMCHAAC+IAAAAQAAC/iMCHIAAAAQiLCHjFAAIAAAAQjEAAiLiHg");
	var mask_14_graphics_254 = new cjs.Graphics().p("AlfFVQiRiNAAjIIAAAAQAAjHCRiNIAAAAQCSiNDNAAIAAAAQDOAACSCNIAAAAQCRCNAADHIAAAAQAADIiRCNIAAAAQiSCNjOAAIAAAAQjNAAiSiNg");
	var mask_14_graphics_255 = new cjs.Graphics().p("AluFkQiYiUAAjQIAAAAQAAjPCYiUIAAAAQCYiTDWAAIAAAAQDXAACYCTIAAAAQCYCUAADPIAAAAQAADQiYCUIAAAAQiYCTjXAAIAAAAQjWAAiYiTg");
	var mask_14_graphics_256 = new cjs.Graphics().p("Al9FyQieiZAAjZIAAAAQAAjYCeiaIAAAAQCeiZDfAAIAAAAQDgAACeCZIAAAAQCeCaAADYIAAAAQAADZieCZIAAAAQieCajgAAIAAAAQjfAAieiag");
	var mask_14_graphics_257 = new cjs.Graphics().p("AmMGBQilifAAjiIAAAAQAAjhClifIAAAAQCkigDoAAIAAAAQDpAACkCgIAAAAQClCfAADhIAAAAQAADiilCfIAAAAQikCgjpAAIAAAAQjoAAikigg");
	var mask_14_graphics_258 = new cjs.Graphics().p("AmbGQQirimAAjqIAAAAQAAjpCrimIAAAAQCrilDwAAIAAAAQDxAACrClIAAAAQCrCmAADpIAAAAQAADqirCmIAAAAQirCljxAAIAAAAQjwAAirilg");
	var mask_14_graphics_259 = new cjs.Graphics().p("AmqGeQixirAAjzIAAAAQAAjyCxirIAAAAQCxisD5AAIAAAAQD6AACxCsIAAAAQCxCrAADyIAAAAQAADzixCrIAAAAQixCsj6AAIAAAAQj5AAixisg");
	var mask_14_graphics_260 = new cjs.Graphics().p("Am5GtQi3iyAAj7IAAAAQAAj6C3iyIAAAAQC3ixECAAIAAAAQEDAAC3CxIAAAAQC3CyAAD6IAAAAQAAD7i3CyIAAAAQi3CxkDAAIAAAAQkCAAi3ixg");
	var mask_14_graphics_261 = new cjs.Graphics().p("AnIG7Qi9i3AAkEIAAAAQAAkDC9i3IAAAAQC9i4ELAAIAAAAQEMAAC9C4IAAAAQC9C3AAEDIAAAAQAAEEi9C3IAAAAQi9C4kMAAIAAAAQkLAAi9i4g");
	var mask_14_graphics_262 = new cjs.Graphics().p("AnXHJQjDi9AAkMIAAAAQAAkLDDi+IAAAAQDEi9ETAAIAAAAQEUAADDC9IAAAAQDEC+AAELIAAAAQAAEMjEC9IAAAAQjDC+kUAAIAAAAQkTAAjEi+g");
	var mask_14_graphics_263 = new cjs.Graphics().p("AnlHYQjKjEAAkUIAAAAQAAkTDKjEIAAAAQDJjDEcAAIAAAAQEdAADJDDIAAAAQDKDEAAETIAAAAQAAEUjKDEIAAAAQjJDDkdAAIAAAAQkcAAjJjDg");
	var mask_14_graphics_264 = new cjs.Graphics().p("An0HmQjPjJAAkdIAAAAQAAkcDPjJIAAAAQDQjJEkAAIAAAAQElAADQDJIAAAAQDPDJAAEcIAAAAQAAEdjPDJIAAAAQjQDJklAAIAAAAQkkAAjQjJg");
	var mask_14_graphics_265 = new cjs.Graphics().p("AoCH0QjWjPAAklIAAAAQAAkkDWjPIAAAAQDVjPEtAAIAAAAQEuAADVDPIAAAAQDWDPAAEkIAAAAQAAEljWDPIAAAAQjVDPkuAAIAAAAQktAAjVjPg");
	var mask_14_graphics_266 = new cjs.Graphics().p("AoRICQjbjVAAktIAAAAQAAksDbjVIAAAAQDcjVE1AAIAAAAQE2AADcDVIAAAAQDbDVAAEsIAAAAQAAEtjbDVIAAAAQjcDVk2AAIAAAAQk1AAjcjVg");
	var mask_14_graphics_267 = new cjs.Graphics().p("AofIQQjhjbAAk1IAAAAQAAk0DhjbIAAAAQDhjaE+AAIAAAAQE/AADhDaIAAAAQDhDbAAE0IAAAAQAAE1jhDbIAAAAQjhDak/AAIAAAAQk+AAjhjag");
	var mask_14_graphics_268 = new cjs.Graphics().p("AotIdQjnjgAAk9IAAAAQAAk8DnjhIAAAAQDnjgFGAAIAAAAQFHAADnDgIAAAAQDnDhAAE8IAAAAQAAE9jnDgIAAAAQjnDhlHAAIAAAAQlGAAjnjhg");
	var mask_14_graphics_269 = new cjs.Graphics().p("Ao7IrQjtjmAAlFIAAAAQAAlEDtjmIAAAAQDtjmFOAAIAAAAQFPAADtDmIAAAAQDtDmAAFEIAAAAQAAFFjtDmIAAAAQjtDmlPAAIAAAAQlOAAjtjmg");
	var mask_14_graphics_270 = new cjs.Graphics().p("ApJI5QjzjsAAlNIAAAAQAAlMDzjsIAAAAQDzjrFWAAIAAAAQFXAADzDrIAAAAQDzDsAAFMIAAAAQAAFNjzDsIAAAAQjzDrlXAAIAAAAQlWAAjzjrg");
	var mask_14_graphics_271 = new cjs.Graphics().p("ApXJGQj4jxAAlVIAAAAQAAlUD4jxIAAAAQD5jxFeAAIAAAAQFfAAD5DxIAAAAQD4DxAAFUIAAAAQAAFVj4DxIAAAAQj5DxlfAAIAAAAQleAAj5jxg");
	var mask_14_graphics_272 = new cjs.Graphics().p("AplJTQj+j2AAldIAAAAQAAlcD+j3IAAAAQD/j2FmAAIAAAAQFnAAD+D2IAAAAQD/D3AAFcIAAAAQAAFdj/D2IAAAAQj+D3lnAAIAAAAQlmAAj/j3g");
	var mask_14_graphics_273 = new cjs.Graphics().p("ApyJgQkEj8AAlkIAAAAQAAljEEj9IAAAAQEEj8FuAAIAAAAQFvAAEED8IAAAAQEED9AAFjIAAAAQAAFkkED8IAAAAQkED9lvAAIAAAAQluAAkEj9g");
	var mask_14_graphics_274 = new cjs.Graphics().p("AqAJtQkJkBAAlsIAAAAQAAlrEJkCIAAAAQEKkBF2AAIAAAAQF3AAEJEBIAAAAQEKECAAFrIAAAAQAAFskKEBIAAAAQkJECl3AAIAAAAQl2AAkKkCg");
	var mask_14_graphics_275 = new cjs.Graphics().p("AqNJ6QkPkGAAl0IAAAAQAAlzEPkHIAAAAQEPkGF+AAIAAAAQF/AAEPEGIAAAAQEPEHAAFzIAAAAQAAF0kPEGIAAAAQkPEHl/AAIAAAAQl+AAkPkHg");
	var mask_14_graphics_276 = new cjs.Graphics().p("AqaKHQkUkMAAl7IAAAAQAAl6EUkMIAAAAQEUkMGGAAIAAAAQGHAAEUEMIAAAAQEUEMAAF6IAAAAQAAF7kUEMIAAAAQkUEMmHAAIAAAAQmGAAkUkMg");
	var mask_14_graphics_277 = new cjs.Graphics().p("AqnKUQkakRAAmDIAAAAQAAmCEakRIAAAAQEakRGNAAIAAAAQGOAAEaERIAAAAQEaERAAGCIAAAAQAAGDkaERIAAAAQkaERmOAAIAAAAQmNAAkakRg");
	var mask_14_graphics_278 = new cjs.Graphics().p("Aq0KgQkfkWAAmKIAAAAQAAmJEfkXIAAAAQEfkWGVAAIAAAAQGWAAEfEWIAAAAQEfEXAAGJIAAAAQAAGKkfEWIAAAAQkfEXmWAAIAAAAQmVAAkfkXg");
	var mask_14_graphics_279 = new cjs.Graphics().p("ArBKtQkkkcAAmRIAAAAQAAmQEkkcIAAAAQElkcGcAAIAAAAQGdAAElEcIAAAAQEkEcAAGQIAAAAQAAGRkkEcIAAAAQklEcmdAAIAAAAQmcAAklkcg");
	var mask_14_graphics_280 = new cjs.Graphics().p("ArOK5QkpkhAAmYIAAAAQAAmXEpkhIAAAAQEqkhGkAAIAAAAQGlAAEpEhIAAAAQEqEhAAGXIAAAAQAAGYkqEhIAAAAQkpEhmlAAIAAAAQmkAAkqkhg");
	var mask_14_graphics_281 = new cjs.Graphics().p("AraLFQkvkmAAmfIAAAAQAAmeEvkmIAAAAQEvkmGrAAIAAAAQGsAAEvEmIAAAAQEvEmAAGeIAAAAQAAGfkvEmIAAAAQkvEmmsAAIAAAAQmrAAkvkmg");
	var mask_14_graphics_282 = new cjs.Graphics().p("ArmLRQk0krAAmmIAAAAQAAmlE0krIAAAAQE0krGyAAIAAAAQGzAAE0ErIAAAAQE0ErAAGlIAAAAQAAGmk0ErIAAAAQk0ErmzAAIAAAAQmyAAk0krg");
	var mask_14_graphics_283 = new cjs.Graphics().p("ArzLdQk4kwAAmtIAAAAQAAmsE4kwIAAAAQE6kwG5AAIAAAAQG6AAE5EwIAAAAQE5EwAAGsIAAAAQAAGtk5EwIAAAAQk5Ewm6AAIAAAAQm5AAk6kwg");
	var mask_14_graphics_284 = new cjs.Graphics().p("Ar/LoQk9k0AAm0IAAAAQAAmzE9k1IAAAAQE/k0HAAAIAAAAQHBAAE+E0IAAAAQE+E1AAGzIAAAAQAAG0k+E0IAAAAQk+E1nBAAIAAAAQnAAAk/k1g");
	var mask_14_graphics_285 = new cjs.Graphics().p("AsKL0QlDk5AAm7IAAAAQAAm6FDk5IAAAAQFDk5HHAAIAAAAQHIAAFDE5IAAAAQFDE5AAG6IAAAAQAAG7lDE5IAAAAQlDE5nIAAIAAAAQnHAAlDk5g");
	var mask_14_graphics_286 = new cjs.Graphics().p("AsWL/QlIk+AAnBIAAAAQAAnAFIk/IAAAAQFIk9HOAAIAAAAQHPAAFIE9IAAAAQFIE/AAHAIAAAAQAAHBlIE+IAAAAQlIE+nPAAIAAAAQnOAAlIk+g");
	var mask_14_graphics_287 = new cjs.Graphics().p("AsiMKQlMlCAAnIIAAAAQAAnHFMlDIAAAAQFNlCHVAAIAAAAQHWAAFMFCIAAAAQFNFDAAHHIAAAAQAAHIlNFCIAAAAQlMFDnWAAIAAAAQnVAAlNlDg");
	var mask_14_graphics_288 = new cjs.Graphics().p("AstMVQlRlGAAnPIAAAAQAAnOFRlHIAAAAQFRlHHcAAIAAAAQHdAAFRFHIAAAAQFRFHAAHOIAAAAQAAHPlRFGIAAAAQlRFIndAAIAAAAQncAAlRlIg");
	var mask_14_graphics_289 = new cjs.Graphics().p("As4MgQlWlLAAnVIAAAAQAAnUFWlMIAAAAQFWlLHiAAIAAAAQHjAAFWFLIAAAAQFWFMAAHUIAAAAQAAHVlWFLIAAAAQlWFMnjAAIAAAAQniAAlWlMg");
	var mask_14_graphics_290 = new cjs.Graphics().p("AtDMrQlalQAAnbIAAAAQAAnaFalQIAAAAQFalQHpAAIAAAAQHqAAFaFQIAAAAQFaFQAAHaIAAAAQAAHblaFQIAAAAQlaFQnqAAIAAAAQnpAAlalQg");
	var mask_14_graphics_291 = new cjs.Graphics().p("AtOM2QlflVAAnhIAAAAQAAngFflVIAAAAQFflUHvAAIAAAAQHwAAFfFUIAAAAQFfFVAAHgIAAAAQAAHhlfFVIAAAAQlfFUnwAAIAAAAQnvAAlflUg");
	var mask_14_graphics_292 = new cjs.Graphics().p("AtZNAQljlYAAnoIAAAAQAAnnFjlZIAAAAQFklYH1AAIAAAAQH2AAFkFYIAAAAQFjFZAAHnIAAAAQAAHoljFYIAAAAQlkFZn2AAIAAAAQn1AAlklZg");
	var mask_14_graphics_293 = new cjs.Graphics().p("AtkNKQlnlcAAnuIAAAAQAAntFnldIAAAAQFoldH8AAIAAAAQH9AAFnFdIAAAAQFoFdAAHtIAAAAQAAHuloFcIAAAAQlnFen9AAIAAAAQn8AAloleg");
	var mask_14_graphics_294 = new cjs.Graphics().p("AtuNUQlslhAAnzIAAAAQAAnyFsliIAAAAQFslhICAAIAAAAQIDAAFsFhIAAAAQFsFiAAHyIAAAAQAAHzlsFhIAAAAQlsFioDAAIAAAAQoCAAlslig");
	var mask_14_graphics_295 = new cjs.Graphics().p("At4NeQlwllAAn5IAAAAQAAn4FwlmIAAAAQFwllIIAAIAAAAQIJAAFwFlIAAAAQFwFmAAH4IAAAAQAAH5lwFlIAAAAQlwFmoJAAIAAAAQoIAAlwlmg");
	var mask_14_graphics_296 = new cjs.Graphics().p("AuCNoQl1lpAAn/IAAAAQAAn+F1lqIAAAAQF0lpIOAAIAAAAQIPAAF0FpIAAAAQF1FqAAH+IAAAAQAAH/l1FpIAAAAQl0FqoPAAIAAAAQoOAAl0lqg");
	var mask_14_graphics_297 = new cjs.Graphics().p("AuMNyQl5ltAAoFIAAAAQAAoEF5ltIAAAAQF5luITAAIAAAAQIUAAF5FuIAAAAQF5FtAAIEIAAAAQAAIFl5FtIAAAAQl5FuoUAAIAAAAQoTAAl5lug");
	var mask_14_graphics_298 = new cjs.Graphics().p("AuWN7Ql8lxAAoKIAAAAQAAoJF8lyIAAAAQF9lxIZAAIAAAAQIaAAF9FxIAAAAQF8FyAAIJIAAAAQAAIKl8FxIAAAAQl9FyoaAAIAAAAQoZAAl9lyg");
	var mask_14_graphics_299 = new cjs.Graphics().p("AugOFQmAl1AAoQIAAAAQAAoPGAl1IAAAAQGBl1IfAAIAAAAQIgAAGAF1IAAAAQGBF1AAIPIAAAAQAAIQmBF1IAAAAQmAF1ogAAIAAAAQofAAmBl1g");
	var mask_14_graphics_300 = new cjs.Graphics().p("AupOOQmEl5AAoVIAAAAQAAoUGEl5IAAAAQGFl5IkAAIAAAAQIlAAGFF5IAAAAQGEF5AAIUIAAAAQAAIVmEF5IAAAAQmFF5olAAIAAAAQokAAmFl5g");
	var mask_14_graphics_301 = new cjs.Graphics().p("AuyOXQmJl9AAoaIAAAAQAAoZGJl9IAAAAQGIl9IqAAIAAAAQIrAAGIF9IAAAAQGJF9AAIZIAAAAQAAIamJF9IAAAAQmIF9orAAIAAAAQoqAAmIl9g");
	var mask_14_graphics_302 = new cjs.Graphics().p("Au8OgQmMmAAAogIAAAAQAAofGMmAIAAAAQGNmAIvAAIAAAAQIwAAGMGAIAAAAQGNGAAAIfIAAAAQAAIgmNGAIAAAAQmMGAowAAIAAAAQovAAmNmAg");
	var mask_14_graphics_303 = new cjs.Graphics().p("AvFOoQmPmDAAolIAAAAQAAokGPmEIAAAAQGRmEI0AAIAAAAQI1AAGQGEIAAAAQGQGEAAIkIAAAAQAAIlmQGDIAAAAQmQGFo1AAIAAAAQo0AAmRmFg");
	var mask_14_graphics_304 = new cjs.Graphics().p("AvNOxQmUmHAAoqIAAAAQAAopGUmIIAAAAQGTmHI6AAIAAAAQI7AAGTGHIAAAAQGUGIAAIpIAAAAQAAIqmUGHIAAAAQmTGIo7AAIAAAAQo6AAmTmIg");
	var mask_14_graphics_305 = new cjs.Graphics().p("AvWO5QmXmKAAovIAAAAQAAouGXmLIAAAAQGXmLI/AAIAAAAQJAAAGXGLIAAAAQGXGLAAIuIAAAAQAAIvmXGKIAAAAQmXGMpAAAIAAAAQo/AAmXmMg");
	var mask_14_graphics_306 = new cjs.Graphics().p("AvfPCQmamPAAozIAAAAQAAoyGamPIAAAAQGbmOJEAAIAAAAQJFAAGaGOIAAAAQGbGPAAIyIAAAAQAAIzmbGPIAAAAQmaGOpFAAIAAAAQpEAAmbmOg");
	var mask_14_graphics_307 = new cjs.Graphics().p("AvnPKQmemSAAo4IAAAAQAAo3GemSIAAAAQGfmSJIAAIAAAAQJJAAGeGSIAAAAQGfGSAAI3IAAAAQAAI4mfGSIAAAAQmeGSpJAAIAAAAQpIAAmfmSg");
	var mask_14_graphics_308 = new cjs.Graphics().p("AvvPSQmhmVAAo9IAAAAQAAo8GhmVIAAAAQGimVJNAAIAAAAQJOAAGiGVIAAAAQGhGVAAI8IAAAAQAAI9mhGVIAAAAQmiGVpOAAIAAAAQpNAAmimVg");
	var mask_14_graphics_309 = new cjs.Graphics().p("Av3PZQmlmYAApBIAAAAQAApAGlmZIAAAAQGlmYJSAAIAAAAQJTAAGlGYIAAAAQGlGZAAJAIAAAAQAAJBmlGYIAAAAQmlGZpTAAIAAAAQpSAAmlmZg");
	var mask_14_graphics_310 = new cjs.Graphics().p("Av/PhQmombAApGIAAAAQAApFGomcIAAAAQGombJXAAIAAAAQJYAAGnGbIAAAAQGpGcAAJFIAAAAQAAJGmpGbIAAAAQmnGcpYAAIAAAAQpXAAmomcg");
	var mask_14_graphics_311 = new cjs.Graphics().p("AwHPpQmrmfAApKIAAAAQAApJGrmfIAAAAQGsmeJbAAIAAAAQJcAAGrGeIAAAAQGsGfAAJJIAAAAQAAJKmsGfIAAAAQmrGepcAAIAAAAQpbAAmsmeg");
	var mask_14_graphics_312 = new cjs.Graphics().p("AwOPwQmumhAApPIAAAAQAApOGumhIAAAAQGumiJgAAIAAAAQJhAAGuGiIAAAAQGuGhAAJOIAAAAQAAJPmuGhIAAAAQmuGiphAAIAAAAQpgAAmumig");
	var mask_14_graphics_313 = new cjs.Graphics().p("AwWP3QmxmkAApTIAAAAQAApSGxmlIAAAAQGymkJkAAIAAAAQJlAAGxGkIAAAAQGyGlAAJSIAAAAQAAJTmyGkIAAAAQmxGlplAAIAAAAQpkAAmymlg");
	var mask_14_graphics_314 = new cjs.Graphics().p("AwdP+Qm0mnAApXIAAAAQAApWG0moIAAAAQG1mnJoAAIAAAAQJpAAG0GnIAAAAQG1GoAAJWIAAAAQAAJXm1GnIAAAAQm0GoppAAIAAAAQpoAAm1mog");
	var mask_14_graphics_315 = new cjs.Graphics().p("AwkQFQm3mqAApbIAAAAQAApaG3mrIAAAAQG4mqJsAAIAAAAQJtAAG3GqIAAAAQG4GrAAJaIAAAAQAAJbm4GqIAAAAQm3GrptAAIAAAAQpsAAm4mrg");
	var mask_14_graphics_316 = new cjs.Graphics().p("AwrQMQm6mtAApfIAAAAQAApeG6mtIAAAAQG7mtJwAAIAAAAQJxAAG6GtIAAAAQG7GtAAJeIAAAAQAAJfm7GtIAAAAQm6GtpxAAIAAAAQpwAAm7mtg");
	var mask_14_graphics_317 = new cjs.Graphics().p("AwyQSQm9mvAApjIAAAAQAApiG9mwIAAAAQG+mwJ0AAIAAAAQJ1AAG9GwIAAAAQG+GwAAJiIAAAAQAAJjm+GvIAAAAQm9Gxp1AAIAAAAQp0AAm+mxg");
	var mask_14_graphics_318 = new cjs.Graphics().p("Aw4QZQnAmzAApmIAAAAQAAplHAmzIAAAAQHAmzJ4AAIAAAAQJ5AAHAGzIAAAAQHAGzAAJlIAAAAQAAJmnAGzIAAAAQnAGzp5AAIAAAAQp4AAnAmzg");
	var mask_14_graphics_319 = new cjs.Graphics().p("Aw/QfQnCm1AApqIAAAAQAAppHCm2IAAAAQHDm1J8AAIAAAAQJ9AAHCG1IAAAAQHDG2AAJpIAAAAQAAJqnDG1IAAAAQnCG2p9AAIAAAAQp8AAnDm2g");
	var mask_14_graphics_320 = new cjs.Graphics().p("AxFQlQnFm3AApuIAAAAQAAptHFm4IAAAAQHFm3KAAAIAAAAQKBAAHFG3IAAAAQHFG4AAJtIAAAAQAAJunFG3IAAAAQnFG4qBAAIAAAAQqAAAnFm4g");
	var mask_14_graphics_321 = new cjs.Graphics().p("AxLQrQnIm6AApxIAAAAQAApwHIm7IAAAAQHIm6KDAAIAAAAQKEAAHIG6IAAAAQHIG7AAJwIAAAAQAAJxnIG6IAAAAQnIG7qEAAIAAAAQqDAAnIm7g");
	var mask_14_graphics_322 = new cjs.Graphics().p("AxRQxQnKm8AAp1IAAAAQAAp0HKm9IAAAAQHKm8KHAAIAAAAQKIAAHKG8IAAAAQHKG9AAJ0IAAAAQAAJ1nKG8IAAAAQnKG9qIAAIAAAAQqHAAnKm9g");
	var mask_14_graphics_323 = new cjs.Graphics().p("AxXQ3QnNm/AAp4IAAAAQAAp3HNm/IAAAAQHNm/KKAAIAAAAQKLAAHNG/IAAAAQHNG/AAJ3IAAAAQAAJ4nNG/IAAAAQnNG/qLAAIAAAAQqKAAnNm/g");
	var mask_14_graphics_324 = new cjs.Graphics().p("AxdQ9QnPnCAAp7IAAAAQAAp6HPnCIAAAAQHPnBKOAAIAAAAQKPAAHPHBIAAAAQHPHCAAJ6IAAAAQAAJ7nPHCIAAAAQnPHBqPAAIAAAAQqOAAnPnBg");
	var mask_14_graphics_325 = new cjs.Graphics().p("AxjRCQnRnDAAp/IAAAAQAAp+HRnEIAAAAQHSnDKRAAIAAAAQKSAAHRHDIAAAAQHSHEAAJ+IAAAAQAAJ/nSHDIAAAAQnRHEqSAAIAAAAQqRAAnSnEg");
	var mask_14_graphics_326 = new cjs.Graphics().p("AxoRHQnUnFAAqCIAAAAQAAqBHUnGIAAAAQHUnGKUAAIAAAAQKVAAHUHGIAAAAQHUHGAAKBIAAAAQAAKCnUHFIAAAAQnUHHqVAAIAAAAQqUAAnUnHg");
	var mask_14_graphics_327 = new cjs.Graphics().p("AxuRNQnVnIAAqFIAAAAQAAqEHVnIIAAAAQHXnIKXAAIAAAAQKYAAHWHIIAAAAQHWHIAAKEIAAAAQAAKFnWHIIAAAAQnWHIqYAAIAAAAQqXAAnXnIg");
	var mask_14_graphics_328 = new cjs.Graphics().p("AxzRSQnYnKAAqIIAAAAQAAqHHYnKIAAAAQHYnKKbAAIAAAAQKcAAHXHKIAAAAQHZHKAAKHIAAAAQAAKInZHKIAAAAQnXHKqcAAIAAAAQqbAAnYnKg");
	var mask_14_graphics_329 = new cjs.Graphics().p("Ax4RXQnanMAAqLIAAAAQAAqKHanMIAAAAQHbnMKdAAIAAAAQKeAAHaHMIAAAAQHbHMAAKKIAAAAQAAKLnbHMIAAAAQnaHMqeAAIAAAAQqdAAnbnMg");
	var mask_14_graphics_330 = new cjs.Graphics().p("Ax9RbQncnOAAqNIAAAAQAAqMHcnPIAAAAQHdnOKgAAIAAAAQKhAAHcHOIAAAAQHdHPAAKMIAAAAQAAKNndHOIAAAAQncHPqhAAIAAAAQqgAAndnPg");
	var mask_14_graphics_331 = new cjs.Graphics().p("AyCRgQnenQAAqQIAAAAQAAqPHenRIAAAAQHfnPKjAAIAAAAQKkAAHeHPIAAAAQHfHRAAKPIAAAAQAAKQnfHQIAAAAQneHQqkAAIAAAAQqjAAnfnQg");
	var mask_14_graphics_332 = new cjs.Graphics().p("AyGRlQngnSAAqTIAAAAQAAqSHgnSIAAAAQHgnSKmAAIAAAAQKnAAHgHSIAAAAQHgHSAAKSIAAAAQAAKTngHSIAAAAQngHSqnAAIAAAAQqmAAngnSg");
	var mask_14_graphics_333 = new cjs.Graphics().p("AyLRpQninUAAqVIAAAAQAAqUHinVIAAAAQHinTKpAAIAAAAQKqAAHhHTIAAAAQHjHVAAKUIAAAAQAAKVnjHUIAAAAQnhHUqqAAIAAAAQqpAAninUg");
	var mask_14_graphics_334 = new cjs.Graphics().p("AyPRtQnknVAAqYIAAAAQAAqXHknWIAAAAQHknVKrAAIAAAAQKsAAHkHVIAAAAQHkHWAAKXIAAAAQAAKYnkHVIAAAAQnkHWqsAAIAAAAQqrAAnknWg");
	var mask_14_graphics_335 = new cjs.Graphics().p("AyURxQnlnXAAqaIAAAAQAAqZHlnYIAAAAQHmnXKuAAIAAAAQKvAAHlHXIAAAAQHmHYAAKZIAAAAQAAKanmHXIAAAAQnlHYqvAAIAAAAQquAAnmnYg");
	var mask_14_graphics_336 = new cjs.Graphics().p("AyYR1QnnnYAAqdIAAAAQAAqcHnnZIAAAAQHonZKwAAIAAAAQKxAAHnHZIAAAAQHoHZAAKcIAAAAQAAKdnoHYIAAAAQnnHaqxAAIAAAAQqwAAnonag");
	var mask_14_graphics_337 = new cjs.Graphics().p("AycR5QnpnaAAqfIAAAAQAAqeHpnbIAAAAQHpnaKzAAIAAAAQK0AAHoHaIAAAAQHqHbAAKeIAAAAQAAKfnqHaIAAAAQnoHbq0AAIAAAAQqzAAnpnbg");
	var mask_14_graphics_338 = new cjs.Graphics().p("AygR9QnqncAAqhIAAAAQAAqgHqndIAAAAQHrncK1AAIAAAAQK2AAHqHcIAAAAQHrHdAAKgIAAAAQAAKhnrHcIAAAAQnqHdq2AAIAAAAQq1AAnrndg");
	var mask_14_graphics_339 = new cjs.Graphics().p("AykSBQnsneAAqjIAAAAQAAqiHsneIAAAAQHtneK3AAIAAAAQK4AAHsHeIAAAAQHtHeAAKiIAAAAQAAKjntHeIAAAAQnsHeq4AAIAAAAQq3AAntneg");
	var mask_14_graphics_340 = new cjs.Graphics().p("AynSEQnunfAAqlIAAAAQAAqkHungIAAAAQHunfK5AAIAAAAQK6AAHuHfIAAAAQHuHgAAKkIAAAAQAAKlnuHfIAAAAQnuHgq6AAIAAAAQq5AAnungg");
	var mask_14_graphics_341 = new cjs.Graphics().p("AyrSIQnvngAAqoIAAAAQAAqmHvnhIAAAAQHwnhK7AAIAAAAQK8AAHvHhIAAAAQHwHhAAKmIAAAAQAAKonwHgIAAAAQnvHhq8AAIAAAAQq7AAnwnhg");
	var mask_14_graphics_342 = new cjs.Graphics().p("AyuSLQnxniAAqpIAAAAQAAqoHxnjIAAAAQHxnhK9AAIAAAAQK+AAHxHhIAAAAQHxHjAAKoIAAAAQAAKpnxHiIAAAAQnxHiq+AAIAAAAQq9AAnxnig");
	var mask_14_graphics_343 = new cjs.Graphics().p("AyxSOQnynjAAqrIAAAAQAAqqHynkIAAAAQHynjK/AAIAAAAQLAAAHyHjIAAAAQHyHkAAKqIAAAAQAAKrnyHjIAAAAQnyHkrAAAIAAAAQq/AAnynkg");
	var mask_14_graphics_344 = new cjs.Graphics().p("Ay1SRQnznkAAqtIAAAAQAAqsHznlIAAAAQH0nkLBAAIAAAAQLCAAHzHkIAAAAQH0HlAAKsIAAAAQAAKtn0HkIAAAAQnzHlrCAAIAAAAQrBAAn0nlg");
	var mask_14_graphics_345 = new cjs.Graphics().p("Ay4SUQn0nlAAqvIAAAAQAAquH0nmIAAAAQH1nlLDAAIAAAAQLEAAH0HlIAAAAQH1HmAAKuIAAAAQAAKvn1HlIAAAAQn0HmrEAAIAAAAQrDAAn1nmg");
	var mask_14_graphics_346 = new cjs.Graphics().p("Ay7SXQn1nmAAqxIAAAAQAAqwH1nnIAAAAQH2nmLFAAIAAAAQLGAAH1HmIAAAAQH2HnAAKwIAAAAQAAKxn2HmIAAAAQn1HnrGAAIAAAAQrFAAn2nng");
	var mask_14_graphics_347 = new cjs.Graphics().p("Ay9SaQn3noAAqyIAAAAQAAqxH3npIAAAAQH3nnLGAAIAAAAQLHAAH3HnIAAAAQH3HpAAKxIAAAAQAAKyn3HoIAAAAQn3HorHAAIAAAAQrGAAn3nog");
	var mask_14_graphics_348 = new cjs.Graphics().p("AzASdQn4npAAq0IAAAAQAAqzH4npIAAAAQH4npLIAAIAAAAQLJAAH4HpIAAAAQH4HpAAKzIAAAAQAAK0n4HpIAAAAQn4HprJAAIAAAAQrIAAn4npg");

	this.timeline.addTween(cjs.Tween.get(mask_14).to({graphics:null,x:0,y:0}).wait(232).to({graphics:mask_14_graphics_232,x:140.6502,y:426.6499}).wait(1).to({graphics:mask_14_graphics_233,x:141.0556,y:425.4953}).wait(1).to({graphics:mask_14_graphics_234,x:141.4633,y:424.3338}).wait(1).to({graphics:mask_14_graphics_235,x:141.8733,y:423.1665}).wait(1).to({graphics:mask_14_graphics_236,x:142.2846,y:421.9933}).wait(1).to({graphics:mask_14_graphics_237,x:142.6986,y:420.8148}).wait(1).to({graphics:mask_14_graphics_238,x:143.1139,y:419.6313}).wait(1).to({graphics:mask_14_graphics_239,x:143.5311,y:418.4438}).wait(1).to({graphics:mask_14_graphics_240,x:143.9496,y:417.2517}).wait(1).to({graphics:mask_14_graphics_241,x:144.369,y:416.0565}).wait(1).to({graphics:mask_14_graphics_242,x:144.7893,y:414.8586}).wait(1).to({graphics:mask_14_graphics_243,x:145.2109,y:413.658}).wait(1).to({graphics:mask_14_graphics_244,x:145.6331,y:412.4551}).wait(1).to({graphics:mask_14_graphics_245,x:146.056,y:411.2514}).wait(1).to({graphics:mask_14_graphics_246,x:146.4786,y:410.0467}).wait(1).to({graphics:mask_14_graphics_247,x:146.902,y:408.8407}).wait(1).to({graphics:mask_14_graphics_248,x:147.325,y:407.6352}).wait(1).to({graphics:mask_14_graphics_249,x:147.7485,y:406.4301}).wait(1).to({graphics:mask_14_graphics_250,x:148.1706,y:405.2259}).wait(1).to({graphics:mask_14_graphics_251,x:148.5936,y:404.023}).wait(1).to({graphics:mask_14_graphics_252,x:149.0148,y:402.822}).wait(1).to({graphics:mask_14_graphics_253,x:149.4355,y:401.6236}).wait(1).to({graphics:mask_14_graphics_254,x:149.8554,y:400.428}).wait(1).to({graphics:mask_14_graphics_255,x:150.2739,y:399.2355}).wait(1).to({graphics:mask_14_graphics_256,x:150.6911,y:398.047}).wait(1).to({graphics:mask_14_graphics_257,x:151.1068,y:396.8626}).wait(1).to({graphics:mask_14_graphics_258,x:151.5208,y:395.6832}).wait(1).to({graphics:mask_14_graphics_259,x:151.9335,y:394.5087}).wait(1).to({graphics:mask_14_graphics_260,x:152.3434,y:393.3391}).wait(1).to({graphics:mask_14_graphics_261,x:152.7516,y:392.1763}).wait(1).to({graphics:mask_14_graphics_262,x:153.158,y:391.0194}).wait(1).to({graphics:mask_14_graphics_263,x:153.562,y:389.8692}).wait(1).to({graphics:mask_14_graphics_264,x:153.9634,y:388.7262}).wait(1).to({graphics:mask_14_graphics_265,x:154.3617,y:387.5908}).wait(1).to({graphics:mask_14_graphics_266,x:154.7573,y:386.4632}).wait(1).to({graphics:mask_14_graphics_267,x:155.1505,y:385.3431}).wait(1).to({graphics:mask_14_graphics_268,x:155.5407,y:384.232}).wait(1).to({graphics:mask_14_graphics_269,x:155.9277,y:383.1295}).wait(1).to({graphics:mask_14_graphics_270,x:156.3111,y:382.037}).wait(1).to({graphics:mask_14_graphics_271,x:156.6918,y:380.9529}).wait(1).to({graphics:mask_14_graphics_272,x:157.0689,y:379.8787}).wait(1).to({graphics:mask_14_graphics_273,x:157.4428,y:378.8145}).wait(1).to({graphics:mask_14_graphics_274,x:157.8127,y:377.7606}).wait(1).to({graphics:mask_14_graphics_275,x:158.179,y:376.7166}).wait(1).to({graphics:mask_14_graphics_276,x:158.5417,y:375.6834}).wait(1).to({graphics:mask_14_graphics_277,x:158.9004,y:374.6614}).wait(1).to({graphics:mask_14_graphics_278,x:159.2555,y:373.6503}).wait(1).to({graphics:mask_14_graphics_279,x:159.6065,y:372.6504}).wait(1).to({graphics:mask_14_graphics_280,x:159.9534,y:371.6617}).wait(1).to({graphics:mask_14_graphics_281,x:160.2963,y:370.6843}).wait(1).to({graphics:mask_14_graphics_282,x:160.6356,y:369.7191}).wait(1).to({graphics:mask_14_graphics_283,x:160.9699,y:368.7655}).wait(1).to({graphics:mask_14_graphics_284,x:161.3007,y:367.8241}).wait(1).to({graphics:mask_14_graphics_285,x:161.6269,y:366.8949}).wait(1).to({graphics:mask_14_graphics_286,x:161.9492,y:365.9769}).wait(1).to({graphics:mask_14_graphics_287,x:162.2664,y:365.0724}).wait(1).to({graphics:mask_14_graphics_288,x:162.58,y:364.1792}).wait(1).to({graphics:mask_14_graphics_289,x:162.8892,y:363.2989}).wait(1).to({graphics:mask_14_graphics_290,x:163.1938,y:362.4309}).wait(1).to({graphics:mask_14_graphics_291,x:163.4935,y:361.5754}).wait(1).to({graphics:mask_14_graphics_292,x:163.7901,y:360.733}).wait(1).to({graphics:mask_14_graphics_293,x:164.0813,y:359.9028}).wait(1).to({graphics:mask_14_graphics_294,x:164.3683,y:359.0856}).wait(1).to({graphics:mask_14_graphics_295,x:164.6505,y:358.281}).wait(1).to({graphics:mask_14_graphics_296,x:164.929,y:357.4885}).wait(1).to({graphics:mask_14_graphics_297,x:165.2026,y:356.7092}).wait(1).to({graphics:mask_14_graphics_298,x:165.4718,y:355.9419}).wait(1).to({graphics:mask_14_graphics_299,x:165.7363,y:355.1882}).wait(1).to({graphics:mask_14_graphics_300,x:165.9964,y:354.4461}).wait(1).to({graphics:mask_14_graphics_301,x:166.2525,y:353.7176}).wait(1).to({graphics:mask_14_graphics_302,x:166.5041,y:353.0011}).wait(1).to({graphics:mask_14_graphics_303,x:166.7511,y:352.2973}).wait(1).to({graphics:mask_14_graphics_304,x:166.9936,y:351.6066}).wait(1).to({graphics:mask_14_graphics_305,x:167.2317,y:350.9276}).wait(1).to({graphics:mask_14_graphics_306,x:167.4657,y:350.2616}).wait(1).to({graphics:mask_14_graphics_307,x:167.6952,y:349.6077}).wait(1).to({graphics:mask_14_graphics_308,x:167.9206,y:348.966}).wait(1).to({graphics:mask_14_graphics_309,x:168.1416,y:348.3369}).wait(1).to({graphics:mask_14_graphics_310,x:168.3576,y:347.7199}).wait(1).to({graphics:mask_14_graphics_311,x:168.5704,y:347.1152}).wait(1).to({graphics:mask_14_graphics_312,x:168.7783,y:346.5225}).wait(1).to({graphics:mask_14_graphics_313,x:168.9818,y:345.942}).wait(1).to({graphics:mask_14_graphics_314,x:169.1815,y:345.3732}).wait(1).to({graphics:mask_14_graphics_315,x:169.3773,y:344.817}).wait(1).to({graphics:mask_14_graphics_316,x:169.5681,y:344.272}).wait(1).to({graphics:mask_14_graphics_317,x:169.7553,y:343.7388}).wait(1).to({graphics:mask_14_graphics_318,x:169.9389,y:343.2172}).wait(1).to({graphics:mask_14_graphics_319,x:170.1175,y:342.7074}).wait(1).to({graphics:mask_14_graphics_320,x:170.2926,y:342.2088}).wait(1).to({graphics:mask_14_graphics_321,x:170.4631,y:341.7219}).wait(1).to({graphics:mask_14_graphics_322,x:170.6306,y:341.2467}).wait(1).to({graphics:mask_14_graphics_323,x:170.793,y:340.7823}).wait(1).to({graphics:mask_14_graphics_324,x:170.9523,y:340.3291}).wait(1).to({graphics:mask_14_graphics_325,x:171.1075,y:339.8868}).wait(1).to({graphics:mask_14_graphics_326,x:171.2587,y:339.4562}).wait(1).to({graphics:mask_14_graphics_327,x:171.4063,y:339.0354}).wait(1).to({graphics:mask_14_graphics_328,x:171.5503,y:338.6259}).wait(1).to({graphics:mask_14_graphics_329,x:171.6898,y:338.2272}).wait(1).to({graphics:mask_14_graphics_330,x:171.8262,y:337.8393}).wait(1).to({graphics:mask_14_graphics_331,x:171.9589,y:337.4622}).wait(1).to({graphics:mask_14_graphics_332,x:172.0877,y:337.095}).wait(1).to({graphics:mask_14_graphics_333,x:172.2127,y:336.7381}).wait(1).to({graphics:mask_14_graphics_334,x:172.3342,y:336.3921}).wait(1).to({graphics:mask_14_graphics_335,x:172.4526,y:336.0555}).wait(1).to({graphics:mask_14_graphics_336,x:172.5669,y:335.7297}).wait(1).to({graphics:mask_14_graphics_337,x:172.678,y:335.4129}).wait(1).to({graphics:mask_14_graphics_338,x:172.7856,y:335.1073}).wait(1).to({graphics:mask_14_graphics_339,x:172.8896,y:334.8108}).wait(1).to({graphics:mask_14_graphics_340,x:172.9903,y:334.5241}).wait(1).to({graphics:mask_14_graphics_341,x:173.0876,y:334.2469}).wait(1).to({graphics:mask_14_graphics_342,x:173.1811,y:333.9792}).wait(1).to({graphics:mask_14_graphics_343,x:173.2721,y:333.7214}).wait(1).to({graphics:mask_14_graphics_344,x:173.3593,y:333.4725}).wait(1).to({graphics:mask_14_graphics_345,x:173.4435,y:333.2331}).wait(1).to({graphics:mask_14_graphics_346,x:173.5245,y:333.0027}).wait(1).to({graphics:mask_14_graphics_347,x:173.6019,y:332.7817}).wait(1).to({graphics:mask_14_graphics_348,x:173.5668,y:332.4586}).wait(462));

	// Layer_17
	this.instance_25 = new lib.Tween39("synched",0);
	this.instance_25.setTransform(196.5,322.35);
	this.instance_25.alpha = 0.5;
	this.instance_25._off = true;

	var maskedShapeInstanceList = [this.instance_25];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_14;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_25).wait(232).to({_off:false},0).to({alpha:0.9883},116).wait(462));

	// Layer_6 (mask)
	var mask_15 = new cjs.Shape();
	mask_15._off = true;
	var mask_15_graphics_129 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_15_graphics_130 = new cjs.Graphics().p("AguAuQgUgTAAgbIAAAAQAAgaAUgTIAAAAQATgTAbAAIAAAAQAcAAATATIAAAAQAUATAAAaIAAAAQAAAbgUATIAAAAQgTATgcAAIAAAAQgbAAgTgTg");
	var mask_15_graphics_131 = new cjs.Graphics().p("AhNBLQgggfAAgsIAAAAQAAgrAggfIAAAAQAhgfAsAAIAAAAQAtAAAhAfIAAAAQAgAfAAArIAAAAQAAAsggAfIAAAAQghAfgtAAIAAAAQgsAAghgfg");
	var mask_15_graphics_132 = new cjs.Graphics().p("AhrBpQgtgsAAg9IAAAAQAAg8AtgsIAAAAQAtgrA+AAIAAAAQA/AAAtArIAAAAQAtAsAAA8IAAAAQAAA9gtAsIAAAAQgtArg/AAIAAAAQg+AAgtgrg");
	var mask_15_graphics_133 = new cjs.Graphics().p("AiKCHQg5g4AAhPIAAAAQAAhOA5g4IAAAAQA6g3BQAAIAAAAQBRAAA6A3IAAAAQA5A4AABOIAAAAQAABPg5A4IAAAAQg6A3hRAAIAAAAQhQAAg6g3g");
	var mask_15_graphics_134 = new cjs.Graphics().p("AipClQhGhFAAhgIAAAAQAAhfBGhFIAAAAQBGhEBjAAIAAAAQBjAABHBEIAAAAQBGBFAABfIAAAAQAABghGBFIAAAAQhHBEhjAAIAAAAQhjAAhGhEg");
	var mask_15_graphics_135 = new cjs.Graphics().p("AjIDDQhThRAAhyIAAAAQAAhxBThRIAAAAQBThRB1AAIAAAAQB2AABTBRIAAAAQBTBRAABxIAAAAQAAByhTBRIAAAAQhTBRh2AAIAAAAQh1AAhThRg");
	var mask_15_graphics_136 = new cjs.Graphics().p("AjnDhQhghdAAiEIAAAAQAAiDBghdIAAAAQBghdCHAAIAAAAQCIAABgBdIAAAAQBgBdAACDIAAAAQAACEhgBdIAAAAQhgBdiIAAIAAAAQiHAAhghdg");
	var mask_15_graphics_137 = new cjs.Graphics().p("AkGD/QhuhpAAiWIAAAAQAAiVBuhpIAAAAQBthqCZAAIAAAAQCaAABtBqIAAAAQBuBpAACVIAAAAQAACWhuBpIAAAAQhtBqiaAAIAAAAQiZAAhthqg");
	var mask_15_graphics_138 = new cjs.Graphics().p("AkmEeQh6h3AAinIAAAAQAAimB6h3IAAAAQB6h2CsAAIAAAAQCtAAB6B2IAAAAQB6B3AACmIAAAAQAACnh6B3IAAAAQh6B2itAAIAAAAQisAAh6h2g");
	var mask_15_graphics_139 = new cjs.Graphics().p("AlFE8QiHiDAAi5IAAAAQAAi4CHiDIAAAAQCHiDC+AAIAAAAQC/AACHCDIAAAAQCHCDAAC4IAAAAQAAC5iHCDIAAAAQiHCDi/AAIAAAAQi+AAiHiDg");
	var mask_15_graphics_140 = new cjs.Graphics().p("AlkFaQiUiPAAjLIAAAAQAAjKCUiPIAAAAQCUiQDQAAIAAAAQDRAACUCQIAAAAQCUCPAADKIAAAAQAADLiUCPIAAAAQiUCQjRAAIAAAAQjQAAiUiQg");
	var mask_15_graphics_141 = new cjs.Graphics().p("AmDF4QihibAAjdIAAAAQAAjcChicIAAAAQChibDiAAIAAAAQDjAAChCbIAAAAQChCcAADcIAAAAQAADdihCbIAAAAQihCcjjAAIAAAAQjiAAihicg");
	var mask_15_graphics_142 = new cjs.Graphics().p("AmiGWQiuioAAjuIAAAAQAAjtCuipIAAAAQCuioD0AAIAAAAQD1AACuCoIAAAAQCuCpAADtIAAAAQAADuiuCoIAAAAQiuCpj1AAIAAAAQj0AAiuipg");
	var mask_15_graphics_143 = new cjs.Graphics().p("AnBG0Qi6i0AAkAIAAAAQAAj/C6i0IAAAAQC7i1EGAAIAAAAQEHAAC7C1IAAAAQC6C0AAD/IAAAAQAAEAi6C0IAAAAQi7C1kHAAIAAAAQkGAAi7i1g");
	var mask_15_graphics_144 = new cjs.Graphics().p("AnfHSQjHjBAAkRIAAAAQAAkQDHjBIAAAAQDHjBEYAAIAAAAQEZAADHDBIAAAAQDHDBAAEQIAAAAQAAERjHDBIAAAAQjHDBkZAAIAAAAQkYAAjHjBg");
	var mask_15_graphics_145 = new cjs.Graphics().p("An+HvQjTjNAAkiIAAAAQAAkhDTjNIAAAAQDUjNEqAAIAAAAQErAADTDNIAAAAQDUDNAAEhIAAAAQAAEijUDNIAAAAQjTDNkrAAIAAAAQkqAAjUjNg");
	var mask_15_graphics_146 = new cjs.Graphics().p("AobIMQjgjZAAkzIAAAAQAAkyDgjZIAAAAQDgjZE7AAIAAAAQE8AADgDZIAAAAQDgDZAAEyIAAAAQAAEzjgDZIAAAAQjgDZk8AAIAAAAQk7AAjgjZg");
	var mask_15_graphics_147 = new cjs.Graphics().p("Ao5IpQjsjlAAlEIAAAAQAAlDDsjlIAAAAQDsjlFNAAIAAAAQFOAADsDlIAAAAQDsDlAAFDIAAAAQAAFEjsDlIAAAAQjsDllOAAIAAAAQlNAAjsjlg");
	var mask_15_graphics_148 = new cjs.Graphics().p("ApWJFQj4jxAAlUIAAAAQAAlTD4jxIAAAAQD4jxFeAAIAAAAQFfAAD4DxIAAAAQD4DxAAFTIAAAAQAAFUj4DxIAAAAQj4DxlfAAIAAAAQleAAj4jxg");
	var mask_15_graphics_149 = new cjs.Graphics().p("ApzJhQkEj8AAllIAAAAQAAlkEEj8IAAAAQEEj9FvAAIAAAAQFwAAEED9IAAAAQEED8AAFkIAAAAQAAFlkED8IAAAAQkED9lwAAIAAAAQlvAAkEj9g");
	var mask_15_graphics_150 = new cjs.Graphics().p("AqQJ9QkPkIAAl1IAAAAQAAl0EPkIIAAAAQERkIF/AAIAAAAQGAAAEQEIIAAAAQEQEIAAF0IAAAAQAAF1kQEIIAAAAQkQEImAAAIAAAAQl/AAkRkIg");
	var mask_15_graphics_151 = new cjs.Graphics().p("AqsKYQkbkTAAmFIAAAAQAAmEEbkTIAAAAQEckTGQAAIAAAAQGRAAEbETIAAAAQEcETAAGEIAAAAQAAGFkcETIAAAAQkbETmRAAIAAAAQmQAAkckTg");
	var mask_15_graphics_152 = new cjs.Graphics().p("ArHKzQknkeAAmVIAAAAQAAmUEnkeIAAAAQEnkeGgAAIAAAAQGhAAEnEeIAAAAQEnEeAAGUIAAAAQAAGVknEeIAAAAQknEemhAAIAAAAQmgAAknkeg");
	var mask_15_graphics_153 = new cjs.Graphics().p("AriLNQkykpAAmkIAAAAQAAmjEykpIAAAAQEykpGwAAIAAAAQGxAAEyEpIAAAAQEyEpAAGjIAAAAQAAGkkyEpIAAAAQkyEpmxAAIAAAAQmwAAkykpg");
	var mask_15_graphics_154 = new cjs.Graphics().p("Ar9LnQk9k0AAmzIAAAAQAAmyE9k0IAAAAQE+kzG/AAIAAAAQHAAAE9EzIAAAAQE+E0AAGyIAAAAQAAGzk+E0IAAAAQk9EznAAAIAAAAQm/AAk+kzg");
	var mask_15_graphics_155 = new cjs.Graphics().p("AsXMAQlHk+AAnCIAAAAQAAnBFHk+IAAAAQFIk+HPAAIAAAAQHQAAFHE+IAAAAQFIE+AAHBIAAAAQAAHClIE+IAAAAQlHE+nQAAIAAAAQnPAAlIk+g");
	var mask_15_graphics_156 = new cjs.Graphics().p("AswMZQlSlJAAnQIAAAAQAAnPFSlJIAAAAQFSlIHeAAIAAAAQHfAAFSFIIAAAAQFSFJAAHPIAAAAQAAHQlSFJIAAAAQlSFInfAAIAAAAQneAAlSlIg");
	var mask_15_graphics_157 = new cjs.Graphics().p("AtJMxQldlTAAneIAAAAQAAndFdlTIAAAAQFdlSHsAAIAAAAQHtAAFdFSIAAAAQFdFTAAHdIAAAAQAAHeldFTIAAAAQldFSntAAIAAAAQnsAAldlSg");
	var mask_15_graphics_158 = new cjs.Graphics().p("AthNIQlnlcAAnsIAAAAQAAnrFnldIAAAAQFnlcH6AAIAAAAQH7AAFnFcIAAAAQFnFdAAHrIAAAAQAAHslnFcIAAAAQlnFdn7AAIAAAAQn6AAlnldg");
	var mask_15_graphics_159 = new cjs.Graphics().p("At5NfQlxllAAn6IAAAAQAAn5FxlmIAAAAQFxllIIAAIAAAAQIJAAFxFlIAAAAQFxFmAAH5IAAAAQAAH6lxFlIAAAAQlxFmoJAAIAAAAQoIAAlxlmg");
	var mask_15_graphics_160 = new cjs.Graphics().p("AuQN2Ql7lvAAoHIAAAAQAAoGF7lvIAAAAQF6lvIWAAIAAAAQIXAAF6FvIAAAAQF7FvAAIGIAAAAQAAIHl7FvIAAAAQl6FvoXAAIAAAAQoWAAl6lvg");
	var mask_15_graphics_161 = new cjs.Graphics().p("AunOMQmEl4AAoUIAAAAQAAoTGEl4IAAAAQGEl4IjAAIAAAAQIkAAGEF4IAAAAQGEF4AAITIAAAAQAAIUmEF4IAAAAQmEF4okAAIAAAAQojAAmEl4g");
	var mask_15_graphics_162 = new cjs.Graphics().p("Au9OhQmNmBAAogIAAAAQAAofGNmCIAAAAQGNmBIwAAIAAAAQIxAAGNGBIAAAAQGNGCAAIfIAAAAQAAIgmNGBIAAAAQmNGCoxAAIAAAAQowAAmNmCg");
	var mask_15_graphics_163 = new cjs.Graphics().p("AvTO2QmVmJAAotIAAAAQAAosGVmKIAAAAQGWmJI9AAIAAAAQI+AAGVGJIAAAAQGWGKAAIsIAAAAQAAItmWGJIAAAAQmVGKo+AAIAAAAQo9AAmWmKg");
	var mask_15_graphics_164 = new cjs.Graphics().p("AvnPKQmfmRAAo5IAAAAQAAo4GfmSIAAAAQGemSJJAAIAAAAQJKAAGeGSIAAAAQGfGSAAI4IAAAAQAAI5mfGRIAAAAQmeGTpKAAIAAAAQpJAAmemTg");
	var mask_15_graphics_165 = new cjs.Graphics().p("Av8PeQmmmaAApEIAAAAQAApDGmmbIAAAAQGnmaJVAAIAAAAQJWAAGmGaIAAAAQGnGbAAJDIAAAAQAAJEmnGaIAAAAQmmGbpWAAIAAAAQpVAAmnmbg");
	var mask_15_graphics_166 = new cjs.Graphics().p("AwPPxQmvmiAApPIAAAAQAApOGvmjIAAAAQGvmiJgAAIAAAAQJhAAGvGiIAAAAQGvGjAAJOIAAAAQAAJPmvGiIAAAAQmvGjphAAIAAAAQpgAAmvmjg");
	var mask_15_graphics_167 = new cjs.Graphics().p("AwiQEQm3mqAApaIAAAAQAApZG3mqIAAAAQG3mqJrAAIAAAAQJsAAG3GqIAAAAQG3GqAAJZIAAAAQAAJam3GqIAAAAQm3GqpsAAIAAAAQprAAm3mqg");
	var mask_15_graphics_168 = new cjs.Graphics().p("Aw1QWQm+mxAAplIAAAAQAApkG+mxIAAAAQG/mxJ2AAIAAAAQJ3AAG+GxIAAAAQG/GxAAJkIAAAAQAAJlm/GxIAAAAQm+Gxp3AAIAAAAQp2AAm/mxg");
	var mask_15_graphics_169 = new cjs.Graphics().p("AxHQnQnFm4AApvIAAAAQAApuHFm4IAAAAQHGm5KBAAIAAAAQKCAAHFG5IAAAAQHGG4AAJuIAAAAQAAJvnGG4IAAAAQnFG5qCAAIAAAAQqBAAnGm5g");
	var mask_15_graphics_170 = new cjs.Graphics().p("AxYQ4QnNm/AAp5IAAAAQAAp4HNm/IAAAAQHNm/KLAAIAAAAQKMAAHNG/IAAAAQHNG/AAJ4IAAAAQAAJ5nNG/IAAAAQnNG/qMAAIAAAAQqLAAnNm/g");
	var mask_15_graphics_171 = new cjs.Graphics().p("AxpRIQnUnGAAqCIAAAAQAAqBHUnGIAAAAQHUnGKVAAIAAAAQKWAAHTHGIAAAAQHVHGAAKBIAAAAQAAKCnVHGIAAAAQnTHGqWAAIAAAAQqVAAnUnGg");
	var mask_15_graphics_172 = new cjs.Graphics().p("Ax5RYQnanNAAqLIAAAAQAAqKHanNIAAAAQHbnMKeAAIAAAAQKfAAHaHMIAAAAQHbHNAAKKIAAAAQAAKLnbHNIAAAAQnaHMqfAAIAAAAQqeAAnbnMg");
	var mask_15_graphics_173 = new cjs.Graphics().p("AyJRnQngnTAAqUIAAAAQAAqTHgnTIAAAAQHinTKnAAIAAAAQKoAAHhHTIAAAAQHhHTAAKTIAAAAQAAKUnhHTIAAAAQnhHTqoAAIAAAAQqnAAninTg");
	var mask_15_graphics_174 = new cjs.Graphics().p("AyYR1QnnnYAAqdIAAAAQAAqcHnnZIAAAAQHonYKwAAIAAAAQKxAAHnHYIAAAAQHoHZAAKcIAAAAQAAKdnoHYIAAAAQnnHZqxAAIAAAAQqwAAnonZg");
	var mask_15_graphics_175 = new cjs.Graphics().p("AymSDQntneAAqlIAAAAQAAqkHtnfIAAAAQHuneK4AAIAAAAQK5AAHuHeIAAAAQHtHfAAKkIAAAAQAAKlntHeIAAAAQnuHfq5AAIAAAAQq4AAnunfg");
	var mask_15_graphics_176 = new cjs.Graphics().p("Ay0SRQnznkAAqtIAAAAQAAqsHznkIAAAAQHznkLBAAIAAAAQLCAAHyHkIAAAAQH0HkAAKsIAAAAQAAKtn0HkIAAAAQnyHkrCAAIAAAAQrBAAnznkg");
	var mask_15_graphics_177 = new cjs.Graphics().p("AzBSeQn5nqAAq0IAAAAQAAqzH5nqIAAAAQH5nqLIAAIAAAAQLJAAH5HqIAAAAQH5HqAAKzIAAAAQAAK0n5HqIAAAAQn5HqrJAAIAAAAQrIAAn5nqg");
	var mask_15_graphics_178 = new cjs.Graphics().p("AzOSqQn+nuAAq8IAAAAQAAq7H+nvIAAAAQH+nuLQAAIAAAAQLRAAH+HuIAAAAQH+HvAAK7IAAAAQAAK8n+HuIAAAAQn+HvrRAAIAAAAQrQAAn+nvg");
	var mask_15_graphics_179 = new cjs.Graphics().p("AzaS2QoDnzAArDIAAAAQAArCIDn0IAAAAQIDnzLXAAIAAAAQLYAAIDHzIAAAAQIDH0AALCIAAAAQAALDoDHzIAAAAQoDH0rYAAIAAAAQrXAAoDn0g");
	var mask_15_graphics_180 = new cjs.Graphics().p("AzmTBQoIn4AArJIAAAAQAArIIIn5IAAAAQIIn4LeAAIAAAAQLfAAIIH4IAAAAQIIH5AALIIAAAAQAALJoIH4IAAAAQoIH5rfAAIAAAAQreAAoIn5g");
	var mask_15_graphics_181 = new cjs.Graphics().p("AzxTMQoNn8AArQIAAAAQAArPINn9IAAAAQIMn9LlAAIAAAAQLmAAIMH9IAAAAQINH9AALPIAAAAQAALQoNH8IAAAAQoMH+rmAAIAAAAQrlAAoMn+g");
	var mask_15_graphics_182 = new cjs.Graphics().p("Az8TXQoRoBAArWIAAAAQAArVIRoBIAAAAQIRoBLrAAIAAAAQLsAAIQIBIAAAAQISIBAALVIAAAAQAALWoSIBIAAAAQoQIBrsAAIAAAAQrrAAoRoBg");
	var mask_15_graphics_183 = new cjs.Graphics().p("A0GThQoVoFAArcIAAAAQAArbIVoFIAAAAQIVoFLxAAIAAAAQLyAAIVIFIAAAAQIVIFAALbIAAAAQAALcoVIFIAAAAQoVIFryAAIAAAAQrxAAoVoFg");
	var mask_15_graphics_184 = new cjs.Graphics().p("A0QTqQoZoJAArhIAAAAQAArgIZoKIAAAAQIaoJL2AAIAAAAQL3AAIZIJIAAAAQIaIKAALgIAAAAQAALhoaIJIAAAAQoZIKr3AAIAAAAQr2AAoaoKg");
	var mask_15_graphics_185 = new cjs.Graphics().p("A0ZTzQodoNAArmIAAAAQAArlIdoOIAAAAQIdoML8AAIAAAAQL9AAIdIMIAAAAQIdIOAALlIAAAAQAALmodINIAAAAQodINr9AAIAAAAQr8AAodoNg");
	var mask_15_graphics_186 = new cjs.Graphics().p("A0iT7QogoQAArrIAAAAQAArqIgoRIAAAAQIhoQMBAAIAAAAQMCAAIgIQIAAAAQIhIRAALqIAAAAQAALrohIQIAAAAQogIRsCAAIAAAAQsBAAohoRg");
	var mask_15_graphics_187 = new cjs.Graphics().p("A0qUDQokoTAArwIAAAAQAArvIkoUIAAAAQIkoUMGAAIAAAAQMHAAIkIUIAAAAQIkIUAALvIAAAAQAALwokITIAAAAQokIVsHAAIAAAAQsGAAokoVg");
	var mask_15_graphics_188 = new cjs.Graphics().p("A0yULQonoXAAr0IAAAAQAArzInoYIAAAAQIooWMKAAIAAAAQMLAAInIWIAAAAQIoIYAALzIAAAAQAAL0ooIXIAAAAQonIXsLAAIAAAAQsKAAoooXg");
	var mask_15_graphics_189 = new cjs.Graphics().p("A05USQoqoZAAr5IAAAAQAAr4IqoaIAAAAQIqoZMPAAIAAAAQMQAAIqIZIAAAAQIqIaAAL4IAAAAQAAL5oqIZIAAAAQoqIasQAAIAAAAQsPAAoqoag");
	var mask_15_graphics_190 = new cjs.Graphics().p("A1AUZQotodAAr8IAAAAQAAr7ItoeIAAAAQItocMTAAIAAAAQMUAAItIcIAAAAQItIeAAL7IAAAAQAAL8otIdIAAAAQotIdsUAAIAAAAQsTAAotodg");
	var mask_15_graphics_191 = new cjs.Graphics().p("A1HUfQovofAAsAIAAAAQAAr/IvogIAAAAQIwofMXAAIAAAAQMYAAIvIfIAAAAQIwIgAAL/IAAAAQAAMAowIfIAAAAQovIgsYAAIAAAAQsXAAowogg");
	var mask_15_graphics_192 = new cjs.Graphics().p("A1NUlQoyohAAsEIAAAAQAAsDIyoiIAAAAQIzohMaAAIAAAAQMbAAIyIhIAAAAQIzIiAAMDIAAAAQAAMEozIhIAAAAQoyIisbAAIAAAAQsaAAozoig");
	var mask_15_graphics_193 = new cjs.Graphics().p("A1SUqQo1ojAAsHIAAAAQAAsGI1okIAAAAQI1okMdAAIAAAAQMeAAI1IkIAAAAQI1IkAAMGIAAAAQAAMHo1IjIAAAAQo1IlseAAIAAAAQsdAAo1olg");

	this.timeline.addTween(cjs.Tween.get(mask_15).to({graphics:null,x:0,y:0}).wait(129).to({graphics:mask_15_graphics_129,x:610.5501,y:378.7002}).wait(1).to({graphics:mask_15_graphics_130,x:610.5316,y:377.8888}).wait(1).to({graphics:mask_15_graphics_131,x:610.5127,y:377.0699}).wait(1).to({graphics:mask_15_graphics_132,x:610.4943,y:376.2436}).wait(1).to({graphics:mask_15_graphics_133,x:610.4754,y:375.412}).wait(1).to({graphics:mask_15_graphics_134,x:610.456,y:374.575}).wait(1).to({graphics:mask_15_graphics_135,x:610.4371,y:373.7349}).wait(1).to({graphics:mask_15_graphics_136,x:610.4173,y:372.8916}).wait(1).to({graphics:mask_15_graphics_137,x:610.3984,y:372.0469}).wait(1).to({graphics:mask_15_graphics_138,x:610.3791,y:371.2023}).wait(1).to({graphics:mask_15_graphics_139,x:610.3597,y:370.3581}).wait(1).to({graphics:mask_15_graphics_140,x:610.3404,y:369.5157}).wait(1).to({graphics:mask_15_graphics_141,x:610.3215,y:368.676}).wait(1).to({graphics:mask_15_graphics_142,x:610.3021,y:367.8412}).wait(1).to({graphics:mask_15_graphics_143,x:610.2828,y:367.011}).wait(1).to({graphics:mask_15_graphics_144,x:610.2639,y:366.187}).wait(1).to({graphics:mask_15_graphics_145,x:610.2455,y:365.3698}).wait(1).to({graphics:mask_15_graphics_146,x:610.227,y:364.5612}).wait(1).to({graphics:mask_15_graphics_147,x:610.209,y:363.7611}).wait(1).to({graphics:mask_15_graphics_148,x:610.1905,y:362.9709}).wait(1).to({graphics:mask_15_graphics_149,x:610.173,y:362.1915}).wait(1).to({graphics:mask_15_graphics_150,x:610.1554,y:361.4233}).wait(1).to({graphics:mask_15_graphics_151,x:610.1379,y:360.6664}).wait(1).to({graphics:mask_15_graphics_152,x:610.1212,y:359.9226}).wait(1).to({graphics:mask_15_graphics_153,x:610.1041,y:359.1918}).wait(1).to({graphics:mask_15_graphics_154,x:610.088,y:358.4749}).wait(1).to({graphics:mask_15_graphics_155,x:610.0717,y:357.7716}).wait(1).to({graphics:mask_15_graphics_156,x:610.056,y:357.0831}).wait(1).to({graphics:mask_15_graphics_157,x:610.0412,y:356.4094}).wait(1).to({graphics:mask_15_graphics_158,x:610.0258,y:355.7511}).wait(1).to({graphics:mask_15_graphics_159,x:610.011,y:355.108}).wait(1).to({graphics:mask_15_graphics_160,x:609.9966,y:354.4803}).wait(1).to({graphics:mask_15_graphics_161,x:609.9826,y:353.8683}).wait(1).to({graphics:mask_15_graphics_162,x:609.9691,y:353.2725}).wait(1).to({graphics:mask_15_graphics_163,x:609.9556,y:352.6929}).wait(1).to({graphics:mask_15_graphics_164,x:609.9431,y:352.1291}).wait(1).to({graphics:mask_15_graphics_165,x:609.9309,y:351.5809}).wait(1).to({graphics:mask_15_graphics_166,x:609.9188,y:351.0495}).wait(1).to({graphics:mask_15_graphics_167,x:609.9066,y:350.5338}).wait(1).to({graphics:mask_15_graphics_168,x:609.8953,y:350.0347}).wait(1).to({graphics:mask_15_graphics_169,x:609.8841,y:349.551}).wait(1).to({graphics:mask_15_graphics_170,x:609.8733,y:349.0835}).wait(1).to({graphics:mask_15_graphics_171,x:609.8629,y:348.6312}).wait(1).to({graphics:mask_15_graphics_172,x:609.853,y:348.1947}).wait(1).to({graphics:mask_15_graphics_173,x:609.8436,y:347.774}).wait(1).to({graphics:mask_15_graphics_174,x:609.8346,y:347.3685}).wait(1).to({graphics:mask_15_graphics_175,x:609.8251,y:346.9779}).wait(1).to({graphics:mask_15_graphics_176,x:609.8166,y:346.6021}).wait(1).to({graphics:mask_15_graphics_177,x:609.8085,y:346.2417}).wait(1).to({graphics:mask_15_graphics_178,x:609.8004,y:345.8957}).wait(1).to({graphics:mask_15_graphics_179,x:609.7932,y:345.5644}).wait(1).to({graphics:mask_15_graphics_180,x:609.7856,y:345.2467}).wait(1).to({graphics:mask_15_graphics_181,x:609.7788,y:344.9434}).wait(1).to({graphics:mask_15_graphics_182,x:609.7725,y:344.6541}).wait(1).to({graphics:mask_15_graphics_183,x:609.7662,y:344.3782}).wait(1).to({graphics:mask_15_graphics_184,x:609.7599,y:344.1154}).wait(1).to({graphics:mask_15_graphics_185,x:609.7541,y:343.8666}).wait(1).to({graphics:mask_15_graphics_186,x:609.7491,y:343.6299}).wait(1).to({graphics:mask_15_graphics_187,x:609.7437,y:343.4062}).wait(1).to({graphics:mask_15_graphics_188,x:609.7392,y:343.1952}).wait(1).to({graphics:mask_15_graphics_189,x:609.7342,y:342.9967}).wait(1).to({graphics:mask_15_graphics_190,x:609.7302,y:342.8104}).wait(1).to({graphics:mask_15_graphics_191,x:609.7262,y:342.6358}).wait(1).to({graphics:mask_15_graphics_192,x:609.7225,y:342.4734}).wait(1).to({graphics:mask_15_graphics_193,x:609.719,y:342.2601}).wait(617));

	// Layer_24
	this.instance_26 = new lib.Tween46("synched",0);
	this.instance_26.setTransform(656.85,305.7);
	this.instance_26.alpha = 0.5;
	this.instance_26._off = true;

	this.instance_27 = new lib.Tween47("synched",0);
	this.instance_27.setTransform(656.85,305.7);

	var maskedShapeInstanceList = [this.instance_26,this.instance_27];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_15;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_26}]},129).to({state:[{t:this.instance_27}]},64).wait(617));
	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(129).to({_off:false},0).to({_off:true,alpha:1},64).wait(617));

	// Layer_8
	this.instance_28 = new lib.Tween18("synched",2);
	this.instance_28.setTransform(-161.9,238.75,0.3728,0.3728);
	this.instance_28._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(377).to({_off:false},0).wait(433));

	// Layer_6 (mask)
	var mask_16 = new cjs.Shape();
	mask_16._off = true;
	var mask_16_graphics_294 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_16_graphics_295 = new cjs.Graphics().p("AgaAaQgLgLAAgPIAAAAQAAgOALgLIAAAAQALgLAPAAIAAAAQAQAAALALIAAAAQALALAAAOIAAAAQAAAPgLALIAAAAQgLALgQAAIAAAAQgPAAgLgLg");
	var mask_16_graphics_296 = new cjs.Graphics().p("AgkAjQgPgOAAgVIAAAAQAAgUAPgOIAAAAQAQgPAUAAIAAAAQAVAAAQAPIAAAAQAPAOAAAUIAAAAQAAAVgPAOIAAAAQgQAPgVAAIAAAAQgUAAgQgPg");
	var mask_16_graphics_297 = new cjs.Graphics().p("AgtAtQgUgTAAgaIAAAAQAAgZAUgTIAAAAQATgTAaAAIAAAAQAbAAATATIAAAAQAUATAAAZIAAAAQAAAagUATIAAAAQgTATgbAAIAAAAQgaAAgTgTg");
	var mask_16_graphics_298 = new cjs.Graphics().p("Ag3A2QgYgWAAggIAAAAQAAgfAYgXIAAAAQAXgWAgAAIAAAAQAhAAAXAWIAAAAQAYAXAAAfIAAAAQAAAggYAWIAAAAQgXAXghAAIAAAAQggAAgXgXg");
	var mask_16_graphics_299 = new cjs.Graphics().p("AhBBAQgcgaAAgmIAAAAQAAglAcgaIAAAAQAbgbAmAAIAAAAQAnAAAbAbIAAAAQAcAaAAAlIAAAAQAAAmgcAaIAAAAQgbAbgnAAIAAAAQgmAAgbgbg");
	var mask_16_graphics_300 = new cjs.Graphics().p("AhLBKQgggfAAgrIAAAAQAAgqAggfIAAAAQAfgeAsAAIAAAAQAtAAAfAeIAAAAQAgAfAAAqIAAAAQAAArggAfIAAAAQgfAegtAAIAAAAQgsAAgfgeg");
	var mask_16_graphics_301 = new cjs.Graphics().p("AhVBUQgkgjAAgxIAAAAQAAgwAkgjIAAAAQAjgiAyAAIAAAAQAzAAAjAiIAAAAQAkAjAAAwIAAAAQAAAxgkAjIAAAAQgjAigzAAIAAAAQgyAAgjgig");
	var mask_16_graphics_302 = new cjs.Graphics().p("AhfBdQgogmAAg3IAAAAQAAg2AogmIAAAAQAognA3AAIAAAAQA4AAAoAnIAAAAQAoAmAAA2IAAAAQAAA3goAmIAAAAQgoAng4AAIAAAAQg3AAgogng");
	var mask_16_graphics_303 = new cjs.Graphics().p("AhpBnQgsgrAAg8IAAAAQAAg7AsgrIAAAAQAsgrA9AAIAAAAQA+AAAsArIAAAAQAsArAAA7IAAAAQAAA8gsArIAAAAQgsArg+AAIAAAAQg9AAgsgrg");
	var mask_16_graphics_304 = new cjs.Graphics().p("AhzBxQgxgvAAhCIAAAAQAAhBAxgvIAAAAQAwgvBDAAIAAAAQBEAAAwAvIAAAAQAxAvAABBIAAAAQAABCgxAvIAAAAQgwAvhEAAIAAAAQhDAAgwgvg");
	var mask_16_graphics_305 = new cjs.Graphics().p("Ah+B7Qg0gzAAhIIAAAAQAAhHA0gzIAAAAQA1gyBJAAIAAAAQBKAAA0AyIAAAAQA1AzAABHIAAAAQAABIg1AzIAAAAQg0AyhKAAIAAAAQhJAAg1gyg");
	var mask_16_graphics_306 = new cjs.Graphics().p("AiICEQg4g2AAhOIAAAAQAAhNA4g2IAAAAQA5g3BPAAIAAAAQBQAAA5A3IAAAAQA4A2AABNIAAAAQAABOg4A2IAAAAQg5A3hQAAIAAAAQhPAAg5g3g");
	var mask_16_graphics_307 = new cjs.Graphics().p("AiSCOQg8g7AAhTIAAAAQAAhSA8g7IAAAAQA9g7BVAAIAAAAQBWAAA9A7IAAAAQA8A7AABSIAAAAQAABTg8A7IAAAAQg9A7hWAAIAAAAQhVAAg9g7g");
	var mask_16_graphics_308 = new cjs.Graphics().p("AicCYQhBg/AAhZIAAAAQAAhYBBg/IAAAAQBBg/BbAAIAAAAQBcAABBA/IAAAAQBBA/AABYIAAAAQAABZhBA/IAAAAQhBA/hcAAIAAAAQhbAAhBg/g");
	var mask_16_graphics_309 = new cjs.Graphics().p("AimCiQhFhDAAhfIAAAAQAAheBFhDIAAAAQBFhDBhAAIAAAAQBiAABFBDIAAAAQBFBDAABeIAAAAQAABfhFBDIAAAAQhFBDhiAAIAAAAQhhAAhFhDg");
	var mask_16_graphics_310 = new cjs.Graphics().p("AiwCrQhJhHAAhkIAAAAQAAhjBJhHIAAAAQBJhHBnAAIAAAAQBoAABJBHIAAAAQBJBHAABjIAAAAQAABkhJBHIAAAAQhJBHhoAAIAAAAQhnAAhJhHg");
	var mask_16_graphics_311 = new cjs.Graphics().p("Ai6C1QhNhLAAhqIAAAAQAAhpBNhLIAAAAQBOhLBsAAIAAAAQBtAABOBLIAAAAQBNBLAABpIAAAAQAABqhNBLIAAAAQhOBLhtAAIAAAAQhsAAhOhLg");
	var mask_16_graphics_312 = new cjs.Graphics().p("AjEC/QhRhPAAhwIAAAAQAAhvBRhPIAAAAQBShPByAAIAAAAQBzAABSBPIAAAAQBRBPAABvIAAAAQAABwhRBPIAAAAQhSBPhzAAIAAAAQhyAAhShPg");
	var mask_16_graphics_313 = new cjs.Graphics().p("AjODIQhVhTAAh1IAAAAQAAh0BVhTIAAAAQBWhTB4AAIAAAAQB5AABVBTIAAAAQBWBTAAB0IAAAAQAAB1hWBTIAAAAQhVBTh5AAIAAAAQh4AAhWhTg");
	var mask_16_graphics_314 = new cjs.Graphics().p("AjXDSQhahXAAh7IAAAAQAAh6BahXIAAAAQBZhXB+AAIAAAAQB/AABZBXIAAAAQBaBXAAB6IAAAAQAAB7haBXIAAAAQhZBXh/AAIAAAAQh+AAhZhXg");
	var mask_16_graphics_315 = new cjs.Graphics().p("AjhDbQhehbAAiAIAAAAQAAh/BehbIAAAAQBehbCDAAIAAAAQCEAABeBbIAAAAQBeBbAAB/IAAAAQAACAheBbIAAAAQheBbiEAAIAAAAQiDAAhehbg");
	var mask_16_graphics_316 = new cjs.Graphics().p("AjrDkQhhheAAiGIAAAAQAAiFBhhfIAAAAQBiheCJAAIAAAAQCKAABiBeIAAAAQBhBfAACFIAAAAQAACGhhBeIAAAAQhiBfiKAAIAAAAQiJAAhihfg");
	var mask_16_graphics_317 = new cjs.Graphics().p("Aj0DuQhmhjAAiLIAAAAQAAiKBmhjIAAAAQBlhiCPAAIAAAAQCQAABlBiIAAAAQBmBjAACKIAAAAQAACLhmBjIAAAAQhlBiiQAAIAAAAQiPAAhlhig");
	var mask_16_graphics_318 = new cjs.Graphics().p("Aj+D3QhphmAAiRIAAAAQAAiQBphmIAAAAQBqhmCUAAIAAAAQCVAABqBmIAAAAQBpBmAACQIAAAAQAACRhpBmIAAAAQhqBmiVAAIAAAAQiUAAhqhmg");
	var mask_16_graphics_319 = new cjs.Graphics().p("AkHEAQhthqAAiWIAAAAQAAiVBthqIAAAAQBthqCaAAIAAAAQCbAABtBqIAAAAQBtBqAACVIAAAAQAACWhtBqIAAAAQhtBqibAAIAAAAQiaAAhthqg");
	var mask_16_graphics_320 = new cjs.Graphics().p("AkQEJQhyhuAAibIAAAAQAAiaByhuIAAAAQBxhuCfAAIAAAAQCgAABxBuIAAAAQByBuAACaIAAAAQAACbhyBuIAAAAQhxBuigAAIAAAAQifAAhxhug");
	var mask_16_graphics_321 = new cjs.Graphics().p("AkaESQh1hxAAihIAAAAQAAigB1hxIAAAAQB2hyCkAAIAAAAQClAAB1ByIAAAAQB2BxAACgIAAAAQAAChh2BxIAAAAQh1ByilAAIAAAAQikAAh2hyg");
	var mask_16_graphics_322 = new cjs.Graphics().p("AkjEbQh4h1AAimIAAAAQAAilB4h1IAAAAQB5h1CqAAIAAAAQCrAAB5B1IAAAAQB4B1AAClIAAAAQAACmh4B1IAAAAQh5B1irAAIAAAAQiqAAh5h1g");
	var mask_16_graphics_323 = new cjs.Graphics().p("AksEjQh8h4AAirIAAAAQAAiqB8h5IAAAAQB9h4CvAAIAAAAQCwAAB8B4IAAAAQB9B5AACqIAAAAQAACrh9B4IAAAAQh8B5iwAAIAAAAQivAAh9h5g");
	var mask_16_graphics_324 = new cjs.Graphics().p("Ak0EsQiBh8AAiwIAAAAQAAivCBh8IAAAAQCAh8C0AAIAAAAQC1AACAB8IAAAAQCBB8AACvIAAAAQAACwiBB8IAAAAQiAB8i1AAIAAAAQi0AAiAh8g");
	var mask_16_graphics_325 = new cjs.Graphics().p("Ak9E0QiEh/AAi1IAAAAQAAi0CEiAIAAAAQCEh/C5AAIAAAAQC6AACEB/IAAAAQCECAAAC0IAAAAQAAC1iEB/IAAAAQiECAi6AAIAAAAQi5AAiEiAg");
	var mask_16_graphics_326 = new cjs.Graphics().p("AlGE9QiHiDAAi6IAAAAQAAi5CHiDIAAAAQCIiDC+AAIAAAAQC/AACICDIAAAAQCHCDAAC5IAAAAQAAC6iHCDIAAAAQiICDi/AAIAAAAQi+AAiIiDg");
	var mask_16_graphics_327 = new cjs.Graphics().p("AlOFFQiLiHAAi+IAAAAQAAi9CLiHIAAAAQCLiHDDAAIAAAAQDEAACLCHIAAAAQCLCHAAC9IAAAAQAAC+iLCHIAAAAQiLCHjEAAIAAAAQjDAAiLiHg");
	var mask_16_graphics_328 = new cjs.Graphics().p("AlXFNQiOiKAAjDIAAAAQAAjCCOiKIAAAAQCPiKDIAAIAAAAQDJAACOCKIAAAAQCPCKAADCIAAAAQAADDiPCKIAAAAQiOCKjJAAIAAAAQjIAAiPiKg");
	var mask_16_graphics_329 = new cjs.Graphics().p("AlfFVQiRiNAAjIIAAAAQAAjHCRiNIAAAAQCSiODNAAIAAAAQDOAACSCOIAAAAQCRCNAADHIAAAAQAADIiRCNIAAAAQiSCOjOAAIAAAAQjNAAiSiOg");
	var mask_16_graphics_330 = new cjs.Graphics().p("AlnFdQiViRAAjMIAAAAQAAjLCViRIAAAAQCViRDSAAIAAAAQDTAACVCRIAAAAQCVCRAADLIAAAAQAADMiVCRIAAAAQiVCRjTAAIAAAAQjSAAiViRg");
	var mask_16_graphics_331 = new cjs.Graphics().p("AlvFlQiYiUAAjRIAAAAQAAjQCYiUIAAAAQCZiTDWAAIAAAAQDXAACZCTIAAAAQCYCUAADQIAAAAQAADRiYCUIAAAAQiZCTjXAAIAAAAQjWAAiZiTg");
	var mask_16_graphics_332 = new cjs.Graphics().p("Al3FsQibiXAAjVIAAAAQAAjUCbiXIAAAAQCciXDbAAIAAAAQDcAACbCXIAAAAQCcCXAADUIAAAAQAADVicCXIAAAAQibCXjcAAIAAAAQjbAAiciXg");
	var mask_16_graphics_333 = new cjs.Graphics().p("Al+F0QifiaAAjaIAAAAQAAjZCfiaIAAAAQCfiaDfAAIAAAAQDgAACfCaIAAAAQCfCaAADZIAAAAQAADaifCaIAAAAQifCajgAAIAAAAQjfAAifiag");
	var mask_16_graphics_334 = new cjs.Graphics().p("AmGF7QihidAAjeIAAAAQAAjdChidIAAAAQCiidDkAAIAAAAQDlAAChCdIAAAAQCiCdAADdIAAAAQAADeiiCdIAAAAQihCdjlAAIAAAAQjkAAiiidg");
	var mask_16_graphics_335 = new cjs.Graphics().p("AmNGCQiligAAjiIAAAAQAAjhCligIAAAAQCligDoAAIAAAAQDpAAClCgIAAAAQClCgAADhIAAAAQAADiilCgIAAAAQilCgjpAAIAAAAQjoAAiligg");
	var mask_16_graphics_336 = new cjs.Graphics().p("AmUGJQioijAAjmIAAAAQAAjlCoijIAAAAQCoijDsAAIAAAAQDtAACoCjIAAAAQCoCjAADlIAAAAQAADmioCjIAAAAQioCjjtAAIAAAAQjsAAioijg");
	var mask_16_graphics_337 = new cjs.Graphics().p("AmbGQQirimAAjqIAAAAQAAjpCrimIAAAAQCrimDwAAIAAAAQDxAACrCmIAAAAQCrCmAADpIAAAAQAADqirCmIAAAAQirCmjxAAIAAAAQjwAAirimg");
	var mask_16_graphics_338 = new cjs.Graphics().p("AmiGXQiuipAAjuIAAAAQAAjtCuipIAAAAQCuioD0AAIAAAAQD1AACuCoIAAAAQCuCpAADtIAAAAQAADuiuCpIAAAAQiuCoj1AAIAAAAQj0AAiuiog");
	var mask_16_graphics_339 = new cjs.Graphics().p("AmpGdQiwirAAjyIAAAAQAAjxCwirIAAAAQCxirD4AAIAAAAQD5AACxCrIAAAAQCwCrAADxIAAAAQAADyiwCrIAAAAQixCrj5AAIAAAAQj4AAixirg");
	var mask_16_graphics_340 = new cjs.Graphics().p("AmwGkQiziuAAj2IAAAAQAAj1CziuIAAAAQC0itD8AAIAAAAQD9AACzCtIAAAAQC0CuAAD1IAAAAQAAD2i0CuIAAAAQizCtj9AAIAAAAQj8AAi0itg");
	var mask_16_graphics_341 = new cjs.Graphics().p("Am2GqQi2ixAAj5IAAAAQAAj4C2ixIAAAAQC2iwEAAAIAAAAQEBAAC2CwIAAAAQC2CxAAD4IAAAAQAAD5i2CxIAAAAQi2CwkBAAIAAAAQkAAAi2iwg");
	var mask_16_graphics_342 = new cjs.Graphics().p("Am8GwQi5izAAj9IAAAAQAAj8C5izIAAAAQC4izEEAAIAAAAQEFAAC4CzIAAAAQC5CzAAD8IAAAAQAAD9i5CzIAAAAQi4CzkFAAIAAAAQkEAAi4izg");
	var mask_16_graphics_343 = new cjs.Graphics().p("AnDG2Qi6i1AAkBIAAAAQAAkAC6i1IAAAAQC8i1EHAAIAAAAQEIAAC7C1IAAAAQC7C1AAEAIAAAAQAAEBi7C1IAAAAQi7C1kIAAIAAAAQkHAAi8i1g");
	var mask_16_graphics_344 = new cjs.Graphics().p("AnJG8Qi9i4AAkEIAAAAQAAkDC9i4IAAAAQC+i4ELAAIAAAAQEMAAC9C4IAAAAQC+C4AAEDIAAAAQAAEEi+C4IAAAAQi9C4kMAAIAAAAQkLAAi+i4g");
	var mask_16_graphics_345 = new cjs.Graphics().p("AnOHBQjAi6AAkHIAAAAQAAkGDAi7IAAAAQDAi6EOAAIAAAAQEPAADAC6IAAAAQDAC7AAEGIAAAAQAAEHjAC6IAAAAQjAC7kPAAIAAAAQkOAAjAi7g");
	var mask_16_graphics_346 = new cjs.Graphics().p("AnUHHQjCi8AAkLIAAAAQAAkKDCi8IAAAAQDCi9ESAAIAAAAQETAADCC9IAAAAQDCC8AAEKIAAAAQAAELjCC8IAAAAQjCC9kTAAIAAAAQkSAAjCi9g");
	var mask_16_graphics_347 = new cjs.Graphics().p("AnaHMQjEi+AAkOIAAAAQAAkNDEi/IAAAAQDFi+EVAAIAAAAQEWAADFC+IAAAAQDEC/AAENIAAAAQAAEOjEC+IAAAAQjFC/kWAAIAAAAQkVAAjFi/g");
	var mask_16_graphics_348 = new cjs.Graphics().p("AnfHSQjHjBAAkRIAAAAQAAkQDHjBIAAAAQDHjBEYAAIAAAAQEZAADHDBIAAAAQDHDBAAEQIAAAAQAAERjHDBIAAAAQjHDBkZAAIAAAAQkYAAjHjBg");
	var mask_16_graphics_349 = new cjs.Graphics().p("AnkHXQjJjDAAkUIAAAAQAAkTDJjDIAAAAQDJjDEbAAIAAAAQEcAADJDDIAAAAQDJDDAAETIAAAAQAAEUjJDDIAAAAQjJDDkcAAIAAAAQkbAAjJjDg");
	var mask_16_graphics_350 = new cjs.Graphics().p("AnqHcQjLjFAAkXIAAAAQAAkWDLjFIAAAAQDMjFEeAAIAAAAQEfAADLDFIAAAAQDMDFAAEWIAAAAQAAEXjMDFIAAAAQjLDFkfAAIAAAAQkeAAjMjFg");
	var mask_16_graphics_351 = new cjs.Graphics().p("AnvHhQjNjHAAkaIAAAAQAAkZDNjHIAAAAQDOjHEhAAIAAAAQEiAADNDHIAAAAQDODHAAEZIAAAAQAAEajODHIAAAAQjNDHkiAAIAAAAQkhAAjOjHg");
	var mask_16_graphics_352 = new cjs.Graphics().p("An0HlQjPjJAAkcIAAAAQAAkbDPjKIAAAAQDQjJEkAAIAAAAQElAADPDJIAAAAQDQDKAAEbIAAAAQAAEcjQDJIAAAAQjPDKklAAIAAAAQkkAAjQjKg");
	var mask_16_graphics_353 = new cjs.Graphics().p("An4HqQjRjLAAkfIAAAAQAAkeDRjLIAAAAQDRjLEnAAIAAAAQEoAADRDLIAAAAQDRDLAAEeIAAAAQAAEfjRDLIAAAAQjRDLkoAAIAAAAQknAAjRjLg");
	var mask_16_graphics_354 = new cjs.Graphics().p("An9HvQjTjNAAkiIAAAAQAAkhDTjNIAAAAQDTjNEqAAIAAAAQErAADTDNIAAAAQDTDNAAEhIAAAAQAAEijTDNIAAAAQjTDNkrAAIAAAAQkqAAjTjNg");
	var mask_16_graphics_355 = new cjs.Graphics().p("AoBHzQjVjPAAkkIAAAAQAAkjDVjPIAAAAQDVjPEsAAIAAAAQEtAADVDPIAAAAQDVDPAAEjIAAAAQAAEkjVDPIAAAAQjVDPktAAIAAAAQksAAjVjPg");
	var mask_16_graphics_356 = new cjs.Graphics().p("AoGH3QjWjQAAknIAAAAQAAkmDWjQIAAAAQDXjREvAAIAAAAQEwAADWDRIAAAAQDXDQAAEmIAAAAQAAEnjXDQIAAAAQjWDRkwAAIAAAAQkvAAjXjRg");
	var mask_16_graphics_357 = new cjs.Graphics().p("AoKH7QjYjSAAkpIAAAAQAAkoDYjSIAAAAQDZjSExAAIAAAAQEyAADZDSIAAAAQDYDSAAEoIAAAAQAAEpjYDSIAAAAQjZDSkyAAIAAAAQkxAAjZjSg");
	var mask_16_graphics_358 = new cjs.Graphics().p("AoOH/QjajUAAkrIAAAAQAAkqDajUIAAAAQDajUE0AAIAAAAQE1AADaDUIAAAAQDaDUAAEqIAAAAQAAErjaDUIAAAAQjaDUk1AAIAAAAQk0AAjajUg");
	var mask_16_graphics_359 = new cjs.Graphics().p("AoSIDQjbjVAAkuIAAAAQAAktDbjVIAAAAQDcjVE2AAIAAAAQE3AADcDVIAAAAQDbDVAAEtIAAAAQAAEujbDVIAAAAQjcDVk3AAIAAAAQk2AAjcjVg");
	var mask_16_graphics_360 = new cjs.Graphics().p("AoWIGQjdjWAAkwIAAAAQAAkvDdjXIAAAAQDejWE4AAIAAAAQE5AADdDWIAAAAQDeDXAAEvIAAAAQAAEwjeDWIAAAAQjdDXk5AAIAAAAQk4AAjejXg");
	var mask_16_graphics_361 = new cjs.Graphics().p("AoZIKQjfjYAAkyIAAAAQAAkxDfjYIAAAAQDfjYE6AAIAAAAQE7AADfDYIAAAAQDfDYAAExIAAAAQAAEyjfDYIAAAAQjfDYk7AAIAAAAQk6AAjfjYg");
	var mask_16_graphics_362 = new cjs.Graphics().p("AodINQjgjZAAk0IAAAAQAAkzDgjaIAAAAQDhjZE8AAIAAAAQE9AADgDZIAAAAQDhDaAAEzIAAAAQAAE0jhDZIAAAAQjgDak9AAIAAAAQk8AAjhjag");
	var mask_16_graphics_363 = new cjs.Graphics().p("AogIRQjijbAAk2IAAAAQAAk1DijbIAAAAQDijbE+AAIAAAAQE/AADiDbIAAAAQDiDbAAE1IAAAAQAAE2jiDbIAAAAQjiDbk/AAIAAAAQk+AAjijbg");
	var mask_16_graphics_364 = new cjs.Graphics().p("AojIUQjjjcAAk4IAAAAQAAk3DjjcIAAAAQDjjcFAAAIAAAAQFBAADjDcIAAAAQDjDcAAE3IAAAAQAAE4jjDcIAAAAQjjDclBAAIAAAAQlAAAjjjcg");
	var mask_16_graphics_365 = new cjs.Graphics().p("AonIXQjkjeAAk5IAAAAQAAk4DkjeIAAAAQDljeFCAAIAAAAQFDAADkDeIAAAAQDlDeAAE4IAAAAQAAE5jlDeIAAAAQjkDelDAAIAAAAQlCAAjljeg");
	var mask_16_graphics_366 = new cjs.Graphics().p("AoqIaQjljfAAk7IAAAAQAAk6DljfIAAAAQDmjfFEAAIAAAAQFFAADlDfIAAAAQDmDfAAE6IAAAAQAAE7jmDfIAAAAQjlDflFAAIAAAAQlEAAjmjfg");
	var mask_16_graphics_367 = new cjs.Graphics().p("AotIdQjmjgAAk9IAAAAQAAk8DmjgIAAAAQDojgFFAAIAAAAQFGAADnDgIAAAAQDnDgAAE8IAAAAQAAE9jnDgIAAAAQjnDglGAAIAAAAQlFAAjojgg");
	var mask_16_graphics_368 = new cjs.Graphics().p("AovIfQjojhAAk+IAAAAQAAk9DojiIAAAAQDojhFHAAIAAAAQFIAADoDhIAAAAQDoDiAAE9IAAAAQAAE+joDhIAAAAQjoDilIAAIAAAAQlHAAjojig");
	var mask_16_graphics_369 = new cjs.Graphics().p("AoyIiQjpjiAAlAIAAAAQAAk/DpjiIAAAAQDpjiFJAAIAAAAQFKAADpDiIAAAAQDpDiAAE/IAAAAQAAFAjpDiIAAAAQjpDilKAAIAAAAQlJAAjpjig");
	var mask_16_graphics_370 = new cjs.Graphics().p("Ao1IlQjqjkAAlBIAAAAQAAlADqjkIAAAAQDrjjFKAAIAAAAQFLAADqDjIAAAAQDrDkAAFAIAAAAQAAFBjrDkIAAAAQjqDjlLAAIAAAAQlKAAjrjjg");
	var mask_16_graphics_371 = new cjs.Graphics().p("Ao3InQjrjkAAlDIAAAAQAAlCDrjkIAAAAQDrjkFMAAIAAAAQFNAADrDkIAAAAQDrDkAAFCIAAAAQAAFDjrDkIAAAAQjrDklNAAIAAAAQlMAAjrjkg");
	var mask_16_graphics_372 = new cjs.Graphics().p("Ao5IpQjsjlAAlEIAAAAQAAlDDsjlIAAAAQDsjmFNAAIAAAAQFOAADsDmIAAAAQDsDlAAFDIAAAAQAAFEjsDlIAAAAQjsDmlOAAIAAAAQlNAAjsjmg");
	var mask_16_graphics_373 = new cjs.Graphics().p("Ao8IrQjtjmAAlFIAAAAQAAlEDtjnIAAAAQDujmFOAAIAAAAQFPAADtDmIAAAAQDuDnAAFEIAAAAQAAFFjuDmIAAAAQjtDnlPAAIAAAAQlOAAjujng");
	var mask_16_graphics_374 = new cjs.Graphics().p("Ao+ItQjujmAAlHIAAAAQAAlGDujnIAAAAQDujnFQAAIAAAAQFRAADtDnIAAAAQDvDnAAFGIAAAAQAAFHjvDmIAAAAQjtDolRAAIAAAAQlQAAjujog");
	var mask_16_graphics_375 = new cjs.Graphics().p("ApAIvQjujnAAlIIAAAAQAAlHDujoIAAAAQDvjnFRAAIAAAAQFSAADuDnIAAAAQDvDoAAFHIAAAAQAAFIjvDnIAAAAQjuDolSAAIAAAAQlRAAjvjog");
	var mask_16_graphics_376 = new cjs.Graphics().p("ApCIxQjvjoAAlJIAAAAQAAlIDvjoIAAAAQDwjpFSAAIAAAAQFTAADvDpIAAAAQDwDoAAFIIAAAAQAAFJjwDoIAAAAQjvDplTAAIAAAAQlSAAjwjpg");
	var mask_16_graphics_377 = new cjs.Graphics().p("ApDIzQjxjpAAlKIAAAAQAAlJDxjpIAAAAQDwjpFTAAIAAAAQFUAADwDpIAAAAQDxDpAAFJIAAAAQAAFKjxDpIAAAAQjwDplUAAIAAAAQlTAAjwjpg");

	this.timeline.addTween(cjs.Tween.get(mask_16).to({graphics:null,x:0,y:0}).wait(294).to({graphics:mask_16_graphics_294,x:75.2004,y:466.9501}).wait(1).to({graphics:mask_16_graphics_295,x:75.2013,y:466.951}).wait(1).to({graphics:mask_16_graphics_296,x:75.2026,y:466.9524}).wait(1).to({graphics:mask_16_graphics_297,x:75.2035,y:466.9533}).wait(1).to({graphics:mask_16_graphics_298,x:75.2044,y:466.9542}).wait(1).to({graphics:mask_16_graphics_299,x:75.2053,y:466.9551}).wait(1).to({graphics:mask_16_graphics_300,x:75.2062,y:466.9565}).wait(1).to({graphics:mask_16_graphics_301,x:75.2076,y:466.9578}).wait(1).to({graphics:mask_16_graphics_302,x:75.2085,y:466.9583}).wait(1).to({graphics:mask_16_graphics_303,x:75.2094,y:466.9596}).wait(1).to({graphics:mask_16_graphics_304,x:75.2107,y:466.9605}).wait(1).to({graphics:mask_16_graphics_305,x:75.2121,y:466.9618}).wait(1).to({graphics:mask_16_graphics_306,x:75.213,y:466.9627}).wait(1).to({graphics:mask_16_graphics_307,x:75.2143,y:466.9641}).wait(1).to({graphics:mask_16_graphics_308,x:75.2152,y:466.965}).wait(1).to({graphics:mask_16_graphics_309,x:75.2162,y:466.9659}).wait(1).to({graphics:mask_16_graphics_310,x:75.217,y:466.9668}).wait(1).to({graphics:mask_16_graphics_311,x:75.2184,y:466.9682}).wait(1).to({graphics:mask_16_graphics_312,x:75.2197,y:466.969}).wait(1).to({graphics:mask_16_graphics_313,x:75.2206,y:466.9699}).wait(1).to({graphics:mask_16_graphics_314,x:75.2215,y:466.9713}).wait(1).to({graphics:mask_16_graphics_315,x:75.2229,y:466.9726}).wait(1).to({graphics:mask_16_graphics_316,x:75.2233,y:466.9731}).wait(1).to({graphics:mask_16_graphics_317,x:75.2247,y:466.9745}).wait(1).to({graphics:mask_16_graphics_318,x:75.2256,y:466.9753}).wait(1).to({graphics:mask_16_graphics_319,x:75.2265,y:466.9762}).wait(1).to({graphics:mask_16_graphics_320,x:75.2274,y:466.9776}).wait(1).to({graphics:mask_16_graphics_321,x:75.2283,y:466.9785}).wait(1).to({graphics:mask_16_graphics_322,x:75.2292,y:466.9789}).wait(1).to({graphics:mask_16_graphics_323,x:75.2305,y:466.9803}).wait(1).to({graphics:mask_16_graphics_324,x:75.2314,y:466.9812}).wait(1).to({graphics:mask_16_graphics_325,x:75.2323,y:466.9821}).wait(1).to({graphics:mask_16_graphics_326,x:75.2332,y:466.983}).wait(1).to({graphics:mask_16_graphics_327,x:75.2342,y:466.9839}).wait(1).to({graphics:mask_16_graphics_328,x:75.2351,y:466.9848}).wait(1).to({graphics:mask_16_graphics_329,x:75.2355,y:466.9853}).wait(1).to({graphics:mask_16_graphics_330,x:75.2369,y:466.9861}).wait(1).to({graphics:mask_16_graphics_331,x:75.2373,y:466.9875}).wait(1).to({graphics:mask_16_graphics_332,x:75.2382,y:466.9879}).wait(1).to({graphics:mask_16_graphics_333,x:75.2395,y:466.9888}).wait(1).to({graphics:mask_16_graphics_334,x:75.24,y:466.9897}).wait(1).to({graphics:mask_16_graphics_335,x:75.2409,y:466.9902}).wait(1).to({graphics:mask_16_graphics_336,x:75.2418,y:466.9911}).wait(1).to({graphics:mask_16_graphics_337,x:75.2422,y:466.992}).wait(1).to({graphics:mask_16_graphics_338,x:75.2431,y:466.9929}).wait(1).to({graphics:mask_16_graphics_339,x:75.2436,y:466.9938}).wait(1).to({graphics:mask_16_graphics_340,x:75.2445,y:466.9942}).wait(1).to({graphics:mask_16_graphics_341,x:75.2454,y:466.9947}).wait(1).to({graphics:mask_16_graphics_342,x:75.2458,y:466.9956}).wait(1).to({graphics:mask_16_graphics_343,x:75.2463,y:466.996}).wait(1).to({graphics:mask_16_graphics_344,x:75.2472,y:466.9969}).wait(1).to({graphics:mask_16_graphics_345,x:75.2481,y:466.9974}).wait(1).to({graphics:mask_16_graphics_346,x:75.2485,y:466.9983}).wait(1).to({graphics:mask_16_graphics_347,x:75.249,y:466.9983}).wait(1).to({graphics:mask_16_graphics_348,x:75.2494,y:466.9992}).wait(1).to({graphics:mask_16_graphics_349,x:75.2499,y:466.9996}).wait(1).to({graphics:mask_16_graphics_350,x:75.2508,y:467.0001}).wait(1).to({graphics:mask_16_graphics_351,x:75.2508,y:467.001}).wait(1).to({graphics:mask_16_graphics_352,x:75.2517,y:467.001}).wait(1).to({graphics:mask_16_graphics_353,x:75.2521,y:467.0019}).wait(1).to({graphics:mask_16_graphics_354,x:75.2526,y:467.0023}).wait(1).to({graphics:mask_16_graphics_355,x:75.253,y:467.0028}).wait(1).to({graphics:mask_16_graphics_356,x:75.2535,y:467.0032}).wait(1).to({graphics:mask_16_graphics_357,x:75.2544,y:467.0037}).wait(1).to({graphics:mask_16_graphics_358,x:75.2544,y:467.0042}).wait(1).to({graphics:mask_16_graphics_359,x:75.2548,y:467.0046}).wait(1).to({graphics:mask_16_graphics_360,x:75.2553,y:467.0051}).wait(1).to({graphics:mask_16_graphics_361,x:75.2557,y:467.0055}).wait(1).to({graphics:mask_16_graphics_362,x:75.2562,y:467.0059}).wait(1).to({graphics:mask_16_graphics_363,x:75.2567,y:467.0059}).wait(1).to({graphics:mask_16_graphics_364,x:75.2567,y:467.0064}).wait(1).to({graphics:mask_16_graphics_365,x:75.2571,y:467.0069}).wait(1).to({graphics:mask_16_graphics_366,x:75.2575,y:467.0069}).wait(1).to({graphics:mask_16_graphics_367,x:75.2575,y:467.0073}).wait(1).to({graphics:mask_16_graphics_368,x:75.258,y:467.0077}).wait(1).to({graphics:mask_16_graphics_369,x:75.2584,y:467.0082}).wait(1).to({graphics:mask_16_graphics_370,x:75.2589,y:467.0082}).wait(1).to({graphics:mask_16_graphics_371,x:75.2589,y:467.0087}).wait(1).to({graphics:mask_16_graphics_372,x:75.2593,y:467.0086}).wait(1).to({graphics:mask_16_graphics_373,x:75.2593,y:467.0091}).wait(1).to({graphics:mask_16_graphics_374,x:75.2593,y:467.0091}).wait(1).to({graphics:mask_16_graphics_375,x:75.2598,y:467.0095}).wait(1).to({graphics:mask_16_graphics_376,x:75.2602,y:467.0096}).wait(1).to({graphics:mask_16_graphics_377,x:75.208,y:466.9042}).wait(433));

	// Layer_21
	this.instance_29 = new lib.Tween48("synched",0);
	this.instance_29.setTransform(44.65,449.4);
	this.instance_29.alpha = 0.5;
	this.instance_29._off = true;

	var maskedShapeInstanceList = [this.instance_29];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_16;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(294).to({_off:false},0).to({alpha:1},83).wait(433));

	// Layer_6 (mask)
	var mask_17 = new cjs.Shape();
	mask_17._off = true;
	var mask_17_graphics_264 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_17_graphics_265 = new cjs.Graphics().p("AgXAXQgKgJAAgOIAAAAQAAgNAKgJIAAAAQAKgKANAAIAAAAQAOAAAKAKIAAAAQAKAJAAANIAAAAQAAAOgKAJIAAAAQgKAKgOAAIAAAAQgNAAgKgKg");
	var mask_17_graphics_266 = new cjs.Graphics().p("AgeAeQgNgMAAgSIAAAAQAAgRANgMIAAAAQANgNARAAIAAAAQASAAANANIAAAAQANAMAAARIAAAAQAAASgNAMIAAAAQgNANgSAAIAAAAQgRAAgNgNg");
	var mask_17_graphics_267 = new cjs.Graphics().p("AglAlQgQgPAAgWIAAAAQAAgVAQgPIAAAAQAPgPAWAAIAAAAQAXAAAPAPIAAAAQAQAPAAAVIAAAAQAAAWgQAPIAAAAQgPAPgXAAIAAAAQgWAAgPgPg");
	var mask_17_graphics_268 = new cjs.Graphics().p("AgtAsQgSgSAAgaIAAAAQAAgZASgSIAAAAQATgSAaAAIAAAAQAbAAATASIAAAAQASASAAAZIAAAAQAAAagSASIAAAAQgTASgbAAIAAAAQgaAAgTgSg");
	var mask_17_graphics_269 = new cjs.Graphics().p("Ag0AzQgWgVAAgeIAAAAQAAgdAWgVIAAAAQAWgVAeAAIAAAAQAfAAAWAVIAAAAQAWAVAAAdIAAAAQAAAegWAVIAAAAQgWAVgfAAIAAAAQgeAAgWgVg");
	var mask_17_graphics_270 = new cjs.Graphics().p("Ag7A6QgZgYAAgiIAAAAQAAghAZgYIAAAAQAZgYAiAAIAAAAQAjAAAZAYIAAAAQAZAYAAAhIAAAAQAAAigZAYIAAAAQgZAYgjAAIAAAAQgiAAgZgYg");
	var mask_17_graphics_271 = new cjs.Graphics().p("AhCBBQgcgbAAgmIAAAAQAAglAcgbIAAAAQAcgbAmAAIAAAAQAnAAAcAbIAAAAQAcAbAAAlIAAAAQAAAmgcAbIAAAAQgcAbgnAAIAAAAQgmAAgcgbg");
	var mask_17_graphics_272 = new cjs.Graphics().p("AhJBIQgfgeAAgqIAAAAQAAgpAfgeIAAAAQAegeArAAIAAAAQAsAAAeAeIAAAAQAfAeAAApIAAAAQAAAqgfAeIAAAAQgeAegsAAIAAAAQgrAAgegeg");
	var mask_17_graphics_273 = new cjs.Graphics().p("AhRBPQgighAAguIAAAAQAAgtAighIAAAAQAighAvAAIAAAAQAwAAAiAhIAAAAQAiAhAAAtIAAAAQAAAugiAhIAAAAQgiAhgwAAIAAAAQgvAAgighg");
	var mask_17_graphics_274 = new cjs.Graphics().p("AhYBWQglgkAAgyIAAAAQAAgxAlgkIAAAAQAlgkAzAAIAAAAQA0AAAlAkIAAAAQAlAkAAAxIAAAAQAAAyglAkIAAAAQglAkg0AAIAAAAQgzAAglgkg");
	var mask_17_graphics_275 = new cjs.Graphics().p("AhfBdQgogmAAg3IAAAAQAAg2AogmIAAAAQAognA3AAIAAAAQA4AAAoAnIAAAAQAoAmAAA2IAAAAQAAA3goAmIAAAAQgoAng4AAIAAAAQg3AAgogng");
	var mask_17_graphics_276 = new cjs.Graphics().p("AhnBkQgrgpAAg7IAAAAQAAg6ArgpIAAAAQArgqA8AAIAAAAQA9AAArAqIAAAAQArApAAA6IAAAAQAAA7grApIAAAAQgrAqg9AAIAAAAQg8AAgrgqg");
	var mask_17_graphics_277 = new cjs.Graphics().p("AhuBrQgugsAAg/IAAAAQAAg+AugtIAAAAQAugsBAAAIAAAAQBBAAAuAsIAAAAQAuAtAAA+IAAAAQAAA/guAsIAAAAQguAthBAAIAAAAQhAAAgugtg");
	var mask_17_graphics_278 = new cjs.Graphics().p("Ah1BzQgxgwAAhDIAAAAQAAhCAxgwIAAAAQAxgvBEAAIAAAAQBFAAAxAvIAAAAQAxAwAABCIAAAAQAABDgxAwIAAAAQgxAvhFAAIAAAAQhEAAgxgvg");
	var mask_17_graphics_279 = new cjs.Graphics().p("Ah9B6Qg0gzAAhHIAAAAQAAhGA0gzIAAAAQA0gyBJAAIAAAAQBKAAA0AyIAAAAQA0AzAABGIAAAAQAABHg0AzIAAAAQg0AyhKAAIAAAAQhJAAg0gyg");
	var mask_17_graphics_280 = new cjs.Graphics().p("AiECBQg3g2AAhLIAAAAQAAhKA3g2IAAAAQA3g1BNAAIAAAAQBOAAA3A1IAAAAQA3A2AABKIAAAAQAABLg3A2IAAAAQg3A1hOAAIAAAAQhNAAg3g1g");
	var mask_17_graphics_281 = new cjs.Graphics().p("AiLCIQg6g4AAhQIAAAAQAAhPA6g4IAAAAQA6g4BRAAIAAAAQBSAAA6A4IAAAAQA6A4AABPIAAAAQAABQg6A4IAAAAQg6A4hSAAIAAAAQhRAAg6g4g");
	var mask_17_graphics_282 = new cjs.Graphics().p("AiTCPQg9g7AAhUIAAAAQAAhTA9g7IAAAAQA+g7BVAAIAAAAQBWAAA+A7IAAAAQA9A7AABTIAAAAQAABUg9A7IAAAAQg+A7hWAAIAAAAQhVAAg+g7g");
	var mask_17_graphics_283 = new cjs.Graphics().p("AiaCWQhAg+AAhYIAAAAQAAhXBAg+IAAAAQBAg+BaAAIAAAAQBbAABAA+IAAAAQBAA+AABXIAAAAQAABYhAA+IAAAAQhAA+hbAAIAAAAQhaAAhAg+g");
	var mask_17_graphics_284 = new cjs.Graphics().p("AihCdQhDhBAAhcIAAAAQAAhbBDhBIAAAAQBDhBBeAAIAAAAQBfAABDBBIAAAAQBDBBAABbIAAAAQAABchDBBIAAAAQhDBBhfAAIAAAAQheAAhDhBg");
	var mask_17_graphics_285 = new cjs.Graphics().p("AipCkQhGhEAAhgIAAAAQAAhfBGhEIAAAAQBHhEBiAAIAAAAQBjAABHBEIAAAAQBGBEAABfIAAAAQAABghGBEIAAAAQhHBEhjAAIAAAAQhiAAhHhEg");
	var mask_17_graphics_286 = new cjs.Graphics().p("AiwCrQhJhHAAhkIAAAAQAAhjBJhHIAAAAQBJhHBnAAIAAAAQBoAABJBHIAAAAQBJBHAABjIAAAAQAABkhJBHIAAAAQhJBHhoAAIAAAAQhnAAhJhHg");
	var mask_17_graphics_287 = new cjs.Graphics().p("Ai3CyQhMhJAAhpIAAAAQAAhoBMhKIAAAAQBMhJBrAAIAAAAQBsAABMBJIAAAAQBMBKAABoIAAAAQAABphMBJIAAAAQhMBKhsAAIAAAAQhrAAhMhKg");
	var mask_17_graphics_288 = new cjs.Graphics().p("Ai+C5QhQhMAAhtIAAAAQAAhsBQhNIAAAAQBPhMBvAAIAAAAQBwAABPBMIAAAAQBQBNAABsIAAAAQAABthQBMIAAAAQhPBNhwAAIAAAAQhvAAhPhNg");
	var mask_17_graphics_289 = new cjs.Graphics().p("AjGDAQhShPAAhxIAAAAQAAhwBShQIAAAAQBThPBzAAIAAAAQB0AABSBPIAAAAQBTBQAABwIAAAAQAABxhTBPIAAAAQhSBQh0AAIAAAAQhzAAhThQg");
	var mask_17_graphics_290 = new cjs.Graphics().p("AjNDHQhVhSAAh1IAAAAQAAh0BVhTIAAAAQBWhSB3AAIAAAAQB4AABWBSIAAAAQBVBTAAB0IAAAAQAAB1hVBSIAAAAQhWBTh4AAIAAAAQh3AAhWhTg");
	var mask_17_graphics_291 = new cjs.Graphics().p("AjUDOQhYhVAAh5IAAAAQAAh4BYhVIAAAAQBYhWB8AAIAAAAQB9AABYBWIAAAAQBYBVAAB4IAAAAQAAB5hYBVIAAAAQhYBWh9AAIAAAAQh8AAhYhWg");
	var mask_17_graphics_292 = new cjs.Graphics().p("AjbDVQhbhYAAh9IAAAAQAAh8BbhYIAAAAQBbhZCAAAIAAAAQCBAABbBZIAAAAQBbBYAAB8IAAAAQAAB9hbBYIAAAAQhbBZiBAAIAAAAQiAAAhbhZg");
	var mask_17_graphics_293 = new cjs.Graphics().p("AjiDcQhehbAAiBIAAAAQAAiABehbIAAAAQBehbCEAAIAAAAQCFAABeBbIAAAAQBeBbAACAIAAAAQAACBheBbIAAAAQheBbiFAAIAAAAQiEAAhehbg");
	var mask_17_graphics_294 = new cjs.Graphics().p("AjpDjQhhheAAiFIAAAAQAAiEBhheIAAAAQBhheCIAAIAAAAQCJAABhBeIAAAAQBhBeAACEIAAAAQAACFhhBeIAAAAQhhBeiJAAIAAAAQiIAAhhheg");
	var mask_17_graphics_295 = new cjs.Graphics().p("AjwDqQhkhhAAiJIAAAAQAAiIBkhhIAAAAQBkhhCMAAIAAAAQCNAABkBhIAAAAQBkBhAACIIAAAAQAACJhkBhIAAAAQhkBhiNAAIAAAAQiMAAhkhhg");
	var mask_17_graphics_296 = new cjs.Graphics().p("Aj3DxQhnhkAAiNIAAAAQAAiMBnhkIAAAAQBnhjCQAAIAAAAQCRAABnBjIAAAAQBnBkAACMIAAAAQAACNhnBkIAAAAQhnBjiRAAIAAAAQiQAAhnhjg");
	var mask_17_graphics_297 = new cjs.Graphics().p("Aj+D3QhqhmAAiRIAAAAQAAiQBqhmIAAAAQBqhnCUAAIAAAAQCVAABqBnIAAAAQBqBmAACQIAAAAQAACRhqBmIAAAAQhqBniVAAIAAAAQiUAAhqhng");
	var mask_17_graphics_298 = new cjs.Graphics().p("AkFD+QhshpAAiVIAAAAQAAiUBshpIAAAAQBthpCYAAIAAAAQCZAABtBpIAAAAQBsBpAACUIAAAAQAACVhsBpIAAAAQhtBpiZAAIAAAAQiYAAhthpg");
	var mask_17_graphics_299 = new cjs.Graphics().p("AkMEEQhvhrAAiZIAAAAQAAiYBvhsIAAAAQBwhrCcAAIAAAAQCdAABwBrIAAAAQBvBsAACYIAAAAQAACZhvBrIAAAAQhwBsidAAIAAAAQicAAhwhsg");
	var mask_17_graphics_300 = new cjs.Graphics().p("AkSELQhyhvAAicIAAAAQAAibByhvIAAAAQByhvCgAAIAAAAQChAAByBvIAAAAQByBvAACbIAAAAQAACchyBvIAAAAQhyBvihAAIAAAAQigAAhyhvg");
	var mask_17_graphics_301 = new cjs.Graphics().p("AkZESQh1hyAAigIAAAAQAAifB1hyIAAAAQB1hxCkAAIAAAAQClAAB1BxIAAAAQB1ByAACfIAAAAQAACgh1ByIAAAAQh1BxilAAIAAAAQikAAh1hxg");
	var mask_17_graphics_302 = new cjs.Graphics().p("AkgEYQh3h0AAikIAAAAQAAijB3h0IAAAAQB4h0CoAAIAAAAQCpAAB4B0IAAAAQB3B0AACjIAAAAQAACkh3B0IAAAAQh4B0ipAAIAAAAQioAAh4h0g");
	var mask_17_graphics_303 = new cjs.Graphics().p("AkmEeQh7h2AAioIAAAAQAAinB7h3IAAAAQB6h2CsAAIAAAAQCtAAB6B2IAAAAQB7B3AACnIAAAAQAACoh7B2IAAAAQh6B3itAAIAAAAQisAAh6h3g");
	var mask_17_graphics_304 = new cjs.Graphics().p("AktElQh9h5AAisIAAAAQAAirB9h5IAAAAQB9h5CwAAIAAAAQCxAAB9B5IAAAAQB9B5AACrIAAAAQAACsh9B5IAAAAQh9B5ixAAIAAAAQiwAAh9h5g");
	var mask_17_graphics_305 = new cjs.Graphics().p("AkzErQiAh8AAivIAAAAQAAiuCAh8IAAAAQB/h8C0AAIAAAAQC1AAB/B8IAAAAQCAB8AACuIAAAAQAACviAB8IAAAAQh/B8i1AAIAAAAQi0AAh/h8g");
	var mask_17_graphics_306 = new cjs.Graphics().p("Ak6ExQiCh+AAizIAAAAQAAiyCCh+IAAAAQCDh/C3AAIAAAAQC4AACDB/IAAAAQCCB+AACyIAAAAQAACziCB+IAAAAQiDB/i4AAIAAAAQi3AAiDh/g");
	var mask_17_graphics_307 = new cjs.Graphics().p("AlAE3QiFiBAAi2IAAAAQAAi1CFiCIAAAAQCFiBC7AAIAAAAQC8AACFCBIAAAAQCFCCAAC1IAAAAQAAC2iFCBIAAAAQiFCCi8AAIAAAAQi7AAiFiCg");
	var mask_17_graphics_308 = new cjs.Graphics().p("AlGE+QiIiEAAi6IAAAAQAAi5CIiEIAAAAQCHiDC/AAIAAAAQDAAACHCDIAAAAQCICEAAC5IAAAAQAAC6iICEIAAAAQiHCDjAAAIAAAAQi/AAiHiDg");
	var mask_17_graphics_309 = new cjs.Graphics().p("AlNFEQiKiGAAi+IAAAAQAAi9CKiGIAAAAQCLiGDCAAIAAAAQDDAACLCGIAAAAQCKCGAAC9IAAAAQAAC+iKCGIAAAAQiLCGjDAAIAAAAQjCAAiLiGg");
	var mask_17_graphics_310 = new cjs.Graphics().p("AlTFKQiNiJAAjBIAAAAQAAjACNiJIAAAAQCNiIDGAAIAAAAQDHAACNCIIAAAAQCNCJAADAIAAAAQAADBiNCJIAAAAQiNCIjHAAIAAAAQjGAAiNiIg");
	var mask_17_graphics_311 = new cjs.Graphics().p("AlZFPQiPiKAAjFIAAAAQAAjECPiLIAAAAQCPiLDKAAIAAAAQDLAACPCLIAAAAQCPCLAADEIAAAAQAADFiPCKIAAAAQiPCMjLAAIAAAAQjKAAiPiMg");
	var mask_17_graphics_312 = new cjs.Graphics().p("AlfFVQiSiNAAjIIAAAAQAAjHCSiNIAAAAQCSiODNAAIAAAAQDOAACSCOIAAAAQCSCNAADHIAAAAQAADIiSCNIAAAAQiSCOjOAAIAAAAQjNAAiSiOg");
	var mask_17_graphics_313 = new cjs.Graphics().p("AllFbQiUiQAAjLIAAAAQAAjKCUiQIAAAAQCUiQDRAAIAAAAQDSAACUCQIAAAAQCUCQAADKIAAAAQAADLiUCQIAAAAQiUCQjSAAIAAAAQjRAAiUiQg");
	var mask_17_graphics_314 = new cjs.Graphics().p("AlrFhQiWiSAAjPIAAAAQAAjOCWiSIAAAAQCXiSDUAAIAAAAQDVAACXCSIAAAAQCWCSAADOIAAAAQAADPiWCSIAAAAQiXCSjVAAIAAAAQjUAAiXiSg");
	var mask_17_graphics_315 = new cjs.Graphics().p("AlxFmQiZiUAAjSIAAAAQAAjRCZiVIAAAAQCaiUDXAAIAAAAQDYAACZCUIAAAAQCaCVAADRIAAAAQAADSiaCUIAAAAQiZCVjYAAIAAAAQjXAAiaiVg");
	var mask_17_graphics_316 = new cjs.Graphics().p("Al2FsQiciXAAjVIAAAAQAAjUCciXIAAAAQCbiXDbAAIAAAAQDcAACbCXIAAAAQCcCXAADUIAAAAQAADVicCXIAAAAQibCXjcAAIAAAAQjbAAibiXg");
	var mask_17_graphics_317 = new cjs.Graphics().p("Al8FxQieiZAAjYIAAAAQAAjXCeiaIAAAAQCeiZDeAAIAAAAQDfAACeCZIAAAAQCeCaAADXIAAAAQAADYieCZIAAAAQieCajfAAIAAAAQjeAAieiag");
	var mask_17_graphics_318 = new cjs.Graphics().p("AmCF3QigibAAjcIAAAAQAAjbCgibIAAAAQChibDhAAIAAAAQDiAACgCbIAAAAQChCbAADbIAAAAQAADcihCbIAAAAQigCbjiAAIAAAAQjhAAihibg");
	var mask_17_graphics_319 = new cjs.Graphics().p("AmHF8QiiidAAjfIAAAAQAAjeCiidIAAAAQCiieDlAAIAAAAQDmAACiCeIAAAAQCiCdAADeIAAAAQAADfiiCdIAAAAQiiCejmAAIAAAAQjlAAiiieg");
	var mask_17_graphics_320 = new cjs.Graphics().p("AmMGBQilifAAjiIAAAAQAAjhCligIAAAAQCkifDoAAIAAAAQDpAACkCfIAAAAQClCgAADhIAAAAQAADiilCfIAAAAQikCgjpAAIAAAAQjoAAikigg");
	var mask_17_graphics_321 = new cjs.Graphics().p("AmSGHQiniiAAjlIAAAAQAAjkCniiIAAAAQCniiDrAAIAAAAQDsAACnCiIAAAAQCnCiAADkIAAAAQAADlinCiIAAAAQinCijsAAIAAAAQjrAAiniig");
	var mask_17_graphics_322 = new cjs.Graphics().p("AmXGMQipikAAjoIAAAAQAAjnCpikIAAAAQCpikDuAAIAAAAQDvAACpCkIAAAAQCpCkAADnIAAAAQAADoipCkIAAAAQipCkjvAAIAAAAQjuAAipikg");
	var mask_17_graphics_323 = new cjs.Graphics().p("AmcGRQirimAAjrIAAAAQAAjqCrimIAAAAQCrimDxAAIAAAAQDyAACrCmIAAAAQCrCmAADqIAAAAQAADrirCmIAAAAQirCmjyAAIAAAAQjxAAirimg");
	var mask_17_graphics_324 = new cjs.Graphics().p("AmhGWQiuioAAjuIAAAAQAAjtCuioIAAAAQCtioD0AAIAAAAQD1AACtCoIAAAAQCuCoAADtIAAAAQAADuiuCoIAAAAQitCoj1AAIAAAAQj0AAitiog");
	var mask_17_graphics_325 = new cjs.Graphics().p("AmnGbQiviqAAjxIAAAAQAAjwCviqIAAAAQCwiqD3AAIAAAAQD4AACvCqIAAAAQCwCqAADwIAAAAQAADxiwCqIAAAAQivCqj4AAIAAAAQj3AAiwiqg");
	var mask_17_graphics_326 = new cjs.Graphics().p("AmrGgQiyitAAjzIAAAAQAAjyCyitIAAAAQCxisD6AAIAAAAQD7AACxCsIAAAAQCyCtAADyIAAAAQAADziyCtIAAAAQixCsj7AAIAAAAQj6AAixisg");
	var mask_17_graphics_327 = new cjs.Graphics().p("AmwGkQi0iuAAj2IAAAAQAAj1C0ivIAAAAQCziuD9AAIAAAAQD+AACzCuIAAAAQC0CvAAD1IAAAAQAAD2i0CuIAAAAQizCvj+AAIAAAAQj9AAizivg");
	var mask_17_graphics_328 = new cjs.Graphics().p("Am1GpQi2iwAAj5IAAAAQAAj4C2iwIAAAAQC1iwEAAAIAAAAQEBAAC1CwIAAAAQC2CwAAD4IAAAAQAAD5i2CwIAAAAQi1CwkBAAIAAAAQkAAAi1iwg");
	var mask_17_graphics_329 = new cjs.Graphics().p("Am6GuQi3iyAAj8IAAAAQAAj7C3iyIAAAAQC4iyECAAIAAAAQEDAAC4CyIAAAAQC3CyAAD7IAAAAQAAD8i3CyIAAAAQi4CykDAAIAAAAQkCAAi4iyg");
	var mask_17_graphics_330 = new cjs.Graphics().p("Am/GyQi5i0AAj+IAAAAQAAj9C5i0IAAAAQC6i0EFAAIAAAAQEGAAC5C0IAAAAQC6C0AAD9IAAAAQAAD+i6C0IAAAAQi5C0kGAAIAAAAQkFAAi6i0g");
	var mask_17_graphics_331 = new cjs.Graphics().p("AnDG3Qi7i2AAkBIAAAAQAAkAC7i2IAAAAQC7i1EIAAIAAAAQEJAAC7C1IAAAAQC7C2AAEAIAAAAQAAEBi7C2IAAAAQi7C1kJAAIAAAAQkIAAi7i1g");
	var mask_17_graphics_332 = new cjs.Graphics().p("AnIG7Qi9i3AAkEIAAAAQAAkDC9i3IAAAAQC+i4EKAAIAAAAQELAAC+C4IAAAAQC9C3AAEDIAAAAQAAEEi9C3IAAAAQi+C4kLAAIAAAAQkKAAi+i4g");
	var mask_17_graphics_333 = new cjs.Graphics().p("AnMG/Qi/i5AAkGIAAAAQAAkFC/i5IAAAAQC/i6ENAAIAAAAQEOAAC/C6IAAAAQC/C5AAEFIAAAAQAAEGi/C5IAAAAQi/C6kOAAIAAAAQkNAAi/i6g");
	var mask_17_graphics_334 = new cjs.Graphics().p("AnRHDQjAi6AAkJIAAAAQAAkIDAi7IAAAAQDBi7EQAAIAAAAQERAADAC7IAAAAQDBC7AAEIIAAAAQAAEJjBC6IAAAAQjAC8kRAAIAAAAQkQAAjBi8g");
	var mask_17_graphics_335 = new cjs.Graphics().p("AnVHIQjCi9AAkLIAAAAQAAkKDCi9IAAAAQDDi9ESAAIAAAAQETAADDC9IAAAAQDCC9AAEKIAAAAQAAELjCC9IAAAAQjDC9kTAAIAAAAQkSAAjDi9g");
	var mask_17_graphics_336 = new cjs.Graphics().p("AnZHMQjEi/AAkNIAAAAQAAkMDEi/IAAAAQDEi+EVAAIAAAAQEWAADEC+IAAAAQDEC/AAEMIAAAAQAAENjEC/IAAAAQjEC+kWAAIAAAAQkVAAjEi+g");
	var mask_17_graphics_337 = new cjs.Graphics().p("AndHQQjGjAAAkQIAAAAQAAkPDGjAIAAAAQDGjAEXAAIAAAAQEYAADGDAIAAAAQDGDAAAEPIAAAAQAAEQjGDAIAAAAQjGDAkYAAIAAAAQkXAAjGjAg");
	var mask_17_graphics_338 = new cjs.Graphics().p("AnhHUQjIjCAAkSIAAAAQAAkRDIjCIAAAAQDIjCEZAAIAAAAQEaAADIDCIAAAAQDIDCAAERIAAAAQAAESjIDCIAAAAQjIDCkaAAIAAAAQkZAAjIjCg");
	var mask_17_graphics_339 = new cjs.Graphics().p("AnlHYQjJjEAAkUIAAAAQAAkTDJjEIAAAAQDJjDEcAAIAAAAQEdAADJDDIAAAAQDJDEAAETIAAAAQAAEUjJDEIAAAAQjJDDkdAAIAAAAQkcAAjJjDg");
	var mask_17_graphics_340 = new cjs.Graphics().p("AnpHbQjLjFAAkWIAAAAQAAkVDLjGIAAAAQDLjEEeAAIAAAAQEfAADLDEIAAAAQDLDGAAEVIAAAAQAAEWjLDFIAAAAQjLDFkfAAIAAAAQkeAAjLjFg");
	var mask_17_graphics_341 = new cjs.Graphics().p("AntHfQjMjGAAkZIAAAAQAAkYDMjGIAAAAQDNjHEgAAIAAAAQEhAADNDHIAAAAQDMDGAAEYIAAAAQAAEZjMDGIAAAAQjNDHkhAAIAAAAQkgAAjNjHg");
	var mask_17_graphics_342 = new cjs.Graphics().p("AnxHjQjOjIAAkbIAAAAQAAkaDOjIIAAAAQDPjIEiAAIAAAAQEjAADODIIAAAAQDPDIAAEaIAAAAQAAEbjPDIIAAAAQjODIkjAAIAAAAQkiAAjPjIg");
	var mask_17_graphics_343 = new cjs.Graphics().p("An0HmQjQjJAAkdIAAAAQAAkcDQjJIAAAAQDPjKElAAIAAAAQEmAADPDKIAAAAQDQDJAAEcIAAAAQAAEdjQDJIAAAAQjPDKkmAAIAAAAQklAAjPjKg");
	var mask_17_graphics_344 = new cjs.Graphics().p("An4HqQjRjLAAkfIAAAAQAAkeDRjLIAAAAQDRjLEnAAIAAAAQEoAADRDLIAAAAQDRDLAAEeIAAAAQAAEfjRDLIAAAAQjRDLkoAAIAAAAQknAAjRjLg");
	var mask_17_graphics_345 = new cjs.Graphics().p("An7HtQjTjMAAkhIAAAAQAAkgDTjMIAAAAQDSjNEpAAIAAAAQEqAADSDNIAAAAQDTDMAAEgIAAAAQAAEhjTDMIAAAAQjSDNkqAAIAAAAQkpAAjSjNg");
	var mask_17_graphics_346 = new cjs.Graphics().p("An/HxQjUjOAAkjIAAAAQAAkiDUjOIAAAAQDUjNErAAIAAAAQEsAADUDNIAAAAQDUDOAAEiIAAAAQAAEjjUDOIAAAAQjUDNksAAIAAAAQkrAAjUjNg");
	var mask_17_graphics_347 = new cjs.Graphics().p("AoCH0QjWjPAAklIAAAAQAAkkDWjPIAAAAQDVjPEtAAIAAAAQEuAADVDPIAAAAQDWDPAAEkIAAAAQAAEljWDPIAAAAQjVDPkuAAIAAAAQktAAjVjPg");
	var mask_17_graphics_348 = new cjs.Graphics().p("AoGH3QjWjQAAknIAAAAQAAkmDWjQIAAAAQDXjREvAAIAAAAQEwAADWDRIAAAAQDXDQAAEmIAAAAQAAEnjXDQIAAAAQjWDRkwAAIAAAAQkvAAjXjRg");
	var mask_17_graphics_349 = new cjs.Graphics().p("AoJH6QjYjRAAkpIAAAAQAAkoDYjRIAAAAQDYjSExAAIAAAAQEyAADYDSIAAAAQDYDRAAEoIAAAAQAAEpjYDRIAAAAQjYDSkyAAIAAAAQkxAAjYjSg");
	var mask_17_graphics_350 = new cjs.Graphics().p("AoMH9QjZjTAAkqIAAAAQAAkpDZjUIAAAAQDajSEyAAIAAAAQEzAADaDSIAAAAQDZDUAAEpIAAAAQAAEqjZDTIAAAAQjaDTkzAAIAAAAQkyAAjajTg");
	var mask_17_graphics_351 = new cjs.Graphics().p("AoPIAQjbjUAAksIAAAAQAAkrDbjVIAAAAQDbjUE0AAIAAAAQE1AADbDUIAAAAQDbDVAAErIAAAAQAAEsjbDUIAAAAQjbDVk1AAIAAAAQk0AAjbjVg");
	var mask_17_graphics_352 = new cjs.Graphics().p("AoSIDQjcjVAAkuIAAAAQAAktDcjVIAAAAQDcjWE2AAIAAAAQE3AADcDWIAAAAQDcDVAAEtIAAAAQAAEujcDVIAAAAQjcDWk3AAIAAAAQk2AAjcjWg");
	var mask_17_graphics_353 = new cjs.Graphics().p("AoVIGQjdjWAAkwIAAAAQAAkvDdjWIAAAAQDdjXE4AAIAAAAQE5AADdDXIAAAAQDdDWAAEvIAAAAQAAEwjdDWIAAAAQjdDXk5AAIAAAAQk4AAjdjXg");
	var mask_17_graphics_354 = new cjs.Graphics().p("AoYIJQjejYAAkxIAAAAQAAkwDejYIAAAAQDfjYE5AAIAAAAQE6AADfDYIAAAAQDeDYAAEwIAAAAQAAExjeDYIAAAAQjfDYk6AAIAAAAQk5AAjfjYg");
	var mask_17_graphics_355 = new cjs.Graphics().p("AobIMQjfjZAAkzIAAAAQAAkyDfjZIAAAAQDgjZE7AAIAAAAQE8AADgDZIAAAAQDfDZAAEyIAAAAQAAEzjfDZIAAAAQjgDZk8AAIAAAAQk7AAjgjZg");
	var mask_17_graphics_356 = new cjs.Graphics().p("AoeIOQjgjaAAk0IAAAAQAAkzDgjbIAAAAQDhjaE9AAIAAAAQE+AADgDaIAAAAQDhDbAAEzIAAAAQAAE0jhDaIAAAAQjgDbk+AAIAAAAQk9AAjhjbg");
	var mask_17_graphics_357 = new cjs.Graphics().p("AogIRQjijbAAk2IAAAAQAAk1DijbIAAAAQDijbE+AAIAAAAQE/AADiDbIAAAAQDiDbAAE1IAAAAQAAE2jiDbIAAAAQjiDbk/AAIAAAAQk+AAjijbg");
	var mask_17_graphics_358 = new cjs.Graphics().p("AojITQjjjcAAk3IAAAAQAAk2DjjdIAAAAQDjjcFAAAIAAAAQFBAADjDcIAAAAQDjDdAAE2IAAAAQAAE3jjDcIAAAAQjjDdlBAAIAAAAQlAAAjjjdg");
	var mask_17_graphics_359 = new cjs.Graphics().p("AomIWQjjjdAAk5IAAAAQAAk4DjjdIAAAAQDljdFBAAIAAAAQFCAADkDdIAAAAQDkDdAAE4IAAAAQAAE5jkDdIAAAAQjkDdlCAAIAAAAQlBAAjljdg");
	var mask_17_graphics_360 = new cjs.Graphics().p("AooIYQjljeAAk6IAAAAQAAk5DljfIAAAAQDljeFDAAIAAAAQFEAADlDeIAAAAQDlDfAAE5IAAAAQAAE6jlDeIAAAAQjlDflEAAIAAAAQlDAAjljfg");
	var mask_17_graphics_361 = new cjs.Graphics().p("AoqIbQjmjfAAk8IAAAAQAAk7DmjfIAAAAQDmjfFEAAIAAAAQFFAADmDfIAAAAQDmDfAAE7IAAAAQAAE8jmDfIAAAAQjmDflFAAIAAAAQlEAAjmjfg");
	var mask_17_graphics_362 = new cjs.Graphics().p("AotIdQjnjgAAk9IAAAAQAAk8DnjgIAAAAQDnjgFGAAIAAAAQFHAADnDgIAAAAQDnDgAAE8IAAAAQAAE9jnDgIAAAAQjnDglHAAIAAAAQlGAAjnjgg");
	var mask_17_graphics_363 = new cjs.Graphics().p("AovIfQjojhAAk+IAAAAQAAk9DojiIAAAAQDojgFHAAIAAAAQFIAADoDgIAAAAQDoDiAAE9IAAAAQAAE+joDhIAAAAQjoDhlIAAIAAAAQlHAAjojhg");
	var mask_17_graphics_364 = new cjs.Graphics().p("AoxIhQjpjhAAlAIAAAAQAAk/DpjiIAAAAQDpjiFIAAIAAAAQFJAADpDiIAAAAQDpDiAAE/IAAAAQAAFAjpDhIAAAAQjpDjlJAAIAAAAQlIAAjpjjg");
	var mask_17_graphics_365 = new cjs.Graphics().p("Ao0IkQjpjjAAlBIAAAAQAAlADpjjIAAAAQDqjjFKAAIAAAAQFLAADpDjIAAAAQDqDjAAFAIAAAAQAAFBjqDjIAAAAQjpDjlLAAIAAAAQlKAAjqjjg");
	var mask_17_graphics_366 = new cjs.Graphics().p("Ao2ImQjqjkAAlCIAAAAQAAlBDqjkIAAAAQDrjjFLAAIAAAAQFMAADqDjIAAAAQDrDkAAFBIAAAAQAAFCjrDkIAAAAQjqDjlMAAIAAAAQlLAAjrjjg");
	var mask_17_graphics_367 = new cjs.Graphics().p("Ao4IoQjrjlAAlDIAAAAQAAlCDrjlIAAAAQDsjkFMAAIAAAAQFNAADrDkIAAAAQDsDlAAFCIAAAAQAAFDjsDlIAAAAQjrDklNAAIAAAAQlMAAjsjkg");
	var mask_17_graphics_368 = new cjs.Graphics().p("Ao6IpQjsjlAAlEIAAAAQAAlDDsjmIAAAAQDtjlFNAAIAAAAQFOAADsDlIAAAAQDtDmAAFDIAAAAQAAFEjtDlIAAAAQjsDmlOAAIAAAAQlNAAjtjmg");
	var mask_17_graphics_369 = new cjs.Graphics().p("Ao8IrQjtjmAAlFIAAAAQAAlEDtjnIAAAAQDujmFOAAIAAAAQFPAADtDmIAAAAQDuDnAAFEIAAAAQAAFFjuDmIAAAAQjtDnlPAAIAAAAQlOAAjujng");
	var mask_17_graphics_370 = new cjs.Graphics().p("Ao9ItQjujnAAlGIAAAAQAAlFDujnIAAAAQDujnFPAAIAAAAQFQAADuDnIAAAAQDuDnAAFFIAAAAQAAFGjuDnIAAAAQjuDnlQAAIAAAAQlPAAjujng");
	var mask_17_graphics_371 = new cjs.Graphics().p("Ao/IvQjvjoAAlHIAAAAQAAlGDvjoIAAAAQDvjoFQAAIAAAAQFRAADvDoIAAAAQDvDoAAFGIAAAAQAAFHjvDoIAAAAQjvDolRAAIAAAAQlQAAjvjog");
	var mask_17_graphics_372 = new cjs.Graphics().p("ApBIxQjvjpAAlIIAAAAQAAlHDvjpIAAAAQDwjoFRAAIAAAAQFSAADwDoIAAAAQDvDpAAFHIAAAAQAAFIjvDpIAAAAQjwDolSAAIAAAAQlRAAjwjog");
	var mask_17_graphics_373 = new cjs.Graphics().p("ApDIyQjwjpAAlJIAAAAQAAlIDwjqIAAAAQDxjoFSAAIAAAAQFTAADwDoIAAAAQDxDqAAFIIAAAAQAAFJjxDpIAAAAQjwDplTAAIAAAAQlSAAjxjpg");
	var mask_17_graphics_374 = new cjs.Graphics().p("ApEI0QjxjqAAlKIAAAAQAAlJDxjqIAAAAQDxjqFTAAIAAAAQFUAADxDqIAAAAQDxDqAAFJIAAAAQAAFKjxDqIAAAAQjxDqlUAAIAAAAQlTAAjxjqg");
	var mask_17_graphics_375 = new cjs.Graphics().p("ApGI1QjxjqAAlLIAAAAQAAlKDxjrIAAAAQDyjqFUAAIAAAAQFVAADyDqIAAAAQDxDrAAFKIAAAAQAAFLjxDqIAAAAQjyDrlVAAIAAAAQlUAAjyjrg");
	var mask_17_graphics_376 = new cjs.Graphics().p("ApHI3QjyjrAAlMIAAAAQAAlLDyjrIAAAAQDyjrFVAAIAAAAQFWAADyDrIAAAAQDyDrAAFLIAAAAQAAFMjyDrIAAAAQjyDrlWAAIAAAAQlVAAjyjrg");
	var mask_17_graphics_377 = new cjs.Graphics().p("ApJI4QjyjrAAlNIAAAAQAAlMDyjsIAAAAQDzjrFWAAIAAAAQFXAADzDrIAAAAQDyDsAAFMIAAAAQAAFNjyDrIAAAAQjzDslXAAIAAAAQlWAAjzjsg");
	var mask_17_graphics_378 = new cjs.Graphics().p("ApKI6QjzjsAAlOIAAAAQAAlNDzjsIAAAAQDzjsFXAAIAAAAQFYAADzDsIAAAAQDzDsAAFNIAAAAQAAFOjzDsIAAAAQjzDslYAAIAAAAQlXAAjzjsg");
	var mask_17_graphics_379 = new cjs.Graphics().p("ApMI7QjzjtAAlOIAAAAQAAlNDzjtIAAAAQD0jtFYAAIAAAAQFZAADzDtIAAAAQD0DtAAFNIAAAAQAAFOj0DtIAAAAQjzDtlZAAIAAAAQlYAAj0jtg");
	var mask_17_graphics_380 = new cjs.Graphics().p("ApNI8Qj0jtAAlPIAAAAQAAlOD0jtIAAAAQD1jtFYAAIAAAAQFZAAD1DtIAAAAQD0DtAAFOIAAAAQAAFPj0DtIAAAAQj1DtlZAAIAAAAQlYAAj1jtg");

	this.timeline.addTween(cjs.Tween.get(mask_17).to({graphics:null,x:0,y:0}).wait(264).to({graphics:mask_17_graphics_264,x:86.1502,y:389.7999}).wait(1).to({graphics:mask_17_graphics_265,x:86.143,y:389.804}).wait(1).to({graphics:mask_17_graphics_266,x:86.1358,y:389.8075}).wait(1).to({graphics:mask_17_graphics_267,x:86.1282,y:389.8116}).wait(1).to({graphics:mask_17_graphics_268,x:86.121,y:389.8156}).wait(1).to({graphics:mask_17_graphics_269,x:86.1138,y:389.8192}).wait(1).to({graphics:mask_17_graphics_270,x:86.1061,y:389.8233}).wait(1).to({graphics:mask_17_graphics_271,x:86.0989,y:389.8273}).wait(1).to({graphics:mask_17_graphics_272,x:86.0913,y:389.8309}).wait(1).to({graphics:mask_17_graphics_273,x:86.0836,y:389.835}).wait(1).to({graphics:mask_17_graphics_274,x:86.076,y:389.8386}).wait(1).to({graphics:mask_17_graphics_275,x:86.0688,y:389.8427}).wait(1).to({graphics:mask_17_graphics_276,x:86.0616,y:389.8467}).wait(1).to({graphics:mask_17_graphics_277,x:86.0535,y:389.8508}).wait(1).to({graphics:mask_17_graphics_278,x:86.0463,y:389.8548}).wait(1).to({graphics:mask_17_graphics_279,x:86.0387,y:389.8584}).wait(1).to({graphics:mask_17_graphics_280,x:86.031,y:389.8624}).wait(1).to({graphics:mask_17_graphics_281,x:86.0238,y:389.8665}).wait(1).to({graphics:mask_17_graphics_282,x:86.0161,y:389.8701}).wait(1).to({graphics:mask_17_graphics_283,x:86.0085,y:389.8741}).wait(1).to({graphics:mask_17_graphics_284,x:86.0013,y:389.8782}).wait(1).to({graphics:mask_17_graphics_285,x:85.9937,y:389.8822}).wait(1).to({graphics:mask_17_graphics_286,x:85.986,y:389.8858}).wait(1).to({graphics:mask_17_graphics_287,x:85.9783,y:389.8899}).wait(1).to({graphics:mask_17_graphics_288,x:85.9716,y:389.894}).wait(1).to({graphics:mask_17_graphics_289,x:85.964,y:389.8976}).wait(1).to({graphics:mask_17_graphics_290,x:85.9567,y:389.9016}).wait(1).to({graphics:mask_17_graphics_291,x:85.9491,y:389.9052}).wait(1).to({graphics:mask_17_graphics_292,x:85.9415,y:389.9092}).wait(1).to({graphics:mask_17_graphics_293,x:85.9342,y:389.9133}).wait(1).to({graphics:mask_17_graphics_294,x:85.927,y:389.9169}).wait(1).to({graphics:mask_17_graphics_295,x:85.9198,y:389.9205}).wait(1).to({graphics:mask_17_graphics_296,x:85.9126,y:389.9245}).wait(1).to({graphics:mask_17_graphics_297,x:85.9054,y:389.9281}).wait(1).to({graphics:mask_17_graphics_298,x:85.8987,y:389.9317}).wait(1).to({graphics:mask_17_graphics_299,x:85.8915,y:389.9353}).wait(1).to({graphics:mask_17_graphics_300,x:85.8848,y:389.9385}).wait(1).to({graphics:mask_17_graphics_301,x:85.8776,y:389.9425}).wait(1).to({graphics:mask_17_graphics_302,x:85.8708,y:389.9457}).wait(1).to({graphics:mask_17_graphics_303,x:85.864,y:389.9493}).wait(1).to({graphics:mask_17_graphics_304,x:85.8577,y:389.9529}).wait(1).to({graphics:mask_17_graphics_305,x:85.851,y:389.9565}).wait(1).to({graphics:mask_17_graphics_306,x:85.8438,y:389.9601}).wait(1).to({graphics:mask_17_graphics_307,x:85.8375,y:389.9633}).wait(1).to({graphics:mask_17_graphics_308,x:85.8312,y:389.9668}).wait(1).to({graphics:mask_17_graphics_309,x:85.8249,y:389.97}).wait(1).to({graphics:mask_17_graphics_310,x:85.8186,y:389.9736}).wait(1).to({graphics:mask_17_graphics_311,x:85.8123,y:389.9772}).wait(1).to({graphics:mask_17_graphics_312,x:85.8055,y:389.9799}).wait(1).to({graphics:mask_17_graphics_313,x:85.7997,y:389.983}).wait(1).to({graphics:mask_17_graphics_314,x:85.7938,y:389.9866}).wait(1).to({graphics:mask_17_graphics_315,x:85.7875,y:389.9893}).wait(1).to({graphics:mask_17_graphics_316,x:85.7817,y:389.9925}).wait(1).to({graphics:mask_17_graphics_317,x:85.7758,y:389.9957}).wait(1).to({graphics:mask_17_graphics_318,x:85.7705,y:389.9988}).wait(1).to({graphics:mask_17_graphics_319,x:85.7646,y:390.0015}).wait(1).to({graphics:mask_17_graphics_320,x:85.7592,y:390.0042}).wait(1).to({graphics:mask_17_graphics_321,x:85.7533,y:390.0074}).wait(1).to({graphics:mask_17_graphics_322,x:85.7479,y:390.01}).wait(1).to({graphics:mask_17_graphics_323,x:85.7425,y:390.0127}).wait(1).to({graphics:mask_17_graphics_324,x:85.7376,y:390.0159}).wait(1).to({graphics:mask_17_graphics_325,x:85.7322,y:390.0181}).wait(1).to({graphics:mask_17_graphics_326,x:85.7273,y:390.0208}).wait(1).to({graphics:mask_17_graphics_327,x:85.7223,y:390.0235}).wait(1).to({graphics:mask_17_graphics_328,x:85.7173,y:390.0267}).wait(1).to({graphics:mask_17_graphics_329,x:85.7124,y:390.0289}).wait(1).to({graphics:mask_17_graphics_330,x:85.7074,y:390.0316}).wait(1).to({graphics:mask_17_graphics_331,x:85.7029,y:390.0339}).wait(1).to({graphics:mask_17_graphics_332,x:85.6984,y:390.0361}).wait(1).to({graphics:mask_17_graphics_333,x:85.6939,y:390.0388}).wait(1).to({graphics:mask_17_graphics_334,x:85.6894,y:390.0411}).wait(1).to({graphics:mask_17_graphics_335,x:85.6849,y:390.0433}).wait(1).to({graphics:mask_17_graphics_336,x:85.6805,y:390.0456}).wait(1).to({graphics:mask_17_graphics_337,x:85.6764,y:390.0483}).wait(1).to({graphics:mask_17_graphics_338,x:85.6719,y:390.0501}).wait(1).to({graphics:mask_17_graphics_339,x:85.6678,y:390.0524}).wait(1).to({graphics:mask_17_graphics_340,x:85.6638,y:390.0541}).wait(1).to({graphics:mask_17_graphics_341,x:85.6597,y:390.0564}).wait(1).to({graphics:mask_17_graphics_342,x:85.6562,y:390.0586}).wait(1).to({graphics:mask_17_graphics_343,x:85.6526,y:390.0604}).wait(1).to({graphics:mask_17_graphics_344,x:85.6485,y:390.0623}).wait(1).to({graphics:mask_17_graphics_345,x:85.6449,y:390.064}).wait(1).to({graphics:mask_17_graphics_346,x:85.6413,y:390.0659}).wait(1).to({graphics:mask_17_graphics_347,x:85.6377,y:390.0677}).wait(1).to({graphics:mask_17_graphics_348,x:85.6345,y:390.0699}).wait(1).to({graphics:mask_17_graphics_349,x:85.6314,y:390.0717}).wait(1).to({graphics:mask_17_graphics_350,x:85.6278,y:390.0735}).wait(1).to({graphics:mask_17_graphics_351,x:85.6246,y:390.0748}).wait(1).to({graphics:mask_17_graphics_352,x:85.6215,y:390.0762}).wait(1).to({graphics:mask_17_graphics_353,x:85.6183,y:390.078}).wait(1).to({graphics:mask_17_graphics_354,x:85.6152,y:390.0793}).wait(1).to({graphics:mask_17_graphics_355,x:85.6125,y:390.0811}).wait(1).to({graphics:mask_17_graphics_356,x:85.6098,y:390.0825}).wait(1).to({graphics:mask_17_graphics_357,x:85.6071,y:390.0838}).wait(1).to({graphics:mask_17_graphics_358,x:85.6044,y:390.0856}).wait(1).to({graphics:mask_17_graphics_359,x:85.6017,y:390.0865}).wait(1).to({graphics:mask_17_graphics_360,x:85.5995,y:390.0883}).wait(1).to({graphics:mask_17_graphics_361,x:85.5967,y:390.0892}).wait(1).to({graphics:mask_17_graphics_362,x:85.5941,y:390.0906}).wait(1).to({graphics:mask_17_graphics_363,x:85.5918,y:390.0919}).wait(1).to({graphics:mask_17_graphics_364,x:85.5895,y:390.0933}).wait(1).to({graphics:mask_17_graphics_365,x:85.5873,y:390.0942}).wait(1).to({graphics:mask_17_graphics_366,x:85.5855,y:390.0956}).wait(1).to({graphics:mask_17_graphics_367,x:85.5832,y:390.0965}).wait(1).to({graphics:mask_17_graphics_368,x:85.581,y:390.0974}).wait(1).to({graphics:mask_17_graphics_369,x:85.5787,y:390.0987}).wait(1).to({graphics:mask_17_graphics_370,x:85.5769,y:390.0996}).wait(1).to({graphics:mask_17_graphics_371,x:85.5756,y:390.101}).wait(1).to({graphics:mask_17_graphics_372,x:85.5738,y:390.1018}).wait(1).to({graphics:mask_17_graphics_373,x:85.572,y:390.1023}).wait(1).to({graphics:mask_17_graphics_374,x:85.5702,y:390.1032}).wait(1).to({graphics:mask_17_graphics_375,x:85.5684,y:390.1041}).wait(1).to({graphics:mask_17_graphics_376,x:85.5671,y:390.1045}).wait(1).to({graphics:mask_17_graphics_377,x:85.5653,y:390.1059}).wait(1).to({graphics:mask_17_graphics_378,x:85.5643,y:390.1063}).wait(1).to({graphics:mask_17_graphics_379,x:85.5625,y:390.1072}).wait(1).to({graphics:mask_17_graphics_380,x:85.5081,y:390.0541}).wait(430));

	// Layer_20
	this.instance_30 = new lib.Tween44("synched",0);
	this.instance_30.setTransform(49.8,410.95);
	this.instance_30.alpha = 0.5;
	this.instance_30._off = true;

	this.instance_31 = new lib.Tween45("synched",0);
	this.instance_31.setTransform(49.8,410.95);

	var maskedShapeInstanceList = [this.instance_30,this.instance_31];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_17;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_30}]},264).to({state:[{t:this.instance_31}]},116).wait(430));
	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(264).to({_off:false},0).to({_off:true,alpha:1},116).wait(430));

	// Layer_8
	this.instance_32 = new lib.Tween18("synched",2);
	this.instance_32.setTransform(-48.4,369,0.3728,0.3728,0,0,0,-0.1,0);
	this.instance_32._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_32).wait(228).to({_off:false},0).wait(582));

	// Layer_6 (mask)
	var mask_18 = new cjs.Shape();
	mask_18._off = true;
	var mask_18_graphics_244 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_18_graphics_245 = new cjs.Graphics().p("AgiAiQgPgOAAgUIAAAAQAAgTAPgOIAAAAQAOgOAUAAIAAAAQAVAAAOAOIAAAAQAPAOAAATIAAAAQAAAUgPAOIAAAAQgOAOgVAAIAAAAQgUAAgOgOg");
	var mask_18_graphics_246 = new cjs.Graphics().p("Ag1A0QgWgWAAgeIAAAAQAAgdAWgWIAAAAQAWgVAfAAIAAAAQAgAAAWAVIAAAAQAWAWAAAdIAAAAQAAAegWAWIAAAAQgWAVggAAIAAAAQgfAAgWgVg");
	var mask_18_graphics_247 = new cjs.Graphics().p("AhHBFQgegcAAgpIAAAAQAAgoAegcIAAAAQAegdApAAIAAAAQAqAAAeAdIAAAAQAeAcAAAoIAAAAQAAApgeAcIAAAAQgeAdgqAAIAAAAQgpAAgegdg");
	var mask_18_graphics_248 = new cjs.Graphics().p("AhaBXQgmgkAAgzIAAAAQAAgyAmgkIAAAAQAmgkA0AAIAAAAQA1AAAmAkIAAAAQAmAkAAAyIAAAAQAAAzgmAkIAAAAQgmAkg1AAIAAAAQg0AAgmgkg");
	var mask_18_graphics_249 = new cjs.Graphics().p("AhtBpQgtgrAAg+IAAAAQAAg9AtgrIAAAAQAugsA/AAIAAAAQBAAAAuAsIAAAAQAtArAAA9IAAAAQAAA+gtArIAAAAQguAshAAAIAAAAQg/AAgugsg");
	var mask_18_graphics_250 = new cjs.Graphics().p("AiAB7Qg1gzAAhIIAAAAQAAhHA1gzIAAAAQA2gzBKAAIAAAAQBLAAA1AzIAAAAQA2AzAABHIAAAAQAABIg2AzIAAAAQg1AzhLAAIAAAAQhKAAg2gzg");
	var mask_18_graphics_251 = new cjs.Graphics().p("AiSCNQg9g6AAhTIAAAAQAAhSA9g6IAAAAQA9g7BVAAIAAAAQBWAAA9A7IAAAAQA9A6AABSIAAAAQAABTg9A6IAAAAQg9A7hWAAIAAAAQhVAAg9g7g");
	var mask_18_graphics_252 = new cjs.Graphics().p("AilCfQhFhCAAhdIAAAAQAAhcBFhCIAAAAQBFhCBgAAIAAAAQBhAABFBCIAAAAQBFBCAABcIAAAAQAABdhFBCIAAAAQhFBChhAAIAAAAQhgAAhFhCg");
	var mask_18_graphics_253 = new cjs.Graphics().p("Ai4CxQhNhJAAhoIAAAAQAAhnBNhKIAAAAQBMhJBsAAIAAAAQBtAABMBJIAAAAQBNBKAABnIAAAAQAABohNBJIAAAAQhMBKhtAAIAAAAQhsAAhMhKg");
	var mask_18_graphics_254 = new cjs.Graphics().p("AjLDEQhVhRAAhzIAAAAQAAhyBVhRIAAAAQBUhRB3AAIAAAAQB4AABUBRIAAAAQBVBRAAByIAAAAQAABzhVBRIAAAAQhUBRh4AAIAAAAQh3AAhUhRg");
	var mask_18_graphics_255 = new cjs.Graphics().p("AjeDWQhdhZAAh9IAAAAQAAh8BdhZIAAAAQBchYCCAAIAAAAQCDAABcBYIAAAAQBdBZAAB8IAAAAQAAB9hdBZIAAAAQhcBYiDAAIAAAAQiCAAhchYg");
	var mask_18_graphics_256 = new cjs.Graphics().p("AjxDoQhkhgAAiIIAAAAQAAiHBkhgIAAAAQBkhgCNAAIAAAAQCOAABkBgIAAAAQBkBgAACHIAAAAQAACIhkBgIAAAAQhkBgiOAAIAAAAQiNAAhkhgg");
	var mask_18_graphics_257 = new cjs.Graphics().p("AkED6QhshoAAiSIAAAAQAAiRBshoIAAAAQBshnCYAAIAAAAQCZAABsBnIAAAAQBsBoAACRIAAAAQAACShsBoIAAAAQhsBniZAAIAAAAQiYAAhshng");
	var mask_18_graphics_258 = new cjs.Graphics().p("AkXEMQhzhvAAidIAAAAQAAicBzhvIAAAAQB0hvCjAAIAAAAQCkAAB0BvIAAAAQBzBvAACcIAAAAQAACdhzBvIAAAAQh0BvikAAIAAAAQijAAh0hvg");
	var mask_18_graphics_259 = new cjs.Graphics().p("AkpEeQh8h3AAinIAAAAQAAimB8h3IAAAAQB7h2CuAAIAAAAQCvAAB7B2IAAAAQB8B3AACmIAAAAQAACnh8B3IAAAAQh7B2ivAAIAAAAQiuAAh7h2g");
	var mask_18_graphics_260 = new cjs.Graphics().p("Ak8EvQiDh9AAiyIAAAAQAAixCDh+IAAAAQCEh9C4AAIAAAAQC5AACEB9IAAAAQCDB+AACxIAAAAQAACyiDB9IAAAAQiEB+i5AAIAAAAQi4AAiEh+g");
	var mask_18_graphics_261 = new cjs.Graphics().p("AlOFBQiLiFAAi8IAAAAQAAi7CLiFIAAAAQCLiFDDAAIAAAAQDEAACLCFIAAAAQCLCFAAC7IAAAAQAAC8iLCFIAAAAQiLCFjEAAIAAAAQjDAAiLiFg");
	var mask_18_graphics_262 = new cjs.Graphics().p("AlgFSQiTiMAAjGIAAAAQAAjFCTiNIAAAAQCSiMDOAAIAAAAQDPAACSCMIAAAAQCTCNAADFIAAAAQAADGiTCMIAAAAQiSCNjPAAIAAAAQjOAAiSiNg");
	var mask_18_graphics_263 = new cjs.Graphics().p("AlyFkQiaiUAAjQIAAAAQAAjPCaiUIAAAAQCaiTDYAAIAAAAQDZAACaCTIAAAAQCaCUAADPIAAAAQAADQiaCUIAAAAQiaCTjZAAIAAAAQjYAAiaiTg");
	var mask_18_graphics_264 = new cjs.Graphics().p("AmEF1QihibAAjaIAAAAQAAjZChibIAAAAQChiaDjAAIAAAAQDkAAChCaIAAAAQChCbAADZIAAAAQAADaihCbIAAAAQihCajkAAIAAAAQjjAAihiag");
	var mask_18_graphics_265 = new cjs.Graphics().p("AmWGGQioiiAAjkIAAAAQAAjjCoiiIAAAAQCpihDtAAIAAAAQDuAACpChIAAAAQCoCiAADjIAAAAQAADkioCiIAAAAQipChjuAAIAAAAQjtAAipihg");
	var mask_18_graphics_266 = new cjs.Graphics().p("AmnGWQiwioAAjuIAAAAQAAjtCwioIAAAAQCwipD3AAIAAAAQD4AACwCpIAAAAQCwCoAADtIAAAAQAADuiwCoIAAAAQiwCpj4AAIAAAAQj3AAiwipg");
	var mask_18_graphics_267 = new cjs.Graphics().p("Am4GnQi3ivAAj4IAAAAQAAj3C3ivIAAAAQC3ivEBAAIAAAAQECAAC3CvIAAAAQC3CvAAD3IAAAAQAAD4i3CvIAAAAQi3CvkCAAIAAAAQkBAAi3ivg");
	var mask_18_graphics_268 = new cjs.Graphics().p("AnJG3Qi+i2AAkBIAAAAQAAkAC+i2IAAAAQC+i2ELAAIAAAAQEMAAC+C2IAAAAQC+C2AAEAIAAAAQAAEBi+C2IAAAAQi+C2kMAAIAAAAQkLAAi+i2g");
	var mask_18_graphics_269 = new cjs.Graphics().p("AnaHHQjEi9AAkKIAAAAQAAkJDEi9IAAAAQDFi8EVAAIAAAAQEWAADEC8IAAAAQDFC9AAEJIAAAAQAAEKjFC9IAAAAQjEC8kWAAIAAAAQkVAAjFi8g");
	var mask_18_graphics_270 = new cjs.Graphics().p("AnqHWQjLjDAAkTIAAAAQAAkSDLjDIAAAAQDLjDEfAAIAAAAQEgAADLDDIAAAAQDLDDAAESIAAAAQAAETjLDDIAAAAQjLDDkgAAIAAAAQkfAAjLjDg");
	var mask_18_graphics_271 = new cjs.Graphics().p("An6HmQjSjKAAkcIAAAAQAAkbDSjKIAAAAQDSjJEoAAIAAAAQEpAADSDJIAAAAQDSDKAAEbIAAAAQAAEcjSDKIAAAAQjSDJkpAAIAAAAQkoAAjSjJg");
	var mask_18_graphics_272 = new cjs.Graphics().p("AoKH1QjYjQAAklIAAAAQAAkkDYjQIAAAAQDZjPExAAIAAAAQEyAADYDPIAAAAQDZDQAAEkIAAAAQAAEljZDQIAAAAQjYDPkyAAIAAAAQkxAAjZjPg");
	var mask_18_graphics_273 = new cjs.Graphics().p("AoZIDQjfjVAAkuIAAAAQAAktDfjWIAAAAQDfjVE6AAIAAAAQE7AADfDVIAAAAQDfDWAAEtIAAAAQAAEujfDVIAAAAQjfDWk7AAIAAAAQk6AAjfjWg");
	var mask_18_graphics_274 = new cjs.Graphics().p("AooISQjljcAAk2IAAAAQAAk1DljcIAAAAQDljcFDAAIAAAAQFEAADlDcIAAAAQDlDcAAE1IAAAAQAAE2jlDcIAAAAQjlDclEAAIAAAAQlDAAjljcg");
	var mask_18_graphics_275 = new cjs.Graphics().p("Ao3IgQjrjhAAk/IAAAAQAAk+DrjhIAAAAQDrjiFMAAIAAAAQFNAADrDiIAAAAQDrDhAAE+IAAAAQAAE/jrDhIAAAAQjrDilNAAIAAAAQlMAAjrjig");
	var mask_18_graphics_276 = new cjs.Graphics().p("ApGIuQjxjnAAlHIAAAAQAAlGDxjnIAAAAQDyjnFUAAIAAAAQFVAADxDnIAAAAQDyDnAAFGIAAAAQAAFHjyDnIAAAAQjxDnlVAAIAAAAQlUAAjyjng");
	var mask_18_graphics_277 = new cjs.Graphics().p("ApUI8Qj3jtAAlPIAAAAQAAlOD3jtIAAAAQD4jsFcgBIAAAAQFdABD3DsIAAAAQD4DtAAFOIAAAAQAAFPj4DtIAAAAQj3DsldABIAAAAQlcgBj4jsg");
	var mask_18_graphics_278 = new cjs.Graphics().p("ApiJJQj8jyAAlXIAAAAQAAlWD8jyIAAAAQD9jyFlAAIAAAAQFmAAD8DyIAAAAQD9DyAAFWIAAAAQAAFXj9DyIAAAAQj8DylmAAIAAAAQllAAj9jyg");
	var mask_18_graphics_279 = new cjs.Graphics().p("ApvJWQkCj4AAleIAAAAQAAldECj4IAAAAQEDj4FsAAIAAAAQFtAAEDD4IAAAAQECD4AAFdIAAAAQAAFekCD4IAAAAQkDD4ltAAIAAAAQlsAAkDj4g");
	var mask_18_graphics_280 = new cjs.Graphics().p("Ap8JiQkIj8AAlmIAAAAQAAllEIj9IAAAAQEIj8F0AAIAAAAQF1AAEID8IAAAAQEID9AAFlIAAAAQAAFmkID8IAAAAQkID9l1AAIAAAAQl0AAkIj9g");
	var mask_18_graphics_281 = new cjs.Graphics().p("AqJJvQkNkCAAltIAAAAQAAlsENkCIAAAAQENkCF8AAIAAAAQF9AAENECIAAAAQENECAAFsIAAAAQAAFtkNECIAAAAQkNECl9AAIAAAAQl8AAkNkCg");
	var mask_18_graphics_282 = new cjs.Graphics().p("AqWJ7QkSkHAAl0IAAAAQAAlzESkHIAAAAQETkHGDAAIAAAAQGEAAESEHIAAAAQETEHAAFzIAAAAQAAF0kTEHIAAAAQkSEHmEAAIAAAAQmDAAkTkHg");
	var mask_18_graphics_283 = new cjs.Graphics().p("AqiKGQkXkLAAl7IAAAAQAAl6EXkMIAAAAQEYkLGKAAIAAAAQGLAAEXELIAAAAQEYEMAAF6IAAAAQAAF7kYELIAAAAQkXEMmLAAIAAAAQmKAAkYkMg");
	var mask_18_graphics_284 = new cjs.Graphics().p("AquKSQkckRAAmBIAAAAQAAmAEckRIAAAAQEdkQGRAAIAAAAQGSAAEcEQIAAAAQEdERAAGAIAAAAQAAGBkdERIAAAAQkcEQmSAAIAAAAQmRAAkdkQg");
	var mask_18_graphics_285 = new cjs.Graphics().p("Aq5KdQkhkVAAmIIAAAAQAAmHEhkVIAAAAQEhkVGYAAIAAAAQGZAAEhEVIAAAAQEhEVAAGHIAAAAQAAGIkhEVIAAAAQkhEVmZAAIAAAAQmYAAkhkVg");
	var mask_18_graphics_286 = new cjs.Graphics().p("ArEKnQkmkZAAmOIAAAAQAAmNEmkaIAAAAQEmkZGeAAIAAAAQGfAAEmEZIAAAAQEmEaAAGNIAAAAQAAGOkmEZIAAAAQkmEamfAAIAAAAQmeAAkmkag");
	var mask_18_graphics_287 = new cjs.Graphics().p("ArPKyQkqkeAAmUIAAAAQAAmTEqkeIAAAAQEqkeGlAAIAAAAQGmAAEqEeIAAAAQEqEeAAGTIAAAAQAAGUkqEeIAAAAQkqEemmAAIAAAAQmlAAkqkeg");
	var mask_18_graphics_288 = new cjs.Graphics().p("AraK8QkukiAAmaIAAAAQAAmZEukiIAAAAQEvkiGrAAIAAAAQGsAAEuEiIAAAAQEvEiAAGZIAAAAQAAGakvEiIAAAAQkuEimsAAIAAAAQmrAAkvkig");
	var mask_18_graphics_289 = new cjs.Graphics().p("ArkLFQkyklAAmgIAAAAQAAmfEykmIAAAAQEzklGxgBIAAAAQGyABEyElIAAAAQEzEmAAGfIAAAAQAAGgkzElIAAAAQkyEnmyAAIAAAAQmxAAkzkng");
	var mask_18_graphics_290 = new cjs.Graphics().p("AruLPQk2kqAAmlIAAAAQAAmkE2kqIAAAAQE4kqG2AAIAAAAQG3AAE3EqIAAAAQE3EqAAGkIAAAAQAAGlk3EqIAAAAQk3Eqm3AAIAAAAQm2AAk4kqg");
	var mask_18_graphics_291 = new cjs.Graphics().p("Ar3LYQk7kuAAmqIAAAAQAAmpE7kuIAAAAQE7kuG8AAIAAAAQG9AAE7EuIAAAAQE7EuAAGpIAAAAQAAGqk7EuIAAAAQk7Eum9AAIAAAAQm8AAk7kug");
	var mask_18_graphics_292 = new cjs.Graphics().p("AsALhQk/kxAAmwIAAAAQAAmvE/kxIAAAAQE/kxHBAAIAAAAQHCAAE/ExIAAAAQE/ExAAGvIAAAAQAAGwk/ExIAAAAQk/ExnCAAIAAAAQnBAAk/kxg");
	var mask_18_graphics_293 = new cjs.Graphics().p("AsJLpQlCk0AAm1IAAAAQAAm0FCk1IAAAAQFCk0HHAAIAAAAQHIAAFCE0IAAAAQFCE1AAG0IAAAAQAAG1lCE0IAAAAQlCE1nIAAIAAAAQnHAAlCk1g");
	var mask_18_graphics_294 = new cjs.Graphics().p("AsSLxQlFk4AAm5IAAAAQAAm4FFk5IAAAAQFGk4HMAAIAAAAQHNAAFFE4IAAAAQFGE5AAG4IAAAAQAAG5lGE4IAAAAQlFE5nNAAIAAAAQnMAAlGk5g");
	var mask_18_graphics_295 = new cjs.Graphics().p("AsaL5QlJk7AAm+IAAAAQAAm9FJk8IAAAAQFKk7HQAAIAAAAQHRAAFKE7IAAAAQFJE8AAG9IAAAAQAAG+lJE7IAAAAQlKE8nRAAIAAAAQnQAAlKk8g");
	var mask_18_graphics_296 = new cjs.Graphics().p("AsiMBQlMk/AAnCIAAAAQAAnBFMk/IAAAAQFNk/HVAAIAAAAQHWAAFME/IAAAAQFNE/AAHBIAAAAQAAHClNE/IAAAAQlME/nWAAIAAAAQnVAAlNk/g");
	var mask_18_graphics_297 = new cjs.Graphics().p("AspMIQlQlBAAnHIAAAAQAAnGFQlCIAAAAQFPlBHaAAIAAAAQHbAAFPFBIAAAAQFQFCAAHGIAAAAQAAHHlQFBIAAAAQlPFCnbAAIAAAAQnaAAlPlCg");
	var mask_18_graphics_298 = new cjs.Graphics().p("AsxMPQlSlEAAnLIAAAAQAAnKFSlFIAAAAQFTlEHeAAIAAAAQHfAAFSFEIAAAAQFTFFAAHKIAAAAQAAHLlTFEIAAAAQlSFFnfAAIAAAAQneAAlTlFg");
	var mask_18_graphics_299 = new cjs.Graphics().p("As4MWQlVlHAAnPIAAAAQAAnOFVlHIAAAAQFWlIHiAAIAAAAQHjAAFVFIIAAAAQFWFHAAHOIAAAAQAAHPlWFHIAAAAQlVFInjAAIAAAAQniAAlWlIg");
	var mask_18_graphics_300 = new cjs.Graphics().p("As/McQlYlJAAnTIAAAAQAAnSFYlKIAAAAQFZlKHmAAIAAAAQHnAAFYFKIAAAAQFZFKAAHSIAAAAQAAHTlZFJIAAAAQlYFLnnAAIAAAAQnmAAlZlLg");
	var mask_18_graphics_301 = new cjs.Graphics().p("AtFMjQlblNAAnWIAAAAQAAnVFblNIAAAAQFblMHqAAIAAAAQHrAAFbFMIAAAAQFbFNAAHVIAAAAQAAHWlbFNIAAAAQlbFMnrAAIAAAAQnqAAlblMg");
	var mask_18_graphics_302 = new cjs.Graphics().p("AtLMpQlelPAAnaIAAAAQAAnZFelPIAAAAQFelPHtAAIAAAAQHuAAFeFPIAAAAQFeFPAAHZIAAAAQAAHaleFPIAAAAQleFPnuAAIAAAAQntAAlelPg");
	var mask_18_graphics_303 = new cjs.Graphics().p("AtRMuQlglRAAndIAAAAQAAncFglSIAAAAQFglRHxAAIAAAAQHyAAFgFRIAAAAQFgFSAAHcIAAAAQAAHdlgFRIAAAAQlgFSnyAAIAAAAQnxAAlglSg");
	var mask_18_graphics_304 = new cjs.Graphics().p("AtXM0QlilUAAngIAAAAQAAnfFilUIAAAAQFjlTH0AAIAAAAQH1AAFiFTIAAAAQFjFUAAHfIAAAAQAAHgljFUIAAAAQliFTn1AAIAAAAQn0AAljlTg");
	var mask_18_graphics_305 = new cjs.Graphics().p("AtcM5QlllWAAnjIAAAAQAAniFllWIAAAAQFllWH3AAIAAAAQH4AAFlFWIAAAAQFlFWAAHiIAAAAQAAHjllFWIAAAAQllFWn4AAIAAAAQn3AAlllWg");
	var mask_18_graphics_306 = new cjs.Graphics().p("AthM+QlnlYAAnmIAAAAQAAnlFnlYIAAAAQFnlYH6AAIAAAAQH7AAFnFYIAAAAQFnFYAAHlIAAAAQAAHmlnFYIAAAAQlnFYn7AAIAAAAQn6AAlnlYg");
	var mask_18_graphics_307 = new cjs.Graphics().p("AtmNCQlplZAAnpIAAAAQAAnoFplaIAAAAQFplZH9AAIAAAAQH+AAFpFZIAAAAQFpFaAAHoIAAAAQAAHplpFZIAAAAQlpFan+AAIAAAAQn9AAlplag");
	var mask_18_graphics_308 = new cjs.Graphics().p("AtrNHQlqlcAAnrIAAAAQAAnqFqlcIAAAAQFrlbIAAAIAAAAQIBAAFqFbIAAAAQFrFcAAHqIAAAAQAAHrlrFcIAAAAQlqFboBAAIAAAAQoAAAlrlbg");
	var mask_18_graphics_309 = new cjs.Graphics().p("AtvNLQlsldAAnuIAAAAQAAntFsldIAAAAQFtldICAAIAAAAQIDAAFsFdIAAAAQFtFdAAHtIAAAAQAAHultFdIAAAAQlsFdoDAAIAAAAQoCAAltldg");
	var mask_18_graphics_310 = new cjs.Graphics().p("AtzNPQlulfAAnwIAAAAQAAnvFulfIAAAAQFulfIFAAIAAAAQIGAAFtFfIAAAAQFvFfAAHvIAAAAQAAHwlvFfIAAAAQltFfoGAAIAAAAQoFAAlulfg");
	var mask_18_graphics_311 = new cjs.Graphics().p("At3NSQlvlgAAnyIAAAAQAAnxFvlhIAAAAQFwlgIHAAIAAAAQIIAAFvFgIAAAAQFwFhAAHxIAAAAQAAHylwFgIAAAAQlvFhoIAAIAAAAQoHAAlwlhg");
	var mask_18_graphics_312 = new cjs.Graphics().p("At6NWQlxliAAn0IAAAAQAAnzFxliIAAAAQFxlhIJAAIAAAAQIKAAFxFhIAAAAQFxFiAAHzIAAAAQAAH0lxFiIAAAAQlxFhoKAAIAAAAQoJAAlxlhg");
	var mask_18_graphics_313 = new cjs.Graphics().p("At+NZQlyljAAn2IAAAAQAAn1FyljIAAAAQFzljILAAIAAAAQIMAAFyFjIAAAAQFzFjAAH1IAAAAQAAH2lzFjIAAAAQlyFjoMAAIAAAAQoLAAlzljg");
	var mask_18_graphics_314 = new cjs.Graphics().p("AuBNcQlzlkAAn4IAAAAQAAn3FzlkIAAAAQF0lkINAAIAAAAQIOAAFzFkIAAAAQF0FkAAH3IAAAAQAAH4l0FkIAAAAQlzFkoOAAIAAAAQoNAAl0lkg");
	var mask_18_graphics_315 = new cjs.Graphics().p("AuENeQl0llAAn5IAAAAQAAn4F0lmIAAAAQF2llIOAAIAAAAQIPAAF1FlIAAAAQF1FmAAH4IAAAAQAAH5l1FlIAAAAQl1FmoPAAIAAAAQoOAAl2lmg");
	var mask_18_graphics_316 = new cjs.Graphics().p("AuGNhQl2lmAAn7IAAAAQAAn6F2lmIAAAAQF2lnIQAAIAAAAQIRAAF2FnIAAAAQF2FmAAH6IAAAAQAAH7l2FmIAAAAQl2FnoRAAIAAAAQoQAAl2lng");
	var mask_18_graphics_317 = new cjs.Graphics().p("AuJNjQl2lnAAn8IAAAAQAAn7F2loIAAAAQF4lnIRAAIAAAAQISAAF3FnIAAAAQF3FoAAH7IAAAAQAAH8l3FnIAAAAQl3FooSAAIAAAAQoRAAl4log");
	var mask_18_graphics_318 = new cjs.Graphics().p("AuLNlQl3loAAn9IAAAAQAAn8F3lpIAAAAQF4loITAAIAAAAQIUAAF3FoIAAAAQF4FpAAH8IAAAAQAAH9l4FoIAAAAQl3FpoUAAIAAAAQoTAAl4lpg");
	var mask_18_graphics_319 = new cjs.Graphics().p("AuNNnQl4lpAAn+IAAAAQAAn9F4lqIAAAAQF5loIUAAIAAAAQIVAAF4FoIAAAAQF5FqAAH9IAAAAQAAH+l5FpIAAAAQl4FpoVAAIAAAAQoUAAl5lpg");
	var mask_18_graphics_320 = new cjs.Graphics().p("AuONpQl6lqAAn/IAAAAQAAn+F6lqIAAAAQF5lqIVAAIAAAAQIWAAF5FqIAAAAQF6FqAAH+IAAAAQAAH/l6FqIAAAAQl5FqoWAAIAAAAQoVAAl5lqg");
	var mask_18_graphics_321 = new cjs.Graphics().p("AuQNqQl6lqAAoAIAAAAQAAn/F6lrIAAAAQF6lqIWAAIAAAAQIXAAF5FqIAAAAQF7FrAAH/IAAAAQAAIAl7FqIAAAAQl5FroXAAIAAAAQoWAAl6lrg");

	this.timeline.addTween(cjs.Tween.get(mask_18).to({graphics:null,x:0,y:0}).wait(244).to({graphics:mask_18_graphics_244,x:128.25,y:562.7002}).wait(1).to({graphics:mask_18_graphics_245,x:128.4367,y:562.4464}).wait(1).to({graphics:mask_18_graphics_246,x:128.6244,y:562.1908}).wait(1).to({graphics:mask_18_graphics_247,x:128.8143,y:561.933}).wait(1).to({graphics:mask_18_graphics_248,x:129.0051,y:561.6738}).wait(1).to({graphics:mask_18_graphics_249,x:129.1973,y:561.4124}).wait(1).to({graphics:mask_18_graphics_250,x:129.3898,y:561.1504}).wait(1).to({graphics:mask_18_graphics_251,x:129.5833,y:560.8872}).wait(1).to({graphics:mask_18_graphics_252,x:129.7768,y:560.6235}).wait(1).to({graphics:mask_18_graphics_253,x:129.9712,y:560.3593}).wait(1).to({graphics:mask_18_graphics_254,x:130.1656,y:560.0956}).wait(1).to({graphics:mask_18_graphics_255,x:130.3591,y:559.8319}).wait(1).to({graphics:mask_18_graphics_256,x:130.5526,y:559.5687}).wait(1).to({graphics:mask_18_graphics_257,x:130.7457,y:559.3068}).wait(1).to({graphics:mask_18_graphics_258,x:130.9374,y:559.0458}).wait(1).to({graphics:mask_18_graphics_259,x:131.1282,y:558.7861}).wait(1).to({graphics:mask_18_graphics_260,x:131.3176,y:558.5287}).wait(1).to({graphics:mask_18_graphics_261,x:131.5058,y:558.2731}).wait(1).to({graphics:mask_18_graphics_262,x:131.6916,y:558.0198}).wait(1).to({graphics:mask_18_graphics_263,x:131.8761,y:557.7691}).wait(1).to({graphics:mask_18_graphics_264,x:132.0583,y:557.5208}).wait(1).to({graphics:mask_18_graphics_265,x:132.2388,y:557.2759}).wait(1).to({graphics:mask_18_graphics_266,x:132.4165,y:557.0343}).wait(1).to({graphics:mask_18_graphics_267,x:132.5916,y:556.7958}).wait(1).to({graphics:mask_18_graphics_268,x:132.7644,y:556.5609}).wait(1).to({graphics:mask_18_graphics_269,x:132.9345,y:556.33}).wait(1).to({graphics:mask_18_graphics_270,x:133.1014,y:556.1023}).wait(1).to({graphics:mask_18_graphics_271,x:133.2657,y:555.8796}).wait(1).to({graphics:mask_18_graphics_272,x:133.4268,y:555.66}).wait(1).to({graphics:mask_18_graphics_273,x:133.5847,y:555.4453}).wait(1).to({graphics:mask_18_graphics_274,x:133.74,y:555.2347}).wait(1).to({graphics:mask_18_graphics_275,x:133.8917,y:555.0282}).wait(1).to({graphics:mask_18_graphics_276,x:134.0397,y:554.8262}).wait(1).to({graphics:mask_18_graphics_277,x:134.1851,y:554.629}).wait(1).to({graphics:mask_18_graphics_278,x:134.3264,y:554.4364}).wait(1).to({graphics:mask_18_graphics_279,x:134.465,y:554.2484}).wait(1).to({graphics:mask_18_graphics_280,x:134.6,y:554.0647}).wait(1).to({graphics:mask_18_graphics_281,x:134.7314,y:553.8861}).wait(1).to({graphics:mask_18_graphics_282,x:134.8592,y:553.7119}).wait(1).to({graphics:mask_18_graphics_283,x:134.9838,y:553.5432}).wait(1).to({graphics:mask_18_graphics_284,x:135.1048,y:553.3785}).wait(1).to({graphics:mask_18_graphics_285,x:135.2227,y:553.2183}).wait(1).to({graphics:mask_18_graphics_286,x:135.3366,y:553.063}).wait(1).to({graphics:mask_18_graphics_287,x:135.4473,y:552.9118}).wait(1).to({graphics:mask_18_graphics_288,x:135.5553,y:552.7661}).wait(1).to({graphics:mask_18_graphics_289,x:135.6592,y:552.6243}).wait(1).to({graphics:mask_18_graphics_290,x:135.7596,y:552.4875}).wait(1).to({graphics:mask_18_graphics_291,x:135.8573,y:552.3552}).wait(1).to({graphics:mask_18_graphics_292,x:135.9513,y:552.2269}).wait(1).to({graphics:mask_18_graphics_293,x:136.0422,y:552.1036}).wait(1).to({graphics:mask_18_graphics_294,x:136.13,y:551.9839}).wait(1).to({graphics:mask_18_graphics_295,x:136.2141,y:551.8692}).wait(1).to({graphics:mask_18_graphics_296,x:136.2956,y:551.7585}).wait(1).to({graphics:mask_18_graphics_297,x:136.3734,y:551.6528}).wait(1).to({graphics:mask_18_graphics_298,x:136.4485,y:551.5501}).wait(1).to({graphics:mask_18_graphics_299,x:136.521,y:551.4525}).wait(1).to({graphics:mask_18_graphics_300,x:136.5898,y:551.358}).wait(1).to({graphics:mask_18_graphics_301,x:136.656,y:551.2684}).wait(1).to({graphics:mask_18_graphics_302,x:136.7194,y:551.1825}).wait(1).to({graphics:mask_18_graphics_303,x:136.7797,y:551.1001}).wait(1).to({graphics:mask_18_graphics_304,x:136.8373,y:551.0223}).wait(1).to({graphics:mask_18_graphics_305,x:136.8918,y:550.9476}).wait(1).to({graphics:mask_18_graphics_306,x:136.944,y:550.8769}).wait(1).to({graphics:mask_18_graphics_307,x:136.9935,y:550.8099}).wait(1).to({graphics:mask_18_graphics_308,x:137.0398,y:550.7464}).wait(1).to({graphics:mask_18_graphics_309,x:137.0844,y:550.6866}).wait(1).to({graphics:mask_18_graphics_310,x:137.1258,y:550.6303}).wait(1).to({graphics:mask_18_graphics_311,x:137.1645,y:550.5773}).wait(1).to({graphics:mask_18_graphics_312,x:137.201,y:550.5273}).wait(1).to({graphics:mask_18_graphics_313,x:137.2351,y:550.481}).wait(1).to({graphics:mask_18_graphics_314,x:137.2666,y:550.4386}).wait(1).to({graphics:mask_18_graphics_315,x:137.2959,y:550.3986}).wait(1).to({graphics:mask_18_graphics_316,x:137.3224,y:550.3622}).wait(1).to({graphics:mask_18_graphics_317,x:137.3467,y:550.3288}).wait(1).to({graphics:mask_18_graphics_318,x:137.3697,y:550.2987}).wait(1).to({graphics:mask_18_graphics_319,x:137.389,y:550.2712}).wait(1).to({graphics:mask_18_graphics_320,x:137.407,y:550.2474}).wait(1).to({graphics:mask_18_graphics_321,x:137.0128,y:549.8563}).wait(489));

	// Layer_14
	this.instance_33 = new lib.Tween37("synched",0);
	this.instance_33.setTransform(142.8,534.65);
	this.instance_33.alpha = 0.5;
	this.instance_33._off = true;

	var maskedShapeInstanceList = [this.instance_33];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_18;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_33).wait(244).to({_off:false},0).to({alpha:1},77).wait(489));

	// Layer_6 (mask)
	var mask_19 = new cjs.Shape();
	mask_19._off = true;
	var mask_19_graphics_199 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_19_graphics_200 = new cjs.Graphics().p("AgbAbQgMgLAAgQIAAAAQAAgPAMgLIAAAAQALgLAQAAIAAAAQARAAALALIAAAAQAMALAAAPIAAAAQAAAQgMALIAAAAQgLALgRAAIAAAAQgQAAgLgLg");
	var mask_19_graphics_201 = new cjs.Graphics().p("AgmAmQgQgQAAgWIAAAAQAAgVAQgQIAAAAQAQgPAWAAIAAAAQAXAAAQAPIAAAAQAQAQAAAVIAAAAQAAAWgQAQIAAAAQgQAPgXAAIAAAAQgWAAgQgPg");
	var mask_19_graphics_202 = new cjs.Graphics().p("AgxAxQgVgVAAgcIAAAAQAAgbAVgVIAAAAQAVgUAcAAIAAAAQAdAAAVAUIAAAAQAVAVAAAbIAAAAQAAAcgVAVIAAAAQgVAUgdAAIAAAAQgcAAgVgUg");
	var mask_19_graphics_203 = new cjs.Graphics().p("Ag8A7QgagYAAgjIAAAAQAAgiAagYIAAAAQAZgZAjAAIAAAAQAkAAAZAZIAAAAQAaAYAAAiIAAAAQAAAjgaAYIAAAAQgZAZgkAAIAAAAQgjAAgZgZg");
	var mask_19_graphics_204 = new cjs.Graphics().p("AhHBGQgegdgBgpIAAAAQABgoAegdIAAAAQAegdApAAIAAAAQAqAAAeAdIAAAAQAeAdABAoIAAAAQgBApgeAdIAAAAQgeAdgqAAIAAAAQgpAAgegdg");
	var mask_19_graphics_205 = new cjs.Graphics().p("AhTBRQgigiAAgvIAAAAQAAguAigiIAAAAQAjgiAwAAIAAAAQAxAAAjAiIAAAAQAiAiAAAuIAAAAQAAAvgiAiIAAAAQgjAigxAAIAAAAQgwAAgjgig");
	var mask_19_graphics_206 = new cjs.Graphics().p("AheBcQgngmAAg2IAAAAQAAg1AngmIAAAAQAngmA3AAIAAAAQA4AAAnAmIAAAAQAnAmAAA1IAAAAQAAA2gnAmIAAAAQgnAmg4AAIAAAAQg3AAgngmg");
	var mask_19_graphics_207 = new cjs.Graphics().p("AhpBnQgsgrAAg8IAAAAQAAg7AsgrIAAAAQAsgqA9AAIAAAAQA+AAAsAqIAAAAQAsArAAA7IAAAAQAAA8gsArIAAAAQgsAqg+AAIAAAAQg9AAgsgqg");
	var mask_19_graphics_208 = new cjs.Graphics().p("Ah1ByQgwgvAAhDIAAAAQAAhCAwgvIAAAAQAxgvBEAAIAAAAQBFAAAwAvIAAAAQAxAvAABCIAAAAQAABDgxAvIAAAAQgwAvhFAAIAAAAQhEAAgxgvg");
	var mask_19_graphics_209 = new cjs.Graphics().p("AiAB9Qg1g0AAhJIAAAAQAAhIA1g0IAAAAQA2g0BKAAIAAAAQBLAAA2A0IAAAAQA1A0AABIIAAAAQAABJg1A0IAAAAQg2A0hLAAIAAAAQhKAAg2g0g");
	var mask_19_graphics_210 = new cjs.Graphics().p("AiLCIQg6g4AAhQIAAAAQAAhPA6g4IAAAAQA6g4BRAAIAAAAQBSAAA6A4IAAAAQA6A4AABPIAAAAQAABQg6A4IAAAAQg6A4hSAAIAAAAQhRAAg6g4g");
	var mask_19_graphics_211 = new cjs.Graphics().p("AiXCTQg+g9AAhWIAAAAQAAhVA+g9IAAAAQA/g9BYAAIAAAAQBZAAA/A9IAAAAQA+A9AABVIAAAAQAABWg+A9IAAAAQg/A9hZAAIAAAAQhYAAg/g9g");
	var mask_19_graphics_212 = new cjs.Graphics().p("AiiCeQhDhBAAhdIAAAAQAAhcBDhBIAAAAQBEhBBeAAIAAAAQBfAABEBBIAAAAQBDBBAABcIAAAAQAABdhDBBIAAAAQhEBBhfAAIAAAAQheAAhEhBg");
	var mask_19_graphics_213 = new cjs.Graphics().p("AitCpQhJhGAAhjIAAAAQAAhiBJhGIAAAAQBIhGBlAAIAAAAQBmAABIBGIAAAAQBJBGAABiIAAAAQAABjhJBGIAAAAQhIBGhmAAIAAAAQhlAAhIhGg");
	var mask_19_graphics_214 = new cjs.Graphics().p("Ai5C0QhNhLAAhpIAAAAQAAhoBNhLIAAAAQBNhLBsAAIAAAAQBtAABNBLIAAAAQBNBLAABoIAAAAQAABphNBLIAAAAQhNBLhtAAIAAAAQhsAAhNhLg");
	var mask_19_graphics_215 = new cjs.Graphics().p("AjEC/QhShPAAhwIAAAAQAAhvBShPIAAAAQBShPByAAIAAAAQBzAABSBPIAAAAQBSBPAABvIAAAAQAABwhSBPIAAAAQhSBPhzAAIAAAAQhyAAhShPg");
	var mask_19_graphics_216 = new cjs.Graphics().p("AjQDKQhWhUAAh2IAAAAQAAh1BWhUIAAAAQBXhUB5AAIAAAAQB6AABXBUIAAAAQBWBUAAB1IAAAAQAAB2hWBUIAAAAQhXBUh6AAIAAAAQh5AAhXhUg");
	var mask_19_graphics_217 = new cjs.Graphics().p("AjbDVQhbhYAAh9IAAAAQAAh8BbhYIAAAAQBbhZCAAAIAAAAQCBAABbBZIAAAAQBbBYAAB8IAAAAQAAB9hbBYIAAAAQhbBZiBAAIAAAAQiAAAhbhZg");
	var mask_19_graphics_218 = new cjs.Graphics().p("AjmDgQhghdAAiDIAAAAQAAiCBghdIAAAAQBfhdCHAAIAAAAQCHAABgBdIAAAAQBgBdAACCIAAAAQAACDhgBdIAAAAQhgBdiHAAIAAAAQiHAAhfhdg");
	var mask_19_graphics_219 = new cjs.Graphics().p("AjyDrQhkhhAAiKIAAAAQAAiJBkhhIAAAAQBlhiCNAAIAAAAQCOAABlBiIAAAAQBkBhAACJIAAAAQAACKhkBhIAAAAQhlBiiOAAIAAAAQiNAAhlhig");
	var mask_19_graphics_220 = new cjs.Graphics().p("Aj9D2QhphmAAiQIAAAAQAAiPBphmIAAAAQBphmCUAAIAAAAQCVAABpBmIAAAAQBpBmAACPIAAAAQAACQhpBmIAAAAQhpBmiVAAIAAAAQiUAAhphmg");
	var mask_19_graphics_221 = new cjs.Graphics().p("AkIEBQhuhqAAiXIAAAAQAAiWBuhqIAAAAQBuhrCaAAIAAAAQCbAABuBrIAAAAQBuBqAACWIAAAAQAACXhuBqIAAAAQhuBribAAIAAAAQiaAAhuhrg");
	var mask_19_graphics_222 = new cjs.Graphics().p("AkUEMQhyhvAAidIAAAAQAAicByhvIAAAAQBzhvChAAIAAAAQCiAABzBvIAAAAQByBvAACcIAAAAQAACdhyBvIAAAAQhzBviiAAIAAAAQihAAhzhvg");
	var mask_19_graphics_223 = new cjs.Graphics().p("AkfEXQh3hzAAikIAAAAQAAijB3hzIAAAAQB3h0CoAAIAAAAQCpAAB3B0IAAAAQB3BzAACjIAAAAQAACkh3BzIAAAAQh3B0ipAAIAAAAQioAAh3h0g");
	var mask_19_graphics_224 = new cjs.Graphics().p("AkqEiQh8h4AAiqIAAAAQAAipB8h4IAAAAQB8h4CuAAIAAAAQCvAAB8B4IAAAAQB8B4AACpIAAAAQAACqh8B4IAAAAQh8B4ivAAIAAAAQiuAAh8h4g");
	var mask_19_graphics_225 = new cjs.Graphics().p("Ak1EtQiBh9AAiwIAAAAQAAivCBh9IAAAAQCAh9C1AAIAAAAQC2AACAB9IAAAAQCBB9AACvIAAAAQAACwiBB9IAAAAQiAB9i2AAIAAAAQi1AAiAh9g");
	var mask_19_graphics_226 = new cjs.Graphics().p("AlAE4QiFiBAAi3IAAAAQAAi2CFiBIAAAAQCFiBC7AAIAAAAQC8AACFCBIAAAAQCFCBAAC2IAAAAQAAC3iFCBIAAAAQiFCBi8AAIAAAAQi7AAiFiBg");
	var mask_19_graphics_227 = new cjs.Graphics().p("AlMFCQiJiFAAi9IAAAAQAAi8CJiGIAAAAQCKiFDCAAIAAAAQDDAACJCFIAAAAQCKCGAAC8IAAAAQAAC9iKCFIAAAAQiJCGjDAAIAAAAQjCAAiKiGg");
	var mask_19_graphics_228 = new cjs.Graphics().p("AlXFNQiOiKAAjDIAAAAQAAjCCOiKIAAAAQCPiKDIAAIAAAAQDJAACOCKIAAAAQCPCKAADCIAAAAQAADDiPCKIAAAAQiOCKjJAAIAAAAQjIAAiPiKg");
	var mask_19_graphics_229 = new cjs.Graphics().p("AlhFYQiTiPAAjJIAAAAQAAjICTiPIAAAAQCSiODPAAIAAAAQDQAACSCOIAAAAQCTCPAADIIAAAAQAADJiTCPIAAAAQiSCOjQAAIAAAAQjPAAiSiOg");
	var mask_19_graphics_230 = new cjs.Graphics().p("AlsFiQiYiSAAjQIAAAAQAAjPCYiSIAAAAQCXiTDVAAIAAAAQDWAACXCTIAAAAQCYCSAADPIAAAAQAADQiYCSIAAAAQiXCTjWAAIAAAAQjVAAiXiTg");
	var mask_19_graphics_231 = new cjs.Graphics().p("Al3FtQiciXAAjWIAAAAQAAjVCciXIAAAAQCciXDbAAIAAAAQDcAACcCXIAAAAQCcCXAADVIAAAAQAADWicCXIAAAAQicCXjcAAIAAAAQjbAAiciXg");
	var mask_19_graphics_232 = new cjs.Graphics().p("AmCF3QigibAAjcIAAAAQAAjbCgibIAAAAQCgicDiAAIAAAAQDjAACgCcIAAAAQCgCbAADbIAAAAQAADcigCbIAAAAQigCcjjAAIAAAAQjiAAigicg");
	var mask_19_graphics_233 = new cjs.Graphics().p("AmNGCQikigAAjiIAAAAQAAjhCkigIAAAAQClifDoAAIAAAAQDpAACkCfIAAAAQClCgAADhIAAAAQAADiilCgIAAAAQikCfjpAAIAAAAQjoAAilifg");
	var mask_19_graphics_234 = new cjs.Graphics().p("AmXGMQipikAAjoIAAAAQAAjnCpikIAAAAQCpikDuAAIAAAAQDvAACpCkIAAAAQCpCkAADnIAAAAQAADoipCkIAAAAQipCkjvAAIAAAAQjuAAipikg");
	var mask_19_graphics_235 = new cjs.Graphics().p("AmiGWQitioAAjuIAAAAQAAjtCtioIAAAAQCuioD0AAIAAAAQD1AACtCoIAAAAQCuCoAADtIAAAAQAADuiuCoIAAAAQitCoj1AAIAAAAQj0AAiuiog");
	var mask_19_graphics_236 = new cjs.Graphics().p("AmsGgQiyisAAj0IAAAAQAAjzCyisIAAAAQCyitD6AAIAAAAQD7AACyCtIAAAAQCyCsAADzIAAAAQAAD0iyCsIAAAAQiyCtj7AAIAAAAQj6AAiyitg");
	var mask_19_graphics_237 = new cjs.Graphics().p("Am2GqQi2iwAAj6IAAAAQAAj5C2iwIAAAAQC2ixEAAAIAAAAQEBAAC2CxIAAAAQC2CwAAD5IAAAAQAAD6i2CwIAAAAQi2CxkBAAIAAAAQkAAAi2ixg");
	var mask_19_graphics_238 = new cjs.Graphics().p("AnBG0Qi6i1AAj/IAAAAQAAj/C6i0IAAAAQC7i1EGAAIAAAAQEHAAC7C1IAAAAQC6C0AAD/IAAAAQAAD/i6C1IAAAAQi7C1kHAAIAAAAQkGAAi7i1g");
	var mask_19_graphics_239 = new cjs.Graphics().p("AnLG+Qi+i5AAkFIAAAAQAAkEC+i5IAAAAQC/i5EMAAIAAAAQENAAC/C5IAAAAQC+C5AAEEIAAAAQAAEFi+C5IAAAAQi/C5kNAAIAAAAQkMAAi/i5g");
	var mask_19_graphics_240 = new cjs.Graphics().p("AnVHIQjCi9AAkLIAAAAQAAkKDCi9IAAAAQDDi9ESAAIAAAAQETAADDC9IAAAAQDCC9AAEKIAAAAQAAELjCC9IAAAAQjDC9kTAAIAAAAQkSAAjDi9g");
	var mask_19_graphics_241 = new cjs.Graphics().p("AnfHRQjHjAAAkRIAAAAQAAkQDHjBIAAAAQDHjAEYAAIAAAAQEZAADHDAIAAAAQDHDBAAEQIAAAAQAAERjHDAIAAAAQjHDBkZAAIAAAAQkYAAjHjBg");
	var mask_19_graphics_242 = new cjs.Graphics().p("AnpHbQjLjFAAkWIAAAAQAAkVDLjFIAAAAQDLjFEeAAIAAAAQEfAADLDFIAAAAQDLDFAAEVIAAAAQAAEWjLDFIAAAAQjLDFkfAAIAAAAQkeAAjLjFg");
	var mask_19_graphics_243 = new cjs.Graphics().p("AnzHkQjOjIAAkcIAAAAQAAkbDOjJIAAAAQDPjIEkAAIAAAAQElAADODIIAAAAQDPDJAAEbIAAAAQAAEcjPDIIAAAAQjODJklAAIAAAAQkkAAjPjJg");
	var mask_19_graphics_244 = new cjs.Graphics().p("An8HuQjTjNAAkhIAAAAQAAkgDTjNIAAAAQDTjNEpAAIAAAAQEqAADTDNIAAAAQDTDNAAEgIAAAAQAAEhjTDNIAAAAQjTDNkqAAIAAAAQkpAAjTjNg");
	var mask_19_graphics_245 = new cjs.Graphics().p("AoGH3QjXjQAAknIAAAAQAAkmDXjQIAAAAQDXjREvAAIAAAAQEwAADXDRIAAAAQDXDQAAEmIAAAAQAAEnjXDQIAAAAQjXDRkwAAIAAAAQkvAAjXjRg");
	var mask_19_graphics_246 = new cjs.Graphics().p("AoPIAQjbjUAAksIAAAAQAAkrDbjVIAAAAQDbjUE0AAIAAAAQE1AADbDUIAAAAQDbDVAAErIAAAAQAAEsjbDUIAAAAQjbDVk1AAIAAAAQk0AAjbjVg");
	var mask_19_graphics_247 = new cjs.Graphics().p("AoZIJQjejYAAkxIAAAAQAAkwDejZIAAAAQDfjYE6AAIAAAAQE7AADeDYIAAAAQDfDZAAEwIAAAAQAAExjfDYIAAAAQjeDZk7AAIAAAAQk6AAjfjZg");
	var mask_19_graphics_248 = new cjs.Graphics().p("AoiISQjijbAAk3IAAAAQAAk2DijcIAAAAQDjjbE/AAIAAAAQFAAADjDbIAAAAQDiDcAAE2IAAAAQAAE3jiDbIAAAAQjjDclAAAIAAAAQk/AAjjjcg");
	var mask_19_graphics_249 = new cjs.Graphics().p("AorIbQjmjfAAk8IAAAAQAAk7DmjgIAAAAQDmjfFFAAIAAAAQFGAADmDfIAAAAQDmDgAAE7IAAAAQAAE8jmDfIAAAAQjmDglGAAIAAAAQlFAAjmjgg");
	var mask_19_graphics_250 = new cjs.Graphics().p("Ao0IkQjqjjAAlBIAAAAQAAlADqjjIAAAAQDqjjFKAAIAAAAQFLAADqDjIAAAAQDqDjAAFAIAAAAQAAFBjqDjIAAAAQjqDjlLAAIAAAAQlKAAjqjjg");
	var mask_19_graphics_251 = new cjs.Graphics().p("Ao9ItQjujnAAlGIAAAAQAAlFDujnIAAAAQDujmFPAAIAAAAQFQAADuDmIAAAAQDuDnAAFFIAAAAQAAFGjuDnIAAAAQjuDmlQAAIAAAAQlPAAjujmg");
	var mask_19_graphics_252 = new cjs.Graphics().p("ApGI1QjxjqAAlLIAAAAQAAlKDxjqIAAAAQDyjrFUAAIAAAAQFVAADxDrIAAAAQDyDqAAFKIAAAAQAAFLjyDqIAAAAQjxDrlVAAIAAAAQlUAAjyjrg");
	var mask_19_graphics_253 = new cjs.Graphics().p("ApOI+Qj1juAAlQIAAAAQAAlPD1juIAAAAQD1jtFZAAIAAAAQFaAAD1DtIAAAAQD1DuAAFPIAAAAQAAFQj1DuIAAAAQj1DtlaAAIAAAAQlZAAj1jtg");
	var mask_19_graphics_254 = new cjs.Graphics().p("ApXJGQj4jxAAlVIAAAAQAAlUD4jxIAAAAQD5jxFeAAIAAAAQFfAAD5DxIAAAAQD4DxAAFUIAAAAQAAFVj4DxIAAAAQj5DxlfAAIAAAAQleAAj5jxg");
	var mask_19_graphics_255 = new cjs.Graphics().p("ApfJOQj8j0AAlaIAAAAQAAlZD8j0IAAAAQD8j1FjAAIAAAAQFkAAD8D1IAAAAQD8D0AAFZIAAAAQAAFaj8D0IAAAAQj8D1lkAAIAAAAQljAAj8j1g");
	var mask_19_graphics_256 = new cjs.Graphics().p("ApoJWQj/j4AAleIAAAAQAAldD/j4IAAAAQEAj4FoAAIAAAAQFpAAD/D4IAAAAQEAD4AAFdIAAAAQAAFekAD4IAAAAQj/D4lpAAIAAAAQloAAkAj4g");
	var mask_19_graphics_257 = new cjs.Graphics().p("ApwJeQkDj7AAljIAAAAQAAliEDj7IAAAAQEDj7FtAAIAAAAQFuAAEDD7IAAAAQEDD7AAFiIAAAAQAAFjkDD7IAAAAQkDD7luAAIAAAAQltAAkDj7g");
	var mask_19_graphics_258 = new cjs.Graphics().p("Ap4JmQkGj+AAloIAAAAQAAlnEGj+IAAAAQEGj/FyAAIAAAAQFzAAEGD/IAAAAQEGD+AAFnIAAAAQAAFokGD+IAAAAQkGD/lzAAIAAAAQlyAAkGj/g");
	var mask_19_graphics_259 = new cjs.Graphics().p("AqAJuQkJkCAAlsIAAAAQAAlrEJkCIAAAAQEKkCF2AAIAAAAQF3AAEKECIAAAAQEJECAAFrIAAAAQAAFskJECIAAAAQkKECl3AAIAAAAQl2AAkKkCg");
	var mask_19_graphics_260 = new cjs.Graphics().p("AqIJ1QkNkEAAlxIAAAAQAAlwENkFIAAAAQENkEF7AAIAAAAQF8AAENEEIAAAAQENEFAAFwIAAAAQAAFxkNEEIAAAAQkNEFl8AAIAAAAQl7AAkNkFg");
	var mask_19_graphics_261 = new cjs.Graphics().p("AqQJ9QkPkIAAl1IAAAAQAAl0EPkIIAAAAQEQkIGAAAIAAAAQGBAAEPEIIAAAAQEQEIAAF0IAAAAQAAF1kQEIIAAAAQkPEImBAAIAAAAQmAAAkQkIg");
	var mask_19_graphics_262 = new cjs.Graphics().p("AqXKEQkTkLAAl5IAAAAQAAl4ETkMIAAAAQETkKGEAAIAAAAQGFAAETEKIAAAAQETEMAAF4IAAAAQAAF5kTELIAAAAQkTELmFAAIAAAAQmEAAkTkLg");
	var mask_19_graphics_263 = new cjs.Graphics().p("AqfKMQkWkOAAl+IAAAAQAAl9EWkOIAAAAQEXkOGIAAIAAAAQGJAAEWEOIAAAAQEXEOAAF9IAAAAQAAF+kXEOIAAAAQkWEOmJAAIAAAAQmIAAkXkOg");
	var mask_19_graphics_264 = new cjs.Graphics().p("AqmKTQkZkRAAmCIAAAAQAAmBEZkRIAAAAQEZkRGNAAIAAAAQGOAAEZERIAAAAQEZERAAGBIAAAAQAAGCkZERIAAAAQkZERmOAAIAAAAQmNAAkZkRg");
	var mask_19_graphics_265 = new cjs.Graphics().p("AqtKaQkdkUAAmGIAAAAQAAmFEdkUIAAAAQEckUGRAAIAAAAQGSAAEcEUIAAAAQEdEUAAGFIAAAAQAAGGkdEUIAAAAQkcEUmSAAIAAAAQmRAAkckUg");
	var mask_19_graphics_266 = new cjs.Graphics().p("Aq1KhQkfkXAAmKIAAAAQAAmJEfkXIAAAAQEgkXGVAAIAAAAQGWAAEfEXIAAAAQEgEXAAGJIAAAAQAAGKkgEXIAAAAQkfEXmWAAIAAAAQmVAAkgkXg");
	var mask_19_graphics_267 = new cjs.Graphics().p("Aq8KnQkikZAAmOIAAAAQAAmNEikaIAAAAQEjkZGZAAIAAAAQGaAAEiEZIAAAAQEjEaAAGNIAAAAQAAGOkjEZIAAAAQkiEamaAAIAAAAQmZAAkjkag");
	var mask_19_graphics_268 = new cjs.Graphics().p("ArCKuQklkcAAmSIAAAAQAAmRElkdIAAAAQElkcGdAAIAAAAQGeAAElEcIAAAAQElEdAAGRIAAAAQAAGSklEcIAAAAQklEdmeAAIAAAAQmdAAklkdg");
	var mask_19_graphics_269 = new cjs.Graphics().p("ArJK1QkokfAAmWIAAAAQAAmVEokfIAAAAQEokfGhAAIAAAAQGiAAEoEfIAAAAQEoEfAAGVIAAAAQAAGWkoEfIAAAAQkoEfmiAAIAAAAQmhAAkokfg");
	var mask_19_graphics_270 = new cjs.Graphics().p("ArQK7QkqkhAAmaIAAAAQAAmZEqkiIAAAAQErkhGlAAIAAAAQGmAAErEhIAAAAQEqEiAAGZIAAAAQAAGakqEhIAAAAQkrEimmAAIAAAAQmlAAkrkig");
	var mask_19_graphics_271 = new cjs.Graphics().p("ArWLCQkuklAAmdIAAAAQAAmcEuklIAAAAQEtkkGpAAIAAAAQGqAAEtEkIAAAAQEuElAAGcIAAAAQAAGdkuElIAAAAQktEkmqAAIAAAAQmpAAktkkg");
	var mask_19_graphics_272 = new cjs.Graphics().p("ArdLIQkwknAAmhIAAAAQAAmgEwknIAAAAQEwknGtAAIAAAAQGuAAEwEnIAAAAQEwEnAAGgIAAAAQAAGhkwEnIAAAAQkwEnmuAAIAAAAQmtAAkwkng");
	var mask_19_graphics_273 = new cjs.Graphics().p("ArjLOQkzkpAAmlIAAAAQAAmkEzkpIAAAAQEzkqGwAAIAAAAQGxAAEzEqIAAAAQEzEpAAGkIAAAAQAAGlkzEpIAAAAQkzEqmxAAIAAAAQmwAAkzkqg");
	var mask_19_graphics_274 = new cjs.Graphics().p("ArpLUQk1ksAAmoIAAAAQAAmnE1ksIAAAAQE1ksG0AAIAAAAQG1AAE1EsIAAAAQE1EsAAGnIAAAAQAAGok1EsIAAAAQk1Esm1AAIAAAAQm0AAk1ksg");
	var mask_19_graphics_275 = new cjs.Graphics().p("ArvLaQk4kuAAmsIAAAAQAAmrE4kuIAAAAQE3kuG4AAIAAAAQG5AAE3EuIAAAAQE4EuAAGrIAAAAQAAGsk4EuIAAAAQk3Eum5AAIAAAAQm4AAk3kug");
	var mask_19_graphics_276 = new cjs.Graphics().p("Ar1LgQk6kxAAmvIAAAAQAAmuE6kxIAAAAQE6kxG7AAIAAAAQG8AAE6ExIAAAAQE6ExAAGuIAAAAQAAGvk6ExIAAAAQk6Exm8AAIAAAAQm7AAk6kxg");
	var mask_19_graphics_277 = new cjs.Graphics().p("Ar7LlQk9kzAAmyIAAAAQAAmxE9k0IAAAAQE8kzG/AAIAAAAQHAAAE8EzIAAAAQE9E0AAGxIAAAAQAAGyk9EzIAAAAQk8E0nAAAIAAAAQm/AAk8k0g");
	var mask_19_graphics_278 = new cjs.Graphics().p("AsBLrQk/k1AAm2IAAAAQAAm1E/k1IAAAAQE/k1HCAAIAAAAQHDAAE/E1IAAAAQE/E1AAG1IAAAAQAAG2k/E1IAAAAQk/E1nDAAIAAAAQnCAAk/k1g");
	var mask_19_graphics_279 = new cjs.Graphics().p("AsHLwQlBk3AAm5IAAAAQAAm4FBk4IAAAAQFCk3HFAAIAAAAQHGAAFBE3IAAAAQFCE4AAG4IAAAAQAAG5lCE3IAAAAQlBE4nGAAIAAAAQnFAAlCk4g");
	var mask_19_graphics_280 = new cjs.Graphics().p("AsML2QlDk6AAm8IAAAAQAAm7FDk6IAAAAQFEk6HIAAIAAAAQHJAAFEE6IAAAAQFDE6AAG7IAAAAQAAG8lDE6IAAAAQlEE6nJAAIAAAAQnIAAlEk6g");
	var mask_19_graphics_281 = new cjs.Graphics().p("AsRL7QlGk8AAm/IAAAAQAAm+FGk8IAAAAQFFk8HMAAIAAAAQHNAAFFE8IAAAAQFGE8AAG+IAAAAQAAG/lGE8IAAAAQlFE8nNAAIAAAAQnMAAlFk8g");
	var mask_19_graphics_282 = new cjs.Graphics().p("AsXMAQlHk+AAnCIAAAAQAAnBFHk+IAAAAQFIk+HPAAIAAAAQHQAAFHE+IAAAAQFIE+AAHBIAAAAQAAHClIE+IAAAAQlHE+nQAAIAAAAQnPAAlIk+g");
	var mask_19_graphics_283 = new cjs.Graphics().p("AscMFQlKlAAAnFIAAAAQAAnEFKlAIAAAAQFKlAHSAAIAAAAQHTAAFJFAIAAAAQFLFAAAHEIAAAAQAAHFlLFAIAAAAQlJFAnTAAIAAAAQnSAAlKlAg");
	var mask_19_graphics_284 = new cjs.Graphics().p("AshMKQlMlCAAnIIAAAAQAAnHFMlCIAAAAQFMlCHVAAIAAAAQHWAAFMFCIAAAAQFMFCAAHHIAAAAQAAHIlMFCIAAAAQlMFCnWAAIAAAAQnVAAlMlCg");
	var mask_19_graphics_285 = new cjs.Graphics().p("AsmMPQlOlFAAnKIAAAAQAAnJFOlFIAAAAQFPlEHXAAIAAAAQHYAAFOFEIAAAAQFPFFAAHJIAAAAQAAHKlPFFIAAAAQlOFEnYAAIAAAAQnXAAlPlEg");
	var mask_19_graphics_286 = new cjs.Graphics().p("AsrMTQlQlGAAnNIAAAAQAAnMFQlHIAAAAQFRlGHaAAIAAAAQHbAAFQFGIAAAAQFRFHAAHMIAAAAQAAHNlRFGIAAAAQlQFHnbAAIAAAAQnaAAlRlHg");
	var mask_19_graphics_287 = new cjs.Graphics().p("AsvMYQlSlIAAnQIAAAAQAAnPFSlIIAAAAQFSlIHdAAIAAAAQHeAAFSFIIAAAAQFSFIAAHPIAAAAQAAHQlSFIIAAAAQlSFIneAAIAAAAQndAAlSlIg");
	var mask_19_graphics_288 = new cjs.Graphics().p("As0McQlUlJAAnTIAAAAQAAnSFUlKIAAAAQFUlJHgAAIAAAAQHhAAFUFJIAAAAQFUFKAAHSIAAAAQAAHTlUFJIAAAAQlUFKnhAAIAAAAQngAAlUlKg");
	var mask_19_graphics_289 = new cjs.Graphics().p("As4MhQlWlMAAnVIAAAAQAAnUFWlMIAAAAQFWlMHiAAIAAAAQHjAAFWFMIAAAAQFWFMAAHUIAAAAQAAHVlWFMIAAAAQlWFMnjAAIAAAAQniAAlWlMg");
	var mask_19_graphics_290 = new cjs.Graphics().p("As9MlQlXlNAAnYIAAAAQAAnXFXlNIAAAAQFYlOHlAAIAAAAQHmAAFXFOIAAAAQFYFNAAHXIAAAAQAAHYlYFNIAAAAQlXFOnmAAIAAAAQnlAAlYlOg");
	var mask_19_graphics_291 = new cjs.Graphics().p("AtBMpQlZlPAAnaIAAAAQAAnZFZlPIAAAAQFalQHnAAIAAAAQHoAAFaFQIAAAAQFZFPAAHZIAAAAQAAHalZFPIAAAAQlaFQnoAAIAAAAQnnAAlalQg");
	var mask_19_graphics_292 = new cjs.Graphics().p("AtFMtQlblRAAncIAAAAQAAnbFblSIAAAAQFblQHqAAIAAAAQHrAAFbFQIAAAAQFbFSAAHbIAAAAQAAHclbFRIAAAAQlbFRnrAAIAAAAQnqAAlblRg");
	var mask_19_graphics_293 = new cjs.Graphics().p("AtJMxQldlSAAnfIAAAAQAAneFdlTIAAAAQFdlSHsAAIAAAAQHtAAFdFSIAAAAQFdFTAAHeIAAAAQAAHfldFSIAAAAQldFTntAAIAAAAQnsAAldlTg");
	var mask_19_graphics_294 = new cjs.Graphics().p("AtNM1QlflUAAnhIAAAAQAAngFflUIAAAAQFelUHvAAIAAAAQHwAAFeFUIAAAAQFfFUAAHgIAAAAQAAHhlfFUIAAAAQleFUnwAAIAAAAQnvAAlelUg");
	var mask_19_graphics_295 = new cjs.Graphics().p("AtRM5QlglWAAnjIAAAAQAAniFglWIAAAAQFglWHxAAIAAAAQHyAAFgFWIAAAAQFgFWAAHiIAAAAQAAHjlgFWIAAAAQlgFWnyAAIAAAAQnxAAlglWg");
	var mask_19_graphics_296 = new cjs.Graphics().p("AtVM8QlilXAAnlIAAAAQAAnkFilYIAAAAQFilXHzAAIAAAAQH0AAFiFXIAAAAQFiFYAAHkIAAAAQAAHlliFXIAAAAQliFYn0AAIAAAAQnzAAlilYg");
	var mask_19_graphics_297 = new cjs.Graphics().p("AtZNAQljlZAAnnIAAAAQAAnmFjlZIAAAAQFklZH1AAIAAAAQH2AAFjFZIAAAAQFkFZAAHmIAAAAQAAHnlkFZIAAAAQljFZn2AAIAAAAQn1AAlklZg");
	var mask_19_graphics_298 = new cjs.Graphics().p("AtcNDQlllaAAnpIAAAAQAAnoFllbIAAAAQFllaH3AAIAAAAQH4AAFlFaIAAAAQFlFbAAHoIAAAAQAAHpllFaIAAAAQllFbn4AAIAAAAQn3AAlllbg");
	var mask_19_graphics_299 = new cjs.Graphics().p("AtgNHQlmlcAAnrIAAAAQAAnqFmlcIAAAAQFnlcH5AAIAAAAQH6AAFmFcIAAAAQFnFcAAHqIAAAAQAAHrlnFcIAAAAQlmFcn6AAIAAAAQn5AAlnlcg");
	var mask_19_graphics_300 = new cjs.Graphics().p("AtjNKQloldAAntIAAAAQAAnsFoldIAAAAQFoldH7AAIAAAAQH8AAFoFdIAAAAQFoFdAAHsIAAAAQAAHtloFdIAAAAQloFdn8AAIAAAAQn7AAloldg");
	var mask_19_graphics_301 = new cjs.Graphics().p("AtmNNQlpleAAnvIAAAAQAAnuFplfIAAAAQFpleH9AAIAAAAQH+AAFpFeIAAAAQFpFfAAHuIAAAAQAAHvlpFeIAAAAQlpFfn+AAIAAAAQn9AAlplfg");
	var mask_19_graphics_302 = new cjs.Graphics().p("AtqNQQlqlfAAnxIAAAAQAAnwFqlgIAAAAQFrlfH/AAIAAAAQIAAAFqFfIAAAAQFrFgAAHwIAAAAQAAHxlrFfIAAAAQlqFgoAAAIAAAAQn/AAlrlgg");
	var mask_19_graphics_303 = new cjs.Graphics().p("AttNTQlrlgAAnzIAAAAQAAnyFrlhIAAAAQFslgIBAAIAAAAQICAAFrFgIAAAAQFsFhAAHyIAAAAQAAHzlsFgIAAAAQlrFhoCAAIAAAAQoBAAlslhg");
	var mask_19_graphics_304 = new cjs.Graphics().p("AtwNWQlsliAAn0IAAAAQAAnzFsljIAAAAQFtlhIDAAIAAAAQIEAAFsFhIAAAAQFtFjAAHzIAAAAQAAH0ltFiIAAAAQlsFioEAAIAAAAQoDAAltlig");
	var mask_19_graphics_305 = new cjs.Graphics().p("AtzNZQltljAAn2IAAAAQAAn1FtljIAAAAQFvljIEAAIAAAAQIFAAFuFjIAAAAQFuFjAAH1IAAAAQAAH2luFjIAAAAQluFjoFAAIAAAAQoEAAlvljg");
	var mask_19_graphics_306 = new cjs.Graphics().p("At1NcQlvlkAAn4IAAAAQAAn3FvlkIAAAAQFvlkIGAAIAAAAQIHAAFvFkIAAAAQFvFkAAH3IAAAAQAAH4lvFkIAAAAQlvFkoHAAIAAAAQoGAAlvlkg");
	var mask_19_graphics_307 = new cjs.Graphics().p("At4NeQlwllAAn5IAAAAQAAn4FwlmIAAAAQFwllIIAAIAAAAQIJAAFwFlIAAAAQFwFmAAH4IAAAAQAAH5lwFlIAAAAQlwFmoJAAIAAAAQoIAAlwlmg");
	var mask_19_graphics_308 = new cjs.Graphics().p("At7NhQlxlmAAn7IAAAAQAAn6FxlmIAAAAQFylnIJAAIAAAAQIKAAFxFnIAAAAQFyFmAAH6IAAAAQAAH7lyFmIAAAAQlxFnoKAAIAAAAQoJAAlylng");
	var mask_19_graphics_309 = new cjs.Graphics().p("At9NjQlylnAAn8IAAAAQAAn7FyloIAAAAQFylnILAAIAAAAQIMAAFyFnIAAAAQFyFoAAH7IAAAAQAAH8lyFnIAAAAQlyFooMAAIAAAAQoLAAlylog");
	var mask_19_graphics_310 = new cjs.Graphics().p("AuANmQlzloAAn+IAAAAQAAn9FzloIAAAAQF0loIMAAIAAAAQINAAFzFoIAAAAQF0FoAAH9IAAAAQAAH+l0FoIAAAAQlzFooNAAIAAAAQoMAAl0log");
	var mask_19_graphics_311 = new cjs.Graphics().p("AuCNoQl0lpAAn/IAAAAQAAn+F0lpIAAAAQF1lqINAAIAAAAQIOAAF1FqIAAAAQF0FpAAH+IAAAAQAAH/l0FpIAAAAQl1FqoOAAIAAAAQoNAAl1lqg");
	var mask_19_graphics_312 = new cjs.Graphics().p("AuENqQl1lqAAoAIAAAAQAAn/F1lrIAAAAQF1lqIPAAIAAAAQIQAAF1FqIAAAAQF1FrAAH/IAAAAQAAIAl1FqIAAAAQl1FroQAAIAAAAQoPAAl1lrg");
	var mask_19_graphics_313 = new cjs.Graphics().p("AuHNsQl1lrAAoBIAAAAQAAoAF1lsIAAAAQF3lrIQAAIAAAAQIRAAF2FrIAAAAQF2FsAAIAIAAAAQAAIBl2FrIAAAAQl2FsoRAAIAAAAQoQAAl3lsg");
	var mask_19_graphics_314 = new cjs.Graphics().p("AuJNuQl2lrAAoDIAAAAQAAoCF2lsIAAAAQF4lsIRAAIAAAAQISAAF3FsIAAAAQF3FsAAICIAAAAQAAIDl3FrIAAAAQl3FtoSAAIAAAAQoRAAl4ltg");
	var mask_19_graphics_315 = new cjs.Graphics().p("AuLNwQl3lsAAoEIAAAAQAAoDF3ltIAAAAQF5lsISAAIAAAAQITAAF4FsIAAAAQF4FtAAIDIAAAAQAAIEl4FsIAAAAQl4FtoTAAIAAAAQoSAAl5ltg");

	this.timeline.addTween(cjs.Tween.get(mask_19).to({graphics:null,x:0,y:0}).wait(199).to({graphics:mask_19_graphics_199,x:229.4001,y:468.1503}).wait(1).to({graphics:mask_19_graphics_200,x:229.27,y:468.2772}).wait(1).to({graphics:mask_19_graphics_201,x:229.1391,y:468.405}).wait(1).to({graphics:mask_19_graphics_202,x:229.0072,y:468.5332}).wait(1).to({graphics:mask_19_graphics_203,x:228.8754,y:468.6624}).wait(1).to({graphics:mask_19_graphics_204,x:228.7422,y:468.792}).wait(1).to({graphics:mask_19_graphics_205,x:228.609,y:468.922}).wait(1).to({graphics:mask_19_graphics_206,x:228.4749,y:469.053}).wait(1).to({graphics:mask_19_graphics_207,x:228.3408,y:469.1839}).wait(1).to({graphics:mask_19_graphics_208,x:228.2058,y:469.3153}).wait(1).to({graphics:mask_19_graphics_209,x:228.0708,y:469.4467}).wait(1).to({graphics:mask_19_graphics_210,x:227.9358,y:469.5795}).wait(1).to({graphics:mask_19_graphics_211,x:227.7999,y:469.7113}).wait(1).to({graphics:mask_19_graphics_212,x:227.664,y:469.8441}).wait(1).to({graphics:mask_19_graphics_213,x:227.5285,y:469.9764}).wait(1).to({graphics:mask_19_graphics_214,x:227.3922,y:470.1087}).wait(1).to({graphics:mask_19_graphics_215,x:227.2567,y:470.2414}).wait(1).to({graphics:mask_19_graphics_216,x:227.1204,y:470.3742}).wait(1).to({graphics:mask_19_graphics_217,x:226.9849,y:470.5065}).wait(1).to({graphics:mask_19_graphics_218,x:226.8495,y:470.6388}).wait(1).to({graphics:mask_19_graphics_219,x:226.714,y:470.7711}).wait(1).to({graphics:mask_19_graphics_220,x:226.5786,y:470.903}).wait(1).to({graphics:mask_19_graphics_221,x:226.444,y:471.0343}).wait(1).to({graphics:mask_19_graphics_222,x:226.3099,y:471.1653}).wait(1).to({graphics:mask_19_graphics_223,x:226.1758,y:471.2958}).wait(1).to({graphics:mask_19_graphics_224,x:226.0422,y:471.4263}).wait(1).to({graphics:mask_19_graphics_225,x:225.909,y:471.5563}).wait(1).to({graphics:mask_19_graphics_226,x:225.7771,y:471.685}).wait(1).to({graphics:mask_19_graphics_227,x:225.6449,y:471.8137}).wait(1).to({graphics:mask_19_graphics_228,x:225.5139,y:471.9415}).wait(1).to({graphics:mask_19_graphics_229,x:225.3834,y:472.0689}).wait(1).to({graphics:mask_19_graphics_230,x:225.2538,y:472.1953}).wait(1).to({graphics:mask_19_graphics_231,x:225.1251,y:472.3214}).wait(1).to({graphics:mask_19_graphics_232,x:224.9968,y:472.446}).wait(1).to({graphics:mask_19_graphics_233,x:224.8695,y:472.5702}).wait(1).to({graphics:mask_19_graphics_234,x:224.7435,y:472.6935}).wait(1).to({graphics:mask_19_graphics_235,x:224.6179,y:472.8154}).wait(1).to({graphics:mask_19_graphics_236,x:224.4937,y:472.9369}).wait(1).to({graphics:mask_19_graphics_237,x:224.3709,y:473.0571}).wait(1).to({graphics:mask_19_graphics_238,x:224.2485,y:473.1763}).wait(1).to({graphics:mask_19_graphics_239,x:224.1274,y:473.2942}).wait(1).to({graphics:mask_19_graphics_240,x:224.0078,y:473.4113}).wait(1).to({graphics:mask_19_graphics_241,x:223.889,y:473.5273}).wait(1).to({graphics:mask_19_graphics_242,x:223.771,y:473.6421}).wait(1).to({graphics:mask_19_graphics_243,x:223.6545,y:473.756}).wait(1).to({graphics:mask_19_graphics_244,x:223.5393,y:473.868}).wait(1).to({graphics:mask_19_graphics_245,x:223.4254,y:473.9796}).wait(1).to({graphics:mask_19_graphics_246,x:223.3125,y:474.0894}).wait(1).to({graphics:mask_19_graphics_247,x:223.2009,y:474.1983}).wait(1).to({graphics:mask_19_graphics_248,x:223.0906,y:474.3054}).wait(1).to({graphics:mask_19_graphics_249,x:222.9822,y:474.4116}).wait(1).to({graphics:mask_19_graphics_250,x:222.8746,y:474.5169}).wait(1).to({graphics:mask_19_graphics_251,x:222.7684,y:474.6204}).wait(1).to({graphics:mask_19_graphics_252,x:222.6636,y:474.7225}).wait(1).to({graphics:mask_19_graphics_253,x:222.5601,y:474.8233}).wait(1).to({graphics:mask_19_graphics_254,x:222.4584,y:474.9228}).wait(1).to({graphics:mask_19_graphics_255,x:222.3576,y:475.0213}).wait(1).to({graphics:mask_19_graphics_256,x:222.2586,y:475.1181}).wait(1).to({graphics:mask_19_graphics_257,x:222.1605,y:475.213}).wait(1).to({graphics:mask_19_graphics_258,x:222.0642,y:475.3075}).wait(1).to({graphics:mask_19_graphics_259,x:221.9693,y:475.4002}).wait(1).to({graphics:mask_19_graphics_260,x:221.8756,y:475.4916}).wait(1).to({graphics:mask_19_graphics_261,x:221.7834,y:475.5816}).wait(1).to({graphics:mask_19_graphics_262,x:221.6925,y:475.6702}).wait(1).to({graphics:mask_19_graphics_263,x:221.6034,y:475.7571}).wait(1).to({graphics:mask_19_graphics_264,x:221.5156,y:475.843}).wait(1).to({graphics:mask_19_graphics_265,x:221.4292,y:475.9272}).wait(1).to({graphics:mask_19_graphics_266,x:221.3442,y:476.01}).wait(1).to({graphics:mask_19_graphics_267,x:221.26,y:476.0919}).wait(1).to({graphics:mask_19_graphics_268,x:221.1782,y:476.172}).wait(1).to({graphics:mask_19_graphics_269,x:221.0976,y:476.2507}).wait(1).to({graphics:mask_19_graphics_270,x:221.0179,y:476.3277}).wait(1).to({graphics:mask_19_graphics_271,x:220.9401,y:476.4037}).wait(1).to({graphics:mask_19_graphics_272,x:220.8636,y:476.4789}).wait(1).to({graphics:mask_19_graphics_273,x:220.7885,y:476.5522}).wait(1).to({graphics:mask_19_graphics_274,x:220.7146,y:476.6238}).wait(1).to({graphics:mask_19_graphics_275,x:220.6426,y:476.6944}).wait(1).to({graphics:mask_19_graphics_276,x:220.5716,y:476.7637}).wait(1).to({graphics:mask_19_graphics_277,x:220.5018,y:476.8317}).wait(1).to({graphics:mask_19_graphics_278,x:220.4343,y:476.8978}).wait(1).to({graphics:mask_19_graphics_279,x:220.3668,y:476.9631}).wait(1).to({graphics:mask_19_graphics_280,x:220.3015,y:477.027}).wait(1).to({graphics:mask_19_graphics_281,x:220.2377,y:477.0896}).wait(1).to({graphics:mask_19_graphics_282,x:220.1746,y:477.1507}).wait(1).to({graphics:mask_19_graphics_283,x:220.1134,y:477.2106}).wait(1).to({graphics:mask_19_graphics_284,x:220.0536,y:477.2695}).wait(1).to({graphics:mask_19_graphics_285,x:219.9946,y:477.3267}).wait(1).to({graphics:mask_19_graphics_286,x:219.937,y:477.3829}).wait(1).to({graphics:mask_19_graphics_287,x:219.8808,y:477.4374}).wait(1).to({graphics:mask_19_graphics_288,x:219.8259,y:477.491}).wait(1).to({graphics:mask_19_graphics_289,x:219.7724,y:477.5436}).wait(1).to({graphics:mask_19_graphics_290,x:219.7201,y:477.5944}).wait(1).to({graphics:mask_19_graphics_291,x:219.6688,y:477.6444}).wait(1).to({graphics:mask_19_graphics_292,x:219.6193,y:477.693}).wait(1).to({graphics:mask_19_graphics_293,x:219.5707,y:477.7402}).wait(1).to({graphics:mask_19_graphics_294,x:219.523,y:477.7866}).wait(1).to({graphics:mask_19_graphics_295,x:219.4767,y:477.832}).wait(1).to({graphics:mask_19_graphics_296,x:219.4321,y:477.8757}).wait(1).to({graphics:mask_19_graphics_297,x:219.3881,y:477.918}).wait(1).to({graphics:mask_19_graphics_298,x:219.3457,y:477.9598}).wait(1).to({graphics:mask_19_graphics_299,x:219.3043,y:478.0004}).wait(1).to({graphics:mask_19_graphics_300,x:219.2643,y:478.0395}).wait(1).to({graphics:mask_19_graphics_301,x:219.2251,y:478.0773}).wait(1).to({graphics:mask_19_graphics_302,x:219.1873,y:478.1142}).wait(1).to({graphics:mask_19_graphics_303,x:219.1504,y:478.1502}).wait(1).to({graphics:mask_19_graphics_304,x:219.1149,y:478.1853}).wait(1).to({graphics:mask_19_graphics_305,x:219.0802,y:478.2186}).wait(1).to({graphics:mask_19_graphics_306,x:219.047,y:478.2514}).wait(1).to({graphics:mask_19_graphics_307,x:219.0145,y:478.2829}).wait(1).to({graphics:mask_19_graphics_308,x:218.9835,y:478.3136}).wait(1).to({graphics:mask_19_graphics_309,x:218.9534,y:478.3428}).wait(1).to({graphics:mask_19_graphics_310,x:218.9241,y:478.3716}).wait(1).to({graphics:mask_19_graphics_311,x:218.8962,y:478.3986}).wait(1).to({graphics:mask_19_graphics_312,x:218.8692,y:478.4251}).wait(1).to({graphics:mask_19_graphics_313,x:218.8431,y:478.4503}).wait(1).to({graphics:mask_19_graphics_314,x:218.8179,y:478.4742}).wait(1).to({graphics:mask_19_graphics_315,x:218.713,y:478.4562}).wait(495));

	// Layer_19
	this.instance_34 = new lib.Tween43("synched",0);
	this.instance_34.setTransform(224.1,426.7);
	this.instance_34.alpha = 0.5;
	this.instance_34._off = true;

	var maskedShapeInstanceList = [this.instance_34];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_19;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_34).wait(199).to({_off:false},0).to({alpha:1},116).wait(495));

	// Layer_6 (mask)
	var mask_20 = new cjs.Shape();
	mask_20._off = true;
	var mask_20_graphics_116 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_20_graphics_117 = new cjs.Graphics().p("AgbAbQgLgLAAgQIAAAAQAAgPALgLIAAAAQAMgLAPAAIAAAAQAQAAAMALIAAAAQALALAAAPIAAAAQAAAQgLALIAAAAQgMALgQAAIAAAAQgPAAgMgLg");
	var mask_20_graphics_118 = new cjs.Graphics().p("AgmAlQgQgPAAgWIAAAAQAAgVAQgPIAAAAQAQgQAWAAIAAAAQAXAAAQAQIAAAAQAQAPAAAVIAAAAQAAAWgQAPIAAAAQgQAQgXAAIAAAAQgWAAgQgQg");
	var mask_20_graphics_119 = new cjs.Graphics().p("AgwAwQgVgUAAgcIAAAAQAAgbAVgUIAAAAQAUgTAcAAIAAAAQAdAAAUATIAAAAQAVAUAAAbIAAAAQAAAcgVAUIAAAAQgUATgdAAIAAAAQgcAAgUgTg");
	var mask_20_graphics_120 = new cjs.Graphics().p("Ag7A6QgZgYAAgiIAAAAQAAghAZgYIAAAAQAZgYAiAAIAAAAQAjAAAZAYIAAAAQAZAYAAAhIAAAAQAAAigZAYIAAAAQgZAYgjAAIAAAAQgiAAgZgYg");
	var mask_20_graphics_121 = new cjs.Graphics().p("AhGBFQgdgdAAgoIAAAAQAAgnAdgdIAAAAQAdgcApAAIAAAAQAqAAAdAcIAAAAQAdAdAAAnIAAAAQAAAogdAdIAAAAQgdAcgqAAIAAAAQgpAAgdgcg");
	var mask_20_graphics_122 = new cjs.Graphics().p("AhRBPQgighAAguIAAAAQAAgtAighIAAAAQAighAvAAIAAAAQAwAAAiAhIAAAAQAiAhAAAtIAAAAQAAAugiAhIAAAAQgiAhgwAAIAAAAQgvAAgighg");
	var mask_20_graphics_123 = new cjs.Graphics().p("AhcBaQgmglAAg1IAAAAQAAg0AmglIAAAAQAnglA1AAIAAAAQA2AAAnAlIAAAAQAmAlAAA0IAAAAQAAA1gmAlIAAAAQgnAlg2AAIAAAAQg1AAgnglg");
	var mask_20_graphics_124 = new cjs.Graphics().p("AhnBlQgrgqAAg7IAAAAQAAg6ArgqIAAAAQArgpA8AAIAAAAQA9AAArApIAAAAQArAqAAA6IAAAAQAAA7grAqIAAAAQgrApg9AAIAAAAQg8AAgrgpg");
	var mask_20_graphics_125 = new cjs.Graphics().p("AhyBvQgvguAAhBIAAAAQAAhAAvguIAAAAQAwguBCAAIAAAAQBDAAAwAuIAAAAQAvAuAABAIAAAAQAABBgvAuIAAAAQgwAuhDAAIAAAAQhCAAgwgug");
	var mask_20_graphics_126 = new cjs.Graphics().p("Ah9B6Qg0gzAAhHIAAAAQAAhGA0gzIAAAAQA0gyBJAAIAAAAQBKAAA0AyIAAAAQA0AzAABGIAAAAQAABHg0AzIAAAAQg0AyhKAAIAAAAQhJAAg0gyg");
	var mask_20_graphics_127 = new cjs.Graphics().p("AiICFQg5g3AAhOIAAAAQAAhNA5g3IAAAAQA5g3BPAAIAAAAQBQAAA5A3IAAAAQA5A3AABNIAAAAQAABOg5A3IAAAAQg5A3hQAAIAAAAQhPAAg5g3g");
	var mask_20_graphics_128 = new cjs.Graphics().p("AiTCPQg9g7AAhUIAAAAQAAhTA9g7IAAAAQA9g8BWAAIAAAAQBXAAA9A8IAAAAQA9A7AABTIAAAAQAABUg9A7IAAAAQg9A8hXAAIAAAAQhWAAg9g8g");
	var mask_20_graphics_129 = new cjs.Graphics().p("AieCaQhChAAAhaIAAAAQAAhZBChAIAAAAQBChABcAAIAAAAQBdAABCBAIAAAAQBCBAAABZIAAAAQAABahCBAIAAAAQhCBAhdAAIAAAAQhcAAhChAg");
	var mask_20_graphics_130 = new cjs.Graphics().p("AipClQhHhEAAhhIAAAAQAAhgBHhEIAAAAQBGhEBjAAIAAAAQBkAABGBEIAAAAQBHBEAABgIAAAAQAABhhHBEIAAAAQhGBEhkAAIAAAAQhjAAhGhEg");
	var mask_20_graphics_131 = new cjs.Graphics().p("Ai0CwQhLhJAAhnIAAAAQAAhmBLhJIAAAAQBLhJBpAAIAAAAQBqAABLBJIAAAAQBLBJAABmIAAAAQAABnhLBJIAAAAQhLBJhqAAIAAAAQhpAAhLhJg");
	var mask_20_graphics_132 = new cjs.Graphics().p("Ai/C6QhQhNAAhtIAAAAQAAhsBQhOIAAAAQBPhNBwAAIAAAAQBxAABPBNIAAAAQBQBOAABsIAAAAQAABthQBNIAAAAQhPBOhxAAIAAAAQhwAAhPhOg");
	var mask_20_graphics_133 = new cjs.Graphics().p("AjLDFQhUhRAAh0IAAAAQAAhzBUhRIAAAAQBVhSB2AAIAAAAQB3AABUBSIAAAAQBVBRAABzIAAAAQAAB0hVBRIAAAAQhUBSh3AAIAAAAQh2AAhVhSg");
	var mask_20_graphics_134 = new cjs.Graphics().p("AjWDQQhYhWAAh6IAAAAQAAh5BYhWIAAAAQBZhWB9AAIAAAAQB+AABZBWIAAAAQBYBWAAB5IAAAAQAAB6hYBWIAAAAQhZBWh+AAIAAAAQh9AAhZhWg");
	var mask_20_graphics_135 = new cjs.Graphics().p("AjhDbQhdhbAAiAIAAAAQAAh/BdhbIAAAAQBehaCDAAIAAAAQCEAABeBaIAAAAQBdBbAAB/IAAAAQAACAhdBbIAAAAQheBaiEAAIAAAAQiDAAhehag");
	var mask_20_graphics_136 = new cjs.Graphics().p("AjsDmQhihgAAiGIAAAAQAAiFBihgIAAAAQBihfCKAAIAAAAQCLAABiBfIAAAAQBiBgAACFIAAAAQAACGhiBgIAAAAQhiBfiLAAIAAAAQiKAAhihfg");
	var mask_20_graphics_137 = new cjs.Graphics().p("Aj3DwQhmhjAAiNIAAAAQAAiMBmhjIAAAAQBnhkCQAAIAAAAQCRAABnBkIAAAAQBmBjAACMIAAAAQAACNhmBjIAAAAQhnBkiRAAIAAAAQiQAAhnhkg");
	var mask_20_graphics_138 = new cjs.Graphics().p("AkCD7QhrhoAAiTIAAAAQAAiSBrhoIAAAAQBrhoCXAAIAAAAQCYAABrBoIAAAAQBrBoAACSIAAAAQAACThrBoIAAAAQhrBoiYAAIAAAAQiXAAhrhog");
	var mask_20_graphics_139 = new cjs.Graphics().p("AkNEGQhvhtAAiZIAAAAQAAiYBvhtIAAAAQBwhsCdAAIAAAAQCeAABwBsIAAAAQBvBtAACYIAAAAQAACZhvBtIAAAAQhwBsieAAIAAAAQidAAhwhsg");
	var mask_20_graphics_140 = new cjs.Graphics().p("AkYEQQh0hxAAifIAAAAQAAieB0hxIAAAAQB1hxCjAAIAAAAQCkAAB1BxIAAAAQB0BxAACeIAAAAQAACfh0BxIAAAAQh1BxikAAIAAAAQijAAh1hxg");
	var mask_20_graphics_141 = new cjs.Graphics().p("AkjEbQh4h1AAimIAAAAQAAilB4h1IAAAAQB5h1CqAAIAAAAQCrAAB5B1IAAAAQB4B1AAClIAAAAQAACmh4B1IAAAAQh5B1irAAIAAAAQiqAAh5h1g");
	var mask_20_graphics_142 = new cjs.Graphics().p("AkuElQh9h5AAisIAAAAQAAirB9h5IAAAAQB+h6CwAAIAAAAQCxAAB9B6IAAAAQB+B5AACrIAAAAQAACsh+B5IAAAAQh9B6ixAAIAAAAQiwAAh+h6g");
	var mask_20_graphics_143 = new cjs.Graphics().p("Ak4EwQiCh+AAiyIAAAAQAAixCCh+IAAAAQCCh+C2AAIAAAAQC3AACCB+IAAAAQCCB+AACxIAAAAQAACyiCB+IAAAAQiCB+i3AAIAAAAQi2AAiCh+g");
	var mask_20_graphics_144 = new cjs.Graphics().p("AlDE6QiGiCAAi4IAAAAQAAi3CGiCIAAAAQCGiDC9AAIAAAAQC+AACGCDIAAAAQCGCCAAC3IAAAAQAAC4iGCCIAAAAQiGCDi+AAIAAAAQi9AAiGiDg");
	var mask_20_graphics_145 = new cjs.Graphics().p("AlOFFQiKiHAAi+IAAAAQAAi9CKiHIAAAAQCLiGDDAAIAAAAQDEAACLCGIAAAAQCKCHAAC9IAAAAQAAC+iKCHIAAAAQiLCGjEAAIAAAAQjDAAiLiGg");
	var mask_20_graphics_146 = new cjs.Graphics().p("AlZFPQiPiLAAjEIAAAAQAAjDCPiLIAAAAQCQiLDJAAIAAAAQDKAACPCLIAAAAQCQCLAADDIAAAAQAADEiQCLIAAAAQiPCLjKAAIAAAAQjJAAiQiLg");
	var mask_20_graphics_147 = new cjs.Graphics().p("AljFZQiTiPAAjKIAAAAQAAjJCTiPIAAAAQCTiPDQAAIAAAAQDRAACTCPIAAAAQCTCPAADJIAAAAQAADKiTCPIAAAAQiTCPjRAAIAAAAQjQAAiTiPg");
	var mask_20_graphics_148 = new cjs.Graphics().p("AluFjQiXiTAAjQIAAAAQAAjPCXiUIAAAAQCYiTDWAAIAAAAQDXAACXCTIAAAAQCYCUAADPIAAAAQAADQiYCTIAAAAQiXCUjXAAIAAAAQjWAAiYiUg");
	var mask_20_graphics_149 = new cjs.Graphics().p("Al4FuQiciYAAjWIAAAAQAAjVCciYIAAAAQCciXDcAAIAAAAQDdAACcCXIAAAAQCcCYAADVIAAAAQAADWicCYIAAAAQicCXjdAAIAAAAQjcAAiciXg");
	var mask_20_graphics_150 = new cjs.Graphics().p("AmCF4QihicAAjcIAAAAQAAjbChicIAAAAQCgibDiAAIAAAAQDjAACgCbIAAAAQChCcAADbIAAAAQAADcihCcIAAAAQigCbjjAAIAAAAQjiAAigibg");
	var mask_20_graphics_151 = new cjs.Graphics().p("AmNGCQikigAAjiIAAAAQAAjhCkigIAAAAQCligDoAAIAAAAQDpAAClCgIAAAAQCkCgAADhIAAAAQAADiikCgIAAAAQilCgjpAAIAAAAQjoAAiligg");
	var mask_20_graphics_152 = new cjs.Graphics().p("AmXGMQipikAAjoIAAAAQAAjnCpikIAAAAQCpikDuAAIAAAAQDvAACpCkIAAAAQCpCkAADnIAAAAQAADoipCkIAAAAQipCkjvAAIAAAAQjuAAipikg");
	var mask_20_graphics_153 = new cjs.Graphics().p("AmhGWQitioAAjuIAAAAQAAjtCtioIAAAAQCtioD0AAIAAAAQD1AACtCoIAAAAQCtCoAADtIAAAAQAADuitCoIAAAAQitCoj1AAIAAAAQj0AAitiog");
	var mask_20_graphics_154 = new cjs.Graphics().p("AmrGfQiyisAAjzIAAAAQAAjyCyisIAAAAQCxisD6AAIAAAAQD7AACxCsIAAAAQCyCsAADyIAAAAQAADziyCsIAAAAQixCsj7AAIAAAAQj6AAixisg");
	var mask_20_graphics_155 = new cjs.Graphics().p("Am1GpQi2iwAAj5IAAAAQAAj4C2iwIAAAAQC1iwEAAAIAAAAQEBAAC1CwIAAAAQC2CwAAD4IAAAAQAAD5i2CwIAAAAQi1CwkBAAIAAAAQkAAAi1iwg");
	var mask_20_graphics_156 = new cjs.Graphics().p("Am/GzQi6i0AAj/IAAAAQAAj+C6i0IAAAAQC6i0EFAAIAAAAQEGAAC6C0IAAAAQC6C0AAD+IAAAAQAAD/i6C0IAAAAQi6C0kGAAIAAAAQkFAAi6i0g");
	var mask_20_graphics_157 = new cjs.Graphics().p("AnJG8Qi9i4AAkEIAAAAQAAkDC9i4IAAAAQC+i4ELAAIAAAAQEMAAC+C4IAAAAQC9C4AAEDIAAAAQAAEEi9C4IAAAAQi+C4kMAAIAAAAQkLAAi+i4g");
	var mask_20_graphics_158 = new cjs.Graphics().p("AnTHFQjBi7AAkKIAAAAQAAkJDBi8IAAAAQDCi8ERAAIAAAAQESAADBC8IAAAAQDCC8AAEJIAAAAQAAEKjCC7IAAAAQjBC9kSAAIAAAAQkRAAjCi9g");
	var mask_20_graphics_159 = new cjs.Graphics().p("AncHPQjGjAAAkPIAAAAQAAkODGjAIAAAAQDGjAEWAAIAAAAQEXAADGDAIAAAAQDGDAAAEOIAAAAQAAEPjGDAIAAAAQjGDAkXAAIAAAAQkWAAjGjAg");
	var mask_20_graphics_160 = new cjs.Graphics().p("AnmHYQjJjDAAkVIAAAAQAAkUDJjDIAAAAQDKjEEcAAIAAAAQEdAADKDEIAAAAQDJDDAAEUIAAAAQAAEVjJDDIAAAAQjKDEkdAAIAAAAQkcAAjKjEg");
	var mask_20_graphics_161 = new cjs.Graphics().p("AnvHhQjOjHAAkaIAAAAQAAkZDOjHIAAAAQDNjIEiAAIAAAAQEjAADNDIIAAAAQDODHAAEZIAAAAQAAEajODHIAAAAQjNDIkjAAIAAAAQkiAAjNjIg");
	var mask_20_graphics_162 = new cjs.Graphics().p("An5HqQjRjLAAkfIAAAAQAAkeDRjLIAAAAQDSjLEnAAIAAAAQEoAADRDLIAAAAQDSDLAAEeIAAAAQAAEfjSDLIAAAAQjRDLkoAAIAAAAQknAAjSjLg");
	var mask_20_graphics_163 = new cjs.Graphics().p("AoCHzQjVjPAAkkIAAAAQAAkjDVjPIAAAAQDWjPEsAAIAAAAQEtAADVDPIAAAAQDWDPAAEjIAAAAQAAEkjWDPIAAAAQjVDPktAAIAAAAQksAAjWjPg");
	var mask_20_graphics_164 = new cjs.Graphics().p("AoLH8QjZjSAAkqIAAAAQAAkpDZjSIAAAAQDZjTEyAAIAAAAQEzAADZDTIAAAAQDZDSAAEpIAAAAQAAEqjZDSIAAAAQjZDTkzAAIAAAAQkyAAjZjTg");
	var mask_20_graphics_165 = new cjs.Graphics().p("AoUIFQjcjWAAkvIAAAAQAAkuDcjWIAAAAQDdjWE3AAIAAAAQE4AADdDWIAAAAQDcDWAAEuIAAAAQAAEvjcDWIAAAAQjdDWk4AAIAAAAQk3AAjdjWg");
	var mask_20_graphics_166 = new cjs.Graphics().p("AodINQjgjZAAk0IAAAAQAAkzDgjaIAAAAQDhjZE8AAIAAAAQE9AADgDZIAAAAQDhDaAAEzIAAAAQAAE0jhDZIAAAAQjgDak9AAIAAAAQk8AAjhjag");
	var mask_20_graphics_167 = new cjs.Graphics().p("AomIWQjjjdAAk5IAAAAQAAk4DjjdIAAAAQDljdFBAAIAAAAQFCAADkDdIAAAAQDkDdAAE4IAAAAQAAE5jkDdIAAAAQjkDdlCAAIAAAAQlBAAjljdg");
	var mask_20_graphics_168 = new cjs.Graphics().p("AouIeQjojgAAk+IAAAAQAAk9DojhIAAAAQDojgFGAAIAAAAQFHAADoDgIAAAAQDoDhAAE9IAAAAQAAE+joDgIAAAAQjoDhlHAAIAAAAQlGAAjojhg");
	var mask_20_graphics_169 = new cjs.Graphics().p("Ao3InQjrjkAAlDIAAAAQAAlCDrjkIAAAAQDsjkFLAAIAAAAQFMAADrDkIAAAAQDsDkAAFCIAAAAQAAFDjsDkIAAAAQjrDklMAAIAAAAQlLAAjsjkg");
	var mask_20_graphics_170 = new cjs.Graphics().p("Ao/IvQjvjoAAlHIAAAAQAAlGDvjoIAAAAQDvjnFQAAIAAAAQFRAADvDnIAAAAQDvDoAAFGIAAAAQAAFHjvDoIAAAAQjvDnlRAAIAAAAQlQAAjvjng");
	var mask_20_graphics_171 = new cjs.Graphics().p("ApII3QjxjrAAlMIAAAAQAAlLDxjrIAAAAQDzjrFVAAIAAAAQFWAADyDrIAAAAQDyDrAAFLIAAAAQAAFMjyDrIAAAAQjyDrlWAAIAAAAQlVAAjzjrg");
	var mask_20_graphics_172 = new cjs.Graphics().p("ApQI/Qj1juAAlRIAAAAQAAlQD1juIAAAAQD2juFaAAIAAAAQFbAAD1DuIAAAAQD2DuAAFQIAAAAQAAFRj2DuIAAAAQj1DulbAAIAAAAQlaAAj2jug");
	var mask_20_graphics_173 = new cjs.Graphics().p("ApYJHQj5jyAAlVIAAAAQAAlUD5jyIAAAAQD5jxFfAAIAAAAQFgAAD5DxIAAAAQD5DyAAFUIAAAAQAAFVj5DyIAAAAQj5DxlgAAIAAAAQlfAAj5jxg");
	var mask_20_graphics_174 = new cjs.Graphics().p("ApgJPQj8j1AAlaIAAAAQAAlZD8j1IAAAAQD8j0FkAAIAAAAQFlAAD8D0IAAAAQD8D1AAFZIAAAAQAAFaj8D1IAAAAQj8D0llAAIAAAAQlkAAj8j0g");
	var mask_20_graphics_175 = new cjs.Graphics().p("ApoJWQj/j4AAleIAAAAQAAldD/j4IAAAAQEAj4FoAAIAAAAQFpAAD/D4IAAAAQEAD4AAFdIAAAAQAAFekAD4IAAAAQj/D4lpAAIAAAAQloAAkAj4g");
	var mask_20_graphics_176 = new cjs.Graphics().p("ApvJeQkDj7AAljIAAAAQAAliEDj7IAAAAQECj7FtAAIAAAAQFuAAECD7IAAAAQEDD7AAFiIAAAAQAAFjkDD7IAAAAQkCD7luAAIAAAAQltAAkCj7g");
	var mask_20_graphics_177 = new cjs.Graphics().p("Ap3JlQkGj+AAlnIAAAAQAAlmEGj+IAAAAQEGj+FxAAIAAAAQFyAAEGD+IAAAAQEGD+AAFmIAAAAQAAFnkGD+IAAAAQkGD+lyAAIAAAAQlxAAkGj+g");
	var mask_20_graphics_178 = new cjs.Graphics().p("Ap/JsQkIkBAAlrIAAAAQAAlqEIkCIAAAAQEJkBF2AAIAAAAQF3AAEIEBIAAAAQEJECAAFqIAAAAQAAFrkJEBIAAAAQkIECl3AAIAAAAQl2AAkJkCg");
	var mask_20_graphics_179 = new cjs.Graphics().p("AqGJ0QkMkEAAlwIAAAAQAAlvEMkEIAAAAQEMkEF6AAIAAAAQF7AAEMEEIAAAAQEMEEAAFvIAAAAQAAFwkMEEIAAAAQkMEEl7AAIAAAAQl6AAkMkEg");
	var mask_20_graphics_180 = new cjs.Graphics().p("AqNJ7QkPkHAAl0IAAAAQAAlzEPkHIAAAAQEPkHF+AAIAAAAQF/AAEPEHIAAAAQEPEHAAFzIAAAAQAAF0kPEHIAAAAQkPEHl/AAIAAAAQl+AAkPkHg");
	var mask_20_graphics_181 = new cjs.Graphics().p("AqVKCQkRkKAAl4IAAAAQAAl3ERkKIAAAAQETkKGCAAIAAAAQGDAAESEKIAAAAQESEKAAF3IAAAAQAAF4kSEKIAAAAQkSEKmDAAIAAAAQmCAAkTkKg");
	var mask_20_graphics_182 = new cjs.Graphics().p("AqcKIQkUkMAAl8IAAAAQAAl7EUkNIAAAAQEVkMGHAAIAAAAQGIAAEUEMIAAAAQEVENAAF7IAAAAQAAF8kVEMIAAAAQkUENmIAAIAAAAQmHAAkVkNg");
	var mask_20_graphics_183 = new cjs.Graphics().p("AqjKPQkXkPAAmAIAAAAQAAl/EXkQIAAAAQEYkPGLAAIAAAAQGMAAEXEPIAAAAQEYEQAAF/IAAAAQAAGAkYEPIAAAAQkXEQmMAAIAAAAQmLAAkYkQg");
	var mask_20_graphics_184 = new cjs.Graphics().p("AqpKWQkbkSAAmEIAAAAQAAmDEbkSIAAAAQEakSGPAAIAAAAQGQAAEaESIAAAAQEbESAAGDIAAAAQAAGEkbESIAAAAQkaESmQAAIAAAAQmPAAkakSg");
	var mask_20_graphics_185 = new cjs.Graphics().p("AqwKcQkdkUAAmIIAAAAQAAmHEdkVIAAAAQEdkUGTAAIAAAAQGUAAEdEUIAAAAQEdEVAAGHIAAAAQAAGIkdEUIAAAAQkdEVmUAAIAAAAQmTAAkdkVg");
	var mask_20_graphics_186 = new cjs.Graphics().p("Aq3KjQkgkYAAmLIAAAAQAAmKEgkYIAAAAQEhkYGWAAIAAAAQGXAAEgEYIAAAAQEhEYAAGKIAAAAQAAGLkhEYIAAAAQkgEYmXAAIAAAAQmWAAkhkYg");
	var mask_20_graphics_187 = new cjs.Graphics().p("Aq9KpQkjkaAAmPIAAAAQAAmOEjkaIAAAAQEjkaGaAAIAAAAQGbAAEjEaIAAAAQEjEaAAGOIAAAAQAAGPkjEaIAAAAQkjEambAAIAAAAQmaAAkjkag");
	var mask_20_graphics_188 = new cjs.Graphics().p("ArEKvQklkcAAmTIAAAAQAAmSElkdIAAAAQEmkcGeAAIAAAAQGfAAElEcIAAAAQEmEdAAGSIAAAAQAAGTkmEcIAAAAQklEdmfAAIAAAAQmeAAkmkdg");
	var mask_20_graphics_189 = new cjs.Graphics().p("ArKK1QkokfAAmWIAAAAQAAmVEokgIAAAAQEokfGiAAIAAAAQGjAAEnEfIAAAAQEpEgAAGVIAAAAQAAGWkpEfIAAAAQknEgmjAAIAAAAQmiAAkokgg");
	var mask_20_graphics_190 = new cjs.Graphics().p("ArQK7QkqkhAAmaIAAAAQAAmZEqkiIAAAAQErkhGlAAIAAAAQGmAAErEhIAAAAQEqEiAAGZIAAAAQAAGakqEhIAAAAQkrEimmAAIAAAAQmlAAkrkig");
	var mask_20_graphics_191 = new cjs.Graphics().p("ArWLBQktkkAAmdIAAAAQAAmcEtkkIAAAAQEtkkGpAAIAAAAQGqAAEtEkIAAAAQEtEkAAGcIAAAAQAAGdktEkIAAAAQktEkmqAAIAAAAQmpAAktkkg");
	var mask_20_graphics_192 = new cjs.Graphics().p("ArcLHQkvknAAmgIAAAAQAAmfEvknIAAAAQEwknGsAAIAAAAQGtAAEwEnIAAAAQEvEnAAGfIAAAAQAAGgkvEnIAAAAQkwEnmtAAIAAAAQmsAAkwkng");
	var mask_20_graphics_193 = new cjs.Graphics().p("AriLMQkxkoAAmkIAAAAQAAmjExkpIAAAAQEykpGwAAIAAAAQGxAAExEpIAAAAQEyEpAAGjIAAAAQAAGkkyEoIAAAAQkxEqmxAAIAAAAQmwAAkykqg");
	var mask_20_graphics_194 = new cjs.Graphics().p("ArnLSQk1krABmnIAAAAQgBmmE1krIAAAAQE0krGzAAIAAAAQG0AAE0ErIAAAAQE0ErAAGmIAAAAQAAGnk0ErIAAAAQk0Erm0AAIAAAAQmzAAk0krg");
	var mask_20_graphics_195 = new cjs.Graphics().p("ArtLXQk2ktAAmqIAAAAQAAmpE2kuIAAAAQE3ktG2AAIAAAAQG3AAE3EtIAAAAQE2EuAAGpIAAAAQAAGqk2EtIAAAAQk3Eum3AAIAAAAQm2AAk3kug");
	var mask_20_graphics_196 = new cjs.Graphics().p("AryLdQk5kwAAmtIAAAAQAAmsE5kwIAAAAQE5kvG5AAIAAAAQG6AAE5EvIAAAAQE5EwAAGsIAAAAQAAGtk5EwIAAAAQk5Evm6AAIAAAAQm5AAk5kvg");
	var mask_20_graphics_197 = new cjs.Graphics().p("Ar4LiQk7kyAAmwIAAAAQAAmvE7kyIAAAAQE8kyG8AAIAAAAQG9AAE7EyIAAAAQE8EyAAGvIAAAAQAAGwk8EyIAAAAQk7Eym9AAIAAAAQm8AAk8kyg");
	var mask_20_graphics_198 = new cjs.Graphics().p("Ar9LnQk9k0AAmzIAAAAQAAmyE9k0IAAAAQE9k0HAAAIAAAAQHBAAE9E0IAAAAQE9E0AAGyIAAAAQAAGzk9E0IAAAAQk9E0nBAAIAAAAQnAAAk9k0g");
	var mask_20_graphics_199 = new cjs.Graphics().p("AsCLsQk/k2AAm2IAAAAQAAm1E/k2IAAAAQE/k2HDAAIAAAAQHEAAE/E2IAAAAQE/E2AAG1IAAAAQAAG2k/E2IAAAAQk/E2nEAAIAAAAQnDAAk/k2g");
	var mask_20_graphics_200 = new cjs.Graphics().p("AsHLxQlBk4AAm5IAAAAQAAm4FBk4IAAAAQFCk4HFAAIAAAAQHGAAFCE4IAAAAQFBE4AAG4IAAAAQAAG5lBE4IAAAAQlCE4nGAAIAAAAQnFAAlCk4g");
	var mask_20_graphics_201 = new cjs.Graphics().p("AsML2QlDk6AAm8IAAAAQAAm7FDk6IAAAAQFEk6HIAAIAAAAQHJAAFEE6IAAAAQFDE6AAG7IAAAAQAAG8lDE6IAAAAQlEE6nJAAIAAAAQnIAAlEk6g");
	var mask_20_graphics_202 = new cjs.Graphics().p("AsRL6QlFk7AAm/IAAAAQAAm+FFk8IAAAAQFGk7HLAAIAAAAQHMAAFFE7IAAAAQFGE8AAG+IAAAAQAAG/lGE7IAAAAQlFE8nMAAIAAAAQnLAAlGk8g");
	var mask_20_graphics_203 = new cjs.Graphics().p("AsWL/QlHk+AAnBIAAAAQAAnAFHk+IAAAAQFIk+HOAAIAAAAQHPAAFHE+IAAAAQFIE+AAHAIAAAAQAAHBlIE+IAAAAQlHE+nPAAIAAAAQnOAAlIk+g");
	var mask_20_graphics_204 = new cjs.Graphics().p("AsaMDQlJk/AAnEIAAAAQAAnDFJlAIAAAAQFJk/HRAAIAAAAQHSAAFJE/IAAAAQFJFAAAHDIAAAAQAAHElJE/IAAAAQlJFAnSAAIAAAAQnRAAlJlAg");
	var mask_20_graphics_205 = new cjs.Graphics().p("AsfMIQlLlCAAnGIAAAAQAAnFFLlCIAAAAQFMlBHTAAIAAAAQHUAAFLFBIAAAAQFMFCAAHFIAAAAQAAHGlMFCIAAAAQlLFBnUAAIAAAAQnTAAlMlBg");
	var mask_20_graphics_206 = new cjs.Graphics().p("AsjMMQlNlDAAnJIAAAAQAAnIFNlDIAAAAQFNlDHWAAIAAAAQHXAAFNFDIAAAAQFNFDAAHIIAAAAQAAHJlNFDIAAAAQlNFDnXAAIAAAAQnWAAlNlDg");
	var mask_20_graphics_207 = new cjs.Graphics().p("AsnMQQlPlFAAnLIAAAAQAAnKFPlFIAAAAQFPlFHYAAIAAAAQHZAAFPFFIAAAAQFPFFAAHKIAAAAQAAHLlPFFIAAAAQlPFFnZAAIAAAAQnYAAlPlFg");
	var mask_20_graphics_208 = new cjs.Graphics().p("AsrMUQlRlGAAnOIAAAAQAAnNFRlGIAAAAQFQlHHbAAIAAAAQHcAAFQFHIAAAAQFRFGAAHNIAAAAQAAHOlRFGIAAAAQlQFHncAAIAAAAQnbAAlQlHg");
	var mask_20_graphics_209 = new cjs.Graphics().p("AswMYQlSlIAAnQIAAAAQAAnPFSlIIAAAAQFTlIHdAAIAAAAQHeAAFSFIIAAAAQFTFIAAHPIAAAAQAAHQlTFIIAAAAQlSFIneAAIAAAAQndAAlTlIg");
	var mask_20_graphics_210 = new cjs.Graphics().p("As0McQlTlKAAnSIAAAAQAAnRFTlKIAAAAQFVlKHfAAIAAAAQHgAAFUFKIAAAAQFUFKAAHRIAAAAQAAHSlUFKIAAAAQlUFKngAAIAAAAQnfAAlVlKg");
	var mask_20_graphics_211 = new cjs.Graphics().p("As3MgQlWlMAAnUIAAAAQAAnTFWlMIAAAAQFVlLHiAAIAAAAQHjAAFVFLIAAAAQFWFMAAHTIAAAAQAAHUlWFMIAAAAQlVFLnjAAIAAAAQniAAlVlLg");
	var mask_20_graphics_212 = new cjs.Graphics().p("As7MjQlXlMAAnXIAAAAQAAnWFXlNIAAAAQFXlMHkAAIAAAAQHlAAFXFMIAAAAQFXFNAAHWIAAAAQAAHXlXFMIAAAAQlXFNnlAAIAAAAQnkAAlXlNg");
	var mask_20_graphics_213 = new cjs.Graphics().p("As/MnQlYlOAAnZIAAAAQAAnYFYlOIAAAAQFZlOHmAAIAAAAQHnAAFYFOIAAAAQFZFOAAHYIAAAAQAAHZlZFOIAAAAQlYFOnnAAIAAAAQnmAAlZlOg");
	var mask_20_graphics_214 = new cjs.Graphics().p("AtCMqQlalPAAnbIAAAAQAAnaFalQIAAAAQFalPHoAAIAAAAQHpAAFaFPIAAAAQFaFQAAHaIAAAAQAAHblaFPIAAAAQlaFQnpAAIAAAAQnoAAlalQg");
	var mask_20_graphics_215 = new cjs.Graphics().p("AtGMuQlblRAAndIAAAAQAAncFblRIAAAAQFclRHqAAIAAAAQHrAAFbFRIAAAAQFcFRAAHcIAAAAQAAHdlcFRIAAAAQlbFRnrAAIAAAAQnqAAlclRg");
	var mask_20_graphics_216 = new cjs.Graphics().p("AtJMxQldlSAAnfIAAAAQAAneFdlSIAAAAQFdlTHsAAIAAAAQHtAAFdFTIAAAAQFdFSAAHeIAAAAQAAHfldFSIAAAAQldFTntAAIAAAAQnsAAldlTg");
	var mask_20_graphics_217 = new cjs.Graphics().p("AtNM0QlelUAAngIAAAAQAAnfFelVIAAAAQFflTHuAAIAAAAQHvAAFeFTIAAAAQFfFVAAHfIAAAAQAAHglfFUIAAAAQleFUnvAAIAAAAQnuAAlflUg");
	var mask_20_graphics_218 = new cjs.Graphics().p("AtQM3QlflVAAniIAAAAQAAnhFflWIAAAAQFglVHwAAIAAAAQHxAAFfFVIAAAAQFgFWAAHhIAAAAQAAHilgFVIAAAAQlfFWnxAAIAAAAQnwAAlglWg");
	var mask_20_graphics_219 = new cjs.Graphics().p("AtTM6QlglWAAnkIAAAAQAAnjFglXIAAAAQFhlWHyAAIAAAAQHzAAFgFWIAAAAQFhFXAAHjIAAAAQAAHklhFWIAAAAQlgFXnzAAIAAAAQnyAAlhlXg");
	var mask_20_graphics_220 = new cjs.Graphics().p("AtWM9QlilXAAnmIAAAAQAAnlFilYIAAAAQFilXH0AAIAAAAQH1AAFhFXIAAAAQFjFYAAHlIAAAAQAAHmljFXIAAAAQlhFYn1AAIAAAAQn0AAlilYg");
	var mask_20_graphics_221 = new cjs.Graphics().p("AtZNAQljlZAAnnIAAAAQAAnmFjlZIAAAAQFklZH1AAIAAAAQH2AAFjFZIAAAAQFkFZAAHmIAAAAQAAHnlkFZIAAAAQljFZn2AAIAAAAQn1AAlklZg");
	var mask_20_graphics_222 = new cjs.Graphics().p("AtcNDQlklaAAnpIAAAAQAAnoFklaIAAAAQFllaH3AAIAAAAQH4AAFkFaIAAAAQFlFaAAHoIAAAAQAAHpllFaIAAAAQlkFan4AAIAAAAQn3AAlllag");
	var mask_20_graphics_223 = new cjs.Graphics().p("AteNFQlmlaAAnrIAAAAQAAnqFmlbIAAAAQFllbH5AAIAAAAQH6AAFlFbIAAAAQFmFbAAHqIAAAAQAAHrlmFaIAAAAQllFcn6AAIAAAAQn5AAlllcg");
	var mask_20_graphics_224 = new cjs.Graphics().p("AthNIQlmlcAAnsIAAAAQAAnrFmlcIAAAAQFnlcH6AAIAAAAQH7AAFnFcIAAAAQFmFcAAHrIAAAAQAAHslmFcIAAAAQlnFcn7AAIAAAAQn6AAlnlcg");
	var mask_20_graphics_225 = new cjs.Graphics().p("AtjNKQlolcAAnuIAAAAQAAntFoldIAAAAQFnldH8AAIAAAAQH9AAFnFdIAAAAQFoFdAAHtIAAAAQAAHuloFcIAAAAQlnFen9AAIAAAAQn8AAlnleg");
	var mask_20_graphics_226 = new cjs.Graphics().p("AtmNNQloleAAnvIAAAAQAAnuFoleIAAAAQFpleH9AAIAAAAQH+AAFpFeIAAAAQFoFeAAHuIAAAAQAAHvloFeIAAAAQlpFen+AAIAAAAQn9AAlpleg");
	var mask_20_graphics_227 = new cjs.Graphics().p("AtoNPQlqlfAAnwIAAAAQAAnvFqlgIAAAAQFqleH+AAIAAAAQH/AAFqFeIAAAAQFqFgAAHvIAAAAQAAHwlqFfIAAAAQlqFfn/AAIAAAAQn+AAlqlfg");
	var mask_20_graphics_228 = new cjs.Graphics().p("AtrNRQlqlfAAnyIAAAAQAAnxFqlgIAAAAQFrlfIAAAIAAAAQIBAAFqFfIAAAAQFrFgAAHxIAAAAQAAHylrFfIAAAAQlqFgoBAAIAAAAQoAAAlrlgg");
	var mask_20_graphics_229 = new cjs.Graphics().p("AttNTQlrlgAAnzIAAAAQAAnyFrlhIAAAAQFslgIBAAIAAAAQICAAFrFgIAAAAQFsFhAAHyIAAAAQAAHzlsFgIAAAAQlrFhoCAAIAAAAQoBAAlslhg");
	var mask_20_graphics_230 = new cjs.Graphics().p("AtvNWQlsliAAn0IAAAAQAAnzFsliIAAAAQFtlhICAAIAAAAQIDAAFtFhIAAAAQFsFiAAHzIAAAAQAAH0lsFiIAAAAQltFhoDAAIAAAAQoCAAltlhg");
	var mask_20_graphics_231 = new cjs.Graphics().p("AtxNXQltliAAn1IAAAAQAAn0FtljIAAAAQFuliIDAAIAAAAQIEAAFuFiIAAAAQFtFjAAH0IAAAAQAAH1ltFiIAAAAQluFjoEAAIAAAAQoDAAluljg");
	var mask_20_graphics_232 = new cjs.Graphics().p("AtzNZQluljAAn2IAAAAQAAn1FulkIAAAAQFuljIFAAIAAAAQIGAAFuFjIAAAAQFuFkAAH1IAAAAQAAH2luFjIAAAAQluFkoGAAIAAAAQoFAAlulkg");

	this.timeline.addTween(cjs.Tween.get(mask_20).to({graphics:null,x:0,y:0}).wait(116).to({graphics:mask_20_graphics_116,x:307.5502,y:385.25}).wait(1).to({graphics:mask_20_graphics_117,x:306.7875,y:384.9129}).wait(1).to({graphics:mask_20_graphics_118,x:306.0207,y:384.5732}).wait(1).to({graphics:mask_20_graphics_119,x:305.2494,y:384.232}).wait(1).to({graphics:mask_20_graphics_120,x:304.4745,y:383.8887}).wait(1).to({graphics:mask_20_graphics_121,x:303.6964,y:383.5444}).wait(1).to({graphics:mask_20_graphics_122,x:302.9148,y:383.1984}).wait(1).to({graphics:mask_20_graphics_123,x:302.13,y:382.851}).wait(1).to({graphics:mask_20_graphics_124,x:301.3429,y:382.5022}).wait(1).to({graphics:mask_20_graphics_125,x:300.5536,y:382.153}).wait(1).to({graphics:mask_20_graphics_126,x:299.7621,y:381.8029}).wait(1).to({graphics:mask_20_graphics_127,x:298.9692,y:381.4524}).wait(1).to({graphics:mask_20_graphics_128,x:298.1754,y:381.1005}).wait(1).to({graphics:mask_20_graphics_129,x:297.3798,y:380.7486}).wait(1).to({graphics:mask_20_graphics_130,x:296.5837,y:380.3962}).wait(1).to({graphics:mask_20_graphics_131,x:295.7877,y:380.0439}).wait(1).to({graphics:mask_20_graphics_132,x:294.9912,y:379.6911}).wait(1).to({graphics:mask_20_graphics_133,x:294.1951,y:379.3392}).wait(1).to({graphics:mask_20_graphics_134,x:293.4,y:378.9868}).wait(1).to({graphics:mask_20_graphics_135,x:292.6053,y:378.6354}).wait(1).to({graphics:mask_20_graphics_136,x:291.8124,y:378.2844}).wait(1).to({graphics:mask_20_graphics_137,x:291.0208,y:377.9339}).wait(1).to({graphics:mask_20_graphics_138,x:290.2311,y:377.5846}).wait(1).to({graphics:mask_20_graphics_139,x:289.444,y:377.2355}).wait(1).to({graphics:mask_20_graphics_140,x:288.6583,y:376.8885}).wait(1).to({graphics:mask_20_graphics_141,x:287.8762,y:376.542}).wait(1).to({graphics:mask_20_graphics_142,x:287.0973,y:376.1973}).wait(1).to({graphics:mask_20_graphics_143,x:286.3215,y:375.8539}).wait(1).to({graphics:mask_20_graphics_144,x:285.5493,y:375.5119}).wait(1).to({graphics:mask_20_graphics_145,x:284.7812,y:375.1717}).wait(1).to({graphics:mask_20_graphics_146,x:284.017,y:374.8338}).wait(1).to({graphics:mask_20_graphics_147,x:283.2574,y:374.4977}).wait(1).to({graphics:mask_20_graphics_148,x:282.5023,y:374.1633}).wait(1).to({graphics:mask_20_graphics_149,x:281.7527,y:373.8316}).wait(1).to({graphics:mask_20_graphics_150,x:281.0074,y:373.5018}).wait(1).to({graphics:mask_20_graphics_151,x:280.2681,y:373.1747}).wait(1).to({graphics:mask_20_graphics_152,x:279.5346,y:372.8497}).wait(1).to({graphics:mask_20_graphics_153,x:278.8061,y:372.5271}).wait(1).to({graphics:mask_20_graphics_154,x:278.0843,y:372.2081}).wait(1).to({graphics:mask_20_graphics_155,x:277.3683,y:371.8913}).wait(1).to({graphics:mask_20_graphics_156,x:276.6587,y:371.5771}).wait(1).to({graphics:mask_20_graphics_157,x:275.9562,y:371.2657}).wait(1).to({graphics:mask_20_graphics_158,x:275.26,y:370.9575}).wait(1).to({graphics:mask_20_graphics_159,x:274.5702,y:370.6528}).wait(1).to({graphics:mask_20_graphics_160,x:273.888,y:370.3504}).wait(1).to({graphics:mask_20_graphics_161,x:273.2125,y:370.0517}).wait(1).to({graphics:mask_20_graphics_162,x:272.5452,y:369.756}).wait(1).to({graphics:mask_20_graphics_163,x:271.8846,y:369.4635}).wait(1).to({graphics:mask_20_graphics_164,x:271.2316,y:369.175}).wait(1).to({graphics:mask_20_graphics_165,x:270.5863,y:368.8893}).wait(1).to({graphics:mask_20_graphics_166,x:269.9487,y:368.6071}).wait(1).to({graphics:mask_20_graphics_167,x:269.3187,y:368.3281}).wait(1).to({graphics:mask_20_graphics_168,x:268.6972,y:368.0527}).wait(1).to({graphics:mask_20_graphics_169,x:268.083,y:367.7809}).wait(1).to({graphics:mask_20_graphics_170,x:267.4773,y:367.5132}).wait(1).to({graphics:mask_20_graphics_171,x:266.8792,y:367.2481}).wait(1).to({graphics:mask_20_graphics_172,x:266.2897,y:366.9871}).wait(1).to({graphics:mask_20_graphics_173,x:265.7084,y:366.7302}).wait(1).to({graphics:mask_20_graphics_174,x:265.135,y:366.476}).wait(1).to({graphics:mask_20_graphics_175,x:264.5703,y:366.2262}).wait(1).to({graphics:mask_20_graphics_176,x:264.0136,y:365.9796}).wait(1).to({graphics:mask_20_graphics_177,x:263.4655,y:365.7375}).wait(1).to({graphics:mask_20_graphics_178,x:262.9255,y:365.4986}).wait(1).to({graphics:mask_20_graphics_179,x:262.3936,y:365.2627}).wait(1).to({graphics:mask_20_graphics_180,x:261.8708,y:365.0314}).wait(1).to({graphics:mask_20_graphics_181,x:261.3555,y:364.8033}).wait(1).to({graphics:mask_20_graphics_182,x:260.8492,y:364.5797}).wait(1).to({graphics:mask_20_graphics_183,x:260.3511,y:364.3587}).wait(1).to({graphics:mask_20_graphics_184,x:259.861,y:364.1422}).wait(1).to({graphics:mask_20_graphics_185,x:259.38,y:363.9289}).wait(1).to({graphics:mask_20_graphics_186,x:258.9066,y:363.7197}).wait(1).to({graphics:mask_20_graphics_187,x:258.4417,y:363.514}).wait(1).to({graphics:mask_20_graphics_188,x:257.9855,y:363.3115}).wait(1).to({graphics:mask_20_graphics_189,x:257.5372,y:363.1131}).wait(1).to({graphics:mask_20_graphics_190,x:257.0971,y:362.9187}).wait(1).to({graphics:mask_20_graphics_191,x:256.6651,y:362.7274}).wait(1).to({graphics:mask_20_graphics_192,x:256.2417,y:362.5402}).wait(1).to({graphics:mask_20_graphics_193,x:255.8263,y:362.3562}).wait(1).to({graphics:mask_20_graphics_194,x:255.4191,y:362.1758}).wait(1).to({graphics:mask_20_graphics_195,x:255.0195,y:361.9989}).wait(1).to({graphics:mask_20_graphics_196,x:254.628,y:361.8256}).wait(1).to({graphics:mask_20_graphics_197,x:254.2446,y:361.6555}).wait(1).to({graphics:mask_20_graphics_198,x:253.8688,y:361.4899}).wait(1).to({graphics:mask_20_graphics_199,x:253.5012,y:361.327}).wait(1).to({graphics:mask_20_graphics_200,x:253.1416,y:361.1677}).wait(1).to({graphics:mask_20_graphics_201,x:252.7893,y:361.0116}).wait(1).to({graphics:mask_20_graphics_202,x:252.445,y:360.8595}).wait(1).to({graphics:mask_20_graphics_203,x:252.1084,y:360.7105}).wait(1).to({graphics:mask_20_graphics_204,x:251.7791,y:360.5648}).wait(1).to({graphics:mask_20_graphics_205,x:251.4573,y:360.4221}).wait(1).to({graphics:mask_20_graphics_206,x:251.1432,y:360.2835}).wait(1).to({graphics:mask_20_graphics_207,x:250.8363,y:360.1476}).wait(1).to({graphics:mask_20_graphics_208,x:250.537,y:360.0149}).wait(1).to({graphics:mask_20_graphics_209,x:250.2455,y:359.8857}).wait(1).to({graphics:mask_20_graphics_210,x:249.9606,y:359.7597}).wait(1).to({graphics:mask_20_graphics_211,x:249.6829,y:359.6368}).wait(1).to({graphics:mask_20_graphics_212,x:249.4125,y:359.5171}).wait(1).to({graphics:mask_20_graphics_213,x:249.1492,y:359.4006}).wait(1).to({graphics:mask_20_graphics_214,x:248.8927,y:359.2872}).wait(1).to({graphics:mask_20_graphics_215,x:248.6434,y:359.1769}).wait(1).to({graphics:mask_20_graphics_216,x:248.4009,y:359.0694}).wait(1).to({graphics:mask_20_graphics_217,x:248.1656,y:358.965}).wait(1).to({graphics:mask_20_graphics_218,x:247.9369,y:358.8637}).wait(1).to({graphics:mask_20_graphics_219,x:247.7146,y:358.7661}).wait(1).to({graphics:mask_20_graphics_220,x:247.4991,y:358.6707}).wait(1).to({graphics:mask_20_graphics_221,x:247.2907,y:358.578}).wait(1).to({graphics:mask_20_graphics_222,x:247.0882,y:358.4884}).wait(1).to({graphics:mask_20_graphics_223,x:246.8925,y:358.4016}).wait(1).to({graphics:mask_20_graphics_224,x:246.703,y:358.3179}).wait(1).to({graphics:mask_20_graphics_225,x:246.5199,y:358.2369}).wait(1).to({graphics:mask_20_graphics_226,x:246.3435,y:358.1586}).wait(1).to({graphics:mask_20_graphics_227,x:246.1729,y:358.0834}).wait(1).to({graphics:mask_20_graphics_228,x:246.0082,y:358.0105}).wait(1).to({graphics:mask_20_graphics_229,x:245.8503,y:357.9408}).wait(1).to({graphics:mask_20_graphics_230,x:245.6987,y:357.8733}).wait(1).to({graphics:mask_20_graphics_231,x:245.5524,y:357.8085}).wait(1).to({graphics:mask_20_graphics_232,x:245.4125,y:357.7063}).wait(578));

	// Layer_18
	this.instance_35 = new lib.Tween40("synched",0);
	this.instance_35.setTransform(255.75,365.15);
	this.instance_35.alpha = 0.5;
	this.instance_35._off = true;

	this.instance_36 = new lib.Tween41("synched",0);
	this.instance_36.setTransform(255.75,365.15);

	var maskedShapeInstanceList = [this.instance_35,this.instance_36];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_20;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_35}]},116).to({state:[{t:this.instance_36}]},116).wait(578));
	this.timeline.addTween(cjs.Tween.get(this.instance_35).wait(116).to({_off:false},0).to({_off:true,alpha:1},116).wait(578));

	// Layer_6 (mask)
	var mask_21 = new cjs.Shape();
	mask_21._off = true;
	var mask_21_graphics_208 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_21_graphics_209 = new cjs.Graphics().p("AgkAkQgPgPAAgVIAAAAQAAgUAPgPIAAAAQAPgOAVAAIAAAAQAWAAAPAOIAAAAQAPAPAAAUIAAAAQAAAVgPAPIAAAAQgPAOgWAAIAAAAQgVAAgPgOg");
	var mask_21_graphics_210 = new cjs.Graphics().p("Ag4A3QgYgXAAggIAAAAQAAgfAYgXIAAAAQAYgWAgAAIAAAAQAhAAAYAWIAAAAQAYAXAAAfIAAAAQAAAggYAXIAAAAQgYAWghAAIAAAAQggAAgYgWg");
	var mask_21_graphics_211 = new cjs.Graphics().p("AhMBKQgggfAAgrIAAAAQAAgqAggfIAAAAQAggfAsAAIAAAAQAtAAAgAfIAAAAQAgAfAAAqIAAAAQAAArggAfIAAAAQggAfgtAAIAAAAQgsAAgggfg");
	var mask_21_graphics_212 = new cjs.Graphics().p("AhgBdQgpgmAAg3IAAAAQAAg2ApgmIAAAAQAognA4AAIAAAAQA5AAAoAnIAAAAQApAmAAA2IAAAAQAAA3gpAmIAAAAQgoAng5AAIAAAAQg4AAgogng");
	var mask_21_graphics_213 = new cjs.Graphics().p("Ah1BxQgxgvAAhCIAAAAQAAhBAxgvIAAAAQAxgvBEAAIAAAAQBFAAAxAvIAAAAQAxAvAABBIAAAAQAABCgxAvIAAAAQgxAvhFAAIAAAAQhEAAgxgvg");
	var mask_21_graphics_214 = new cjs.Graphics().p("AiJCEQg6g2AAhOIAAAAQAAhNA6g3IAAAAQA5g2BQAAIAAAAQBRAAA5A2IAAAAQA6A3AABNIAAAAQAABOg6A2IAAAAQg5A3hRAAIAAAAQhQAAg5g3g");
	var mask_21_graphics_215 = new cjs.Graphics().p("AieCYQhCg/AAhZIAAAAQAAhYBCg/IAAAAQBCg/BcAAIAAAAQBdAABCA/IAAAAQBCA/AABYIAAAAQAABZhCA/IAAAAQhCA/hdAAIAAAAQhcAAhCg/g");
	var mask_21_graphics_216 = new cjs.Graphics().p("AiyCsQhLhHAAhlIAAAAQAAhkBLhHIAAAAQBKhHBoAAIAAAAQBpAABKBHIAAAAQBLBHAABkIAAAAQAABlhLBHIAAAAQhKBHhpAAIAAAAQhoAAhKhHg");
	var mask_21_graphics_217 = new cjs.Graphics().p("AjHDAQhThQAAhwIAAAAQAAhvBThQIAAAAQBThPB0AAIAAAAQB1AABTBPIAAAAQBTBQAABvIAAAAQAABwhTBQIAAAAQhTBPh1AAIAAAAQh0AAhThPg");
	var mask_21_graphics_218 = new cjs.Graphics().p("AjcDTQhbhXAAh8IAAAAQAAh7BbhXIAAAAQBchYCAAAIAAAAQCBAABcBYIAAAAQBbBXAAB7IAAAAQAAB8hbBXIAAAAQhcBYiBAAIAAAAQiAAAhchYg");
	var mask_21_graphics_219 = new cjs.Graphics().p("AjwDnQhkhgAAiHIAAAAQAAiGBkhgIAAAAQBkhgCMAAIAAAAQCNAABkBgIAAAAQBkBgAACGIAAAAQAACHhkBgIAAAAQhkBgiNAAIAAAAQiMAAhkhgg");
	var mask_21_graphics_220 = new cjs.Graphics().p("AkFD7QhshoAAiTIAAAAQAAiSBshoIAAAAQBthoCYAAIAAAAQCZAABtBoIAAAAQBsBoAACSIAAAAQAACThsBoIAAAAQhtBoiZAAIAAAAQiYAAhthog");
	var mask_21_graphics_221 = new cjs.Graphics().p("AkaEPQh1hwAAifIAAAAQAAieB1hwIAAAAQB2hwCkAAIAAAAQClAAB1BwIAAAAQB2BwAACeIAAAAQAACfh2BwIAAAAQh1BwilAAIAAAAQikAAh2hwg");
	var mask_21_graphics_222 = new cjs.Graphics().p("AkuEiQh+h4AAiqIAAAAQAAipB+h4IAAAAQB9h5CxAAIAAAAQCyAAB9B5IAAAAQB+B4AACpIAAAAQAACqh+B4IAAAAQh9B5iyAAIAAAAQixAAh9h5g");
	var mask_21_graphics_223 = new cjs.Graphics().p("AlDE2QiGiAAAi2IAAAAQAAi1CGiAIAAAAQCHiAC8AAIAAAAQC9AACGCAIAAAAQCHCAAAC1IAAAAQAAC2iHCAIAAAAQiGCAi9AAIAAAAQi8AAiHiAg");
	var mask_21_graphics_224 = new cjs.Graphics().p("AlXFJQiOiIAAjBIAAAAQAAjACOiJIAAAAQCPiIDIAAIAAAAQDJAACPCIIAAAAQCOCJAADAIAAAAQAADBiOCIIAAAAQiPCJjJAAIAAAAQjIAAiPiJg");
	var mask_21_graphics_225 = new cjs.Graphics().p("AlrFdQiXiRAAjMIAAAAQAAjLCXiRIAAAAQCXiQDUAAIAAAAQDVAACXCQIAAAAQCXCRAADLIAAAAQAADMiXCRIAAAAQiXCQjVAAIAAAAQjUAAiXiQg");
	var mask_21_graphics_226 = new cjs.Graphics().p("Al/FwQifiYAAjYIAAAAQAAjXCfiYIAAAAQCfiZDgAAIAAAAQDhAACfCZIAAAAQCfCYAADXIAAAAQAADYifCYIAAAAQifCZjhAAIAAAAQjgAAifiZg");
	var mask_21_graphics_227 = new cjs.Graphics().p("AmTGDQioigAAjjIAAAAQAAjiCoigIAAAAQCnihDsAAIAAAAQDtAACnChIAAAAQCoCgAADiIAAAAQAADjioCgIAAAAQinChjtAAIAAAAQjsAAinihg");
	var mask_21_graphics_228 = new cjs.Graphics().p("AmnGWQiwioAAjuIAAAAQAAjtCwioIAAAAQCwipD3AAIAAAAQD4AACwCpIAAAAQCwCoAADtIAAAAQAADuiwCoIAAAAQiwCpj4AAIAAAAQj3AAiwipg");
	var mask_21_graphics_229 = new cjs.Graphics().p("Am7GpQi4iwAAj5IAAAAQAAj4C4iwIAAAAQC4iwEDAAIAAAAQEEAAC4CwIAAAAQC4CwAAD4IAAAAQAAD5i4CwIAAAAQi4CwkEAAIAAAAQkDAAi4iwg");
	var mask_21_graphics_230 = new cjs.Graphics().p("AnOG8QjAi4AAkEIAAAAQAAkDDAi4IAAAAQDAi4EOAAIAAAAQEPAADAC4IAAAAQDAC4AAEDIAAAAQAAEEjAC4IAAAAQjAC4kPAAIAAAAQkOAAjAi4g");
	var mask_21_graphics_231 = new cjs.Graphics().p("AniHOQjHi/AAkPIAAAAQAAkODHi/IAAAAQDIjAEaAAIAAAAQEbAADHDAIAAAAQDIC/AAEOIAAAAQAAEPjIC/IAAAAQjHDAkbAAIAAAAQkaAAjIjAg");
	var mask_21_graphics_232 = new cjs.Graphics().p("An1HgQjPjHAAkZIAAAAQAAkYDPjIIAAAAQDQjHElAAIAAAAQEmAADPDHIAAAAQDQDIAAEYIAAAAQAAEZjQDHIAAAAQjPDIkmAAIAAAAQklAAjQjIg");
	var mask_21_graphics_233 = new cjs.Graphics().p("AoHHyQjYjOAAkkIAAAAQAAkjDYjPIAAAAQDXjOEwAAIAAAAQExAADXDOIAAAAQDYDPAAEjIAAAAQAAEkjYDOIAAAAQjXDPkxAAIAAAAQkwAAjXjPg");
	var mask_21_graphics_234 = new cjs.Graphics().p("AoaIEQjfjWAAkuIAAAAQAAktDfjWIAAAAQDfjWE7AAIAAAAQE8AADfDWIAAAAQDfDWAAEtIAAAAQAAEujfDWIAAAAQjfDWk8AAIAAAAQk7AAjfjWg");
	var mask_21_graphics_235 = new cjs.Graphics().p("AosIWQjnjdAAk5IAAAAQAAk4DnjdIAAAAQDnjdFFAAIAAAAQFGAADnDdIAAAAQDnDdAAE4IAAAAQAAE5jnDdIAAAAQjnDdlGAAIAAAAQlFAAjnjdg");
	var mask_21_graphics_236 = new cjs.Graphics().p("Ao+InQjujkAAlDIAAAAQAAlCDujkIAAAAQDujkFQAAIAAAAQFRAADuDkIAAAAQDuDkAAFCIAAAAQAAFDjuDkIAAAAQjuDklRAAIAAAAQlQAAjujkg");
	var mask_21_graphics_237 = new cjs.Graphics().p("ApQI4Qj2jrAAlNIAAAAQAAlMD2jrIAAAAQD2jrFaAAIAAAAQFbAAD2DrIAAAAQD2DrAAFMIAAAAQAAFNj2DrIAAAAQj2DrlbAAIAAAAQlaAAj2jrg");
	var mask_21_graphics_238 = new cjs.Graphics().p("ApiJJQj8jyAAlXIAAAAQAAlWD8jyIAAAAQD9jyFlAAIAAAAQFmAAD8DyIAAAAQD9DyAAFWIAAAAQAAFXj9DyIAAAAQj8DylmAAIAAAAQllAAj9jyg");
	var mask_21_graphics_239 = new cjs.Graphics().p("ApzJZQkEj5AAlgIAAAAQAAlfEEj6IAAAAQEEj5FvAAIAAAAQFwAAEDD5IAAAAQEFD6AAFfIAAAAQAAFgkFD5IAAAAQkDD6lwAAIAAAAQlvAAkEj6g");
	var mask_21_graphics_240 = new cjs.Graphics().p("AqEJpQkLj/AAlqIAAAAQAAlpELkAIAAAAQELj/F5AAIAAAAQF6AAEKD/IAAAAQEMEAAAFpIAAAAQAAFqkMD/IAAAAQkKEAl6AAIAAAAQl5AAkLkAg");
	var mask_21_graphics_241 = new cjs.Graphics().p("AqUJ5QkSkGAAlzIAAAAQAAlyESkHIAAAAQESkGGCAAIAAAAQGDAAESEGIAAAAQESEHAAFyIAAAAQAAFzkSEGIAAAAQkSEHmDAAIAAAAQmCAAkSkHg");
	var mask_21_graphics_242 = new cjs.Graphics().p("AqlKJQkYkNAAl8IAAAAQAAl7EYkNIAAAAQEZkNGMAAIAAAAQGNAAEYENIAAAAQEZENAAF7IAAAAQAAF8kZENIAAAAQkYENmNAAIAAAAQmMAAkZkNg");
	var mask_21_graphics_243 = new cjs.Graphics().p("Aq1KYQkfkTAAmFIAAAAQAAmEEfkUIAAAAQEgkTGVAAIAAAAQGWAAEfETIAAAAQEgEUAAGEIAAAAQAAGFkgETIAAAAQkfEUmWAAIAAAAQmVAAkgkUg");
	var mask_21_graphics_244 = new cjs.Graphics().p("ArEKnQkmkZAAmOIAAAAQAAmNEmkaIAAAAQEmkZGeAAIAAAAQGfAAEmEZIAAAAQEmEaAAGNIAAAAQAAGOkmEZIAAAAQkmEamfAAIAAAAQmeAAkmkag");
	var mask_21_graphics_245 = new cjs.Graphics().p("ArUK2QkskfAAmXIAAAAQAAmWEskfIAAAAQEtkgGnAAIAAAAQGoAAEsEgIAAAAQEtEfAAGWIAAAAQAAGXktEfIAAAAQksEgmoAAIAAAAQmnAAktkgg");
	var mask_21_graphics_246 = new cjs.Graphics().p("ArjLEQkyklAAmfIAAAAQAAmeEykmIAAAAQEzklGwAAIAAAAQGxAAEyElIAAAAQEzEmAAGeIAAAAQAAGfkzElIAAAAQkyEmmxAAIAAAAQmwAAkzkmg");
	var mask_21_graphics_247 = new cjs.Graphics().p("ArxLTQk5ksAAmnIAAAAQAAmmE5ksIAAAAQE4krG5AAIAAAAQG6AAE4ErIAAAAQE5EsAAGmIAAAAQAAGnk5EsIAAAAQk4Erm6AAIAAAAQm5AAk4krg");
	var mask_21_graphics_248 = new cjs.Graphics().p("AsALgQk+kxAAmvIAAAAQAAmuE+kyIAAAAQE/kxHBAAIAAAAQHCAAE+ExIAAAAQE/EyAAGuIAAAAQAAGvk/ExIAAAAQk+EynCAAIAAAAQnBAAk/kyg");
	var mask_21_graphics_249 = new cjs.Graphics().p("AsOLuQlEk3AAm3IAAAAQAAm2FEk3IAAAAQFFk3HJAAIAAAAQHKAAFFE3IAAAAQFEE3AAG2IAAAAQAAG3lEE3IAAAAQlFE3nKAAIAAAAQnJAAlFk3g");
	var mask_21_graphics_250 = new cjs.Graphics().p("AscL7QlJk8AAm/IAAAAQAAm+FJk8IAAAAQFLk8HRAAIAAAAQHSAAFKE8IAAAAQFKE8AAG+IAAAAQAAG/lKE8IAAAAQlKE8nSAAIAAAAQnRAAlLk8g");
	var mask_21_graphics_251 = new cjs.Graphics().p("AspMIQlPlBAAnHIAAAAQAAnGFPlBIAAAAQFQlBHZAAIAAAAQHaAAFQFBIAAAAQFPFBAAHGIAAAAQAAHHlPFBIAAAAQlQFBnaAAIAAAAQnZAAlQlBg");
	var mask_21_graphics_252 = new cjs.Graphics().p("As2MUQlVlGAAnOIAAAAQAAnNFVlHIAAAAQFVlGHhAAIAAAAQHiAAFVFGIAAAAQFVFHAAHNIAAAAQAAHOlVFGIAAAAQlVFHniAAIAAAAQnhAAlVlHg");
	var mask_21_graphics_253 = new cjs.Graphics().p("AtDMhQlalMAAnVIAAAAQAAnUFalMIAAAAQFblLHoAAIAAAAQHpAAFaFLIAAAAQFbFMAAHUIAAAAQAAHVlbFMIAAAAQlaFLnpAAIAAAAQnoAAlblLg");
	var mask_21_graphics_254 = new cjs.Graphics().p("AtPMsQlflQAAncIAAAAQAAnbFflRIAAAAQFflQHwAAIAAAAQHxAAFfFQIAAAAQFfFRAAHbIAAAAQAAHclfFQIAAAAQlfFRnxAAIAAAAQnwAAlflRg");
	var mask_21_graphics_255 = new cjs.Graphics().p("AtbM4QlllVAAnjIAAAAQAAniFllVIAAAAQFklWH3AAIAAAAQH4AAFkFWIAAAAQFlFVAAHiIAAAAQAAHjllFVIAAAAQlkFWn4AAIAAAAQn3AAlklWg");
	var mask_21_graphics_256 = new cjs.Graphics().p("AtnNDQlplaAAnpIAAAAQAAnoFplbIAAAAQFplaH+AAIAAAAQH/AAFpFaIAAAAQFpFbAAHoIAAAAQAAHplpFaIAAAAQlpFbn/AAIAAAAQn+AAlplbg");
	var mask_21_graphics_257 = new cjs.Graphics().p("AtzNOQltleAAnwIAAAAQAAnvFtlfIAAAAQFvleIEAAIAAAAQIFAAFuFeIAAAAQFuFfAAHvIAAAAQAAHwluFeIAAAAQluFfoFAAIAAAAQoEAAlvlfg");
	var mask_21_graphics_258 = new cjs.Graphics().p("At+NZQlyljAAn2IAAAAQAAn1FyljIAAAAQFzljILAAIAAAAQIMAAFyFjIAAAAQFzFjAAH1IAAAAQAAH2lzFjIAAAAQlyFjoMAAIAAAAQoLAAlzljg");
	var mask_21_graphics_259 = new cjs.Graphics().p("AuJNjQl2lnAAn8IAAAAQAAn7F2loIAAAAQF4lnIRAAIAAAAQISAAF3FnIAAAAQF3FoAAH7IAAAAQAAH8l3FnIAAAAQl3FooSAAIAAAAQoRAAl4log");
	var mask_21_graphics_260 = new cjs.Graphics().p("AuTNtQl7lrAAoCIAAAAQAAoBF7lsIAAAAQF8lrIXAAIAAAAQIYAAF8FrIAAAAQF7FsAAIBIAAAAQAAICl7FrIAAAAQl8FsoYAAIAAAAQoXAAl8lsg");
	var mask_21_graphics_261 = new cjs.Graphics().p("AudN3QmAlvAAoIIAAAAQAAoHGAlwIAAAAQGAlvIdAAIAAAAQIeAAGAFvIAAAAQGAFwAAIHIAAAAQAAIImAFvIAAAAQmAFwoeAAIAAAAQodAAmAlwg");
	var mask_21_graphics_262 = new cjs.Graphics().p("AunOBQmEl0AAoNIAAAAQAAoMGEl0IAAAAQGElzIjAAIAAAAQIkAAGEFzIAAAAQGEF0AAIMIAAAAQAAINmEF0IAAAAQmEFzokAAIAAAAQojAAmElzg");
	var mask_21_graphics_263 = new cjs.Graphics().p("AuxOKQmHl3AAoTIAAAAQAAoSGHl3IAAAAQGIl3IpAAIAAAAQIqAAGHF3IAAAAQGIF3AAISIAAAAQAAITmIF3IAAAAQmHF3oqAAIAAAAQopAAmIl3g");
	var mask_21_graphics_264 = new cjs.Graphics().p("Au6OTQmLl7AAoYIAAAAQAAoXGLl7IAAAAQGMl7IuAAIAAAAQIvAAGMF7IAAAAQGLF7AAIXIAAAAQAAIYmLF7IAAAAQmMF7ovAAIAAAAQouAAmMl7g");
	var mask_21_graphics_265 = new cjs.Graphics().p("AvDObQmPl+AAodIAAAAQAAocGPl/IAAAAQGQl+IzAAIAAAAQI0AAGPF+IAAAAQGQF/AAIcIAAAAQAAIdmQF+IAAAAQmPF/o0AAIAAAAQozAAmQl/g");
	var mask_21_graphics_266 = new cjs.Graphics().p("AvMOjQmSmBAAoiIAAAAQAAohGSmCIAAAAQGTmCI5AAIAAAAQI6AAGSGCIAAAAQGTGCAAIhIAAAAQAAIimTGBIAAAAQmSGDo6AAIAAAAQo5AAmTmDg");
	var mask_21_graphics_267 = new cjs.Graphics().p("AvUOrQmWmFAAomIAAAAQAAolGWmGIAAAAQGXmFI9AAIAAAAQI+AAGWGFIAAAAQGXGGAAIlIAAAAQAAImmXGFIAAAAQmWGGo+AAIAAAAQo9AAmXmGg");
	var mask_21_graphics_268 = new cjs.Graphics().p("AvcOzQmZmIAAorIAAAAQAAoqGZmJIAAAAQGamIJCAAIAAAAQJDAAGaGIIAAAAQGZGJAAIqIAAAAQAAIrmZGIIAAAAQmaGJpDAAIAAAAQpCAAmamJg");
	var mask_21_graphics_269 = new cjs.Graphics().p("AvkO7QmcmMAAovIAAAAQAAouGcmMIAAAAQGdmMJHAAIAAAAQJIAAGcGMIAAAAQGdGMAAIuIAAAAQAAIvmdGMIAAAAQmcGMpIAAIAAAAQpHAAmdmMg");
	var mask_21_graphics_270 = new cjs.Graphics().p("AvrPCQmgmOAAo0IAAAAQAAozGgmOIAAAAQGgmPJLAAIAAAAQJMAAGgGPIAAAAQGgGOAAIzIAAAAQAAI0mgGOIAAAAQmgGPpMAAIAAAAQpLAAmgmPg");
	var mask_21_graphics_271 = new cjs.Graphics().p("AvzPJQmimRAAo4IAAAAQAAo3GimRIAAAAQGkmRJPAAIAAAAQJQAAGjGRIAAAAQGjGRAAI3IAAAAQAAI4mjGRIAAAAQmjGRpQAAIAAAAQpPAAmkmRg");
	var mask_21_graphics_272 = new cjs.Graphics().p("Av5PPQmmmUAAo7IAAAAQAAo6GmmVIAAAAQGmmUJTAAIAAAAQJUAAGmGUIAAAAQGmGVAAI6IAAAAQAAI7mmGUIAAAAQmmGVpUAAIAAAAQpTAAmmmVg");
	var mask_21_graphics_273 = new cjs.Graphics().p("AwAPWQmomXAAo/IAAAAQAAo+GomXIAAAAQGpmXJXAAIAAAAQJYAAGpGXIAAAAQGoGXAAI+IAAAAQAAI/moGXIAAAAQmpGXpYAAIAAAAQpXAAmpmXg");
	var mask_21_graphics_274 = new cjs.Graphics().p("AwGPcQmrmZAApDIAAAAQAApCGrmZIAAAAQGrmZJbAAIAAAAQJcAAGrGZIAAAAQGrGZAAJCIAAAAQAAJDmrGZIAAAAQmrGZpcAAIAAAAQpbAAmrmZg");
	var mask_21_graphics_275 = new cjs.Graphics().p("AwNPiQmtmcAApGIAAAAQAApFGtmcIAAAAQGumcJfAAIAAAAQJgAAGtGcIAAAAQGuGcAAJFIAAAAQAAJGmuGcIAAAAQmtGcpgAAIAAAAQpfAAmumcg");
	var mask_21_graphics_276 = new cjs.Graphics().p("AwSPnQmwmeAApJIAAAAQAApIGwmfIAAAAQGwmeJiAAIAAAAQJjAAGwGeIAAAAQGwGfAAJIIAAAAQAAJJmwGeIAAAAQmwGfpjAAIAAAAQpiAAmwmfg");
	var mask_21_graphics_277 = new cjs.Graphics().p("AwYPtQmymgAApNIAAAAQAApMGymgIAAAAQGzmgJlAAIAAAAQJmAAGyGgIAAAAQGzGgAAJMIAAAAQAAJNmzGgIAAAAQmyGgpmAAIAAAAQplAAmzmgg");
	var mask_21_graphics_278 = new cjs.Graphics().p("AwdPyQm1miAApQIAAAAQAApPG1miIAAAAQG1miJoAAIAAAAQJpAAG1GiIAAAAQG1GiAAJPIAAAAQAAJQm1GiIAAAAQm1GippAAIAAAAQpoAAm1mig");
	var mask_21_graphics_279 = new cjs.Graphics().p("AwiP3Qm3mlAApSIAAAAQAApRG3mlIAAAAQG3mkJrAAIAAAAQJsAAG3GkIAAAAQG3GlAAJRIAAAAQAAJSm3GlIAAAAQm3GkpsAAIAAAAQprAAm3mkg");
	var mask_21_graphics_280 = new cjs.Graphics().p("AwnP7Qm5mmAApVIAAAAQAApUG5mnIAAAAQG5mmJuAAIAAAAQJvAAG5GmIAAAAQG5GnAAJUIAAAAQAAJVm5GmIAAAAQm5GnpvAAIAAAAQpuAAm5mng");
	var mask_21_graphics_281 = new cjs.Graphics().p("AwsQAQm6moAApYIAAAAQAApXG6moIAAAAQG7moJxAAIAAAAQJyAAG6GoIAAAAQG7GoAAJXIAAAAQAAJYm7GoIAAAAQm6GopyAAIAAAAQpxAAm7mog");
	var mask_21_graphics_282 = new cjs.Graphics().p("AwwQEQm8mqAApaIAAAAQAApZG8mqIAAAAQG9mqJzAAIAAAAQJ0AAG9GqIAAAAQG8GqAAJZIAAAAQAAJam8GqIAAAAQm9Gqp0AAIAAAAQpzAAm9mqg");
	var mask_21_graphics_283 = new cjs.Graphics().p("Aw0QIQm+msAApcIAAAAQAApbG+msIAAAAQG+mrJ2AAIAAAAQJ3AAG+GrIAAAAQG+GsAAJbIAAAAQAAJcm+GsIAAAAQm+Grp3AAIAAAAQp2AAm+mrg");
	var mask_21_graphics_284 = new cjs.Graphics().p("Aw4QLQnAmsAApfIAAAAQAApeHAmtIAAAAQHAmtJ4AAIAAAAQJ5AAHAGtIAAAAQHAGtAAJeIAAAAQAAJfnAGsIAAAAQnAGup5AAIAAAAQp4AAnAmug");
	var mask_21_graphics_285 = new cjs.Graphics().p("Aw8QPQnBmuAAphIAAAAQAApgHBmuIAAAAQHCmvJ6AAIAAAAQJ7AAHBGvIAAAAQHCGuAAJgIAAAAQAAJhnCGuIAAAAQnBGvp7AAIAAAAQp6AAnCmvg");
	var mask_21_graphics_286 = new cjs.Graphics().p("Aw/QSQnCmvAApjIAAAAQAApiHCmwIAAAAQHDmvJ8AAIAAAAQJ9AAHDGvIAAAAQHCGwAAJiIAAAAQAAJjnCGvIAAAAQnDGwp9AAIAAAAQp8AAnDmwg");
	var mask_21_graphics_287 = new cjs.Graphics().p("AxCQVQnEmxAApkIAAAAQAApjHEmyIAAAAQHEmwJ+AAIAAAAQJ/AAHEGwIAAAAQHEGyAAJjIAAAAQAAJknEGxIAAAAQnEGxp/AAIAAAAQp+AAnEmxg");
	var mask_21_graphics_288 = new cjs.Graphics().p("AxFQYQnFmyAApmIAAAAQAAplHFmyIAAAAQHFmyKAAAIAAAAQKBAAHFGyIAAAAQHFGyAAJlIAAAAQAAJmnFGyIAAAAQnFGyqBAAIAAAAQqAAAnFmyg");
	var mask_21_graphics_289 = new cjs.Graphics().p("AxIQaQnGmzAApnIAAAAQAApmHGm0IAAAAQHHmzKBAAIAAAAQKCAAHGGzIAAAAQHHG0AAJmIAAAAQAAJnnHGzIAAAAQnGG0qCAAIAAAAQqBAAnHm0g");
	var mask_21_graphics_290 = new cjs.Graphics().p("AxKQdQnHm0AAppIAAAAQAApoHHm0IAAAAQHHm0KDAAIAAAAQKEAAHHG0IAAAAQHHG0AAJoIAAAAQAAJpnHG0IAAAAQnHG0qEAAIAAAAQqDAAnHm0g");
	var mask_21_graphics_291 = new cjs.Graphics().p("AxNQfQnIm1AApqIAAAAQAAppHIm2IAAAAQHJm1KEAAIAAAAQKFAAHIG1IAAAAQHJG2AAJpIAAAAQAAJqnJG1IAAAAQnIG2qFAAIAAAAQqEAAnJm2g");
	var mask_21_graphics_292 = new cjs.Graphics().p("AxPQhQnJm2AAprIAAAAQAApqHJm3IAAAAQHKm1KFAAIAAAAQKGAAHJG1IAAAAQHKG3AAJqIAAAAQAAJrnKG2IAAAAQnJG2qGAAIAAAAQqFAAnKm2g");
	var mask_21_graphics_293 = new cjs.Graphics().p("AxRQjQnJm3AApsIAAAAQAAprHJm3IAAAAQHLm3KGAAIAAAAQKHAAHKG3IAAAAQHKG3AAJrIAAAAQAAJsnKG3IAAAAQnKG3qHAAIAAAAQqGAAnLm3g");
	var mask_21_graphics_294 = new cjs.Graphics().p("AxSQkQnLm3AAptIAAAAQAApsHLm4IAAAAQHLm3KHAAIAAAAQKIAAHLG3IAAAAQHLG4AAJsIAAAAQAAJtnLG3IAAAAQnLG4qIAAIAAAAQqHAAnLm4g");

	this.timeline.addTween(cjs.Tween.get(mask_21).to({graphics:null,x:0,y:0}).wait(208).to({graphics:mask_21_graphics_208,x:182.7504,y:587.8003}).wait(1).to({graphics:mask_21_graphics_209,x:182.934,y:588.2035}).wait(1).to({graphics:mask_21_graphics_210,x:183.1194,y:588.6108}).wait(1).to({graphics:mask_21_graphics_211,x:183.3062,y:589.0212}).wait(1).to({graphics:mask_21_graphics_212,x:183.4942,y:589.4338}).wait(1).to({graphics:mask_21_graphics_213,x:183.6833,y:589.8487}).wait(1).to({graphics:mask_21_graphics_214,x:183.8736,y:590.2654}).wait(1).to({graphics:mask_21_graphics_215,x:184.0635,y:590.6844}).wait(1).to({graphics:mask_21_graphics_216,x:184.2552,y:591.1038}).wait(1).to({graphics:mask_21_graphics_217,x:184.4464,y:591.5241}).wait(1).to({graphics:mask_21_graphics_218,x:184.6377,y:591.9453}).wait(1).to({graphics:mask_21_graphics_219,x:184.8298,y:592.366}).wait(1).to({graphics:mask_21_graphics_220,x:185.0215,y:592.7863}).wait(1).to({graphics:mask_21_graphics_221,x:185.2123,y:593.2062}).wait(1).to({graphics:mask_21_graphics_222,x:185.4027,y:593.6242}).wait(1).to({graphics:mask_21_graphics_223,x:185.593,y:594.0414}).wait(1).to({graphics:mask_21_graphics_224,x:185.7821,y:594.4563}).wait(1).to({graphics:mask_21_graphics_225,x:185.9697,y:594.8689}).wait(1).to({graphics:mask_21_graphics_226,x:186.1564,y:595.2793}).wait(1).to({graphics:mask_21_graphics_227,x:186.3419,y:595.6866}).wait(1).to({graphics:mask_21_graphics_228,x:186.5259,y:596.0898}).wait(1).to({graphics:mask_21_graphics_229,x:186.7082,y:596.4908}).wait(1).to({graphics:mask_21_graphics_230,x:186.889,y:596.8867}).wait(1).to({graphics:mask_21_graphics_231,x:187.0677,y:597.2791}).wait(1).to({graphics:mask_21_graphics_232,x:187.2441,y:597.6666}).wait(1).to({graphics:mask_21_graphics_233,x:187.4182,y:598.05}).wait(1).to({graphics:mask_21_graphics_234,x:187.5906,y:598.428}).wait(1).to({graphics:mask_21_graphics_235,x:187.7607,y:598.801}).wait(1).to({graphics:mask_21_graphics_236,x:187.9281,y:599.1691}).wait(1).to({graphics:mask_21_graphics_237,x:188.0928,y:599.5314}).wait(1).to({graphics:mask_21_graphics_238,x:188.2557,y:599.8878}).wait(1).to({graphics:mask_21_graphics_239,x:188.415,y:600.2383}).wait(1).to({graphics:mask_21_graphics_240,x:188.5721,y:600.583}).wait(1).to({graphics:mask_21_graphics_241,x:188.7264,y:600.9214}).wait(1).to({graphics:mask_21_graphics_242,x:188.8781,y:601.254}).wait(1).to({graphics:mask_21_graphics_243,x:189.0261,y:601.5798}).wait(1).to({graphics:mask_21_graphics_244,x:189.1719,y:601.8997}).wait(1).to({graphics:mask_21_graphics_245,x:189.3145,y:602.213}).wait(1).to({graphics:mask_21_graphics_246,x:189.4536,y:602.5189}).wait(1).to({graphics:mask_21_graphics_247,x:189.5904,y:602.8186}).wait(1).to({graphics:mask_21_graphics_248,x:189.724,y:603.1125}).wait(1).to({graphics:mask_21_graphics_249,x:189.855,y:603.3991}).wait(1).to({graphics:mask_21_graphics_250,x:189.9819,y:603.679}).wait(1).to({graphics:mask_21_graphics_251,x:190.1066,y:603.9522}).wait(1).to({graphics:mask_21_graphics_252,x:190.2281,y:604.219}).wait(1).to({graphics:mask_21_graphics_253,x:190.3468,y:604.4787}).wait(1).to({graphics:mask_21_graphics_254,x:190.462,y:604.7321}).wait(1).to({graphics:mask_21_graphics_255,x:190.5741,y:604.9786}).wait(1).to({graphics:mask_21_graphics_256,x:190.6834,y:605.2185}).wait(1).to({graphics:mask_21_graphics_257,x:190.7896,y:605.4521}).wait(1).to({graphics:mask_21_graphics_258,x:190.8931,y:605.6793}).wait(1).to({graphics:mask_21_graphics_259,x:190.9935,y:605.8994}).wait(1).to({graphics:mask_21_graphics_260,x:191.0911,y:606.1131}).wait(1).to({graphics:mask_21_graphics_261,x:191.1856,y:606.321}).wait(1).to({graphics:mask_21_graphics_262,x:191.277,y:606.5221}).wait(1).to({graphics:mask_21_graphics_263,x:191.3656,y:606.717}).wait(1).to({graphics:mask_21_graphics_264,x:191.4516,y:606.9055}).wait(1).to({graphics:mask_21_graphics_265,x:191.5348,y:607.0882}).wait(1).to({graphics:mask_21_graphics_266,x:191.6154,y:607.2646}).wait(1).to({graphics:mask_21_graphics_267,x:191.6928,y:607.4348}).wait(1).to({graphics:mask_21_graphics_268,x:191.7675,y:607.599}).wait(1).to({graphics:mask_21_graphics_269,x:191.8399,y:607.7574}).wait(1).to({graphics:mask_21_graphics_270,x:191.9088,y:607.9099}).wait(1).to({graphics:mask_21_graphics_271,x:191.9763,y:608.0571}).wait(1).to({graphics:mask_21_graphics_272,x:192.0407,y:608.1984}).wait(1).to({graphics:mask_21_graphics_273,x:192.1018,y:608.3338}).wait(1).to({graphics:mask_21_graphics_274,x:192.1612,y:608.4634}).wait(1).to({graphics:mask_21_graphics_275,x:192.2179,y:608.5881}).wait(1).to({graphics:mask_21_graphics_276,x:192.2724,y:608.7073}).wait(1).to({graphics:mask_21_graphics_277,x:192.3241,y:608.8212}).wait(1).to({graphics:mask_21_graphics_278,x:192.3732,y:608.9297}).wait(1).to({graphics:mask_21_graphics_279,x:192.4204,y:609.0327}).wait(1).to({graphics:mask_21_graphics_280,x:192.4655,y:609.1308}).wait(1).to({graphics:mask_21_graphics_281,x:192.5077,y:609.224}).wait(1).to({graphics:mask_21_graphics_282,x:192.5478,y:609.3126}).wait(1).to({graphics:mask_21_graphics_283,x:192.5856,y:609.3958}).wait(1).to({graphics:mask_21_graphics_284,x:192.6216,y:609.4737}).wait(1).to({graphics:mask_21_graphics_285,x:192.6549,y:609.5475}).wait(1).to({graphics:mask_21_graphics_286,x:192.6864,y:609.6168}).wait(1).to({graphics:mask_21_graphics_287,x:192.7161,y:609.6812}).wait(1).to({graphics:mask_21_graphics_288,x:192.7431,y:609.741}).wait(1).to({graphics:mask_21_graphics_289,x:192.7678,y:609.7959}).wait(1).to({graphics:mask_21_graphics_290,x:192.7912,y:609.8467}).wait(1).to({graphics:mask_21_graphics_291,x:192.8124,y:609.8935}).wait(1).to({graphics:mask_21_graphics_292,x:192.8317,y:609.9354}).wait(1).to({graphics:mask_21_graphics_293,x:192.8489,y:609.9736}).wait(1).to({graphics:mask_21_graphics_294,x:192.6657,y:609.9079}).wait(516));

	// Layer_13
	this.instance_37 = new lib.Tween36("synched",0);
	this.instance_37.setTransform(166.2,600.2);
	this.instance_37.alpha = 0.5;
	this.instance_37._off = true;

	var maskedShapeInstanceList = [this.instance_37];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_21;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_37).wait(208).to({_off:false},0).to({alpha:1},86).wait(516));

	// Layer_6 (mask)
	var mask_22 = new cjs.Shape();
	mask_22._off = true;
	var mask_22_graphics_224 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_22_graphics_225 = new cjs.Graphics().p("AggAfQgNgNAAgSIAAAAQAAgRANgNIAAAAQAOgNASAAIAAAAQATAAAOANIAAAAQANANAAARIAAAAQAAASgNANIAAAAQgOANgTAAIAAAAQgSAAgOgNg");
	var mask_22_graphics_226 = new cjs.Graphics().p("AgvAuQgUgTAAgbIAAAAQAAgaAUgTIAAAAQAUgTAbAAIAAAAQAcAAAUATIAAAAQAUATAAAaIAAAAQAAAbgUATIAAAAQgUATgcAAIAAAAQgbAAgUgTg");
	var mask_22_graphics_227 = new cjs.Graphics().p("Ag/A9QgagZAAgkIAAAAQAAgjAagZIAAAAQAbgaAkAAIAAAAQAlAAAbAaIAAAAQAaAZAAAjIAAAAQAAAkgaAZIAAAAQgbAaglAAIAAAAQgkAAgbgag");
	var mask_22_graphics_228 = new cjs.Graphics().p("AhPBMQghgfAAgtIAAAAQAAgsAhgfIAAAAQAhggAuAAIAAAAQAvAAAhAgIAAAAQAhAfAAAsIAAAAQAAAtghAfIAAAAQghAggvAAIAAAAQguAAghggg");
	var mask_22_graphics_229 = new cjs.Graphics().p("AhfBcQgngmAAg2IAAAAQAAg1AngmIAAAAQAogmA3AAIAAAAQA4AAAoAmIAAAAQAnAmAAA1IAAAAQAAA2gnAmIAAAAQgoAmg4AAIAAAAQg3AAgogmg");
	var mask_22_graphics_230 = new cjs.Graphics().p("AhvBrQgugsAAg/IAAAAQAAg+AugsIAAAAQAvgsBAAAIAAAAQBBAAAvAsIAAAAQAuAsAAA+IAAAAQAAA/guAsIAAAAQgvAshBAAIAAAAQhAAAgvgsg");
	var mask_22_graphics_231 = new cjs.Graphics().p("Ah/B6Qg1gyAAhIIAAAAQAAhHA1gyIAAAAQA1gzBKAAIAAAAQBLAAA1AzIAAAAQA1AyAABHIAAAAQAABIg1AyIAAAAQg1AzhLAAIAAAAQhKAAg1gzg");
	var mask_22_graphics_232 = new cjs.Graphics().p("AiPCKQg7g5AAhRIAAAAQAAhQA7g5IAAAAQA8g5BTAAIAAAAQBUAAA8A5IAAAAQA7A5AABQIAAAAQAABRg7A5IAAAAQg8A5hUAAIAAAAQhTAAg8g5g");
	var mask_22_graphics_233 = new cjs.Graphics().p("AifCZQhCg/AAhaIAAAAQAAhZBCg/IAAAAQBCg/BdAAIAAAAQBeAABCA/IAAAAQBCA/AABZIAAAAQAABahCA/IAAAAQhCA/heAAIAAAAQhdAAhCg/g");
	var mask_22_graphics_234 = new cjs.Graphics().p("AivCoQhJhFAAhjIAAAAQAAhiBJhFIAAAAQBJhGBmAAIAAAAQBnAABJBGIAAAAQBJBFAABiIAAAAQAABjhJBFIAAAAQhJBGhnAAIAAAAQhmAAhJhGg");
	var mask_22_graphics_235 = new cjs.Graphics().p("Ai/C4QhPhMAAhsIAAAAQAAhrBPhMIAAAAQBQhMBvAAIAAAAQBwAABQBMIAAAAQBPBMAABrIAAAAQAABshPBMIAAAAQhQBMhwAAIAAAAQhvAAhQhMg");
	var mask_22_graphics_236 = new cjs.Graphics().p("AjPDHQhWhSAAh1IAAAAQAAh0BWhSIAAAAQBWhSB5AAIAAAAQB6AABWBSIAAAAQBWBSAAB0IAAAAQAAB1hWBSIAAAAQhWBSh6AAIAAAAQh5AAhWhSg");
	var mask_22_graphics_237 = new cjs.Graphics().p("AjfDWQhchZAAh9IAAAAQAAh8BchZIAAAAQBdhZCCAAIAAAAQCDAABcBZIAAAAQBdBZAAB8IAAAAQAAB9hdBZIAAAAQhcBZiDAAIAAAAQiCAAhdhZg");
	var mask_22_graphics_238 = new cjs.Graphics().p("AjuDlQhjhfAAiGIAAAAQAAiFBjhfIAAAAQBjhfCLAAIAAAAQCMAABjBfIAAAAQBjBfAACFIAAAAQAACGhjBfIAAAAQhjBfiMAAIAAAAQiLAAhjhfg");
	var mask_22_graphics_239 = new cjs.Graphics().p("Aj+D0QhphlAAiPIAAAAQAAiOBphlIAAAAQBqhlCUAAIAAAAQCVAABqBlIAAAAQBpBlAACOIAAAAQAACPhpBlIAAAAQhqBliVAAIAAAAQiUAAhqhlg");
	var mask_22_graphics_240 = new cjs.Graphics().p("AkNEDQhwhrAAiYIAAAAQAAiXBwhrIAAAAQBwhrCdAAIAAAAQCeAABwBrIAAAAQBwBrAACXIAAAAQAACYhwBrIAAAAQhwBrieAAIAAAAQidAAhwhrg");
	var mask_22_graphics_241 = new cjs.Graphics().p("AkdESQh2hyAAigIAAAAQAAifB2hyIAAAAQB3hxCmAAIAAAAQCnAAB3BxIAAAAQB2ByAACfIAAAAQAACgh2ByIAAAAQh3BxinAAIAAAAQimAAh3hxg");
	var mask_22_graphics_242 = new cjs.Graphics().p("AksEgQh8h3AAipIAAAAQAAioB8h3IAAAAQB9h4CvAAIAAAAQCwAAB9B4IAAAAQB8B3AACoIAAAAQAACph8B3IAAAAQh9B4iwAAIAAAAQivAAh9h4g");
	var mask_22_graphics_243 = new cjs.Graphics().p("Ak7EuQiCh9AAixIAAAAQAAiwCCh+IAAAAQCDh9C4AAIAAAAQC5AACDB9IAAAAQCCB+AACwIAAAAQAACxiCB9IAAAAQiDB+i5AAIAAAAQi4AAiDh+g");
	var mask_22_graphics_244 = new cjs.Graphics().p("AlJE8QiJiDAAi5IAAAAQAAi4CJiEIAAAAQCIiDDBAAIAAAAQDCAACICDIAAAAQCJCEAAC4IAAAAQAAC5iJCDIAAAAQiICEjCAAIAAAAQjBAAiIiEg");
	var mask_22_graphics_245 = new cjs.Graphics().p("AlYFKQiPiIAAjCIAAAAQAAjBCPiJIAAAAQCPiIDJAAIAAAAQDKAACPCIIAAAAQCPCJAADBIAAAAQAADCiPCIIAAAAQiPCJjKAAIAAAAQjJAAiPiJg");
	var mask_22_graphics_246 = new cjs.Graphics().p("AlmFYQiViOAAjKIAAAAQAAjJCViOIAAAAQCViPDRAAIAAAAQDSAACVCPIAAAAQCVCOAADJIAAAAQAADKiVCOIAAAAQiVCPjSAAIAAAAQjRAAiViPg");
	var mask_22_graphics_247 = new cjs.Graphics().p("Al0FlQibiUAAjRIAAAAQAAjQCbiVIAAAAQCaiUDaAAIAAAAQDbAACaCUIAAAAQCbCVAADQIAAAAQAADRibCUIAAAAQiaCVjbAAIAAAAQjaAAiaiVg");
	var mask_22_graphics_248 = new cjs.Graphics().p("AmCFzQigiaAAjZIAAAAQAAjYCgiaIAAAAQCgiZDiAAIAAAAQDjAACgCZIAAAAQCgCaAADYIAAAAQAADZigCaIAAAAQigCZjjAAIAAAAQjiAAigiZg");
	var mask_22_graphics_249 = new cjs.Graphics().p("AmPF/QimieAAjhIAAAAQAAjgCmifIAAAAQCmieDpAAIAAAAQDqAACmCeIAAAAQCmCfAADgIAAAAQAADhimCeIAAAAQimCfjqAAIAAAAQjpAAimifg");
	var mask_22_graphics_250 = new cjs.Graphics().p("AmdGMQirikAAjoIAAAAQAAjnCrikIAAAAQCsikDxAAIAAAAQDyAACrCkIAAAAQCsCkAADnIAAAAQAADoisCkIAAAAQirCkjyAAIAAAAQjxAAisikg");
	var mask_22_graphics_251 = new cjs.Graphics().p("AmpGYQixipAAjvIAAAAQAAjuCxiqIAAAAQCwipD5AAIAAAAQD6AACwCpIAAAAQCxCqAADuIAAAAQAADvixCpIAAAAQiwCqj6AAIAAAAQj5AAiwiqg");
	var mask_22_graphics_252 = new cjs.Graphics().p("Am2GlQi2ivAAj2IAAAAQAAj1C2ivIAAAAQC2iuEAAAIAAAAQEBAAC2CuIAAAAQC2CvAAD1IAAAAQAAD2i2CvIAAAAQi2CukBAAIAAAAQkAAAi2iug");
	var mask_22_graphics_253 = new cjs.Graphics().p("AnCGwQi7izAAj9IAAAAQAAj8C7i0IAAAAQC7izEHAAIAAAAQEIAAC7CzIAAAAQC7C0AAD8IAAAAQAAD9i7CzIAAAAQi7C0kIAAIAAAAQkHAAi7i0g");
	var mask_22_graphics_254 = new cjs.Graphics().p("AnOG8QjAi4AAkEIAAAAQAAkDDAi4IAAAAQDAi4EOAAIAAAAQEPAADAC4IAAAAQDAC4AAEDIAAAAQAAEEjAC4IAAAAQjAC4kPAAIAAAAQkOAAjAi4g");
	var mask_22_graphics_255 = new cjs.Graphics().p("AnaHHQjFi8AAkLIAAAAQAAkKDFi8IAAAAQDFi9EVAAIAAAAQEWAADFC9IAAAAQDFC8AAEKIAAAAQAAELjFC8IAAAAQjFC9kWAAIAAAAQkVAAjFi9g");
	var mask_22_graphics_256 = new cjs.Graphics().p("AnmHSQjJjBAAkRIAAAAQAAkQDJjBIAAAAQDKjBEcAAIAAAAQEdAADJDBIAAAAQDKDBAAEQIAAAAQAAERjKDBIAAAAQjJDBkdAAIAAAAQkcAAjKjBg");
	var mask_22_graphics_257 = new cjs.Graphics().p("AnxHdQjOjGAAkXIAAAAQAAkWDOjGIAAAAQDPjFEiAAIAAAAQEjAADODFIAAAAQDPDGAAEWIAAAAQAAEXjPDGIAAAAQjODFkjAAIAAAAQkiAAjPjFg");
	var mask_22_graphics_258 = new cjs.Graphics().p("An7HnQjTjKAAkdIAAAAQAAkcDTjKIAAAAQDSjKEpAAIAAAAQEqAADSDKIAAAAQDTDKAAEcIAAAAQAAEdjTDKIAAAAQjSDKkqAAIAAAAQkpAAjSjKg");
	var mask_22_graphics_259 = new cjs.Graphics().p("AoGHxQjXjOAAkjIAAAAQAAkiDXjOIAAAAQDXjOEvAAIAAAAQEwAADXDOIAAAAQDXDOAAEiIAAAAQAAEjjXDOIAAAAQjXDOkwAAIAAAAQkvAAjXjOg");
	var mask_22_graphics_260 = new cjs.Graphics().p("AoQH7QjbjSAAkpIAAAAQAAkoDbjSIAAAAQDbjSE1AAIAAAAQE2AADbDSIAAAAQDbDSAAEoIAAAAQAAEpjbDSIAAAAQjbDSk2AAIAAAAQk1AAjbjSg");
	var mask_22_graphics_261 = new cjs.Graphics().p("AoaIEQjfjWAAkuIAAAAQAAktDfjWIAAAAQDfjWE7AAIAAAAQE8AADfDWIAAAAQDfDWAAEtIAAAAQAAEujfDWIAAAAQjfDWk8AAIAAAAQk7AAjfjWg");
	var mask_22_graphics_262 = new cjs.Graphics().p("AojINQjjjZAAk0IAAAAQAAkzDjjZIAAAAQDjjaFAAAIAAAAQFBAADjDaIAAAAQDjDZAAEzIAAAAQAAE0jjDZIAAAAQjjDalBAAIAAAAQlAAAjjjag");
	var mask_22_graphics_263 = new cjs.Graphics().p("AotIWQjmjdAAk5IAAAAQAAk4DmjdIAAAAQDojdFFAAIAAAAQFGAADnDdIAAAAQDnDdAAE4IAAAAQAAE5jnDdIAAAAQjnDdlGAAIAAAAQlFAAjojdg");
	var mask_22_graphics_264 = new cjs.Graphics().p("Ao1IeQjrjgAAk+IAAAAQAAk9DrjhIAAAAQDqjgFLAAIAAAAQFMAADqDgIAAAAQDrDhAAE9IAAAAQAAE+jrDgIAAAAQjqDhlMAAIAAAAQlLAAjqjhg");
	var mask_22_graphics_265 = new cjs.Graphics().p("Ao+InQjujkAAlDIAAAAQAAlCDujkIAAAAQDujkFQAAIAAAAQFRAADuDkIAAAAQDuDkAAFCIAAAAQAAFDjuDkIAAAAQjuDklRAAIAAAAQlQAAjujkg");
	var mask_22_graphics_266 = new cjs.Graphics().p("ApGIvQjyjoAAlHIAAAAQAAlGDyjoIAAAAQDxjnFVAAIAAAAQFWAADxDnIAAAAQDyDoAAFGIAAAAQAAFHjyDoIAAAAQjxDnlWAAIAAAAQlVAAjxjng");
	var mask_22_graphics_267 = new cjs.Graphics().p("ApOI2Qj1jqAAlMIAAAAQAAlLD1jrIAAAAQD1jqFZAAIAAAAQFaAAD1DqIAAAAQD1DrAAFLIAAAAQAAFMj1DqIAAAAQj1DrlaAAIAAAAQlZAAj1jrg");
	var mask_22_graphics_268 = new cjs.Graphics().p("ApWI+Qj4juAAlQIAAAAQAAlPD4juIAAAAQD4jtFeAAIAAAAQFfAAD4DtIAAAAQD4DuAAFPIAAAAQAAFQj4DuIAAAAQj4DtlfAAIAAAAQleAAj4jtg");
	var mask_22_graphics_269 = new cjs.Graphics().p("ApdJFQj7jxAAlUIAAAAQAAlTD7jxIAAAAQD7jxFiAAIAAAAQFjAAD7DxIAAAAQD7DxAAFTIAAAAQAAFUj7DxIAAAAQj7DxljAAIAAAAQliAAj7jxg");
	var mask_22_graphics_270 = new cjs.Graphics().p("ApkJMQj+j0AAlYIAAAAQAAlXD+j0IAAAAQD+jzFmAAIAAAAQFnAAD+DzIAAAAQD+D0AAFXIAAAAQAAFYj+D0IAAAAQj+DzlnAAIAAAAQlmAAj+jzg");
	var mask_22_graphics_271 = new cjs.Graphics().p("AprJSQkBj2AAlcIAAAAQAAlbEBj2IAAAAQEBj2FqAAIAAAAQFrAAEBD2IAAAAQEBD2AAFbIAAAAQAAFckBD2IAAAAQkBD2lrAAIAAAAQlqAAkBj2g");
	var mask_22_graphics_272 = new cjs.Graphics().p("ApyJYQkDj4AAlgIAAAAQAAlfEDj5IAAAAQEEj4FuAAIAAAAQFvAAEED4IAAAAQEDD5AAFfIAAAAQAAFgkDD4IAAAAQkED5lvAAIAAAAQluAAkEj5g");
	var mask_22_graphics_273 = new cjs.Graphics().p("Ap4JeQkGj7AAljIAAAAQAAliEGj8IAAAAQEGj7FyAAIAAAAQFzAAEGD7IAAAAQEGD8AAFiIAAAAQAAFjkGD7IAAAAQkGD8lzAAIAAAAQlyAAkGj8g");
	var mask_22_graphics_274 = new cjs.Graphics().p("Ap+JkQkJj9AAlnIAAAAQAAlmEJj9IAAAAQEJj+F1AAIAAAAQF2AAEJD+IAAAAQEJD9AAFmIAAAAQAAFnkJD9IAAAAQkJD+l2AAIAAAAQl1AAkJj+g");
	var mask_22_graphics_275 = new cjs.Graphics().p("AqEJpQkLj/AAlqIAAAAQAAlpELkAIAAAAQELj/F5AAIAAAAQF6AAEKD/IAAAAQEMEAAAFpIAAAAQAAFqkMD/IAAAAQkKEBl6gBIAAAAQl5ABkLkBg");
	var mask_22_graphics_276 = new cjs.Graphics().p("AqJJvQkNkCAAltIAAAAQAAlsENkCIAAAAQENkCF8AAIAAAAQF9AAENECIAAAAQENECAAFsIAAAAQAAFtkNECIAAAAQkNECl9AAIAAAAQl8AAkNkCg");
	var mask_22_graphics_277 = new cjs.Graphics().p("AqOJ0QkQkEAAlwIAAAAQAAlvEQkEIAAAAQEPkEF/AAIAAAAQGAAAEPEEIAAAAQEQEEAAFvIAAAAQAAFwkQEEIAAAAQkPEEmAAAIAAAAQl/AAkPkEg");
	var mask_22_graphics_278 = new cjs.Graphics().p("AqTJ4QkSkGAAlyIAAAAQAAlxESkHIAAAAQERkGGCAAIAAAAQGDAAEREGIAAAAQESEHAAFxIAAAAQAAFykSEGIAAAAQkREHmDAAIAAAAQmCAAkRkHg");
	var mask_22_graphics_279 = new cjs.Graphics().p("AqYJ9QkTkIAAl1IAAAAQAAl0ETkIIAAAAQEUkIGEAAIAAAAQGFAAEUEIIAAAAQETEIAAF0IAAAAQAAF1kTEIIAAAAQkUEImFAAIAAAAQmEAAkUkIg");
	var mask_22_graphics_280 = new cjs.Graphics().p("AqcKBQkVkJAAl4IAAAAQAAl3EVkJIAAAAQEVkKGHAAIAAAAQGIAAEVEKIAAAAQEVEJAAF3IAAAAQAAF4kVEJIAAAAQkVEKmIAAIAAAAQmHAAkVkKg");
	var mask_22_graphics_281 = new cjs.Graphics().p("AqgKFQkXkLAAl6IAAAAQAAl5EXkLIAAAAQEXkLGJAAIAAAAQGKAAEXELIAAAAQEXELAAF5IAAAAQAAF6kXELIAAAAQkXELmKAAIAAAAQmJAAkXkLg");
	var mask_22_graphics_282 = new cjs.Graphics().p("AqkKJQkZkNAAl8IAAAAQAAl7EZkNIAAAAQEYkNGMAAIAAAAQGNAAEYENIAAAAQEZENAAF7IAAAAQAAF8kZENIAAAAQkYENmNAAIAAAAQmMAAkYkNg");
	var mask_22_graphics_283 = new cjs.Graphics().p("AqoKMQkakOAAl+IAAAAQAAl9EakPIAAAAQEakOGOAAIAAAAQGPAAEaEOIAAAAQEaEPAAF9IAAAAQAAF+kaEOIAAAAQkaEPmPAAIAAAAQmOAAkakPg");
	var mask_22_graphics_284 = new cjs.Graphics().p("AqrKQQkckQAAmAIAAAAQAAl/EckQIAAAAQEbkPGQAAIAAAAQGRAAEbEPIAAAAQEcEQAAF/IAAAAQAAGAkcEQIAAAAQkbEPmRAAIAAAAQmQAAkbkPg");
	var mask_22_graphics_285 = new cjs.Graphics().p("AqvKTQkckRAAmCIAAAAQAAmBEckRIAAAAQEdkRGSAAIAAAAQGTAAEcERIAAAAQEdERAAGBIAAAAQAAGCkdERIAAAAQkcERmTAAIAAAAQmSAAkdkRg");
	var mask_22_graphics_286 = new cjs.Graphics().p("AqyKVQkekRAAmEIAAAAQAAmDEekSIAAAAQEfkSGTAAIAAAAQGUAAEeESIAAAAQEfESAAGDIAAAAQAAGEkfERIAAAAQkeETmUAAIAAAAQmTAAkfkTg");
	var mask_22_graphics_287 = new cjs.Graphics().p("Aq0KYQkfkTAAmFIAAAAQAAmEEfkTIAAAAQEfkTGVAAIAAAAQGWAAEfETIAAAAQEfETAAGEIAAAAQAAGFkfETIAAAAQkfETmWAAIAAAAQmVAAkfkTg");
	var mask_22_graphics_288 = new cjs.Graphics().p("Aq3KbQkgkUAAmHIAAAAQAAmGEgkUIAAAAQEgkUGXAAIAAAAQGYAAEgEUIAAAAQEgEUAAGGIAAAAQAAGHkgEUIAAAAQkgEUmYAAIAAAAQmXAAkgkUg");
	var mask_22_graphics_289 = new cjs.Graphics().p("Aq5KdQkhkVAAmIIAAAAQAAmHEhkVIAAAAQEhkVGYAAIAAAAQGZAAEhEVIAAAAQEhEVAAGHIAAAAQAAGIkhEVIAAAAQkhEVmZAAIAAAAQmYAAkhkVg");
	var mask_22_graphics_290 = new cjs.Graphics().p("Aq7KfQkikWAAmJIAAAAQAAmIEikWIAAAAQEikWGZAAIAAAAQGaAAEiEWIAAAAQEiEWAAGIIAAAAQAAGJkiEWIAAAAQkiEWmaAAIAAAAQmZAAkikWg");
	var mask_22_graphics_291 = new cjs.Graphics().p("Aq9KhQkjkXAAmKIAAAAQAAmJEjkXIAAAAQEjkXGaAAIAAAAQGbAAEjEXIAAAAQEjEXAAGJIAAAAQAAGKkjEXIAAAAQkjEXmbAAIAAAAQmaAAkjkXg");
	var mask_22_graphics_292 = new cjs.Graphics().p("Aq/KiQkjkXAAmLIAAAAQAAmKEjkYIAAAAQEkkXGbAAIAAAAQGcAAEkEXIAAAAQEjEYAAGKIAAAAQAAGLkjEXIAAAAQkkEYmcAAIAAAAQmbAAkkkYg");
	var mask_22_graphics_293 = new cjs.Graphics().p("ArBKkQkkkYAAmMIAAAAQAAmLEkkYIAAAAQElkYGcAAIAAAAQGdAAEkEYIAAAAQElEYAAGLIAAAAQAAGMklEYIAAAAQkkEYmdAAIAAAAQmcAAklkYg");
	var mask_22_graphics_294 = new cjs.Graphics().p("ArCKlQkkkYAAmNIAAAAQAAmMEkkYIAAAAQElkZGdAAIAAAAQGeAAEkEZIAAAAQElEYAAGMIAAAAQAAGNklEYIAAAAQkkEZmeAAIAAAAQmdAAklkZg");

	this.timeline.addTween(cjs.Tween.get(mask_22).to({graphics:null,x:0,y:0}).wait(224).to({graphics:mask_22_graphics_224,x:705.0001,y:649.8999}).wait(1).to({graphics:mask_22_graphics_225,x:706.0716,y:648.009}).wait(1).to({graphics:mask_22_graphics_226,x:707.1534,y:646.0992}).wait(1).to({graphics:mask_22_graphics_227,x:708.2451,y:644.1723}).wait(1).to({graphics:mask_22_graphics_228,x:709.344,y:642.2319}).wait(1).to({graphics:mask_22_graphics_229,x:710.4496,y:640.2807}).wait(1).to({graphics:mask_22_graphics_230,x:711.5602,y:638.3205}).wait(1).to({graphics:mask_22_graphics_231,x:712.674,y:636.3545}).wait(1).to({graphics:mask_22_graphics_232,x:713.7891,y:634.3853}).wait(1).to({graphics:mask_22_graphics_233,x:714.9051,y:632.416}).wait(1).to({graphics:mask_22_graphics_234,x:716.0193,y:630.4491}).wait(1).to({graphics:mask_22_graphics_235,x:717.1308,y:628.4871}).wait(1).to({graphics:mask_22_graphics_236,x:718.2373,y:626.5332}).wait(1).to({graphics:mask_22_graphics_237,x:719.3389,y:624.5897}).wait(1).to({graphics:mask_22_graphics_238,x:720.4325,y:622.6587}).wait(1).to({graphics:mask_22_graphics_239,x:721.5169,y:620.7439}).wait(1).to({graphics:mask_22_graphics_240,x:722.592,y:618.8463}).wait(1).to({graphics:mask_22_graphics_241,x:723.6553,y:616.9693}).wait(1).to({graphics:mask_22_graphics_242,x:724.7065,y:615.114}).wait(1).to({graphics:mask_22_graphics_243,x:725.7438,y:613.2834}).wait(1).to({graphics:mask_22_graphics_244,x:726.7666,y:611.478}).wait(1).to({graphics:mask_22_graphics_245,x:727.7733,y:609.7005}).wait(1).to({graphics:mask_22_graphics_246,x:728.7637,y:607.9527}).wait(1).to({graphics:mask_22_graphics_247,x:729.7366,y:606.235}).wait(1).to({graphics:mask_22_graphics_248,x:730.6911,y:604.5498}).wait(1).to({graphics:mask_22_graphics_249,x:731.6266,y:602.8979}).wait(1).to({graphics:mask_22_graphics_250,x:732.5437,y:601.2801}).wait(1).to({graphics:mask_22_graphics_251,x:733.4402,y:599.697}).wait(1).to({graphics:mask_22_graphics_252,x:734.3163,y:598.1504}).wait(1).to({graphics:mask_22_graphics_253,x:735.1722,y:596.6406}).wait(1).to({graphics:mask_22_graphics_254,x:736.006,y:595.1668}).wait(1).to({graphics:mask_22_graphics_255,x:736.8196,y:593.7318}).wait(1).to({graphics:mask_22_graphics_256,x:737.6116,y:592.3341}).wait(1).to({graphics:mask_22_graphics_257,x:738.3811,y:590.9751}).wait(1).to({graphics:mask_22_graphics_258,x:739.1299,y:589.6539}).wait(1).to({graphics:mask_22_graphics_259,x:739.8562,y:588.3714}).wait(1).to({graphics:mask_22_graphics_260,x:740.5614,y:587.1271}).wait(1).to({graphics:mask_22_graphics_261,x:741.2445,y:585.9211}).wait(1).to({graphics:mask_22_graphics_262,x:741.9055,y:584.7534}).wait(1).to({graphics:mask_22_graphics_263,x:742.5459,y:583.6239}).wait(1).to({graphics:mask_22_graphics_264,x:743.1642,y:582.5327}).wait(1).to({graphics:mask_22_graphics_265,x:743.7614,y:581.4788}).wait(1).to({graphics:mask_22_graphics_266,x:744.3373,y:580.4617}).wait(1).to({graphics:mask_22_graphics_267,x:744.8922,y:579.4816}).wait(1).to({graphics:mask_22_graphics_268,x:745.4263,y:578.5389}).wait(1).to({graphics:mask_22_graphics_269,x:745.9402,y:577.6317}).wait(1).to({graphics:mask_22_graphics_270,x:746.4334,y:576.7605}).wait(1).to({graphics:mask_22_graphics_271,x:746.9073,y:575.9244}).wait(1).to({graphics:mask_22_graphics_272,x:747.3609,y:575.1234}).wait(1).to({graphics:mask_22_graphics_273,x:747.7956,y:574.3566}).wait(1).to({graphics:mask_22_graphics_274,x:748.2109,y:573.624}).wait(1).to({graphics:mask_22_graphics_275,x:748.6069,y:572.9242}).wait(1).to({graphics:mask_22_graphics_276,x:748.9845,y:572.2574}).wait(1).to({graphics:mask_22_graphics_277,x:749.344,y:571.6233}).wait(1).to({graphics:mask_22_graphics_278,x:749.6852,y:571.0212}).wait(1).to({graphics:mask_22_graphics_279,x:750.0087,y:570.4501}).wait(1).to({graphics:mask_22_graphics_280,x:750.3147,y:569.9101}).wait(1).to({graphics:mask_22_graphics_281,x:750.6036,y:569.3998}).wait(1).to({graphics:mask_22_graphics_282,x:750.8758,y:568.9197}).wait(1).to({graphics:mask_22_graphics_283,x:751.131,y:568.4693}).wait(1).to({graphics:mask_22_graphics_284,x:751.3699,y:568.0471}).wait(1).to({graphics:mask_22_graphics_285,x:751.5927,y:567.6534}).wait(1).to({graphics:mask_22_graphics_286,x:751.8001,y:567.288}).wait(1).to({graphics:mask_22_graphics_287,x:751.9919,y:566.9491}).wait(1).to({graphics:mask_22_graphics_288,x:752.1682,y:566.6373}).wait(1).to({graphics:mask_22_graphics_289,x:752.3302,y:566.352}).wait(1).to({graphics:mask_22_graphics_290,x:752.4774,y:566.0928}).wait(1).to({graphics:mask_22_graphics_291,x:752.6092,y:565.8588}).wait(1).to({graphics:mask_22_graphics_292,x:752.728,y:565.65}).wait(1).to({graphics:mask_22_graphics_293,x:752.8324,y:565.4655}).wait(1).to({graphics:mask_22_graphics_294,x:752.8599,y:565.3053}).wait(516));

	// Layer_16
	this.instance_38 = new lib.Tween34("synched",0);
	this.instance_38.setTransform(752.4,571.35);
	this.instance_38.alpha = 0.5;
	this.instance_38._off = true;

	this.instance_39 = new lib.Tween35("synched",0);
	this.instance_39.setTransform(752.4,571.35);

	var maskedShapeInstanceList = [this.instance_38,this.instance_39];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_22;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_38}]},224).to({state:[{t:this.instance_39}]},70).wait(516));
	this.timeline.addTween(cjs.Tween.get(this.instance_38).wait(224).to({_off:false},0).to({_off:true,alpha:1},70).wait(516));

	// Layer_8
	this.instance_40 = new lib.Tween18("synched",2);
	this.instance_40.setTransform(581.85,609.05,0.3292,0.3292,0,0,0,472.2,518);
	this.instance_40._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_40).wait(166).to({_off:false},0).wait(644));

	// Layer_6 (mask)
	var mask_23 = new cjs.Shape();
	mask_23._off = true;
	var mask_23_graphics_166 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_23_graphics_167 = new cjs.Graphics().p("AggAgQgOgNAAgTIAAAAQAAgSAOgNIAAAAQAOgNASAAIAAAAQATAAAOANIAAAAQAOANAAASIAAAAQAAATgOANIAAAAQgOANgTAAIAAAAQgSAAgOgNg");
	var mask_23_graphics_168 = new cjs.Graphics().p("AgwAvQgUgUAAgbIAAAAQAAgaAUgUIAAAAQAUgTAcAAIAAAAQAdAAAUATIAAAAQAUAUAAAaIAAAAQAAAbgUAUIAAAAQgUATgdAAIAAAAQgcAAgUgTg");
	var mask_23_graphics_169 = new cjs.Graphics().p("AhAA+QgbgaAAgkIAAAAQAAgjAbgaIAAAAQAbgaAlAAIAAAAQAmAAAbAaIAAAAQAbAaAAAjIAAAAQAAAkgbAaIAAAAQgbAagmAAIAAAAQglAAgbgag");
	var mask_23_graphics_170 = new cjs.Graphics().p("AhQBOQghghAAgtIAAAAQAAgsAhghIAAAAQAiggAuAAIAAAAQAvAAAiAgIAAAAQAhAhAAAsIAAAAQAAAtghAhIAAAAQgiAggvAAIAAAAQguAAgiggg");
	var mask_23_graphics_171 = new cjs.Graphics().p("AhgBdQgognAAg2IAAAAQAAg1AognIAAAAQAognA4AAIAAAAQA5AAAoAnIAAAAQAoAnAAA1IAAAAQAAA2goAnIAAAAQgoAng5AAIAAAAQg4AAgogng");
	var mask_23_graphics_172 = new cjs.Graphics().p("AhwBsQgvgsAAhAIAAAAQAAg/AvgtIAAAAQAvgsBBAAIAAAAQBCAAAvAsIAAAAQAvAtAAA/IAAAAQAABAgvAsIAAAAQgvAthCAAIAAAAQhBAAgvgtg");
	var mask_23_graphics_173 = new cjs.Graphics().p("AiBB8Qg1gzAAhJIAAAAQAAhIA1gzIAAAAQA2gzBLAAIAAAAQBMAAA1AzIAAAAQA2AzAABIIAAAAQAABJg2AzIAAAAQg1AzhMAAIAAAAQhLAAg2gzg");
	var mask_23_graphics_174 = new cjs.Graphics().p("AiRCMQg8g6AAhSIAAAAQAAhRA8g6IAAAAQA9g6BUAAIAAAAQBVAAA9A6IAAAAQA8A6AABRIAAAAQAABSg8A6IAAAAQg9A6hVAAIAAAAQhUAAg9g6g");
	var mask_23_graphics_175 = new cjs.Graphics().p("AihCbQhDhAAAhbIAAAAQAAhaBDhAIAAAAQBDhBBeAAIAAAAQBfAABDBBIAAAAQBDBAAABaIAAAAQAABbhDBAIAAAAQhDBBhfAAIAAAAQheAAhDhBg");
	var mask_23_graphics_176 = new cjs.Graphics().p("AiyCrQhJhHAAhkIAAAAQAAhjBJhHIAAAAQBKhHBoAAIAAAAQBpAABJBHIAAAAQBKBHAABjIAAAAQAABkhKBHIAAAAQhJBHhpAAIAAAAQhoAAhKhHg");
	var mask_23_graphics_177 = new cjs.Graphics().p("AjCC7QhRhOAAhtIAAAAQAAhsBRhOIAAAAQBRhNBxAAIAAAAQByAABRBNIAAAAQBRBOAABsIAAAAQAABthRBOIAAAAQhRBNhyAAIAAAAQhxAAhRhNg");
	var mask_23_graphics_178 = new cjs.Graphics().p("AjSDLQhYhUAAh3IAAAAQAAh2BYhUIAAAAQBXhTB7AAIAAAAQB8AABXBTIAAAAQBYBUAAB2IAAAAQAAB3hYBUIAAAAQhXBTh8AAIAAAAQh7AAhXhTg");
	var mask_23_graphics_179 = new cjs.Graphics().p("AjjDaQhehaAAiAIAAAAQAAh/BehaIAAAAQBfhbCEAAIAAAAQCFAABfBbIAAAAQBeBaAAB/IAAAAQAACAheBaIAAAAQhfBbiFAAIAAAAQiEAAhfhbg");
	var mask_23_graphics_180 = new cjs.Graphics().p("AjzDqQhmhhAAiJIAAAAQAAiIBmhhIAAAAQBlhhCOAAIAAAAQCPAABlBhIAAAAQBmBhAACIIAAAAQAACJhmBhIAAAAQhlBhiPAAIAAAAQiOAAhlhhg");
	var mask_23_graphics_181 = new cjs.Graphics().p("AkED6QhshoAAiSIAAAAQAAiRBshoIAAAAQBshnCYAAIAAAAQCZAABsBnIAAAAQBsBoAACRIAAAAQAACShsBoIAAAAQhsBniZAAIAAAAQiYAAhshng");
	var mask_23_graphics_182 = new cjs.Graphics().p("AkUEKQhzhuAAicIAAAAQAAibBzhuIAAAAQBzhuChAAIAAAAQCiAABzBuIAAAAQBzBuAACbIAAAAQAACchzBuIAAAAQhzBuiiAAIAAAAQihAAhzhug");
	var mask_23_graphics_183 = new cjs.Graphics().p("AklEZQh5h0AAilIAAAAQAAikB5h1IAAAAQB6h0CrAAIAAAAQCsAAB6B0IAAAAQB5B1AACkIAAAAQAAClh5B0IAAAAQh6B1isAAIAAAAQirAAh6h1g");
	var mask_23_graphics_184 = new cjs.Graphics().p("Ak1EpQiBh7AAiuIAAAAQAAitCBh7IAAAAQCAh7C1AAIAAAAQC2AACAB7IAAAAQCBB7AACtIAAAAQAACuiBB7IAAAAQiAB7i2AAIAAAAQi1AAiAh7g");
	var mask_23_graphics_185 = new cjs.Graphics().p("AlGE5QiHiCAAi3IAAAAQAAi2CHiCIAAAAQCIiCC+AAIAAAAQC/AACICCIAAAAQCHCCAAC2IAAAAQAAC3iHCCIAAAAQiICCi/AAIAAAAQi+AAiIiCg");
	var mask_23_graphics_186 = new cjs.Graphics().p("AlWFJQiOiJAAjAIAAAAQAAjACOiIIAAAAQCOiIDIAAIAAAAQDJAACOCIIAAAAQCOCIAADAIAAAAQAADAiOCJIAAAAQiOCIjJAAIAAAAQjIAAiOiIg");
	var mask_23_graphics_187 = new cjs.Graphics().p("AlmFYQiViOAAjKIAAAAQAAjJCViOIAAAAQCViPDRAAIAAAAQDSAACVCPIAAAAQCVCOAADJIAAAAQAADKiVCOIAAAAQiVCPjSAAIAAAAQjRAAiViPg");
	var mask_23_graphics_188 = new cjs.Graphics().p("Al3FoQibiVAAjTIAAAAQAAjSCbiVIAAAAQCciVDbAAIAAAAQDcAACcCVIAAAAQCbCVAADSIAAAAQAADTibCVIAAAAQicCVjcAAIAAAAQjbAAiciVg");
	var mask_23_graphics_189 = new cjs.Graphics().p("AmHF3QiiibAAjcIAAAAQAAjbCiicIAAAAQCiibDlAAIAAAAQDmAACiCbIAAAAQCiCcAADbIAAAAQAADciiCbIAAAAQiiCcjmAAIAAAAQjlAAiiicg");
	var mask_23_graphics_190 = new cjs.Graphics().p("AmXGHQipiiAAjlIAAAAQAAjkCpiiIAAAAQCpiiDuAAIAAAAQDvAACpCiIAAAAQCpCiAADkIAAAAQAADlipCiIAAAAQipCijvAAIAAAAQjuAAipiig");
	var mask_23_graphics_191 = new cjs.Graphics().p("AmnGWQiwioAAjuIAAAAQAAjtCwipIAAAAQCwioD3AAIAAAAQD4AACwCoIAAAAQCwCpAADtIAAAAQAADuiwCoIAAAAQiwCpj4AAIAAAAQj3AAiwipg");
	var mask_23_graphics_192 = new cjs.Graphics().p("Am3GmQi3ivAAj3IAAAAQAAj2C3ivIAAAAQC2ivEBAAIAAAAQECAAC2CvIAAAAQC3CvAAD2IAAAAQAAD3i3CvIAAAAQi2CvkCAAIAAAAQkBAAi2ivg");
	var mask_23_graphics_193 = new cjs.Graphics().p("AnHG1Qi9i1AAkAIAAAAQAAj/C9i1IAAAAQC9i1EKAAIAAAAQELAAC9C1IAAAAQC9C1AAD/IAAAAQAAEAi9C1IAAAAQi9C1kLAAIAAAAQkKAAi9i1g");
	var mask_23_graphics_194 = new cjs.Graphics().p("AnXHEQjEi7AAkJIAAAAQAAkIDEi7IAAAAQDEi8ETAAIAAAAQEUAADEC8IAAAAQDEC7AAEIIAAAAQAAEJjEC7IAAAAQjEC8kUAAIAAAAQkTAAjEi8g");
	var mask_23_graphics_195 = new cjs.Graphics().p("AnnHTQjKjBAAkSIAAAAQAAkRDKjCIAAAAQDKjBEdAAIAAAAQEeAADKDBIAAAAQDKDCAAERIAAAAQAAESjKDBIAAAAQjKDCkeAAIAAAAQkdAAjKjCg");
	var mask_23_graphics_196 = new cjs.Graphics().p("An3HiQjQjHAAkbIAAAAQAAkaDQjIIAAAAQDRjHEmAAIAAAAQEnAADQDHIAAAAQDRDIAAEaIAAAAQAAEbjRDHIAAAAQjQDIknAAIAAAAQkmAAjRjIg");
	var mask_23_graphics_197 = new cjs.Graphics().p("AoGHxQjXjOAAkjIAAAAQAAkiDXjPIAAAAQDXjNEvAAIAAAAQEwAADXDNIAAAAQDXDPAAEiIAAAAQAAEjjXDOIAAAAQjXDOkwAAIAAAAQkvAAjXjOg");
	var mask_23_graphics_198 = new cjs.Graphics().p("AoWIAQjdjUAAksIAAAAQAAkrDdjUIAAAAQDejUE4AAIAAAAQE5AADdDUIAAAAQDeDUAAErIAAAAQAAEsjeDUIAAAAQjdDUk5AAIAAAAQk4AAjejUg");
	var mask_23_graphics_199 = new cjs.Graphics().p("AolIPQjkjaAAk1IAAAAQAAk0DkjaIAAAAQDkjaFBAAIAAAAQFCAADkDaIAAAAQDkDaAAE0IAAAAQAAE1jkDaIAAAAQjkDalCAAIAAAAQlBAAjkjag");
	var mask_23_graphics_200 = new cjs.Graphics().p("Ao0IdQjqjgAAk9IAAAAQAAk8DqjhIAAAAQDqjgFKAAIAAAAQFLAADqDgIAAAAQDqDhAAE8IAAAAQAAE9jqDgIAAAAQjqDhlLAAIAAAAQlKAAjqjhg");
	var mask_23_graphics_201 = new cjs.Graphics().p("ApDIsQjxjmAAlGIAAAAQAAlFDxjmIAAAAQDwjmFTAAIAAAAQFUAADwDmIAAAAQDxDmAAFFIAAAAQAAFGjxDmIAAAAQjwDmlUAAIAAAAQlTAAjwjmg");
	var mask_23_graphics_202 = new cjs.Graphics().p("ApSI6Qj3jsAAlOIAAAAQAAlND3jtIAAAAQD2jsFcAAIAAAAQFdAAD2DsIAAAAQD3DtAAFNIAAAAQAAFOj3DsIAAAAQj2DtldAAIAAAAQlcAAj2jtg");
	var mask_23_graphics_203 = new cjs.Graphics().p("AphJIQj9jyAAlWIAAAAQAAlVD9jzIAAAAQD9jyFkAAIAAAAQFlAAD9DyIAAAAQD9DzAAFVIAAAAQAAFWj9DyIAAAAQj9DzllAAIAAAAQlkAAj9jzg");
	var mask_23_graphics_204 = new cjs.Graphics().p("ApwJXQkDj4AAlfIAAAAQAAleEDj4IAAAAQEDj4FtAAIAAAAQFuAAEDD4IAAAAQEDD4AAFeIAAAAQAAFfkDD4IAAAAQkDD4luAAIAAAAQltAAkDj4g");
	var mask_23_graphics_205 = new cjs.Graphics().p("Ap/JlQkIj+AAlnIAAAAQAAlmEIj+IAAAAQEJj+F2AAIAAAAQF3AAEID+IAAAAQEJD+AAFmIAAAAQAAFnkJD+IAAAAQkID+l3AAIAAAAQl2AAkJj+g");
	var mask_23_graphics_206 = new cjs.Graphics().p("AqNJyQkPkDAAlvIAAAAQAAluEPkEIAAAAQEPkDF+AAIAAAAQF/AAEPEDIAAAAQEPEEAAFuIAAAAQAAFvkPEDIAAAAQkPEEl/AAIAAAAQl+AAkPkEg");
	var mask_23_graphics_207 = new cjs.Graphics().p("AqbKAQkVkJAAl3IAAAAQAAl2EVkJIAAAAQEVkJGGAAIAAAAQGHAAEVEJIAAAAQEVEJAAF2IAAAAQAAF3kVEJIAAAAQkVEJmHAAIAAAAQmGAAkVkJg");
	var mask_23_graphics_208 = new cjs.Graphics().p("AqpKOQkbkPAAl/IAAAAQAAl+EbkPIAAAAQEakPGPAAIAAAAQGQAAEaEPIAAAAQEbEPAAF+IAAAAQAAF/kbEPIAAAAQkaEPmQAAIAAAAQmPAAkakPg");
	var mask_23_graphics_209 = new cjs.Graphics().p("Aq3KbQkhkUAAmHIAAAAQAAmGEhkUIAAAAQEgkVGXAAIAAAAQGYAAEgEVIAAAAQEhEUAAGGIAAAAQAAGHkhEUIAAAAQkgEVmYAAIAAAAQmXAAkgkVg");
	var mask_23_graphics_210 = new cjs.Graphics().p("ArFKoQkmkZAAmPIAAAAQAAmOEmkaIAAAAQEmkZGfAAIAAAAQGgAAEmEZIAAAAQEmEaAAGOIAAAAQAAGPkmEZIAAAAQkmEamgAAIAAAAQmfAAkmkag");
	var mask_23_graphics_211 = new cjs.Graphics().p("ArTK1QkskfAAmWIAAAAQAAmVEskgIAAAAQEskfGnAAIAAAAQGoAAEsEfIAAAAQEsEgAAGVIAAAAQAAGWksEfIAAAAQksEgmoAAIAAAAQmnAAkskgg");
	var mask_23_graphics_212 = new cjs.Graphics().p("ArgLCQkykkAAmeIAAAAQAAmdEyklIAAAAQExkkGvAAIAAAAQGwAAExEkIAAAAQEyElAAGdIAAAAQAAGekyEkIAAAAQkxElmwAAIAAAAQmvAAkxklg");
	var mask_23_graphics_213 = new cjs.Graphics().p("AruLPQk3kqAAmlIAAAAQAAmkE3kqIAAAAQE3kqG3AAIAAAAQG4AAE2EqIAAAAQE4EqAAGkIAAAAQAAGlk4EqIAAAAQk2Eqm4AAIAAAAQm3AAk3kqg");
	var mask_23_graphics_214 = new cjs.Graphics().p("Ar7LcQk8kvAAmtIAAAAQAAmsE8kvIAAAAQE9kvG+AAIAAAAQG/AAE9EvIAAAAQE8EvAAGsIAAAAQAAGtk8EvIAAAAQk9Evm/AAIAAAAQm+AAk9kvg");
	var mask_23_graphics_215 = new cjs.Graphics().p("AsILoQlCk0AAm0IAAAAQAAmzFCk0IAAAAQFCk1HGAAIAAAAQHHAAFCE1IAAAAQFCE0AAGzIAAAAQAAG0lCE0IAAAAQlCE1nHAAIAAAAQnGAAlCk1g");
	var mask_23_graphics_216 = new cjs.Graphics().p("AsVL0QlHk5AAm7IAAAAQAAm6FHk6IAAAAQFIk5HNAAIAAAAQHOAAFHE5IAAAAQFIE6AAG6IAAAAQAAG7lIE5IAAAAQlHE6nOAAIAAAAQnNAAlIk6g");
	var mask_23_graphics_217 = new cjs.Graphics().p("AshMBQlNk/AAnCIAAAAQAAnBFNk/IAAAAQFMk+HVAAIAAAAQHWAAFME+IAAAAQFNE/AAHBIAAAAQAAHClNE/IAAAAQlME+nWAAIAAAAQnVAAlMk+g");
	var mask_23_graphics_218 = new cjs.Graphics().p("AsuMMQlRlDAAnJIAAAAQAAnIFRlEIAAAAQFSlDHcAAIAAAAQHdAAFSFDIAAAAQFRFEAAHIIAAAAQAAHJlRFDIAAAAQlSFEndAAIAAAAQncAAlSlEg");
	var mask_23_graphics_219 = new cjs.Graphics().p("As6MYQlXlIAAnQIAAAAQAAnPFXlJIAAAAQFXlIHjAAIAAAAQHkAAFXFIIAAAAQFXFJAAHPIAAAAQAAHQlXFIIAAAAQlXFJnkAAIAAAAQnjAAlXlJg");
	var mask_23_graphics_220 = new cjs.Graphics().p("AtGMkQlclNAAnXIAAAAQAAnWFclNIAAAAQFblNHrAAIAAAAQHsAAFbFNIAAAAQFcFNAAHWIAAAAQAAHXlcFNIAAAAQlbFNnsAAIAAAAQnrAAlblNg");
	var mask_23_graphics_221 = new cjs.Graphics().p("AtSMvQlhlRAAneIAAAAQAAndFhlSIAAAAQFglRHyAAIAAAAQHzAAFgFRIAAAAQFhFSAAHdIAAAAQAAHelhFRIAAAAQlgFSnzAAIAAAAQnyAAlglSg");
	var mask_23_graphics_222 = new cjs.Graphics().p("AteM7QlllXAAnkIAAAAQAAnjFllXIAAAAQFmlWH4AAIAAAAQH5AAFmFWIAAAAQFlFXAAHjIAAAAQAAHkllFXIAAAAQlmFWn5AAIAAAAQn4AAlmlWg");
	var mask_23_graphics_223 = new cjs.Graphics().p("AtqNGQlqlbAAnrIAAAAQAAnqFqlbIAAAAQFrlbH/AAIAAAAQIAAAFqFbIAAAAQFrFbAAHqIAAAAQAAHrlrFbIAAAAQlqFboAAAIAAAAQn/AAlrlbg");
	var mask_23_graphics_224 = new cjs.Graphics().p("At1NRQlvlgAAnxIAAAAQAAnwFvlgIAAAAQFvlgIGAAIAAAAQIHAAFvFgIAAAAQFvFgAAHwIAAAAQAAHxlvFgIAAAAQlvFgoHAAIAAAAQoGAAlvlgg");
	var mask_23_graphics_225 = new cjs.Graphics().p("AuANbQl0ljAAn4IAAAAQAAn3F0lkIAAAAQF0lkIMAAIAAAAQINAAF0FkIAAAAQF0FkAAH3IAAAAQAAH4l0FjIAAAAQl0FloNAAIAAAAQoMAAl0llg");
	var mask_23_graphics_226 = new cjs.Graphics().p("AuLNmQl4loAAn+IAAAAQAAn9F4loIAAAAQF4lpITAAIAAAAQIUAAF4FpIAAAAQF4FoAAH9IAAAAQAAH+l4FoIAAAAQl4FpoUAAIAAAAQoTAAl4lpg");
	var mask_23_graphics_227 = new cjs.Graphics().p("AuWNwQl9lsAAoEIAAAAQAAoDF9ltIAAAAQF9lsIZAAIAAAAQIaAAF9FsIAAAAQF9FtAAIDIAAAAQAAIEl9FsIAAAAQl9FtoaAAIAAAAQoZAAl9ltg");
	var mask_23_graphics_228 = new cjs.Graphics().p("AuhN7QmBlxAAoKIAAAAQAAoJGBlxIAAAAQGBlxIgAAIAAAAQIhAAGBFxIAAAAQGBFxAAIJIAAAAQAAIKmBFxIAAAAQmBFxohAAIAAAAQogAAmBlxg");
	var mask_23_graphics_229 = new cjs.Graphics().p("AurOFQmGl1AAoQIAAAAQAAoPGGl1IAAAAQGFl1ImAAIAAAAQInAAGFF1IAAAAQGGF1AAIPIAAAAQAAIQmGF1IAAAAQmFF1onAAIAAAAQomAAmFl1g");
	var mask_23_graphics_230 = new cjs.Graphics().p("Au2OPQmJl6AAoVIAAAAQAAoUGJl6IAAAAQGKl5IsAAIAAAAQItAAGJF5IAAAAQGKF6AAIUIAAAAQAAIVmKF6IAAAAQmJF5otAAIAAAAQosAAmKl5g");
	var mask_23_graphics_231 = new cjs.Graphics().p("AvAOYQmOl9AAobIAAAAQAAoaGOl+IAAAAQGOl9IyAAIAAAAQIzAAGNF9IAAAAQGPF+AAIaIAAAAQAAIbmPF9IAAAAQmNF+ozAAIAAAAQoyAAmOl+g");
	var mask_23_graphics_232 = new cjs.Graphics().p("AvKOiQmSmBAAohIAAAAQAAogGSmBIAAAAQGSmBI4AAIAAAAQI5AAGRGBIAAAAQGTGBAAIgIAAAAQAAIhmTGBIAAAAQmRGBo5AAIAAAAQo4AAmSmBg");
	var mask_23_graphics_233 = new cjs.Graphics().p("AvUOrQmWmFAAomIAAAAQAAolGWmGIAAAAQGXmFI9AAIAAAAQI+AAGWGFIAAAAQGXGGAAIlIAAAAQAAImmXGFIAAAAQmWGGo+AAIAAAAQo9AAmXmGg");
	var mask_23_graphics_234 = new cjs.Graphics().p("AvdO0QmamIAAosIAAAAQAAorGamJIAAAAQGamJJDAAIAAAAQJEAAGaGJIAAAAQGaGJAAIrIAAAAQAAIsmaGIIAAAAQmaGKpEAAIAAAAQpDAAmamKg");
	var mask_23_graphics_235 = new cjs.Graphics().p("AvnO9QmemMAAoxIAAAAQAAowGemNIAAAAQGfmMJIAAIAAAAQJJAAGeGMIAAAAQGfGNAAIwIAAAAQAAIxmfGMIAAAAQmeGNpJAAIAAAAQpIAAmfmNg");
	var mask_23_graphics_236 = new cjs.Graphics().p("AvwPGQmimQAAo2IAAAAQAAo1GimRIAAAAQGimQJOAAIAAAAQJPAAGiGQIAAAAQGiGRAAI1IAAAAQAAI2miGQIAAAAQmiGRpPAAIAAAAQpOAAmimRg");
	var mask_23_graphics_237 = new cjs.Graphics().p("Av5PPQmlmUAAo7IAAAAQAAo6GlmVIAAAAQGmmTJTAAIAAAAQJUAAGmGTIAAAAQGlGVAAI6IAAAAQAAI7mlGUIAAAAQmmGUpUAAIAAAAQpTAAmmmUg");
	var mask_23_graphics_238 = new cjs.Graphics().p("AwCPYQmpmYAApAIAAAAQAAo/GpmYIAAAAQGqmXJYAAIAAAAQJZAAGpGXIAAAAQGqGYAAI/IAAAAQAAJAmqGYIAAAAQmpGXpZAAIAAAAQpYAAmqmXg");
	var mask_23_graphics_239 = new cjs.Graphics().p("AwLPgQmsmbAApFIAAAAQAApEGsmbIAAAAQGumbJdAAIAAAAQJeAAGtGbIAAAAQGtGbAAJEIAAAAQAAJFmtGbIAAAAQmtGbpeAAIAAAAQpdAAmumbg");
	var mask_23_graphics_240 = new cjs.Graphics().p("AwTPoQmwmeAApKIAAAAQAApJGwmfIAAAAQGxmeJiAAIAAAAQJjAAGxGeIAAAAQGwGfAAJJIAAAAQAAJKmwGeIAAAAQmxGfpjAAIAAAAQpiAAmxmfg");
	var mask_23_graphics_241 = new cjs.Graphics().p("AwcPwQmzmhAApPIAAAAQAApOGzmiIAAAAQG1mhJnAAIAAAAQJoAAG0GhIAAAAQG0GiAAJOIAAAAQAAJPm0GhIAAAAQm0GipoAAIAAAAQpnAAm1mig");
	var mask_23_graphics_242 = new cjs.Graphics().p("AwkP4Qm3mlAApTIAAAAQAApSG3mlIAAAAQG4mlJsAAIAAAAQJtAAG3GlIAAAAQG4GlAAJSIAAAAQAAJTm4GlIAAAAQm3GlptAAIAAAAQpsAAm4mlg");
	var mask_23_graphics_243 = new cjs.Graphics().p("AwsQAQm6moAApYIAAAAQAApXG6moIAAAAQG7moJxAAIAAAAQJyAAG6GoIAAAAQG7GoAAJXIAAAAQAAJYm7GoIAAAAQm6GopyAAIAAAAQpxAAm7mog");
	var mask_23_graphics_244 = new cjs.Graphics().p("Aw0QHQm9mrAApcIAAAAQAApbG9msIAAAAQG/mrJ1AAIAAAAQJ2AAG+GrIAAAAQG+GsAAJbIAAAAQAAJcm+GrIAAAAQm+Gsp2AAIAAAAQp1AAm/msg");
	var mask_23_graphics_245 = new cjs.Graphics().p("Aw7QPQnBmvAApgIAAAAQAApfHBmvIAAAAQHBmuJ6AAIAAAAQJ7AAHBGuIAAAAQHBGvAAJfIAAAAQAAJgnBGvIAAAAQnBGup7AAIAAAAQp6AAnBmug");
	var mask_23_graphics_246 = new cjs.Graphics().p("AxDQWQnEmxAAplIAAAAQAApkHEmxIAAAAQHFmxJ+AAIAAAAQJ/AAHEGxIAAAAQHFGxAAJkIAAAAQAAJlnFGxIAAAAQnEGxp/AAIAAAAQp+AAnFmxg");
	var mask_23_graphics_247 = new cjs.Graphics().p("AxKQdQnHm0AAppIAAAAQAApoHHm0IAAAAQHHm0KDAAIAAAAQKEAAHHG0IAAAAQHHG0AAJoIAAAAQAAJpnHG0IAAAAQnHG0qEAAIAAAAQqDAAnHm0g");
	var mask_23_graphics_248 = new cjs.Graphics().p("AxRQkQnKm3AAptIAAAAQAApsHKm3IAAAAQHKm3KHAAIAAAAQKIAAHKG3IAAAAQHKG3AAJsIAAAAQAAJtnKG3IAAAAQnKG3qIAAIAAAAQqHAAnKm3g");
	var mask_23_graphics_249 = new cjs.Graphics().p("AxYQqQnNm5AApxIAAAAQAApwHNm6IAAAAQHNm5KLAAIAAAAQKMAAHNG5IAAAAQHNG6AAJwIAAAAQAAJxnNG5IAAAAQnNG6qMAAIAAAAQqLAAnNm6g");
	var mask_23_graphics_250 = new cjs.Graphics().p("AxfQxQnQm8AAp1IAAAAQAAp0HQm8IAAAAQHQm9KPAAIAAAAQKQAAHQG9IAAAAQHQG8AAJ0IAAAAQAAJ1nQG8IAAAAQnQG9qQAAIAAAAQqPAAnQm9g");
	var mask_23_graphics_251 = new cjs.Graphics().p("AxmQ3QnSm/AAp4IAAAAQAAp3HSnAIAAAAQHTm/KTAAIAAAAQKUAAHSG/IAAAAQHTHAAAJ3IAAAAQAAJ4nTG/IAAAAQnSHAqUAAIAAAAQqTAAnTnAg");
	var mask_23_graphics_252 = new cjs.Graphics().p("AxsQ+QnWnCAAp8IAAAAQAAp7HWnCIAAAAQHVnCKXAAIAAAAQKYAAHVHCIAAAAQHWHCAAJ7IAAAAQAAJ8nWHCIAAAAQnVHCqYAAIAAAAQqXAAnVnCg");
	var mask_23_graphics_253 = new cjs.Graphics().p("AxzREQnYnEAAqAIAAAAQAAp/HYnEIAAAAQHZnEKaAAIAAAAQKbAAHYHEIAAAAQHZHEAAJ/IAAAAQAAKAnZHEIAAAAQnYHEqbAAIAAAAQqaAAnZnEg");
	var mask_23_graphics_254 = new cjs.Graphics().p("Ax5RKQnanHAAqDIAAAAQAAqCHanHIAAAAQHbnHKeAAIAAAAQKfAAHaHHIAAAAQHbHHAAKCIAAAAQAAKDnbHHIAAAAQnaHHqfAAIAAAAQqeAAnbnHg");
	var mask_23_graphics_255 = new cjs.Graphics().p("Ax/RPQndnJAAqGIAAAAQAAqFHdnKIAAAAQHdnJKiAAIAAAAQKjAAHdHJIAAAAQHdHKAAKFIAAAAQAAKGndHJIAAAAQndHKqjAAIAAAAQqiAAndnKg");
	var mask_23_graphics_256 = new cjs.Graphics().p("AyFRVQnfnLAAqKIAAAAQAAqJHfnMIAAAAQHgnLKlAAIAAAAQKmAAHfHLIAAAAQHgHMAAKJIAAAAQAAKKngHLIAAAAQnfHMqmAAIAAAAQqlAAngnMg");
	var mask_23_graphics_257 = new cjs.Graphics().p("AyLRaQnhnNAAqNIAAAAQAAqMHhnOIAAAAQHjnOKoAAIAAAAQKpAAHiHOIAAAAQHiHOAAKMIAAAAQAAKNniHNIAAAAQniHPqpAAIAAAAQqoAAnjnPg");
	var mask_23_graphics_258 = new cjs.Graphics().p("AyQRgQnknQAAqQIAAAAQAAqPHknQIAAAAQHknQKsAAIAAAAQKtAAHkHQIAAAAQHkHQAAKPIAAAAQAAKQnkHQIAAAAQnkHQqtAAIAAAAQqsAAnknQg");
	var mask_23_graphics_259 = new cjs.Graphics().p("AyWRlQnmnSAAqTIAAAAQAAqSHmnTIAAAAQHnnRKvAAIAAAAQKwAAHmHRIAAAAQHnHTAAKSIAAAAQAAKTnnHSIAAAAQnmHSqwAAIAAAAQqvAAnnnSg");
	var mask_23_graphics_260 = new cjs.Graphics().p("AybRqQnonUAAqWIAAAAQAAqVHonVIAAAAQHpnUKyAAIAAAAQKzAAHoHUIAAAAQHpHVAAKVIAAAAQAAKWnpHUIAAAAQnoHVqzAAIAAAAQqyAAnpnVg");
	var mask_23_graphics_261 = new cjs.Graphics().p("AygRvQnrnWAAqZIAAAAQAAqYHrnXIAAAAQHrnWK1AAIAAAAQK2AAHqHWIAAAAQHsHXAAKYIAAAAQAAKZnsHWIAAAAQnqHXq2AAIAAAAQq1AAnrnXg");
	var mask_23_graphics_262 = new cjs.Graphics().p("AylR0QntnYAAqcIAAAAQAAqbHtnYIAAAAQHtnYK4AAIAAAAQK5AAHsHYIAAAAQHuHYAAKbIAAAAQAAKcnuHYIAAAAQnsHYq5AAIAAAAQq4AAntnYg");
	var mask_23_graphics_263 = new cjs.Graphics().p("AyqR4QnunaAAqeIAAAAQAAqdHunbIAAAAQHvnaK7AAIAAAAQK8AAHuHaIAAAAQHvHbAAKdIAAAAQAAKenvHaIAAAAQnuHbq8AAIAAAAQq7AAnvnbg");
	var mask_23_graphics_264 = new cjs.Graphics().p("AyvR9QnwncAAqhIAAAAQAAqgHwncIAAAAQHyncK9AAIAAAAQK+AAHxHcIAAAAQHxHcAAKgIAAAAQAAKhnxHcIAAAAQnxHcq+AAIAAAAQq9AAnyncg");
	var mask_23_graphics_265 = new cjs.Graphics().p("AyzSBQnyndAAqkIAAAAQAAqjHyneIAAAAQHzndLAAAIAAAAQLBAAHyHdIAAAAQHzHeAAKjIAAAAQAAKknzHdIAAAAQnyHerBAAIAAAAQrAAAnzneg");
	var mask_23_graphics_266 = new cjs.Graphics().p("Ay3SFQn1nfAAqmIAAAAQAAqlH1ngIAAAAQH0nfLDAAIAAAAQLEAAH0HfIAAAAQH1HgAAKlIAAAAQAAKmn1HfIAAAAQn0HgrEAAIAAAAQrDAAn0ngg");
	var mask_23_graphics_267 = new cjs.Graphics().p("Ay8SJQn2nhAAqoIAAAAQAAqnH2niIAAAAQH3nhLFAAIAAAAQLGAAH2HhIAAAAQH3HiAAKnIAAAAQAAKon3HhIAAAAQn2HirGAAIAAAAQrFAAn3nig");
	var mask_23_graphics_268 = new cjs.Graphics().p("AzASNQn3niAAqrIAAAAQAAqqH3njIAAAAQH4njLIAAIAAAAQLJAAH3HjIAAAAQH4HjAAKqIAAAAQAAKrn4HiIAAAAQn3HkrJAAIAAAAQrIAAn4nkg");
	var mask_23_graphics_269 = new cjs.Graphics().p("AzESRQn5nkAAqtIAAAAQAAqsH5nlIAAAAQH6nkLKAAIAAAAQLLAAH5HkIAAAAQH6HlAAKsIAAAAQAAKtn6HkIAAAAQn5HlrLAAIAAAAQrKAAn6nlg");
	var mask_23_graphics_270 = new cjs.Graphics().p("AzISVQn7nmAAqvIAAAAQAAquH7nmIAAAAQH8nmLMAAIAAAAQLNAAH7HmIAAAAQH8HmAAKuIAAAAQAAKvn8HmIAAAAQn7HmrNAAIAAAAQrMAAn8nmg");
	var mask_23_graphics_271 = new cjs.Graphics().p("AzLSYQn9nnAAqxIAAAAQAAqwH9noIAAAAQH9nnLOAAIAAAAQLPAAH9HnIAAAAQH9HoAAKwIAAAAQAAKxn9HnIAAAAQn9HorPAAIAAAAQrOAAn9nog");
	var mask_23_graphics_272 = new cjs.Graphics().p("AzPScQn+npAAqzIAAAAQAAqyH+npIAAAAQH/npLQAAIAAAAQLRAAH+HpIAAAAQH/HpAAKyIAAAAQAAKzn/HpIAAAAQn+HprRAAIAAAAQrQAAn/npg");
	var mask_23_graphics_273 = new cjs.Graphics().p("AzSSfQoAnqAAq1IAAAAQAAq0IAnrIAAAAQIAnqLSAAIAAAAQLTAAIAHqIAAAAQIAHrAAK0IAAAAQAAK1oAHqIAAAAQoAHrrTAAIAAAAQrSAAoAnrg");
	var mask_23_graphics_274 = new cjs.Graphics().p("AzWSiQoAnrAAq3IAAAAQAAq2IAnsIAAAAQICnrLUAAIAAAAQLVAAIBHrIAAAAQIBHsAAK2IAAAAQAAK3oBHrIAAAAQoBHsrVAAIAAAAQrUAAoCnsg");
	var mask_23_graphics_275 = new cjs.Graphics().p("AzZSlQoCnsAAq5IAAAAQAAq4ICntIAAAAQIDnsLWAAIAAAAQLXAAICHsIAAAAQIDHtAAK4IAAAAQAAK5oDHsIAAAAQoCHtrXAAIAAAAQrWAAoDntg");
	var mask_23_graphics_276 = new cjs.Graphics().p("AzcSoQoDnuAAq6IAAAAQAAq5IDnvIAAAAQIEntLYAAIAAAAQLZAAIDHtIAAAAQIEHvAAK5IAAAAQAAK6oEHuIAAAAQoDHurZAAIAAAAQrYAAoEnug");
	var mask_23_graphics_277 = new cjs.Graphics().p("AzfSrQoEnvAAq8IAAAAQAAq7IEnvIAAAAQIFnvLaAAIAAAAQLbAAIEHvIAAAAQIFHvAAK7IAAAAQAAK8oFHvIAAAAQoEHvrbAAIAAAAQraAAoFnvg");
	var mask_23_graphics_278 = new cjs.Graphics().p("AzhSuQoGnwAAq+IAAAAQAAq9IGnwIAAAAQIGnwLbAAIAAAAQLcAAIGHwIAAAAQIGHwAAK9IAAAAQAAK+oGHwIAAAAQoGHwrcAAIAAAAQrbAAoGnwg");
	var mask_23_graphics_279 = new cjs.Graphics().p("AzkSwQoHnxAAq/IAAAAQAAq+IHnyIAAAAQIHnxLdAAIAAAAQLeAAIGHxIAAAAQIIHyAAK+IAAAAQAAK/oIHxIAAAAQoGHyreAAIAAAAQrdAAoHnyg");
	var mask_23_graphics_280 = new cjs.Graphics().p("AznSzQoHnyAArBIAAAAQAArAIHnyIAAAAQIJnyLeAAIAAAAQLfAAIIHyIAAAAQIIHyAALAIAAAAQAALBoIHyIAAAAQoIHyrfAAIAAAAQreAAoJnyg");
	var mask_23_graphics_281 = new cjs.Graphics().p("AzpS1QoJnzAArCIAAAAQAArBIJnzIAAAAQIJnzLgAAIAAAAQLhAAIIHzIAAAAQIKHzAALBIAAAAQAALCoKHzIAAAAQoIHzrhAAIAAAAQrgAAoJnzg");
	var mask_23_graphics_282 = new cjs.Graphics().p("AzrS3QoKn0AArDIAAAAQAArCIKn1IAAAAQIKnzLhAAIAAAAQLiAAIKHzIAAAAQIKH1AALCIAAAAQAALDoKH0IAAAAQoKH0riAAIAAAAQrhAAoKn0g");
	var mask_23_graphics_283 = new cjs.Graphics().p("AztS5QoLn1AArEIAAAAQAArDILn2IAAAAQILn0LiAAIAAAAQLjAAILH0IAAAAQILH2AALDIAAAAQAALEoLH1IAAAAQoLH1rjAAIAAAAQriAAoLn1g");
	var mask_23_graphics_284 = new cjs.Graphics().p("AzvS7QoMn2AArFIAAAAQAArEIMn3IAAAAQIMn1LjAAIAAAAQLkAAIMH1IAAAAQIMH3AALEIAAAAQAALFoMH2IAAAAQoMH2rkAAIAAAAQrjAAoMn2g");
	var mask_23_graphics_285 = new cjs.Graphics().p("AzxS9QoNn2AArHIAAAAQAArGINn2IAAAAQIMn3LlAAIAAAAQLmAAIMH3IAAAAQINH2AALGIAAAAQAALHoNH2IAAAAQoMH3rmAAIAAAAQrlAAoMn3g");
	var mask_23_graphics_286 = new cjs.Graphics().p("AzzS/QoNn3AArIIAAAAQAArHINn3IAAAAQINn3LmAAIAAAAQLnAAINH3IAAAAQINH3AALHIAAAAQAALIoNH3IAAAAQoNH3rnAAIAAAAQrmAAoNn3g");
	var mask_23_graphics_287 = new cjs.Graphics().p("Az1TAQoNn3AArJIAAAAQAArHINn5IAAAAQIOn3LnAAIAAAAQLoAAINH3IAAAAQIOH5AALHIAAAAQAALJoOH3IAAAAQoNH4roAAIAAAAQrnAAoOn4g");
	var mask_23_graphics_288 = new cjs.Graphics().p("Az2TCQoPn5AArJIAAAAQAArIIPn5IAAAAQIOn5LoAAIAAAAQLpAAIOH5IAAAAQIPH5AALIIAAAAQAALJoPH5IAAAAQoOH4rpABIAAAAQrogBoOn4g");
	var mask_23_graphics_289 = new cjs.Graphics().p("Az4TDQoPn5AArKIAAAAQAArJIPn6IAAAAQIQn4LoAAIAAAAQLpAAIPH4IAAAAQIQH6AALJIAAAAQAALKoQH5IAAAAQoPH5rpAAIAAAAQroAAoQn5g");
	var mask_23_graphics_290 = new cjs.Graphics().p("Az5TEQoQn5AArLIAAAAQAArKIQn6IAAAAQIQn5LpAAIAAAAQLqAAIQH5IAAAAQIQH6AALKIAAAAQAALLoQH5IAAAAQoQH6rqAAIAAAAQrpAAoQn6g");
	var mask_23_graphics_291 = new cjs.Graphics().p("Az6TFQoQn5AArMIAAAAQAArLIQn6IAAAAQIQn6LqAAIAAAAQLrAAIQH6IAAAAQIQH6AALLIAAAAQAALMoQH5IAAAAQoQH7rrAAIAAAAQrqAAoQn7g");
	var mask_23_graphics_292 = new cjs.Graphics().p("Az8THQoQn7AArMIAAAAQAArLIQn7IAAAAQIRn6LrAAIAAAAQLsAAIQH6IAAAAQIRH7AALLIAAAAQAALMoRH7IAAAAQoQH6rsAAIAAAAQrrAAoRn6g");
	var mask_23_graphics_293 = new cjs.Graphics().p("Az9TIQoQn7AArNIAAAAQAArMIQn7IAAAAQISn7LrAAIAAAAQLsAAIRH7IAAAAQIRH7AALMIAAAAQAALNoRH7IAAAAQoRH7rsAAIAAAAQrrAAoSn7g");
	var mask_23_graphics_294 = new cjs.Graphics().p("Az9TIQoSn7AArNIAAAAQAArMISn8IAAAAQIRn7LsAAIAAAAQLtAAIRH7IAAAAQISH8AALMIAAAAQAALNoSH7IAAAAQoRH8rtAAIAAAAQrsAAoRn8g");

	this.timeline.addTween(cjs.Tween.get(mask_23).to({graphics:null,x:0,y:0}).wait(166).to({graphics:mask_23_graphics_166,x:581.85,y:609.1002}).wait(1).to({graphics:mask_23_graphics_167,x:582.5344,y:608.2803}).wait(1).to({graphics:mask_23_graphics_168,x:583.2229,y:607.455}).wait(1).to({graphics:mask_23_graphics_169,x:583.9146,y:606.6261}).wait(1).to({graphics:mask_23_graphics_170,x:584.6107,y:605.7922}).wait(1).to({graphics:mask_23_graphics_171,x:585.3091,y:604.9548}).wait(1).to({graphics:mask_23_graphics_172,x:586.0111,y:604.1137}).wait(1).to({graphics:mask_23_graphics_173,x:586.7154,y:603.27}).wait(1).to({graphics:mask_23_graphics_174,x:587.4219,y:602.4226}).wait(1).to({graphics:mask_23_graphics_175,x:588.1306,y:601.5735}).wait(1).to({graphics:mask_23_graphics_176,x:588.8412,y:600.7221}).wait(1).to({graphics:mask_23_graphics_177,x:589.5526,y:599.8693}).wait(1).to({graphics:mask_23_graphics_178,x:590.2659,y:599.0148}).wait(1).to({graphics:mask_23_graphics_179,x:590.9796,y:598.1593}).wait(1).to({graphics:mask_23_graphics_180,x:591.6937,y:597.3034}).wait(1).to({graphics:mask_23_graphics_181,x:592.4079,y:596.4475}).wait(1).to({graphics:mask_23_graphics_182,x:593.122,y:595.5916}).wait(1).to({graphics:mask_23_graphics_183,x:593.8353,y:594.7366}).wait(1).to({graphics:mask_23_graphics_184,x:594.5481,y:593.8825}).wait(1).to({graphics:mask_23_graphics_185,x:595.2604,y:593.0293}).wait(1).to({graphics:mask_23_graphics_186,x:595.9701,y:592.1788}).wait(1).to({graphics:mask_23_graphics_187,x:596.6784,y:591.3292}).wait(1).to({graphics:mask_23_graphics_188,x:597.3849,y:590.4828}).wait(1).to({graphics:mask_23_graphics_189,x:598.0891,y:589.639}).wait(1).to({graphics:mask_23_graphics_190,x:598.7907,y:588.7984}).wait(1).to({graphics:mask_23_graphics_191,x:599.4891,y:587.9615}).wait(1).to({graphics:mask_23_graphics_192,x:600.1848,y:587.1276}).wait(1).to({graphics:mask_23_graphics_193,x:600.8764,y:586.2987}).wait(1).to({graphics:mask_23_graphics_194,x:601.5645,y:585.4738}).wait(1).to({graphics:mask_23_graphics_195,x:602.2485,y:584.6544}).wait(1).to({graphics:mask_23_graphics_196,x:602.9289,y:583.839}).wait(1).to({graphics:mask_23_graphics_197,x:603.6043,y:583.0299}).wait(1).to({graphics:mask_23_graphics_198,x:604.2753,y:582.2253}).wait(1).to({graphics:mask_23_graphics_199,x:604.9413,y:581.4279}).wait(1).to({graphics:mask_23_graphics_200,x:605.6019,y:580.6359}).wait(1).to({graphics:mask_23_graphics_201,x:606.2566,y:579.8502}).wait(1).to({graphics:mask_23_graphics_202,x:606.9069,y:579.0717}).wait(1).to({graphics:mask_23_graphics_203,x:607.5508,y:578.3004}).wait(1).to({graphics:mask_23_graphics_204,x:608.1889,y:577.535}).wait(1).to({graphics:mask_23_graphics_205,x:608.8212,y:576.778}).wait(1).to({graphics:mask_23_graphics_206,x:609.4467,y:576.0279}).wait(1).to({graphics:mask_23_graphics_207,x:610.0659,y:575.2859}).wait(1).to({graphics:mask_23_graphics_208,x:610.6788,y:574.5515}).wait(1).to({graphics:mask_23_graphics_209,x:611.2849,y:573.8247}).wait(1).to({graphics:mask_23_graphics_210,x:611.8839,y:573.1069}).wait(1).to({graphics:mask_23_graphics_211,x:612.4761,y:572.3973}).wait(1).to({graphics:mask_23_graphics_212,x:613.0615,y:571.6957}).wait(1).to({graphics:mask_23_graphics_213,x:613.6398,y:571.0027}).wait(1).to({graphics:mask_23_graphics_214,x:614.2104,y:570.3187}).wait(1).to({graphics:mask_23_graphics_215,x:614.7738,y:569.6437}).wait(1).to({graphics:mask_23_graphics_216,x:615.33,y:568.9773}).wait(1).to({graphics:mask_23_graphics_217,x:615.8785,y:568.3198}).wait(1).to({graphics:mask_23_graphics_218,x:616.4199,y:567.6714}).wait(1).to({graphics:mask_23_graphics_219,x:616.9531,y:567.0319}).wait(1).to({graphics:mask_23_graphics_220,x:617.4792,y:566.4015}).wait(1).to({graphics:mask_23_graphics_221,x:617.9971,y:565.7809}).wait(1).to({graphics:mask_23_graphics_222,x:618.5074,y:565.1694}).wait(1).to({graphics:mask_23_graphics_223,x:619.0101,y:564.5668}).wait(1).to({graphics:mask_23_graphics_224,x:619.5046,y:563.9742}).wait(1).to({graphics:mask_23_graphics_225,x:619.9915,y:563.3905}).wait(1).to({graphics:mask_23_graphics_226,x:620.4708,y:562.8163}).wait(1).to({graphics:mask_23_graphics_227,x:620.942,y:562.252}).wait(1).to({graphics:mask_23_graphics_228,x:621.4054,y:561.6963}).wait(1).to({graphics:mask_23_graphics_229,x:621.8613,y:561.1505}).wait(1).to({graphics:mask_23_graphics_230,x:622.3086,y:560.614}).wait(1).to({graphics:mask_23_graphics_231,x:622.7482,y:560.0866}).wait(1).to({graphics:mask_23_graphics_232,x:623.1807,y:559.5692}).wait(1).to({graphics:mask_23_graphics_233,x:623.605,y:559.0602}).wait(1).to({graphics:mask_23_graphics_234,x:624.0217,y:558.5612}).wait(1).to({graphics:mask_23_graphics_235,x:624.4299,y:558.0715}).wait(1).to({graphics:mask_23_graphics_236,x:624.8308,y:557.5909}).wait(1).to({graphics:mask_23_graphics_237,x:625.2246,y:557.1198}).wait(1).to({graphics:mask_23_graphics_238,x:625.6098,y:556.6576}).wait(1).to({graphics:mask_23_graphics_239,x:625.9878,y:556.2045}).wait(1).to({graphics:mask_23_graphics_240,x:626.3582,y:555.7608}).wait(1).to({graphics:mask_23_graphics_241,x:626.7209,y:555.3261}).wait(1).to({graphics:mask_23_graphics_242,x:627.0759,y:554.9004}).wait(1).to({graphics:mask_23_graphics_243,x:627.4238,y:554.4837}).wait(1).to({graphics:mask_23_graphics_244,x:627.7644,y:554.076}).wait(1).to({graphics:mask_23_graphics_245,x:628.0974,y:553.6768}).wait(1).to({graphics:mask_23_graphics_246,x:628.4227,y:553.2862}).wait(1).to({graphics:mask_23_graphics_247,x:628.7413,y:552.9051}).wait(1).to({graphics:mask_23_graphics_248,x:629.0523,y:552.532}).wait(1).to({graphics:mask_23_graphics_249,x:629.356,y:552.168}).wait(1).to({graphics:mask_23_graphics_250,x:629.6526,y:551.8129}).wait(1).to({graphics:mask_23_graphics_251,x:629.9424,y:551.4655}).wait(1).to({graphics:mask_23_graphics_252,x:630.225,y:551.1267}).wait(1).to({graphics:mask_23_graphics_253,x:630.5009,y:550.7968}).wait(1).to({graphics:mask_23_graphics_254,x:630.769,y:550.4747}).wait(1).to({graphics:mask_23_graphics_255,x:631.031,y:550.1605}).wait(1).to({graphics:mask_23_graphics_256,x:631.2861,y:549.855}).wait(1).to({graphics:mask_23_graphics_257,x:631.5345,y:549.5575}).wait(1).to({graphics:mask_23_graphics_258,x:631.7761,y:549.2682}).wait(1).to({graphics:mask_23_graphics_259,x:632.011,y:548.9865}).wait(1).to({graphics:mask_23_graphics_260,x:632.2397,y:548.7124}).wait(1).to({graphics:mask_23_graphics_261,x:632.4615,y:548.4465}).wait(1).to({graphics:mask_23_graphics_262,x:632.6766,y:548.1886}).wait(1).to({graphics:mask_23_graphics_263,x:632.8858,y:547.9384}).wait(1).to({graphics:mask_23_graphics_264,x:633.0883,y:547.6954}).wait(1).to({graphics:mask_23_graphics_265,x:633.285,y:547.4596}).wait(1).to({graphics:mask_23_graphics_266,x:633.4749,y:547.2319}).wait(1).to({graphics:mask_23_graphics_267,x:633.6594,y:547.0114}).wait(1).to({graphics:mask_23_graphics_268,x:633.8372,y:546.7977}).wait(1).to({graphics:mask_23_graphics_269,x:634.009,y:546.5916}).wait(1).to({graphics:mask_23_graphics_270,x:634.1751,y:546.3931}).wait(1).to({graphics:mask_23_graphics_271,x:634.3353,y:546.201}).wait(1).to({graphics:mask_23_graphics_272,x:634.4887,y:546.017}).wait(1).to({graphics:mask_23_graphics_273,x:634.6373,y:545.8387}).wait(1).to({graphics:mask_23_graphics_274,x:634.7799,y:545.6677}).wait(1).to({graphics:mask_23_graphics_275,x:634.9167,y:545.5044}).wait(1).to({graphics:mask_23_graphics_276,x:635.0481,y:545.3469}).wait(1).to({graphics:mask_23_graphics_277,x:635.1736,y:545.1966}).wait(1).to({graphics:mask_23_graphics_278,x:635.2938,y:545.0521}).wait(1).to({graphics:mask_23_graphics_279,x:635.4081,y:544.9153}).wait(1).to({graphics:mask_23_graphics_280,x:635.5179,y:544.784}).wait(1).to({graphics:mask_23_graphics_281,x:635.6214,y:544.6597}).wait(1).to({graphics:mask_23_graphics_282,x:635.7199,y:544.5418}).wait(1).to({graphics:mask_23_graphics_283,x:635.8136,y:544.4298}).wait(1).to({graphics:mask_23_graphics_284,x:635.9013,y:544.324}).wait(1).to({graphics:mask_23_graphics_285,x:635.9846,y:544.225}).wait(1).to({graphics:mask_23_graphics_286,x:636.0619,y:544.1319}).wait(1).to({graphics:mask_23_graphics_287,x:636.1348,y:544.0441}).wait(1).to({graphics:mask_23_graphics_288,x:636.2028,y:543.9636}).wait(1).to({graphics:mask_23_graphics_289,x:636.2653,y:543.888}).wait(1).to({graphics:mask_23_graphics_290,x:636.3234,y:543.8182}).wait(1).to({graphics:mask_23_graphics_291,x:636.3765,y:543.7548}).wait(1).to({graphics:mask_23_graphics_292,x:636.4251,y:543.6967}).wait(1).to({graphics:mask_23_graphics_293,x:636.4683,y:543.6446}).wait(1).to({graphics:mask_23_graphics_294,x:635.8181,y:542.9092}).wait(516));

	// Layer_11
	this.instance_41 = new lib.Tween28("synched",0);
	this.instance_41.setTransform(685.95,562.95);
	this.instance_41.alpha = 0.5;
	this.instance_41._off = true;

	var maskedShapeInstanceList = [this.instance_41];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_23;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_41).wait(166).to({_off:false},0).to({alpha:1},91).wait(553));

	// Layer_6 (mask)
	var mask_24 = new cjs.Shape();
	mask_24._off = true;
	var mask_24_graphics_92 = new cjs.Graphics().p("AgqApQgSgRAAgYIAAAAQAAgXASgRIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQASARAAAXIAAAAQAAAYgSARIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_24_graphics_93 = new cjs.Graphics().p("AgsArQgSgSAAgZIAAAAQAAgYASgSIAAAAQATgSAZAAIAAAAQAaAAATASIAAAAQASASAAAYIAAAAQAAAZgSASIAAAAQgTASgaAAIAAAAQgZAAgTgSg");
	var mask_24_graphics_94 = new cjs.Graphics().p("AguAtQgUgTAAgaIAAAAQAAgZAUgTIAAAAQATgTAbAAIAAAAQAcAAATATIAAAAQAUATAAAZIAAAAQAAAagUATIAAAAQgTATgcAAIAAAAQgbAAgTgTg");
	var mask_24_graphics_95 = new cjs.Graphics().p("AgxAwQgVgUAAgcIAAAAQAAgbAVgUIAAAAQAVgUAcAAIAAAAQAdAAAVAUIAAAAQAVAUAAAbIAAAAQAAAcgVAUIAAAAQgVAUgdAAIAAAAQgcAAgVgUg");
	var mask_24_graphics_96 = new cjs.Graphics().p("Ag1A0QgWgWAAgeIAAAAQAAgdAWgWIAAAAQAWgVAfAAIAAAAQAgAAAWAVIAAAAQAWAWAAAdIAAAAQAAAegWAWIAAAAQgWAVggAAIAAAAQgfAAgWgVg");
	var mask_24_graphics_97 = new cjs.Graphics().p("Ag5A4QgYgXAAghIAAAAQAAggAYgXIAAAAQAYgXAhAAIAAAAQAiAAAYAXIAAAAQAYAXAAAgIAAAAQAAAhgYAXIAAAAQgYAXgiAAIAAAAQghAAgYgXg");
	var mask_24_graphics_98 = new cjs.Graphics().p("Ag+A9QgagZgBgkIAAAAQABgjAagZIAAAAQAagZAkAAIAAAAQAlAAAaAZIAAAAQAbAZAAAjIAAAAQAAAkgbAZIAAAAQgaAZglAAIAAAAQgkAAgagZg");
	var mask_24_graphics_99 = new cjs.Graphics().p("AhEBCQgdgbAAgnIAAAAQAAgmAdgbIAAAAQAdgbAnAAIAAAAQAoAAAdAbIAAAAQAdAbAAAmIAAAAQAAAngdAbIAAAAQgdAbgoAAIAAAAQgnAAgdgbg");
	var mask_24_graphics_100 = new cjs.Graphics().p("AhKBIQgggeAAgqIAAAAQAAgpAggeIAAAAQAfgeArAAIAAAAQAsAAAfAeIAAAAQAgAeAAApIAAAAQAAAqggAeIAAAAQgfAegsAAIAAAAQgrAAgfgeg");
	var mask_24_graphics_101 = new cjs.Graphics().p("AhRBPQgjghAAguIAAAAQAAgtAjghIAAAAQAighAvAAIAAAAQAwAAAiAhIAAAAQAjAhAAAtIAAAAQAAAugjAhIAAAAQgiAhgwAAIAAAAQgvAAgighg");
	var mask_24_graphics_102 = new cjs.Graphics().p("AhZBWQgmgjAAgzIAAAAQAAgyAmgjIAAAAQAlgkA0AAIAAAAQA1AAAlAkIAAAAQAmAjAAAyIAAAAQAAAzgmAjIAAAAQglAkg1AAIAAAAQg0AAglgkg");
	var mask_24_graphics_103 = new cjs.Graphics().p("AhiBfQgpgoAAg3IAAAAQAAg2ApgoIAAAAQApgnA5AAIAAAAQA6AAApAnIAAAAQApAoAAA2IAAAAQAAA3gpAoIAAAAQgpAng6AAIAAAAQg5AAgpgng");
	var mask_24_graphics_104 = new cjs.Graphics().p("AhrBoQgtgrAAg9IAAAAQAAg8AtgrIAAAAQAtgqA+AAIAAAAQA/AAAtAqIAAAAQAtArAAA8IAAAAQAAA9gtArIAAAAQgtAqg/AAIAAAAQg+AAgtgqg");
	var mask_24_graphics_105 = new cjs.Graphics().p("Ah1BxQgxgvAAhCIAAAAQAAhBAxgvIAAAAQAxgvBEAAIAAAAQBFAAAxAvIAAAAQAxAvAABBIAAAAQAABCgxAvIAAAAQgxAvhFAAIAAAAQhEAAgxgvg");
	var mask_24_graphics_106 = new cjs.Graphics().p("AiAB8Qg2g0AAhIIAAAAQAAhHA2g0IAAAAQA1gzBLAAIAAAAQBMAAA1AzIAAAAQA2A0AABHIAAAAQAABIg2A0IAAAAQg1AzhMAAIAAAAQhLAAg1gzg");
	var mask_24_graphics_107 = new cjs.Graphics().p("AiMCHQg6g4AAhPIAAAAQAAhOA6g4IAAAAQA7g4BRAAIAAAAQBSAAA7A4IAAAAQA6A4AABOIAAAAQAABPg6A4IAAAAQg7A4hSAAIAAAAQhRAAg7g4g");
	var mask_24_graphics_108 = new cjs.Graphics().p("AiYCTQhAg9AAhWIAAAAQAAhVBAg9IAAAAQA/g9BZAAIAAAAQBaAAA/A9IAAAAQBAA9AABVIAAAAQAABWhAA9IAAAAQg/A9haAAIAAAAQhZAAg/g9g");
	var mask_24_graphics_109 = new cjs.Graphics().p("AimCgQhFhCAAheIAAAAQAAhdBFhCIAAAAQBFhCBhAAIAAAAQBiAABFBCIAAAAQBFBCAABdIAAAAQAABehFBCIAAAAQhFBChiAAIAAAAQhhAAhFhCg");
	var mask_24_graphics_110 = new cjs.Graphics().p("Ai0CtQhLhHAAhmIAAAAQAAhlBLhHIAAAAQBLhIBpAAIAAAAQBqAABLBIIAAAAQBLBHAABlIAAAAQAABmhLBHIAAAAQhLBIhqAAIAAAAQhpAAhLhIg");
	var mask_24_graphics_111 = new cjs.Graphics().p("AjDC8QhRhOAAhuIAAAAQAAhtBRhOIAAAAQBRhOByAAIAAAAQBzAABRBOIAAAAQBRBOAABtIAAAAQAABuhRBOIAAAAQhRBOhzAAIAAAAQhyAAhRhOg");
	var mask_24_graphics_112 = new cjs.Graphics().p("AjTDLQhYhUAAh3IAAAAQAAh2BYhUIAAAAQBYhUB7AAIAAAAQB8AABYBUIAAAAQBYBUAAB2IAAAAQAAB3hYBUIAAAAQhYBUh8AAIAAAAQh7AAhYhUg");
	var mask_24_graphics_113 = new cjs.Graphics().p("AjkDbQhfhaAAiBIAAAAQAAiABfhaIAAAAQBfhbCFAAIAAAAQCGAABfBbIAAAAQBfBaAACAIAAAAQAACBhfBaIAAAAQhfBbiGAAIAAAAQiFAAhfhbg");
	var mask_24_graphics_114 = new cjs.Graphics().p("Aj2DsQhmhhAAiLIAAAAQAAiKBmhiIAAAAQBmhhCQAAIAAAAQCRAABmBhIAAAAQBmBiAACKIAAAAQAACLhmBhIAAAAQhmBiiRAAIAAAAQiQAAhmhig");
	var mask_24_graphics_115 = new cjs.Graphics().p("AkJD+QhuhpAAiVIAAAAQAAiUBuhpIAAAAQBuhqCbAAIAAAAQCcAABtBqIAAAAQBvBpAACUIAAAAQAACVhvBpIAAAAQhtBqicAAIAAAAQibAAhuhqg");
	var mask_24_graphics_116 = new cjs.Graphics().p("AkcERQh2hxAAigIAAAAQAAifB2hxIAAAAQB2hxCmAAIAAAAQCnAAB2BxIAAAAQB2BxAACfIAAAAQAACgh2BxIAAAAQh2BxinAAIAAAAQimAAh2hxg");
	var mask_24_graphics_117 = new cjs.Graphics().p("AkxElQh+h5AAisIAAAAQAAirB+h5IAAAAQB/h5CyAAIAAAAQCzAAB/B5IAAAAQB+B5AACrIAAAAQAACsh+B5IAAAAQh/B5izAAIAAAAQiyAAh/h5g");
	var mask_24_graphics_118 = new cjs.Graphics().p("AlGE5QiIiBAAi4IAAAAQAAi3CIiCIAAAAQCHiBC/AAIAAAAQDAAACHCBIAAAAQCICCAAC3IAAAAQAAC4iICBIAAAAQiHCCjAAAIAAAAQi/AAiHiCg");
	var mask_24_graphics_119 = new cjs.Graphics().p("AldFPQiQiLAAjEIAAAAQAAjDCQiLIAAAAQCRiLDMAAIAAAAQDNAACQCLIAAAAQCRCLAADDIAAAAQAADEiRCLIAAAAQiQCLjNAAIAAAAQjMAAiRiLg");
	var mask_24_graphics_120 = new cjs.Graphics().p("Al0FlQiaiUAAjRIAAAAQAAjQCaiUIAAAAQCbiUDZAAIAAAAQDaAACbCUIAAAAQCaCUAADQIAAAAQAADRiaCUIAAAAQibCUjaAAIAAAAQjZAAibiUg");
	var mask_24_graphics_121 = new cjs.Graphics().p("AmMF8QikidAAjfIAAAAQAAjeCkidIAAAAQClieDnAAIAAAAQDoAAClCeIAAAAQCkCdAADeIAAAAQAADfikCdIAAAAQilCejoAAIAAAAQjnAAilieg");
	var mask_24_graphics_122 = new cjs.Graphics().p("AmlGUQiuingBjtIAAAAQABjsCuinIAAAAQCvioD2AAIAAAAQD3AACvCoIAAAAQCvCnAADsIAAAAQAADtivCnIAAAAQivCoj3AAIAAAAQj2AAiviog");
	var mask_24_graphics_123 = new cjs.Graphics().p("Am/GtQi5iyAAj7IAAAAQAAj6C5iyIAAAAQC6iyEFAAIAAAAQEGAAC5CyIAAAAQC6CyAAD6IAAAAQAAD7i6CyIAAAAQi5CykGAAIAAAAQkFAAi6iyg");
	var mask_24_graphics_124 = new cjs.Graphics().p("AnZHGQjFi8AAkKIAAAAQAAkJDFi8IAAAAQDEi9EVAAIAAAAQEWAADEC9IAAAAQDFC8AAEJIAAAAQAAEKjFC8IAAAAQjEC9kWAAIAAAAQkVAAjEi9g");
	var mask_24_graphics_125 = new cjs.Graphics().p("An1HgQjPjHAAkZIAAAAQAAkYDPjIIAAAAQDQjHElAAIAAAAQEmAADPDHIAAAAQDQDIAAEYIAAAAQAAEZjQDHIAAAAQjPDIkmAAIAAAAQklAAjQjIg");
	var mask_24_graphics_126 = new cjs.Graphics().p("AoRH7QjbjSAAkpIAAAAQAAkoDbjTIAAAAQDcjSE1AAIAAAAQE2AADbDSIAAAAQDcDTAAEoIAAAAQAAEpjcDSIAAAAQjbDTk2AAIAAAAQk1AAjcjTg");
	var mask_24_graphics_127 = new cjs.Graphics().p("AotIXQjnjeAAk5IAAAAQAAk4DnjeIAAAAQDnjdFGAAIAAAAQFHAADnDdIAAAAQDnDeAAE4IAAAAQAAE5jnDeIAAAAQjnDdlHAAIAAAAQlGAAjnjdg");
	var mask_24_graphics_128 = new cjs.Graphics().p("ApLIzQjzjpAAlKIAAAAQAAlJDzjpIAAAAQD0jpFXAAIAAAAQFYAADzDpIAAAAQD0DpAAFJIAAAAQAAFKj0DpIAAAAQjzDplYAAIAAAAQlXAAj0jpg");
	var mask_24_graphics_129 = new cjs.Graphics().p("AppJPQj/j0AAlbIAAAAQAAlaD/j1IAAAAQEAj1FpAAIAAAAQFqAAD/D1IAAAAQEAD1AAFaIAAAAQAAFbkAD0IAAAAQj/D2lqAAIAAAAQlpAAkAj2g");
	var mask_24_graphics_130 = new cjs.Graphics().p("AqHJtQkMkBAAlsIAAAAQAAlrEMkBIAAAAQENkBF6AAIAAAAQF7AAENEBIAAAAQEMEBAAFrIAAAAQAAFskMEBIAAAAQkNEBl7AAIAAAAQl6AAkNkBg");
	var mask_24_graphics_131 = new cjs.Graphics().p("AqmKKQkZkNAAl9IAAAAQAAl8EZkNIAAAAQEakOGMAAIAAAAQGNAAEZEOIAAAAQEaENAAF8IAAAAQAAF9kaENIAAAAQkZEOmNAAIAAAAQmMAAkakOg");
	var mask_24_graphics_132 = new cjs.Graphics().p("ArFKoQkmkaAAmOIAAAAQAAmNEmkaIAAAAQEmkaGfAAIAAAAQGgAAElEaIAAAAQEnEaAAGNIAAAAQAAGOknEaIAAAAQklEamgAAIAAAAQmfAAkmkag");
	var mask_24_graphics_133 = new cjs.Graphics().p("ArkLGQkzkmAAmgIAAAAQAAmfEzkmIAAAAQEzkmGxAAIAAAAQGyAAEzEmIAAAAQEzEmAAGfIAAAAQAAGgkzEmIAAAAQkzEmmyAAIAAAAQmxAAkzkmg");
	var mask_24_graphics_134 = new cjs.Graphics().p("AsELkQlAkyAAmyIAAAAQAAmxFAkyIAAAAQFAkzHEAAIAAAAQHFAAE/EzIAAAAQFBEyAAGxIAAAAQAAGylBEyIAAAAQk/EznFAAIAAAAQnEAAlAkzg");
	var mask_24_graphics_135 = new cjs.Graphics().p("AsjMCQlNk/AAnDIAAAAQAAnCFNlAIAAAAQFNk/HWAAIAAAAQHXAAFNE/IAAAAQFNFAAAHCIAAAAQAAHDlNE/IAAAAQlNFAnXAAIAAAAQnWAAlNlAg");
	var mask_24_graphics_136 = new cjs.Graphics().p("AtDMhQlalMAAnVIAAAAQAAnUFalMIAAAAQFalMHpAAIAAAAQHqAAFaFMIAAAAQFaFMAAHUIAAAAQAAHVlaFMIAAAAQlaFMnqAAIAAAAQnpAAlalMg");
	var mask_24_graphics_137 = new cjs.Graphics().p("AtjM/QlnlYAAnnIAAAAQAAnmFnlYIAAAAQFolZH7AAIAAAAQH8AAFnFZIAAAAQFoFYAAHmIAAAAQAAHnloFYIAAAAQlnFZn8AAIAAAAQn7AAlolZg");
	var mask_24_graphics_138 = new cjs.Graphics().p("AuCNdQl0lkAAn5IAAAAQAAn4F0llIAAAAQF0lkIOAAIAAAAQIPAAF0FkIAAAAQF0FlAAH4IAAAAQAAH5l0FkIAAAAQl0FloPAAIAAAAQoOAAl0llg");
	var mask_24_graphics_139 = new cjs.Graphics().p("AuhN7QmClxAAoKIAAAAQAAoJGClxIAAAAQGBlyIgAAIAAAAQIhAAGBFyIAAAAQGCFxAAIJIAAAAQAAIKmCFxIAAAAQmBFyohAAIAAAAQogAAmBlyg");
	var mask_24_graphics_140 = new cjs.Graphics().p("AvAOZQmOl+AAobIAAAAQAAoaGOl+IAAAAQGOl9IyAAIAAAAQIzAAGOF9IAAAAQGOF+AAIaIAAAAQAAIbmOF+IAAAAQmOF9ozAAIAAAAQoyAAmOl9g");
	var mask_24_graphics_141 = new cjs.Graphics().p("AvfO2QmamJAAotIAAAAQAAosGamJIAAAAQGbmKJEAAIAAAAQJFAAGaGKIAAAAQGbGJAAIsIAAAAQAAItmbGJIAAAAQmaGKpFAAIAAAAQpEAAmbmKg");
	var mask_24_graphics_142 = new cjs.Graphics().p("Av9PTQmnmWAAo9IAAAAQAAo8GnmWIAAAAQGomWJVAAIAAAAQJWAAGnGWIAAAAQGoGWAAI8IAAAAQAAI9moGWIAAAAQmnGWpWAAIAAAAQpVAAmomWg");
	var mask_24_graphics_143 = new cjs.Graphics().p("AwbPvQmzmhAApOIAAAAQAApNGzmiIAAAAQG0mhJnAAIAAAAQJoAAGzGhIAAAAQG0GiAAJNIAAAAQAAJOm0GhIAAAAQmzGipoAAIAAAAQpnAAm0mig");
	var mask_24_graphics_144 = new cjs.Graphics().p("Aw4QLQm/mtAApeIAAAAQAApdG/mtIAAAAQHAmtJ4AAIAAAAQJ5AAG/GtIAAAAQHAGtAAJdIAAAAQAAJenAGtIAAAAQm/Gtp5AAIAAAAQp4AAnAmtg");
	var mask_24_graphics_145 = new cjs.Graphics().p("AxUQmQnLm4AApuIAAAAQAAptHLm5IAAAAQHMm4KIAAIAAAAQKJAAHLG4IAAAAQHMG5AAJtIAAAAQAAJunMG4IAAAAQnLG5qJAAIAAAAQqIAAnMm5g");
	var mask_24_graphics_146 = new cjs.Graphics().p("AxwRBQnWnDAAp+IAAAAQAAp9HWnDIAAAAQHXnDKZAAIAAAAQKaAAHWHDIAAAAQHXHDAAJ9IAAAAQAAJ+nXHDIAAAAQnWHDqaAAIAAAAQqZAAnXnDg");
	var mask_24_graphics_147 = new cjs.Graphics().p("AyLRbQninOAAqNIAAAAQAAqMHinOIAAAAQHinOKpAAIAAAAQKqAAHhHOIAAAAQHjHOAAKMIAAAAQAAKNnjHOIAAAAQnhHOqqAAIAAAAQqpAAninOg");
	var mask_24_graphics_148 = new cjs.Graphics().p("AylR0QntnYAAqcIAAAAQAAqbHtnYIAAAAQHtnYK4AAIAAAAQK5AAHtHYIAAAAQHtHYAAKbIAAAAQAAKcntHYIAAAAQntHYq5AAIAAAAQq4AAntnYg");
	var mask_24_graphics_149 = new cjs.Graphics().p("Ay/SMQn3niAAqqIAAAAQAAqpH3njIAAAAQH4niLHAAIAAAAQLIAAH3HiIAAAAQH4HjAAKpIAAAAQAAKqn4HiIAAAAQn3HjrIAAIAAAAQrHAAn4njg");
	var mask_24_graphics_150 = new cjs.Graphics().p("AzYSkQoBnsAAq4IAAAAQAAq3IBntIAAAAQIDnsLVAAIAAAAQLWAAICHsIAAAAQICHtAAK3IAAAAQAAK4oCHsIAAAAQoCHtrWAAIAAAAQrVAAoDntg");
	var mask_24_graphics_151 = new cjs.Graphics().p("AzwS7QoLn1AArGIAAAAQAArFILn2IAAAAQINn1LjAAIAAAAQLkAAIMH1IAAAAQIMH2AALFIAAAAQAALGoMH1IAAAAQoMH2rkAAIAAAAQrjAAoNn2g");
	var mask_24_graphics_152 = new cjs.Graphics().p("A0HTRQoVn+AArTIAAAAQAArSIVn/IAAAAQIWn/LxAAIAAAAQLyAAIVH/IAAAAQIWH/AALSIAAAAQAALToWH+IAAAAQoVIAryAAIAAAAQrxAAoWoAg");
	var mask_24_graphics_153 = new cjs.Graphics().p("A0dTnQoeoIAArfIAAAAQAAreIeoIIAAAAQIfoIL+AAIAAAAQL/AAIeIIIAAAAQIfIIAALeIAAAAQAALfofIIIAAAAQoeIIr/AAIAAAAQr+AAofoIg");
	var mask_24_graphics_154 = new cjs.Graphics().p("A0yT7QoooQAArrIAAAAQAArqIooRIAAAAQInoQMLAAIAAAAQMMAAInIQIAAAAQIoIRAALqIAAAAQAALrooIQIAAAAQonIRsMAAIAAAAQsLAAonoRg");
	var mask_24_graphics_155 = new cjs.Graphics().p("A1HUPQowoYAAr3IAAAAQAAr2IwoZIAAAAQIwoYMXAAIAAAAQMYAAIvIYIAAAAQIxIZAAL2IAAAAQAAL3oxIYIAAAAQovIZsYAAIAAAAQsXAAowoZg");
	var mask_24_graphics_156 = new cjs.Graphics().p("A1bUiQo4ogAAsCIAAAAQAAsBI4ogIAAAAQI5ohMiAAIAAAAQMjAAI4IhIAAAAQI5IgAAMBIAAAAQAAMCo5IgIAAAAQo4IhsjAAIAAAAQsiAAo5ohg");
	var mask_24_graphics_157 = new cjs.Graphics().p("A1uU0Qo/ooAAsMIAAAAQAAsLI/opIAAAAQJBonMtAAIAAAAQMuAAJAInIAAAAQJAIpAAMLIAAAAQAAMMpAIoIAAAAQpAIosuAAIAAAAQstAApBoog");
	var mask_24_graphics_158 = new cjs.Graphics().p("A2AVFQpHouAAsXIAAAAQAAsWJHovIAAAAQJIovM4AAIAAAAQM5AAJHIvIAAAAQJIIvAAMWIAAAAQAAMXpIIuIAAAAQpHIws5AAIAAAAQs4AApIowg");
	var mask_24_graphics_159 = new cjs.Graphics().p("A2RVWQpPo2AAsgIAAAAQAAsfJPo3IAAAAQJPo1NCAAIAAAAQNDAAJOI1IAAAAQJQI3AAMfIAAAAQAAMgpQI2IAAAAQpOI2tDAAIAAAAQtCAApPo2g");
	var mask_24_graphics_160 = new cjs.Graphics().p("A2iVmQpVo9AAspIAAAAQAAsoJVo9IAAAAQJWo8NMAAIAAAAQNNAAJVI8IAAAAQJWI9AAMoIAAAAQAAMppWI9IAAAAQpVI8tNAAIAAAAQtMAApWo8g");
	var mask_24_graphics_161 = new cjs.Graphics().p("A2xV1QpcpDAAsyIAAAAQAAsxJcpDIAAAAQJcpDNVAAIAAAAQNWAAJcJDIAAAAQJcJDAAMxIAAAAQAAMypcJDIAAAAQpcJDtWAAIAAAAQtVAApcpDg");
	var mask_24_graphics_162 = new cjs.Graphics().p("A3AWDQpipIAAs7IAAAAQAAs6JipJIAAAAQJipINeAAIAAAAQNfAAJhJIIAAAAQJjJJAAM6IAAAAQAAM7pjJIIAAAAQphJJtfAAIAAAAQteAApipJg");
	var mask_24_graphics_163 = new cjs.Graphics().p("A3OWQQpopOAAtCIAAAAQAAtBJopPIAAAAQJopONmAAIAAAAQNnAAJnJOIAAAAQJpJPAANBIAAAAQAANCppJOIAAAAQpnJPtnAAIAAAAQtmAApopPg");
	var mask_24_graphics_164 = new cjs.Graphics().p("A3bWdQpupTAAtKIAAAAQAAtJJupUIAAAAQJtpTNuAAIAAAAQNvAAJtJTIAAAAQJuJUAANJIAAAAQAANKpuJTIAAAAQptJUtvAAIAAAAQtuAAptpUg");
	var mask_24_graphics_165 = new cjs.Graphics().p("A3oWpQpypYAAtRIAAAAQAAtQJypZIAAAAQJzpYN1AAIAAAAQN2AAJyJYIAAAAQJzJZAANQIAAAAQAANRpzJYIAAAAQpyJZt2AAIAAAAQt1AApzpZg");
	var mask_24_graphics_166 = new cjs.Graphics().p("A30W0Qp3pcAAtYIAAAAQAAtXJ3pdIAAAAQJ4pdN8AAIAAAAQN9AAJ3JdIAAAAQJ4JdAANXIAAAAQAANYp4JcIAAAAQp3Jet9AAIAAAAQt8AAp4peg");
	var mask_24_graphics_167 = new cjs.Graphics().p("A3/W/Qp7phAAteIAAAAQAAtdJ7piIAAAAQJ9phOCAAIAAAAQODAAJ8JhIAAAAQJ8JiAANdIAAAAQAANep8JhIAAAAQp8JiuDAAIAAAAQuCAAp9pig");
	var mask_24_graphics_168 = new cjs.Graphics().p("A4JXJQqAplAAtkIAAAAQAAtjKAplIAAAAQKBpmOIAAIAAAAQOJAAKAJmIAAAAQKBJlAANjIAAAAQAANkqBJlIAAAAQqAJmuJAAIAAAAQuIAAqBpmg");
	var mask_24_graphics_169 = new cjs.Graphics().p("A4TXSQqEppAAtpIAAAAQAAtoKEpqIAAAAQKFppOOAAIAAAAQOPAAKEJpIAAAAQKFJqAANoIAAAAQAANpqFJpIAAAAQqEJquPAAIAAAAQuOAAqFpqg");
	var mask_24_graphics_170 = new cjs.Graphics().p("A4cXbQqHptAAtuIAAAAQAAttKHptIAAAAQKJptOTAAIAAAAQOUAAKIJtIAAAAQKIJtAANtIAAAAQAANuqIJtIAAAAQqIJtuUAAIAAAAQuTAAqJptg");
	var mask_24_graphics_171 = new cjs.Graphics().p("A4kXiQqLpvAAtzIAAAAQAAtyKLpwIAAAAQKMpwOYAAIAAAAQOZAAKLJwIAAAAQKMJwAANyIAAAAQAANzqMJvIAAAAQqLJxuZAAIAAAAQuYAAqMpxg");
	var mask_24_graphics_172 = new cjs.Graphics().p("A4sXqQqOpzAAt3IAAAAQAAt2KOpzIAAAAQKPpzOdAAIAAAAQOeAAKOJzIAAAAQKPJzAAN2IAAAAQAAN3qPJzIAAAAQqOJzueAAIAAAAQudAAqPpzg");
	var mask_24_graphics_173 = new cjs.Graphics().p("A4zXwQqRp1AAt7IAAAAQAAt6KRp2IAAAAQKSp2OhAAIAAAAQOiAAKRJ2IAAAAQKSJ2AAN6IAAAAQAAN7qSJ1IAAAAQqRJ3uiAAIAAAAQuhAAqSp3g");
	var mask_24_graphics_174 = new cjs.Graphics().p("A45X3QqUp5AAt+IAAAAQAAt9KUp5IAAAAQKVp4OkAAIAAAAQOlAAKUJ4IAAAAQKVJ5AAN9IAAAAQAAN+qVJ5IAAAAQqUJ4ulAAIAAAAQukAAqVp4g");
	var mask_24_graphics_175 = new cjs.Graphics().p("A4/X8QqWp6AAuCIAAAAQAAuBKWp7IAAAAQKXp6OoAAIAAAAQOpAAKWJ6IAAAAQKXJ7AAOBIAAAAQAAOCqXJ6IAAAAQqWJ7upAAIAAAAQuoAAqXp7g");
	var mask_24_graphics_176 = new cjs.Graphics().p("A5EYBQqYp9AAuEIAAAAQAAuDKYp+IAAAAQKZp8OrAAIAAAAQOsAAKYJ8IAAAAQKZJ+AAODIAAAAQAAOEqZJ9IAAAAQqYJ9usAAIAAAAQurAAqZp9g");
	var mask_24_graphics_177 = new cjs.Graphics().p("A5IYFQqbp+AAuHIAAAAQAAuGKbp/IAAAAQKbp+OtAAIAAAAQOuAAKbJ+IAAAAQKbJ/AAOGIAAAAQAAOHqbJ+IAAAAQqbJ/uuAAIAAAAQutAAqbp/g");
	var mask_24_graphics_178 = new cjs.Graphics().p("A5MYJQqcqAAAuJIAAAAQAAuIKcqBIAAAAQKcqAOwAAIAAAAQOxAAKcKAIAAAAQKcKBAAOIIAAAAQAAOJqcKAIAAAAQqcKBuxAAIAAAAQuwAAqcqBg");
	var mask_24_graphics_179 = new cjs.Graphics().p("A5QYMQqdqBAAuLIAAAAQAAuKKdqCIAAAAQKeqBOyAAIAAAAQOzAAKdKBIAAAAQKeKCAAOKIAAAAQAAOLqeKBIAAAAQqdKCuzAAIAAAAQuyAAqeqCg");
	var mask_24_graphics_180 = new cjs.Graphics().p("A5TYPQqeqCAAuNIAAAAQAAuMKeqDIAAAAQKgqCOzAAIAAAAQO0AAKfKCIAAAAQKfKDAAOMIAAAAQAAONqfKCIAAAAQqfKDu0AAIAAAAQuzAAqgqDg");
	var mask_24_graphics_181 = new cjs.Graphics().p("A5VYSQqgqEAAuOIAAAAQAAuNKgqEIAAAAQKgqEO1AAIAAAAQO2AAKfKEIAAAAQKhKEAAONIAAAAQAAOOqhKEIAAAAQqfKEu2AAIAAAAQu1AAqgqEg");
	var mask_24_graphics_182 = new cjs.Graphics().p("A5XYTQqgqEAAuPIAAAAQAAuOKgqFIAAAAQKhqEO2AAIAAAAQO3AAKgKEIAAAAQKhKFAAOOIAAAAQAAOPqhKEIAAAAQqgKFu3AAIAAAAQu2AAqhqFg");

	this.timeline.addTween(cjs.Tween.get(mask_24).to({graphics:null,x:0,y:0}).wait(92).to({graphics:mask_24_graphics_92,x:576.8505,y:456.5502}).wait(1).to({graphics:mask_24_graphics_93,x:576.8311,y:456.4759}).wait(1).to({graphics:mask_24_graphics_94,x:576.805,y:456.3774}).wait(1).to({graphics:mask_24_graphics_95,x:576.7726,y:456.2545}).wait(1).to({graphics:mask_24_graphics_96,x:576.7335,y:456.1069}).wait(1).to({graphics:mask_24_graphics_97,x:576.688,y:455.9328}).wait(1).to({graphics:mask_24_graphics_98,x:576.6349,y:455.7325}).wait(1).to({graphics:mask_24_graphics_99,x:576.5755,y:455.5053}).wait(1).to({graphics:mask_24_graphics_100,x:576.5081,y:455.2497}).wait(1).to({graphics:mask_24_graphics_101,x:576.4333,y:454.9657}).wait(1).to({graphics:mask_24_graphics_102,x:576.351,y:454.6525}).wait(1).to({graphics:mask_24_graphics_103,x:576.2605,y:454.3096}).wait(1).to({graphics:mask_24_graphics_104,x:576.162,y:453.9361}).wait(1).to({graphics:mask_24_graphics_105,x:576.0553,y:453.5316}).wait(1).to({graphics:mask_24_graphics_106,x:575.9406,y:453.0942}).wait(1).to({graphics:mask_24_graphics_107,x:575.8168,y:452.6244}).wait(1).to({graphics:mask_24_graphics_108,x:575.6845,y:452.1217}).wait(1).to({graphics:mask_24_graphics_109,x:575.5428,y:451.5853}).wait(1).to({graphics:mask_24_graphics_110,x:575.3929,y:451.0139}).wait(1).to({graphics:mask_24_graphics_111,x:575.2328,y:450.4077}).wait(1).to({graphics:mask_24_graphics_112,x:575.064,y:449.766}).wait(1).to({graphics:mask_24_graphics_113,x:574.8853,y:449.0883}).wait(1).to({graphics:mask_24_graphics_114,x:574.6977,y:448.375}).wait(1).to({graphics:mask_24_graphics_115,x:574.5001,y:447.6249}).wait(1).to({graphics:mask_24_graphics_116,x:574.2931,y:446.8378}).wait(1).to({graphics:mask_24_graphics_117,x:574.0762,y:446.0152}).wait(1).to({graphics:mask_24_graphics_118,x:573.8499,y:445.1553}).wait(1).to({graphics:mask_24_graphics_119,x:573.6141,y:444.2598}).wait(1).to({graphics:mask_24_graphics_120,x:573.3693,y:443.3283}).wait(1).to({graphics:mask_24_graphics_121,x:573.1146,y:442.3622}).wait(1).to({graphics:mask_24_graphics_122,x:572.8509,y:441.3618}).wait(1).to({graphics:mask_24_graphics_123,x:572.5786,y:440.3277}).wait(1).to({graphics:mask_24_graphics_124,x:572.2983,y:439.2625}).wait(1).to({graphics:mask_24_graphics_125,x:572.0094,y:438.1668}).wait(1).to({graphics:mask_24_graphics_126,x:571.7137,y:437.0422}).wait(1).to({graphics:mask_24_graphics_127,x:571.4109,y:435.8911}).wait(1).to({graphics:mask_24_graphics_128,x:571.1008,y:434.7153}).wait(1).to({graphics:mask_24_graphics_129,x:570.7859,y:433.5183}).wait(1).to({graphics:mask_24_graphics_130,x:570.465,y:432.3006}).wait(1).to({graphics:mask_24_graphics_131,x:570.1401,y:431.0676}).wait(1).to({graphics:mask_24_graphics_132,x:569.8121,y:429.8202}).wait(1).to({graphics:mask_24_graphics_133,x:569.4808,y:428.5629}).wait(1).to({graphics:mask_24_graphics_134,x:569.1474,y:427.2984}).wait(1).to({graphics:mask_24_graphics_135,x:568.8135,y:426.0294}).wait(1).to({graphics:mask_24_graphics_136,x:568.4791,y:424.7599}).wait(1).to({graphics:mask_24_graphics_137,x:568.1461,y:423.4932}).wait(1).to({graphics:mask_24_graphics_138,x:567.8136,y:422.2332}).wait(1).to({graphics:mask_24_graphics_139,x:567.4842,y:420.9813}).wait(1).to({graphics:mask_24_graphics_140,x:567.1579,y:419.742}).wait(1).to({graphics:mask_24_graphics_141,x:566.8357,y:418.5175}).wait(1).to({graphics:mask_24_graphics_142,x:566.518,y:417.3111}).wait(1).to({graphics:mask_24_graphics_143,x:566.2053,y:416.1249}).wait(1).to({graphics:mask_24_graphics_144,x:565.8988,y:414.9607}).wait(1).to({graphics:mask_24_graphics_145,x:565.5992,y:413.8214}).wait(1).to({graphics:mask_24_graphics_146,x:565.3057,y:412.709}).wait(1).to({graphics:mask_24_graphics_147,x:565.0204,y:411.6245}).wait(1).to({graphics:mask_24_graphics_148,x:564.7423,y:410.5687}).wait(1).to({graphics:mask_24_graphics_149,x:564.4728,y:409.5445}).wait(1).to({graphics:mask_24_graphics_150,x:564.2113,y:408.5509}).wait(1).to({graphics:mask_24_graphics_151,x:563.9585,y:407.5906}).wait(1).to({graphics:mask_24_graphics_152,x:563.7136,y:406.6628}).wait(1).to({graphics:mask_24_graphics_153,x:563.4783,y:405.769}).wait(1).to({graphics:mask_24_graphics_154,x:563.252,y:404.9082}).wait(1).to({graphics:mask_24_graphics_155,x:563.0341,y:404.0811}).wait(1).to({graphics:mask_24_graphics_156,x:562.8253,y:403.2886}).wait(1).to({graphics:mask_24_graphics_157,x:562.6251,y:402.5295}).wait(1).to({graphics:mask_24_graphics_158,x:562.4348,y:401.8036}).wait(1).to({graphics:mask_24_graphics_159,x:562.252,y:401.1111}).wait(1).to({graphics:mask_24_graphics_160,x:562.0783,y:400.4518}).wait(1).to({graphics:mask_24_graphics_161,x:561.9132,y:399.825}).wait(1).to({graphics:mask_24_graphics_162,x:561.7566,y:399.2301}).wait(1).to({graphics:mask_24_graphics_163,x:561.6081,y:398.6667}).wait(1).to({graphics:mask_24_graphics_164,x:561.4681,y:398.1348}).wait(1).to({graphics:mask_24_graphics_165,x:561.3358,y:397.6326}).wait(1).to({graphics:mask_24_graphics_166,x:561.2116,y:397.161}).wait(1).to({graphics:mask_24_graphics_167,x:561.0956,y:396.7182}).wait(1).to({graphics:mask_24_graphics_168,x:560.9862,y:396.3046}).wait(1).to({graphics:mask_24_graphics_169,x:560.8849,y:395.9185}).wait(1).to({graphics:mask_24_graphics_170,x:560.79,y:395.5603}).wait(1).to({graphics:mask_24_graphics_171,x:560.7031,y:395.2287}).wait(1).to({graphics:mask_24_graphics_172,x:560.6226,y:394.9231}).wait(1).to({graphics:mask_24_graphics_173,x:560.5492,y:394.6437}).wait(1).to({graphics:mask_24_graphics_174,x:560.4822,y:394.389}).wait(1).to({graphics:mask_24_graphics_175,x:560.4214,y:394.1586}).wait(1).to({graphics:mask_24_graphics_176,x:560.367,y:393.952}).wait(1).to({graphics:mask_24_graphics_177,x:560.3188,y:393.7693}).wait(1).to({graphics:mask_24_graphics_178,x:560.2766,y:393.6087}).wait(1).to({graphics:mask_24_graphics_179,x:560.2401,y:393.471}).wait(1).to({graphics:mask_24_graphics_180,x:560.2095,y:393.354}).wait(1).to({graphics:mask_24_graphics_181,x:560.1838,y:393.2586}).wait(1).to({graphics:mask_24_graphics_182,x:559.8725,y:394.8619}).wait(628));

	// Layer_10
	this.instance_42 = new lib.Tween27("synched",0);
	this.instance_42.setTransform(571.8,406.5);
	this.instance_42.alpha = 0.5;
	this.instance_42._off = true;

	var maskedShapeInstanceList = [this.instance_42];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_24;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_42).wait(92).to({_off:false},0).to({alpha:1},90).wait(628));

	// Layer_8
	this.instance_43 = new lib.Tween18("synched",2);
	this.instance_43.setTransform(399.65,661,0.7016,0.7011,0,0,0,472,518.1);
	this.instance_43._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_43).wait(152).to({_off:false},0).wait(658));

	// Layer_6 (mask)
	var mask_25 = new cjs.Shape();
	mask_25._off = true;
	var mask_25_graphics_119 = new cjs.Graphics().p("AgbAbQgMgLAAgQIAAAAQAAgPAMgLIAAAAQALgLAQAAIAAAAQARAAALALIAAAAQAMALAAAPIAAAAQAAAQgMALIAAAAQgLALgRAAIAAAAQgQAAgLgLg");
	var mask_25_graphics_120 = new cjs.Graphics().p("AgbAbQgMgLAAgQIAAAAQAAgPAMgLIAAAAQALgMAQAAIAAAAQARAAALAMIAAAAQAMALAAAPIAAAAQAAAQgMALIAAAAQgLAMgRAAIAAAAQgQAAgLgMg");
	var mask_25_graphics_121 = new cjs.Graphics().p("AgcAcQgMgMAAgQIAAAAQAAgPAMgMIAAAAQAMgLAQAAIAAAAQARAAAMALIAAAAQAMAMAAAPIAAAAQAAAQgMAMIAAAAQgMALgRAAIAAAAQgQAAgMgLg");
	var mask_25_graphics_122 = new cjs.Graphics().p("AgdAcQgMgLAAgRIAAAAQAAgQAMgLIAAAAQANgMAQAAIAAAAQARAAANAMIAAAAQAMALAAAQIAAAAQAAARgMALIAAAAQgNAMgRAAIAAAAQgQAAgNgMg");
	var mask_25_graphics_123 = new cjs.Graphics().p("AgeAdQgMgMAAgRIAAAAQAAgQAMgMIAAAAQANgNARAAIAAAAQASAAANANIAAAAQAMAMAAAQIAAAAQAAARgMAMIAAAAQgNANgSAAIAAAAQgRAAgNgNg");
	var mask_25_graphics_124 = new cjs.Graphics().p("AgfAfQgNgNAAgSIAAAAQAAgRANgNIAAAAQANgMASAAIAAAAQATAAANAMIAAAAQANANAAARIAAAAQAAASgNANIAAAAQgNAMgTAAIAAAAQgSAAgNgMg");
	var mask_25_graphics_125 = new cjs.Graphics().p("AghAgQgNgNAAgTIAAAAQAAgSANgNIAAAAQAOgNATAAIAAAAQAUAAAOANIAAAAQANANAAASIAAAAQAAATgNANIAAAAQgOANgUAAIAAAAQgTAAgOgNg");
	var mask_25_graphics_126 = new cjs.Graphics().p("AgiAiQgPgOAAgUIAAAAQAAgTAPgOIAAAAQAOgOAUAAIAAAAQAVAAAOAOIAAAAQAPAOAAATIAAAAQAAAUgPAOIAAAAQgOAOgVAAIAAAAQgUAAgOgOg");
	var mask_25_graphics_127 = new cjs.Graphics().p("AglAkQgPgPAAgVIAAAAQAAgUAPgPIAAAAQAQgPAVAAIAAAAQAWAAAQAPIAAAAQAPAPAAAUIAAAAQAAAVgPAPIAAAAQgQAPgWAAIAAAAQgVAAgQgPg");
	var mask_25_graphics_128 = new cjs.Graphics().p("AgnAmQgRgPAAgXIAAAAQAAgWARgPIAAAAQAQgQAXAAIAAAAQAYAAAQAQIAAAAQARAPAAAWIAAAAQAAAXgRAPIAAAAQgQAQgYAAIAAAAQgXAAgQgQg");
	var mask_25_graphics_129 = new cjs.Graphics().p("AgqApQgSgRAAgYIAAAAQAAgXASgRIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQASARAAAXIAAAAQAAAYgSARIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_25_graphics_130 = new cjs.Graphics().p("AgtAsQgTgSAAgaIAAAAQAAgZATgSIAAAAQATgSAaAAIAAAAQAbAAATASIAAAAQATASAAAZIAAAAQAAAagTASIAAAAQgTASgbAAIAAAAQgaAAgTgSg");
	var mask_25_graphics_131 = new cjs.Graphics().p("AgwAvQgVgTAAgcIAAAAQAAgbAVgTIAAAAQAUgUAcAAIAAAAQAdAAAUAUIAAAAQAVATAAAbIAAAAQAAAcgVATIAAAAQgUAUgdAAIAAAAQgcAAgUgUg");
	var mask_25_graphics_132 = new cjs.Graphics().p("Ag0AzQgWgVAAgeIAAAAQAAgdAWgVIAAAAQAWgVAeAAIAAAAQAfAAAWAVIAAAAQAWAVAAAdIAAAAQAAAegWAVIAAAAQgWAVgfAAIAAAAQgeAAgWgVg");
	var mask_25_graphics_133 = new cjs.Graphics().p("Ag4A3QgYgXAAggIAAAAQAAgfAYgXIAAAAQAYgWAgAAIAAAAQAhAAAYAWIAAAAQAYAXAAAfIAAAAQAAAggYAXIAAAAQgYAWghAAIAAAAQggAAgYgWg");
	var mask_25_graphics_134 = new cjs.Graphics().p("Ag8A7QgagZAAgiIAAAAQAAghAagZIAAAAQAZgYAjAAIAAAAQAkAAAZAYIAAAAQAaAZAAAhIAAAAQAAAigaAZIAAAAQgZAYgkAAIAAAAQgjAAgZgYg");
	var mask_25_graphics_135 = new cjs.Graphics().p("AhBA/QgbgaAAglIAAAAQAAgkAbgaIAAAAQAbgaAmAAIAAAAQAnAAAbAaIAAAAQAbAaAAAkIAAAAQAAAlgbAaIAAAAQgbAagnAAIAAAAQgmAAgbgag");
	var mask_25_graphics_136 = new cjs.Graphics().p("AhGBEQgdgcAAgoIAAAAQAAgnAdgcIAAAAQAegcAoAAIAAAAQApAAAeAcIAAAAQAdAcAAAnIAAAAQAAAogdAcIAAAAQgeAcgpAAIAAAAQgoAAgegcg");
	var mask_25_graphics_137 = new cjs.Graphics().p("AhLBJQgfgfAAgqIAAAAQAAgpAfgfIAAAAQAggeArAAIAAAAQAsAAAgAeIAAAAQAfAfAAApIAAAAQAAAqgfAfIAAAAQggAegsAAIAAAAQgrAAgggeg");
	var mask_25_graphics_138 = new cjs.Graphics().p("AhQBOQgiggAAguIAAAAQAAgtAiggIAAAAQAhggAvAAIAAAAQAwAAAhAgIAAAAQAiAgAAAtIAAAAQAAAugiAgIAAAAQghAggwAAIAAAAQgvAAghggg");
	var mask_25_graphics_139 = new cjs.Graphics().p("AhWBTQgkgiAAgxIAAAAQAAgwAkgiIAAAAQAkgjAyAAIAAAAQAzAAAkAjIAAAAQAkAiAAAwIAAAAQAAAxgkAiIAAAAQgkAjgzAAIAAAAQgyAAgkgjg");
	var mask_25_graphics_140 = new cjs.Graphics().p("AhcBZQgmglAAg0IAAAAQAAgzAmglIAAAAQAnglA1AAIAAAAQA2AAAnAlIAAAAQAmAlAAAzIAAAAQAAA0gmAlIAAAAQgnAlg2AAIAAAAQg1AAgnglg");
	var mask_25_graphics_141 = new cjs.Graphics().p("AhiBfQgpgnAAg4IAAAAQAAg3ApgnIAAAAQApgnA5AAIAAAAQA6AAApAnIAAAAQApAnAAA3IAAAAQAAA4gpAnIAAAAQgpAng6AAIAAAAQg5AAgpgng");
	var mask_25_graphics_142 = new cjs.Graphics().p("AhpBlQgrgqAAg7IAAAAQAAg6ArgqIAAAAQAsgqA9AAIAAAAQA+AAAsAqIAAAAQArAqAAA6IAAAAQAAA7grAqIAAAAQgsAqg+AAIAAAAQg9AAgsgqg");
	var mask_25_graphics_143 = new cjs.Graphics().p("AhwBsQgugtAAg/IAAAAQAAg+AugtIAAAAQAvgtBBAAIAAAAQBCAAAvAtIAAAAQAuAtAAA+IAAAAQAAA/guAtIAAAAQgvAthCAAIAAAAQhBAAgvgtg");
	var mask_25_graphics_144 = new cjs.Graphics().p("Ah3BzQgxgwAAhDIAAAAQAAhCAxgwIAAAAQAygvBFAAIAAAAQBGAAAyAvIAAAAQAxAwAABCIAAAAQAABDgxAwIAAAAQgyAvhGAAIAAAAQhFAAgygvg");
	var mask_25_graphics_145 = new cjs.Graphics().p("Ah+B6Qg1gzAAhHIAAAAQAAhGA1gzIAAAAQA1gyBJAAIAAAAQBKAAA1AyIAAAAQA1AzAABGIAAAAQAABHg1AzIAAAAQg1AyhKAAIAAAAQhJAAg1gyg");
	var mask_25_graphics_146 = new cjs.Graphics().p("AiGCBQg4g1AAhMIAAAAQAAhLA4g1IAAAAQA4g2BOAAIAAAAQBPAAA4A2IAAAAQA4A1AABLIAAAAQAABMg4A1IAAAAQg4A2hPAAIAAAAQhOAAg4g2g");
	var mask_25_graphics_147 = new cjs.Graphics().p("AiOCJQg7g5AAhQIAAAAQAAhPA7g5IAAAAQA7g5BTAAIAAAAQBUAAA7A5IAAAAQA7A5AABPIAAAAQAABQg7A5IAAAAQg7A5hUAAIAAAAQhTAAg7g5g");
	var mask_25_graphics_148 = new cjs.Graphics().p("AiWCRQg/g8AAhVIAAAAQAAhUA/g8IAAAAQA+g8BYAAIAAAAQBZAAA+A8IAAAAQA/A8AABUIAAAAQAABVg/A8IAAAAQg+A8hZAAIAAAAQhYAAg+g8g");
	var mask_25_graphics_149 = new cjs.Graphics().p("AifCZQhCg/AAhaIAAAAQAAhZBCg/IAAAAQBChABdAAIAAAAQBeAABCBAIAAAAQBCA/AABZIAAAAQAABahCA/IAAAAQhCBAheAAIAAAAQhdAAhChAg");
	var mask_25_graphics_150 = new cjs.Graphics().p("AioCiQhGhDAAhfIAAAAQAAheBGhDIAAAAQBGhDBiAAIAAAAQBjAABGBDIAAAAQBGBDAABeIAAAAQAABfhGBDIAAAAQhGBDhjAAIAAAAQhiAAhGhDg");
	var mask_25_graphics_151 = new cjs.Graphics().p("AixCrQhKhHAAhkIAAAAQAAhjBKhHIAAAAQBKhGBnAAIAAAAQBoAABKBGIAAAAQBKBHAABjIAAAAQAABkhKBHIAAAAQhKBGhoAAIAAAAQhnAAhKhGg");
	var mask_25_graphics_152 = new cjs.Graphics().p("Ai7C0QhNhLAAhpIAAAAQAAhoBNhLIAAAAQBOhKBtAAIAAAAQBuAABOBKIAAAAQBNBLAABoIAAAAQAABphNBLIAAAAQhOBKhuAAIAAAAQhtAAhOhKg");
	var mask_25_graphics_153 = new cjs.Graphics().p("AjEC9QhShOAAhvIAAAAQAAhuBShOIAAAAQBRhPBzAAIAAAAQB0AABRBPIAAAAQBSBOAABuIAAAAQAABvhSBOIAAAAQhRBPh0AAIAAAAQhzAAhRhPg");
	var mask_25_graphics_154 = new cjs.Graphics().p("AjPDHQhVhTAAh0IAAAAQAAhzBVhTIAAAAQBWhSB5AAIAAAAQB6AABVBSIAAAAQBWBTAABzIAAAAQAAB0hWBTIAAAAQhVBSh6AAIAAAAQh5AAhWhSg");
	var mask_25_graphics_155 = new cjs.Graphics().p("AjZDRQhahXAAh6IAAAAQAAh5BahXIAAAAQBahWB/AAIAAAAQCAAABaBWIAAAAQBaBXAAB5IAAAAQAAB6haBXIAAAAQhaBWiAAAIAAAAQh/AAhahWg");
	var mask_25_graphics_156 = new cjs.Graphics().p("AjkDbQhehbAAiAIAAAAQAAh/BehbIAAAAQBfhbCFAAIAAAAQCGAABfBbIAAAAQBeBbAAB/IAAAAQAACAheBbIAAAAQhfBbiGAAIAAAAQiFAAhfhbg");
	var mask_25_graphics_157 = new cjs.Graphics().p("AjvDlQhjhfAAiGIAAAAQAAiFBjhgIAAAAQBkhfCLAAIAAAAQCMAABjBfIAAAAQBkBgAACFIAAAAQAACGhkBfIAAAAQhjBgiMAAIAAAAQiLAAhkhgg");
	var mask_25_graphics_158 = new cjs.Graphics().p("Aj6DwQhohjAAiNIAAAAQAAiMBohjIAAAAQBohkCSAAIAAAAQCTAABoBkIAAAAQBoBjAACMIAAAAQAACNhoBjIAAAAQhoBkiTAAIAAAAQiSAAhohkg");
	var mask_25_graphics_159 = new cjs.Graphics().p("AkFD7QhthoAAiTIAAAAQAAiSBthoIAAAAQBshpCZAAIAAAAQCaAABsBpIAAAAQBtBoAACSIAAAAQAACThtBoIAAAAQhsBpiaAAIAAAAQiZAAhshpg");
	var mask_25_graphics_160 = new cjs.Graphics().p("AkREHQhyhtAAiaIAAAAQAAiZByhtIAAAAQBxhtCgAAIAAAAQChAABxBtIAAAAQByBtAACZIAAAAQAACahyBtIAAAAQhxBtihAAIAAAAQigAAhxhtg");
	var mask_25_graphics_161 = new cjs.Graphics().p("AkdESQh3hxAAihIAAAAQAAigB3hxIAAAAQB2hyCnAAIAAAAQCoAAB2ByIAAAAQB3BxAACgIAAAAQAAChh3BxIAAAAQh2ByioAAIAAAAQinAAh2hyg");
	var mask_25_graphics_162 = new cjs.Graphics().p("AkqEeQh8h2AAioIAAAAQAAinB8h2IAAAAQB8h3CuAAIAAAAQCvAAB8B3IAAAAQB8B2AACnIAAAAQAACoh8B2IAAAAQh8B3ivAAIAAAAQiuAAh8h3g");
	var mask_25_graphics_163 = new cjs.Graphics().p("Ak3EqQiBh7AAivIAAAAQAAiuCBh8IAAAAQCCh7C1AAIAAAAQC2AACBB7IAAAAQCCB8AACuIAAAAQAACviCB7IAAAAQiBB8i2AAIAAAAQi1AAiCh8g");
	var mask_25_graphics_164 = new cjs.Graphics().p("AlEE3QiGiBAAi2IAAAAQAAi1CGiBIAAAAQCHiBC9AAIAAAAQC+AACGCBIAAAAQCHCBAAC1IAAAAQAAC2iHCBIAAAAQiGCBi+AAIAAAAQi9AAiHiBg");
	var mask_25_graphics_165 = new cjs.Graphics().p("AlRFEQiMiGAAi+IAAAAQAAi9CMiGIAAAAQCMiGDFAAIAAAAQDGAACMCGIAAAAQCMCGAAC9IAAAAQAAC+iMCGIAAAAQiMCGjGAAIAAAAQjFAAiMiGg");
	var mask_25_graphics_166 = new cjs.Graphics().p("AlfFRQiRiMAAjFIAAAAQAAjECRiMIAAAAQCSiLDNAAIAAAAQDOAACRCLIAAAAQCSCMAADEIAAAAQAADFiSCMIAAAAQiRCLjOAAIAAAAQjNAAiSiLg");
	var mask_25_graphics_167 = new cjs.Graphics().p("AlsFeQiYiRAAjNIAAAAQAAjMCYiRIAAAAQCXiRDVAAIAAAAQDWAACXCRIAAAAQCYCRAADMIAAAAQAADNiYCRIAAAAQiXCRjWAAIAAAAQjVAAiXiRg");
	var mask_25_graphics_168 = new cjs.Graphics().p("Al7FsQidiXAAjVIAAAAQAAjUCdiXIAAAAQCeiWDdAAIAAAAQDeAACdCWIAAAAQCeCXAADUIAAAAQAADVieCXIAAAAQidCWjeAAIAAAAQjdAAieiWg");
	var mask_25_graphics_169 = new cjs.Graphics().p("AmJF5QijicAAjdIAAAAQAAjcCjidIAAAAQCjicDmAAIAAAAQDnAACjCcIAAAAQCjCdAADcIAAAAQAADdijCcIAAAAQijCdjnAAIAAAAQjmAAijidg");
	var mask_25_graphics_170 = new cjs.Graphics().p("AmYGIQipijAAjlIAAAAQAAjkCpijIAAAAQCqiiDuAAIAAAAQDvAACqCiIAAAAQCpCjAADkIAAAAQAADlipCjIAAAAQiqCijvAAIAAAAQjuAAiqiig");
	var mask_25_graphics_171 = new cjs.Graphics().p("AmnGWQivioAAjuIAAAAQAAjtCvioIAAAAQCwioD3AAIAAAAQD4AACvCoIAAAAQCwCoAADtIAAAAQAADuiwCoIAAAAQivCoj4AAIAAAAQj3AAiwiog");
	var mask_25_graphics_172 = new cjs.Graphics().p("Am1GkQi1iuAAj2IAAAAQAAj1C1iuIAAAAQC1iuEAAAIAAAAQEBAAC1CuIAAAAQC1CuAAD1IAAAAQAAD2i1CuIAAAAQi1CukBAAIAAAAQkAAAi1iug");
	var mask_25_graphics_173 = new cjs.Graphics().p("AnDGxQi8izAAj+IAAAAQAAj9C8izIAAAAQC7i0EIAAIAAAAQEJAAC7C0IAAAAQC8CzAAD9IAAAAQAAD+i8CzIAAAAQi7C0kJAAIAAAAQkIAAi7i0g");
	var mask_25_graphics_174 = new cjs.Graphics().p("AnRG/QjBi5AAkGIAAAAQAAkFDBi5IAAAAQDBi5EQAAIAAAAQERAADBC5IAAAAQDBC5AAEFIAAAAQAAEGjBC5IAAAAQjBC5kRAAIAAAAQkQAAjBi5g");
	var mask_25_graphics_175 = new cjs.Graphics().p("AnfHMQjGi/AAkNIAAAAQAAkMDGi/IAAAAQDHi+EYAAIAAAAQEZAADHC+IAAAAQDGC/AAEMIAAAAQAAENjGC/IAAAAQjHC+kZAAIAAAAQkYAAjHi+g");
	var mask_25_graphics_176 = new cjs.Graphics().p("AnsHYQjMjDAAkVIAAAAQAAkUDMjEIAAAAQDMjDEgAAIAAAAQEhAADMDDIAAAAQDMDEAAEUIAAAAQAAEVjMDDIAAAAQjMDEkhAAIAAAAQkgAAjMjEg");
	var mask_25_graphics_177 = new cjs.Graphics().p("An5HlQjSjJAAkcIAAAAQAAkbDSjJIAAAAQDSjJEnAAIAAAAQEoAADSDJIAAAAQDSDJAAEbIAAAAQAAEcjSDJIAAAAQjSDJkoAAIAAAAQknAAjSjJg");
	var mask_25_graphics_178 = new cjs.Graphics().p("AoGHxQjXjOAAkjIAAAAQAAkiDXjOIAAAAQDXjOEvAAIAAAAQEwAADXDOIAAAAQDXDOAAEiIAAAAQAAEjjXDOIAAAAQjXDOkwAAIAAAAQkvAAjXjOg");
	var mask_25_graphics_179 = new cjs.Graphics().p("AoSH9QjcjTAAkqIAAAAQAAkpDcjTIAAAAQDcjTE2AAIAAAAQE3AADcDTIAAAAQDcDTAAEpIAAAAQAAEqjcDTIAAAAQjcDTk3AAIAAAAQk2AAjcjTg");
	var mask_25_graphics_180 = new cjs.Graphics().p("AoeIJQjhjYAAkxIAAAAQAAkwDhjYIAAAAQDhjXE9AAIAAAAQE+AADhDXIAAAAQDhDYAAEwIAAAAQAAExjhDYIAAAAQjhDXk+AAIAAAAQk9AAjhjXg");
	var mask_25_graphics_181 = new cjs.Graphics().p("AoqIUQjmjcAAk4IAAAAQAAk3DmjcIAAAAQDmjcFEAAIAAAAQFFAADmDcIAAAAQDmDcAAE3IAAAAQAAE4jmDcIAAAAQjmDclFAAIAAAAQlEAAjmjcg");
	var mask_25_graphics_182 = new cjs.Graphics().p("Ao2IfQjrjhAAk+IAAAAQAAk9DrjhIAAAAQDrjhFLAAIAAAAQFMAADrDhIAAAAQDrDhAAE9IAAAAQAAE+jrDhIAAAAQjrDhlMAAIAAAAQlLAAjrjhg");
	var mask_25_graphics_183 = new cjs.Graphics().p("ApBIqQjvjmAAlEIAAAAQAAlDDvjmIAAAAQDvjlFSAAIAAAAQFTAADvDlIAAAAQDvDmAAFDIAAAAQAAFEjvDmIAAAAQjvDllTAAIAAAAQlSAAjvjlg");
	var mask_25_graphics_184 = new cjs.Graphics().p("ApMI0Qj0jpAAlLIAAAAQAAlKD0jqIAAAAQD0jpFYAAIAAAAQFZAAD0DpIAAAAQD0DqAAFKIAAAAQAAFLj0DpIAAAAQj0DqlZAAIAAAAQlYAAj0jqg");
	var mask_25_graphics_185 = new cjs.Graphics().p("ApXI+Qj4jtAAlRIAAAAQAAlQD4juIAAAAQD5juFeAAIAAAAQFfAAD5DuIAAAAQD4DuAAFQIAAAAQAAFRj4DtIAAAAQj5DvlfAAIAAAAQleAAj5jvg");
	var mask_25_graphics_186 = new cjs.Graphics().p("AphJIQj9jyAAlWIAAAAQAAlVD9jzIAAAAQD9jyFkAAIAAAAQFlAAD9DyIAAAAQD9DzAAFVIAAAAQAAFWj9DyIAAAAQj9DzllAAIAAAAQlkAAj9jzg");
	var mask_25_graphics_187 = new cjs.Graphics().p("AprJSQkBj2AAlcIAAAAQAAlbEBj2IAAAAQEBj2FqAAIAAAAQFrAAEBD2IAAAAQEBD2AAFbIAAAAQAAFckBD2IAAAAQkBD2lrAAIAAAAQlqAAkBj2g");
	var mask_25_graphics_188 = new cjs.Graphics().p("Ap1JbQkFj5AAliIAAAAQAAlhEFj6IAAAAQEFj6FwAAIAAAAQFxAAEFD6IAAAAQEFD6AAFhIAAAAQAAFikFD5IAAAAQkFD7lxAAIAAAAQlwAAkFj7g");
	var mask_25_graphics_189 = new cjs.Graphics().p("Ap/JlQkIj+AAlnIAAAAQAAlmEIj+IAAAAQEJj+F2AAIAAAAQF3AAEID+IAAAAQEJD+AAFmIAAAAQAAFnkJD+IAAAAQkID+l3AAIAAAAQl2AAkJj+g");
	var mask_25_graphics_190 = new cjs.Graphics().p("AqIJtQkMkBAAlsIAAAAQAAlrEMkCIAAAAQENkBF7AAIAAAAQF8AAENEBIAAAAQEMECAAFrIAAAAQAAFskMEBIAAAAQkNECl8AAIAAAAQl7AAkNkCg");
	var mask_25_graphics_191 = new cjs.Graphics().p("AqRJ2QkQkFAAlxIAAAAQAAlwEQkFIAAAAQERkFGAAAIAAAAQGBAAEQEFIAAAAQEREFAAFwIAAAAQAAFxkREFIAAAAQkQEFmBAAIAAAAQmAAAkRkFg");
	var mask_25_graphics_192 = new cjs.Graphics().p("AqZJ+QkUkIAAl2IAAAAQAAl1EUkJIAAAAQEUkIGFAAIAAAAQGGAAEUEIIAAAAQEUEJAAF1IAAAAQAAF2kUEIIAAAAQkUEJmGAAIAAAAQmFAAkUkJg");
	var mask_25_graphics_193 = new cjs.Graphics().p("AqiKGQkXkLAAl7IAAAAQAAl6EXkMIAAAAQEYkLGKAAIAAAAQGLAAEXELIAAAAQEYEMAAF6IAAAAQAAF7kYELIAAAAQkXEMmLAAIAAAAQmKAAkYkMg");
	var mask_25_graphics_194 = new cjs.Graphics().p("AqqKOQkakPAAl/IAAAAQAAl+EakPIAAAAQEbkPGPAAIAAAAQGQAAEaEPIAAAAQEbEPAAF+IAAAAQAAF/kbEPIAAAAQkaEPmQAAIAAAAQmPAAkbkPg");
	var mask_25_graphics_195 = new cjs.Graphics().p("AqyKVQkdkSAAmDIAAAAQAAmCEdkTIAAAAQEfkSGTAAIAAAAQGUAAEeESIAAAAQEeETAAGCIAAAAQAAGDkeESIAAAAQkeETmUAAIAAAAQmTAAkfkTg");
	var mask_25_graphics_196 = new cjs.Graphics().p("Aq5KcQkhkUAAmIIAAAAQAAmHEhkVIAAAAQEhkVGYAAIAAAAQGZAAEhEVIAAAAQEhEVAAGHIAAAAQAAGIkhEUIAAAAQkhEWmZAAIAAAAQmYAAkhkWg");
	var mask_25_graphics_197 = new cjs.Graphics().p("ArAKjQkkkXAAmMIAAAAQAAmLEkkYIAAAAQEkkXGcAAIAAAAQGdAAEkEXIAAAAQEkEYAAGLIAAAAQAAGMkkEXIAAAAQkkEYmdAAIAAAAQmcAAkkkYg");
	var mask_25_graphics_198 = new cjs.Graphics().p("ArHKqQknkaAAmQIAAAAQAAmPEnkaIAAAAQEnkbGgAAIAAAAQGhAAEnEbIAAAAQEnEaAAGPIAAAAQAAGQknEaIAAAAQknEbmhAAIAAAAQmgAAknkbg");
	var mask_25_graphics_199 = new cjs.Graphics().p("ArOKwQkpkdAAmTIAAAAQAAmSEpkeIAAAAQEqkdGkAAIAAAAQGlAAEpEdIAAAAQEqEeAAGSIAAAAQAAGTkqEdIAAAAQkpEemlAAIAAAAQmkAAkqkeg");
	var mask_25_graphics_200 = new cjs.Graphics().p("ArUK2QkskfAAmXIAAAAQAAmWEskgIAAAAQEtkfGnAAIAAAAQGoAAEtEfIAAAAQEsEgAAGWIAAAAQAAGXksEfIAAAAQktEgmoAAIAAAAQmnAAktkgg");
	var mask_25_graphics_201 = new cjs.Graphics().p("AraK8QkukiAAmaIAAAAQAAmZEukiIAAAAQEvkiGrAAIAAAAQGsAAEvEiIAAAAQEuEiAAGZIAAAAQAAGakuEiIAAAAQkvEimsAAIAAAAQmrAAkvkig");
	var mask_25_graphics_202 = new cjs.Graphics().p("ArgLBQkxkkAAmdIAAAAQAAmcExklIAAAAQEykkGuAAIAAAAQGvAAExEkIAAAAQEyElAAGcIAAAAQAAGdkyEkIAAAAQkxElmvAAIAAAAQmuAAkyklg");
	var mask_25_graphics_203 = new cjs.Graphics().p("ArlLHQkzknAAmgIAAAAQAAmfEzknIAAAAQEzkmGyAAIAAAAQGzAAEzEmIAAAAQEzEnAAGfIAAAAQAAGgkzEnIAAAAQkzEmmzAAIAAAAQmyAAkzkmg");
	var mask_25_graphics_204 = new cjs.Graphics().p("ArqLMQk1kpAAmjIAAAAQAAmiE1kpIAAAAQE1koG1AAIAAAAQG2AAE1EoIAAAAQE1EpAAGiIAAAAQAAGjk1EpIAAAAQk1Eom2AAIAAAAQm1AAk1kog");
	var mask_25_graphics_205 = new cjs.Graphics().p("ArvLQQk3kqAAmmIAAAAQAAmlE3krIAAAAQE4kqG3AAIAAAAQG4AAE4EqIAAAAQE3ErAAGlIAAAAQAAGmk3EqIAAAAQk4Erm4AAIAAAAQm3AAk4krg");
	var mask_25_graphics_206 = new cjs.Graphics().p("Ar0LVQk5ktAAmoIAAAAQAAmnE5ktIAAAAQE6ksG6AAIAAAAQG7AAE5EsIAAAAQE6EtAAGnIAAAAQAAGok6EtIAAAAQk5Esm7AAIAAAAQm6AAk6ksg");
	var mask_25_graphics_207 = new cjs.Graphics().p("Ar4LZQk7kuAAmrIAAAAQAAmqE7kuIAAAAQE8kuG8AAIAAAAQG9AAE7EuIAAAAQE8EuAAGqIAAAAQAAGrk8EuIAAAAQk7Eum9AAIAAAAQm8AAk8kug");
	var mask_25_graphics_208 = new cjs.Graphics().p("Ar8LcQk8kvAAmtIAAAAQAAmsE8kwIAAAAQE9kvG/AAIAAAAQHAAAE8EvIAAAAQE9EwAAGsIAAAAQAAGtk9EvIAAAAQk8EwnAAAIAAAAQm/AAk9kwg");
	var mask_25_graphics_209 = new cjs.Graphics().p("Ar/LgQk+kxAAmvIAAAAQAAmuE+kxIAAAAQE+kxHBAAIAAAAQHCAAE+ExIAAAAQE+ExAAGuIAAAAQAAGvk+ExIAAAAQk+ExnCAAIAAAAQnBAAk+kxg");
	var mask_25_graphics_210 = new cjs.Graphics().p("AsDLjQk/kyAAmxIAAAAQAAmwE/kyIAAAAQFAkzHDAAIAAAAQHEAAE/EzIAAAAQFAEyAAGwIAAAAQAAGxlAEyIAAAAQk/EznEAAIAAAAQnDAAlAkzg");
	var mask_25_graphics_211 = new cjs.Graphics().p("AsGLmQlBkzAAmzIAAAAQAAmyFBkzIAAAAQFBk0HFAAIAAAAQHGAAFAE0IAAAAQFCEzAAGyIAAAAQAAGzlCEzIAAAAQlAE0nGAAIAAAAQnFAAlBk0g");
	var mask_25_graphics_212 = new cjs.Graphics().p("AsJLpQlBk1AAm0IAAAAQAAmzFBk1IAAAAQFDk0HGAAIAAAAQHHAAFCE0IAAAAQFCE1AAGzIAAAAQAAG0lCE1IAAAAQlCE0nHAAIAAAAQnGAAlDk0g");
	var mask_25_graphics_213 = new cjs.Graphics().p("AsLLrQlDk1AAm2IAAAAQAAm1FDk1IAAAAQFDk2HIAAIAAAAQHJAAFDE2IAAAAQFDE1AAG1IAAAAQAAG2lDE1IAAAAQlDE2nJAAIAAAAQnIAAlDk2g");
	var mask_25_graphics_214 = new cjs.Graphics().p("AsNLtQlEk2AAm3IAAAAQAAm2FEk3IAAAAQFEk2HJAAIAAAAQHKAAFEE2IAAAAQFEE3AAG2IAAAAQAAG3lEE2IAAAAQlEE3nKAAIAAAAQnJAAlEk3g");
	var mask_25_graphics_215 = new cjs.Graphics().p("AsPLvQlFk3AAm4IAAAAQAAm3FFk3IAAAAQFFk3HKAAIAAAAQHLAAFFE3IAAAAQFFE3AAG3IAAAAQAAG4lFE3IAAAAQlFE3nLAAIAAAAQnKAAlFk3g");
	var mask_25_graphics_216 = new cjs.Graphics().p("AsRLxQlFk4AAm5IAAAAQAAm4FFk4IAAAAQFGk4HLAAIAAAAQHMAAFFE4IAAAAQFGE4AAG4IAAAAQAAG5lGE4IAAAAQlFE4nMAAIAAAAQnLAAlGk4g");
	var mask_25_graphics_217 = new cjs.Graphics().p("AsSLyQlGk4AAm6IAAAAQAAm5FGk4IAAAAQFGk4HMAAIAAAAQHNAAFGE4IAAAAQFGE4AAG5IAAAAQAAG6lGE4IAAAAQlGE4nNAAIAAAAQnMAAlGk4g");
	var mask_25_graphics_218 = new cjs.Graphics().p("AsTLzQlGk5AAm6IAAAAQAAm5FGk5IAAAAQFGk5HNAAIAAAAQHOAAFGE5IAAAAQFGE5AAG5IAAAAQAAG6lGE5IAAAAQlGE5nOAAIAAAAQnNAAlGk5g");
	var mask_25_graphics_219 = new cjs.Graphics().p("AsUL0QlGk5AAm7IAAAAQAAm6FGk5IAAAAQFHk5HNAAIAAAAQHOAAFGE5IAAAAQFHE5AAG6IAAAAQAAG7lHE5IAAAAQlGE5nOAAIAAAAQnNAAlHk5g");
	var mask_25_graphics_220 = new cjs.Graphics().p("AsUL0QlHk5AAm7IAAAAQAAm6FHk5IAAAAQFHk5HNAAIAAAAQHOAAFHE5IAAAAQFHE5AAG6IAAAAQAAG7lHE5IAAAAQlHE5nOAAIAAAAQnNAAlHk5g");
	var mask_25_graphics_221 = new cjs.Graphics().p("AsUL0QlHk5AAm7IAAAAQAAm6FHk5IAAAAQFHk6HNAAIAAAAQHOAAFHE6IAAAAQFHE5AAG6IAAAAQAAG7lHE5IAAAAQlHE6nOAAIAAAAQnNAAlHk6g");

	this.timeline.addTween(cjs.Tween.get(mask_25).to({graphics:null,x:0,y:0}).wait(119).to({graphics:mask_25_graphics_119,x:467.9005,y:694.5003}).wait(1).to({graphics:mask_25_graphics_120,x:467.8996,y:694.5021}).wait(1).to({graphics:mask_25_graphics_121,x:467.8978,y:694.5079}).wait(1).to({graphics:mask_25_graphics_122,x:467.8951,y:694.5169}).wait(1).to({graphics:mask_25_graphics_123,x:467.8911,y:694.5309}).wait(1).to({graphics:mask_25_graphics_124,x:467.8857,y:694.548}).wait(1).to({graphics:mask_25_graphics_125,x:467.879,y:694.5687}).wait(1).to({graphics:mask_25_graphics_126,x:467.8713,y:694.5934}).wait(1).to({graphics:mask_25_graphics_127,x:467.8627,y:694.6227}).wait(1).to({graphics:mask_25_graphics_128,x:467.8524,y:694.6546}).wait(1).to({graphics:mask_25_graphics_129,x:467.8407,y:694.6911}).wait(1).to({graphics:mask_25_graphics_130,x:467.8286,y:694.7311}).wait(1).to({graphics:mask_25_graphics_131,x:467.815,y:694.7748}).wait(1).to({graphics:mask_25_graphics_132,x:467.8002,y:694.8229}).wait(1).to({graphics:mask_25_graphics_133,x:467.784,y:694.8742}).wait(1).to({graphics:mask_25_graphics_134,x:467.7669,y:694.9296}).wait(1).to({graphics:mask_25_graphics_135,x:467.7484,y:694.989}).wait(1).to({graphics:mask_25_graphics_136,x:467.7286,y:695.0515}).wait(1).to({graphics:mask_25_graphics_137,x:467.7084,y:695.1186}).wait(1).to({graphics:mask_25_graphics_138,x:467.6863,y:695.1892}).wait(1).to({graphics:mask_25_graphics_139,x:467.6629,y:695.2639}).wait(1).to({graphics:mask_25_graphics_140,x:467.6387,y:695.3423}).wait(1).to({graphics:mask_25_graphics_141,x:467.613,y:695.4242}).wait(1).to({graphics:mask_25_graphics_142,x:467.5865,y:695.5101}).wait(1).to({graphics:mask_25_graphics_143,x:467.5585,y:695.5992}).wait(1).to({graphics:mask_25_graphics_144,x:467.5293,y:695.6932}).wait(1).to({graphics:mask_25_graphics_145,x:467.4991,y:695.7904}).wait(1).to({graphics:mask_25_graphics_146,x:467.4677,y:695.8917}).wait(1).to({graphics:mask_25_graphics_147,x:467.4352,y:695.9966}).wait(1).to({graphics:mask_25_graphics_148,x:467.4015,y:696.1054}).wait(1).to({graphics:mask_25_graphics_149,x:467.3664,y:696.2179}).wait(1).to({graphics:mask_25_graphics_150,x:467.3299,y:696.3345}).wait(1).to({graphics:mask_25_graphics_151,x:467.2926,y:696.4546}).wait(1).to({graphics:mask_25_graphics_152,x:467.2539,y:696.5784}).wait(1).to({graphics:mask_25_graphics_153,x:467.2143,y:696.7062}).wait(1).to({graphics:mask_25_graphics_154,x:467.1734,y:696.838}).wait(1).to({graphics:mask_25_graphics_155,x:467.1315,y:696.9739}).wait(1).to({graphics:mask_25_graphics_156,x:467.0883,y:697.113}).wait(1).to({graphics:mask_25_graphics_157,x:467.0433,y:697.2561}).wait(1).to({graphics:mask_25_graphics_158,x:466.9974,y:697.4032}).wait(1).to({graphics:mask_25_graphics_159,x:466.9506,y:697.554}).wait(1).to({graphics:mask_25_graphics_160,x:466.9029,y:697.7083}).wait(1).to({graphics:mask_25_graphics_161,x:466.8534,y:697.8667}).wait(1).to({graphics:mask_25_graphics_162,x:466.8034,y:698.0292}).wait(1).to({graphics:mask_25_graphics_163,x:466.7512,y:698.1952}).wait(1).to({graphics:mask_25_graphics_164,x:466.6986,y:698.3649}).wait(1).to({graphics:mask_25_graphics_165,x:466.6446,y:698.539}).wait(1).to({graphics:mask_25_graphics_166,x:466.5892,y:698.7163}).wait(1).to({graphics:mask_25_graphics_167,x:466.5334,y:698.8977}).wait(1).to({graphics:mask_25_graphics_168,x:466.4754,y:699.0826}).wait(1).to({graphics:mask_25_graphics_169,x:466.4169,y:699.2716}).wait(1).to({graphics:mask_25_graphics_170,x:466.3571,y:699.4647}).wait(1).to({graphics:mask_25_graphics_171,x:466.2967,y:699.6568}).wait(1).to({graphics:mask_25_graphics_172,x:466.2378,y:699.8463}).wait(1).to({graphics:mask_25_graphics_173,x:466.1806,y:700.0313}).wait(1).to({graphics:mask_25_graphics_174,x:466.1239,y:700.2126}).wait(1).to({graphics:mask_25_graphics_175,x:466.069,y:700.3904}).wait(1).to({graphics:mask_25_graphics_176,x:466.015,y:700.564}).wait(1).to({graphics:mask_25_graphics_177,x:465.962,y:700.7337}).wait(1).to({graphics:mask_25_graphics_178,x:465.9106,y:700.8997}).wait(1).to({graphics:mask_25_graphics_179,x:465.8602,y:701.0617}).wait(1).to({graphics:mask_25_graphics_180,x:465.8107,y:701.2202}).wait(1).to({graphics:mask_25_graphics_181,x:465.7626,y:701.3749}).wait(1).to({graphics:mask_25_graphics_182,x:465.7158,y:701.5262}).wait(1).to({graphics:mask_25_graphics_183,x:465.6699,y:701.6729}).wait(1).to({graphics:mask_25_graphics_184,x:465.6258,y:701.8159}).wait(1).to({graphics:mask_25_graphics_185,x:465.5826,y:701.9554}).wait(1).to({graphics:mask_25_graphics_186,x:465.5403,y:702.0909}).wait(1).to({graphics:mask_25_graphics_187,x:465.4993,y:702.2223}).wait(1).to({graphics:mask_25_graphics_188,x:465.4597,y:702.3505}).wait(1).to({graphics:mask_25_graphics_189,x:465.421,y:702.4743}).wait(1).to({graphics:mask_25_graphics_190,x:465.3833,y:702.5949}).wait(1).to({graphics:mask_25_graphics_191,x:465.3472,y:702.711}).wait(1).to({graphics:mask_25_graphics_192,x:465.3126,y:702.8235}).wait(1).to({graphics:mask_25_graphics_193,x:465.2784,y:702.9324}).wait(1).to({graphics:mask_25_graphics_194,x:465.2455,y:703.0377}).wait(1).to({graphics:mask_25_graphics_195,x:465.2145,y:703.1385}).wait(1).to({graphics:mask_25_graphics_196,x:465.1839,y:703.2361}).wait(1).to({graphics:mask_25_graphics_197,x:465.1546,y:703.3293}).wait(1).to({graphics:mask_25_graphics_198,x:465.1272,y:703.4193}).wait(1).to({graphics:mask_25_graphics_199,x:465.1006,y:703.5048}).wait(1).to({graphics:mask_25_graphics_200,x:465.075,y:703.5872}).wait(1).to({graphics:mask_25_graphics_201,x:465.0507,y:703.6654}).wait(1).to({graphics:mask_25_graphics_202,x:465.0273,y:703.7397}).wait(1).to({graphics:mask_25_graphics_203,x:465.0057,y:703.8103}).wait(1).to({graphics:mask_25_graphics_204,x:464.9845,y:703.8774}).wait(1).to({graphics:mask_25_graphics_205,x:464.9652,y:703.9404}).wait(1).to({graphics:mask_25_graphics_206,x:464.9467,y:703.9993}).wait(1).to({graphics:mask_25_graphics_207,x:464.9296,y:704.0547}).wait(1).to({graphics:mask_25_graphics_208,x:464.9135,y:704.106}).wait(1).to({graphics:mask_25_graphics_209,x:464.8986,y:704.1537}).wait(1).to({graphics:mask_25_graphics_210,x:464.8846,y:704.1978}).wait(1).to({graphics:mask_25_graphics_211,x:464.8725,y:704.2383}).wait(1).to({graphics:mask_25_graphics_212,x:464.8617,y:704.2738}).wait(1).to({graphics:mask_25_graphics_213,x:464.8513,y:704.3067}).wait(1).to({graphics:mask_25_graphics_214,x:464.8423,y:704.3351}).wait(1).to({graphics:mask_25_graphics_215,x:464.8342,y:704.3602}).wait(1).to({graphics:mask_25_graphics_216,x:464.8279,y:704.3809}).wait(1).to({graphics:mask_25_graphics_217,x:464.823,y:704.3985}).wait(1).to({graphics:mask_25_graphics_218,x:464.8185,y:704.4115}).wait(1).to({graphics:mask_25_graphics_219,x:464.8158,y:704.4214}).wait(1).to({graphics:mask_25_graphics_220,x:464.814,y:704.4268}).wait(1).to({graphics:mask_25_graphics_221,x:466.1613,y:705.7057}).wait(589));

	// Layer_7
	this.instance_44 = new lib.Tween24("synched",0);
	this.instance_44.setTransform(520.05,699.6);
	this.instance_44.alpha = 0.5;
	this.instance_44._off = true;

	this.instance_45 = new lib.Tween25("synched",0);
	this.instance_45.setTransform(520.05,699.6);

	var maskedShapeInstanceList = [this.instance_44,this.instance_45];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_25;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_44}]},119).to({state:[{t:this.instance_45}]},102).wait(589));
	this.timeline.addTween(cjs.Tween.get(this.instance_44).wait(119).to({_off:false},0).to({_off:true,alpha:1},102,cjs.Ease.quadInOut).wait(589));

	// Layer_6 (mask)
	var mask_26 = new cjs.Shape();
	mask_26._off = true;
	var mask_26_graphics_66 = new cjs.Graphics().p("AgbAbQgMgLAAgQIAAAAQAAgPAMgLIAAAAQALgLAQAAIAAAAQARAAALALIAAAAQAMALAAAPIAAAAQAAAQgMALIAAAAQgLALgRAAIAAAAQgQAAgLgLg");
	var mask_26_graphics_67 = new cjs.Graphics().p("AgcAbQgLgLAAgQIAAAAQAAgPALgLIAAAAQAMgMAQAAIAAAAQARAAAMAMIAAAAQALALAAAPIAAAAQAAAQgLALIAAAAQgMAMgRAAIAAAAQgQAAgMgMg");
	var mask_26_graphics_68 = new cjs.Graphics().p("AgdAcQgMgLAAgRIAAAAQAAgQAMgLIAAAAQANgMAQAAIAAAAQARAAANAMIAAAAQAMALAAAQIAAAAQAAARgMALIAAAAQgNAMgRAAIAAAAQgQAAgNgMg");
	var mask_26_graphics_69 = new cjs.Graphics().p("AgeAeQgNgNAAgRIAAAAQAAgQANgNIAAAAQANgMARAAIAAAAQASAAANAMIAAAAQANANAAAQIAAAAQAAARgNANIAAAAQgNAMgSAAIAAAAQgRAAgNgMg");
	var mask_26_graphics_70 = new cjs.Graphics().p("AggAgQgOgNAAgTIAAAAQAAgSAOgNIAAAAQAOgNASAAIAAAAQATAAAOANIAAAAQAOANAAASIAAAAQAAATgOANIAAAAQgOANgTAAIAAAAQgSAAgOgNg");
	var mask_26_graphics_71 = new cjs.Graphics().p("AgjAiQgPgOAAgUIAAAAQAAgTAPgOIAAAAQAPgPAUAAIAAAAQAVAAAPAPIAAAAQAPAOAAATIAAAAQAAAUgPAOIAAAAQgPAPgVAAIAAAAQgUAAgPgPg");
	var mask_26_graphics_72 = new cjs.Graphics().p("AgmAmQgRgQAAgWIAAAAQAAgVARgQIAAAAQAQgPAWAAIAAAAQAXAAAQAPIAAAAQARAQAAAVIAAAAQAAAWgRAQIAAAAQgQAPgXAAIAAAAQgWAAgQgPg");
	var mask_26_graphics_73 = new cjs.Graphics().p("AgqAqQgSgSAAgYIAAAAQAAgXASgSIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQASASAAAXIAAAAQAAAYgSASIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_26_graphics_74 = new cjs.Graphics().p("AgvAuQgUgTAAgbIAAAAQAAgaAUgTIAAAAQAUgTAbAAIAAAAQAcAAAUATIAAAAQAUATAAAaIAAAAQAAAbgUATIAAAAQgUATgcAAIAAAAQgbAAgUgTg");
	var mask_26_graphics_75 = new cjs.Graphics().p("Ag0AzQgWgVAAgeIAAAAQAAgdAWgVIAAAAQAWgVAeAAIAAAAQAfAAAWAVIAAAAQAWAVAAAdIAAAAQAAAegWAVIAAAAQgWAVgfAAIAAAAQgeAAgWgVg");
	var mask_26_graphics_76 = new cjs.Graphics().p("Ag6A5QgYgYAAghIAAAAQAAggAYgYIAAAAQAYgXAiAAIAAAAQAjAAAYAXIAAAAQAYAYAAAgIAAAAQAAAhgYAYIAAAAQgYAXgjAAIAAAAQgiAAgYgXg");
	var mask_26_graphics_77 = new cjs.Graphics().p("AhAA/QgcgaAAglIAAAAQAAgkAcgaIAAAAQAbgaAlAAIAAAAQAmAAAbAaIAAAAQAcAaAAAkIAAAAQAAAlgcAaIAAAAQgbAagmAAIAAAAQglAAgbgag");
	var mask_26_graphics_78 = new cjs.Graphics().p("AhIBFQgegcAAgpIAAAAQAAgoAegdIAAAAQAfgcApAAIAAAAQAqAAAfAcIAAAAQAeAdAAAoIAAAAQAAApgeAcIAAAAQgfAdgqAAIAAAAQgpAAgfgdg");
	var mask_26_graphics_79 = new cjs.Graphics().p("AhPBNQghggAAgtIAAAAQAAgsAhggIAAAAQAhggAuAAIAAAAQAvAAAhAgIAAAAQAhAgAAAsIAAAAQAAAtghAgIAAAAQghAggvAAIAAAAQguAAghggg");
	var mask_26_graphics_80 = new cjs.Graphics().p("AhYBVQgkgjAAgyIAAAAQAAgxAkgjIAAAAQAlgjAzAAIAAAAQA0AAAkAjIAAAAQAlAjAAAxIAAAAQAAAyglAjIAAAAQgkAjg0AAIAAAAQgzAAglgjg");
	var mask_26_graphics_81 = new cjs.Graphics().p("AhgBdQgpgmAAg3IAAAAQAAg2ApgmIAAAAQAognA4AAIAAAAQA5AAAoAnIAAAAQApAmAAA2IAAAAQAAA3gpAmIAAAAQgoAng5AAIAAAAQg4AAgogng");
	var mask_26_graphics_82 = new cjs.Graphics().p("AhqBmQgsgqAAg8IAAAAQAAg7AsgqIAAAAQAsgrA+AAIAAAAQA/AAAsArIAAAAQAsAqAAA7IAAAAQAAA8gsAqIAAAAQgsArg/AAIAAAAQg+AAgsgrg");
	var mask_26_graphics_83 = new cjs.Graphics().p("Ah0BwQgxguAAhCIAAAAQAAhBAxguIAAAAQAwgvBEAAIAAAAQBFAAAwAvIAAAAQAxAuAABBIAAAAQAABCgxAuIAAAAQgwAvhFAAIAAAAQhEAAgwgvg");
	var mask_26_graphics_84 = new cjs.Graphics().p("Ah/B6Qg1gyAAhIIAAAAQAAhHA1gzIAAAAQA1gyBKAAIAAAAQBLAAA1AyIAAAAQA1AzAABHIAAAAQAABIg1AyIAAAAQg1AzhLAAIAAAAQhKAAg1gzg");
	var mask_26_graphics_85 = new cjs.Graphics().p("AiKCFQg6g3AAhOIAAAAQAAhNA6g3IAAAAQA5g4BRAAIAAAAQBSAAA5A4IAAAAQA6A3AABNIAAAAQAABOg6A3IAAAAQg5A4hSAAIAAAAQhRAAg5g4g");
	var mask_26_graphics_86 = new cjs.Graphics().p("AiWCRQg/g8AAhVIAAAAQAAhUA/g8IAAAAQA+g8BYAAIAAAAQBZAAA+A8IAAAAQA/A8AABUIAAAAQAABVg/A8IAAAAQg+A8hZAAIAAAAQhYAAg+g8g");
	var mask_26_graphics_87 = new cjs.Graphics().p("AijCdQhEhBAAhcIAAAAQAAhbBEhBIAAAAQBEhBBfAAIAAAAQBgAABEBBIAAAAQBEBBAABbIAAAAQAABchEBBIAAAAQhEBBhgAAIAAAAQhfAAhEhBg");
	var mask_26_graphics_88 = new cjs.Graphics().p("AiwCqQhJhHAAhjIAAAAQAAhiBJhHIAAAAQBJhGBnAAIAAAAQBoAABJBGIAAAAQBJBHAABiIAAAAQAABjhJBHIAAAAQhJBGhoAAIAAAAQhnAAhJhGg");
	var mask_26_graphics_89 = new cjs.Graphics().p("Ai+C3QhPhMAAhrIAAAAQAAhqBPhMIAAAAQBPhMBvAAIAAAAQBwAABPBMIAAAAQBPBMAABqIAAAAQAABrhPBMIAAAAQhPBMhwAAIAAAAQhvAAhPhMg");
	var mask_26_graphics_90 = new cjs.Graphics().p("AjMDFQhVhSAAhzIAAAAQAAhyBVhSIAAAAQBVhRB3AAIAAAAQB4AABVBRIAAAAQBVBSAAByIAAAAQAABzhVBSIAAAAQhVBRh4AAIAAAAQh3AAhVhRg");
	var mask_26_graphics_91 = new cjs.Graphics().p("AjbDTQhchXAAh8IAAAAQAAh7BchXIAAAAQBbhYCAAAIAAAAQCBAABbBYIAAAAQBcBXAAB7IAAAAQAAB8hcBXIAAAAQhbBXiBABIAAAAQiAgBhbhXg");
	var mask_26_graphics_92 = new cjs.Graphics().p("AjrDiQhiheAAiEIAAAAQAAiDBiheIAAAAQBiheCJAAIAAAAQCKAABiBeIAAAAQBiBeAACDIAAAAQAACEhiBeIAAAAQhiBeiKAAIAAAAQiJAAhiheg");
	var mask_26_graphics_93 = new cjs.Graphics().p("Aj7DyQhphkAAiOIAAAAQAAiNBphkIAAAAQBohkCTAAIAAAAQCUAABoBkIAAAAQBpBkAACNIAAAAQAACOhpBkIAAAAQhoBkiUAAIAAAAQiTAAhohkg");
	var mask_26_graphics_94 = new cjs.Graphics().p("AkMECQhwhrAAiXIAAAAQAAiWBwhrIAAAAQBvhrCdAAIAAAAQCeAABvBrIAAAAQBwBrAACWIAAAAQAACXhwBrIAAAAQhvBrieAAIAAAAQidAAhvhrg");
	var mask_26_graphics_95 = new cjs.Graphics().p("AkeETQh2hyAAihIAAAAQAAigB2hyIAAAAQB3hxCnAAIAAAAQCoAAB3BxIAAAAQB2ByAACgIAAAAQAAChh2ByIAAAAQh3BxioAAIAAAAQinAAh3hxg");
	var mask_26_graphics_96 = new cjs.Graphics().p("AkwEkQh+h5AAirIAAAAQAAiqB+h5IAAAAQB/h5CxAAIAAAAQCyAAB/B5IAAAAQB+B5AACqIAAAAQAACrh+B5IAAAAQh/B5iyAAIAAAAQixAAh/h5g");
	var mask_26_graphics_97 = new cjs.Graphics().p("AlDE2QiFiAAAi2IAAAAQAAi1CFiAIAAAAQCHiAC8AAIAAAAQC9AACGCAIAAAAQCGCAAAC1IAAAAQAAC2iGCAIAAAAQiGCAi9AAIAAAAQi8AAiHiAg");
	var mask_26_graphics_98 = new cjs.Graphics().p("AlWFIQiOiIAAjAIAAAAQAAi/COiJIAAAAQCOiIDIAAIAAAAQDJAACOCIIAAAAQCOCJAAC/IAAAAQAADAiOCIIAAAAQiOCJjJAAIAAAAQjIAAiOiJg");
	var mask_26_graphics_99 = new cjs.Graphics().p("AlqFcQiWiQAAjMIAAAAQAAjLCWiQIAAAAQCXiQDTAAIAAAAQDVAACWCQIAAAAQCWCQAADLIAAAAQAADMiWCQIAAAAQiWCQjVAAIAAAAQjTAAiXiQg");
	var mask_26_graphics_100 = new cjs.Graphics().p("Al+FvQifiYAAjXIAAAAQAAjWCfiYIAAAAQCeiZDgAAIAAAAQDhAACeCZIAAAAQCfCYAADWIAAAAQAADXifCYIAAAAQieCZjhAAIAAAAQjgAAieiZg");
	var mask_26_graphics_101 = new cjs.Graphics().p("AmUGEQinihAAjjIAAAAQAAjiCnihIAAAAQCoigDsAAIAAAAQDtAACnCgIAAAAQCoChAADiIAAAAQAADjioChIAAAAQinCgjtAAIAAAAQjsAAioigg");
	var mask_26_graphics_102 = new cjs.Graphics().p("AmpGYQixipAAjvIAAAAQAAjuCxiqIAAAAQCwipD5AAIAAAAQD6AACwCpIAAAAQCxCqAADuIAAAAQAADvixCpIAAAAQiwCqj6AAIAAAAQj5AAiwiqg");
	var mask_26_graphics_103 = new cjs.Graphics().p("AnAGuQi6iyAAj8IAAAAQAAj7C6iyIAAAAQC6iyEGAAIAAAAQEHAAC6CyIAAAAQC6CyAAD7IAAAAQAAD8i6CyIAAAAQi6CykHAAIAAAAQkGAAi6iyg");
	var mask_26_graphics_104 = new cjs.Graphics().p("AnXHEQjDi7AAkJIAAAAQAAkIDDi7IAAAAQDEi7ETAAIAAAAQEUAADEC7IAAAAQDDC7AAEIIAAAAQAAEJjDC7IAAAAQjEC7kUAAIAAAAQkTAAjEi7g");
	var mask_26_graphics_105 = new cjs.Graphics().p("AnvHbQjNjFAAkWIAAAAQAAkVDNjFIAAAAQDOjEEhAAIAAAAQEiAADNDEIAAAAQDODFAAEVIAAAAQAAEWjODFIAAAAQjNDEkiAAIAAAAQkhAAjOjEg");
	var mask_26_graphics_106 = new cjs.Graphics().p("AoHHyQjXjOAAkkIAAAAQAAkjDXjOIAAAAQDYjOEvAAIAAAAQEwAADYDOIAAAAQDXDOAAEjIAAAAQAAEkjXDOIAAAAQjYDOkwAAIAAAAQkvAAjYjOg");
	var mask_26_graphics_107 = new cjs.Graphics().p("AofIJQjhjYAAkxIAAAAQAAkwDhjYIAAAAQDhjYE+AAIAAAAQE/AADhDYIAAAAQDhDYAAEwIAAAAQAAExjhDYIAAAAQjhDYk/AAIAAAAQk+AAjhjYg");
	var mask_26_graphics_108 = new cjs.Graphics().p("Ao3IgQjrjhAAk/IAAAAQAAk+DrjhIAAAAQDrjhFMAAIAAAAQFNAADrDhIAAAAQDrDhAAE+IAAAAQAAE/jrDhIAAAAQjrDhlNAAIAAAAQlMAAjrjhg");
	var mask_26_graphics_109 = new cjs.Graphics().p("ApOI2Qj0jqAAlMIAAAAQAAlLD0jqIAAAAQD1jqFZAAIAAAAQFaAAD1DqIAAAAQD0DqAAFLIAAAAQAAFMj0DqIAAAAQj1DqlaAAIAAAAQlZAAj1jqg");
	var mask_26_graphics_110 = new cjs.Graphics().p("ApkJLQj+jzAAlYIAAAAQAAlXD+j0IAAAAQD+jzFmAAIAAAAQFnAAD+DzIAAAAQD+D0AAFXIAAAAQAAFYj+DzIAAAAQj+D0lnAAIAAAAQlmAAj+j0g");
	var mask_26_graphics_111 = new cjs.Graphics().p("Ap6JgQkHj8AAlkIAAAAQAAljEHj9IAAAAQEHj7FzAAIAAAAQF0AAEHD7IAAAAQEHD9AAFjIAAAAQAAFkkHD8IAAAAQkHD8l0AAIAAAAQlzAAkHj8g");
	var mask_26_graphics_112 = new cjs.Graphics().p("AqPJ1QkQkFAAlwIAAAAQAAlvEQkFIAAAAQEQkEF/AAIAAAAQGAAAEQEEIAAAAQEQEFAAFvIAAAAQAAFwkQEFIAAAAQkQEEmAAAIAAAAQl/AAkQkEg");
	var mask_26_graphics_113 = new cjs.Graphics().p("AqkKIQkYkMAAl8IAAAAQAAl7EYkNIAAAAQEZkMGLAAIAAAAQGMAAEZEMIAAAAQEYENAAF7IAAAAQAAF8kYEMIAAAAQkZENmMAAIAAAAQmLAAkZkNg");
	var mask_26_graphics_114 = new cjs.Graphics().p("Aq4KbQkgkUAAmHIAAAAQAAmGEgkVIAAAAQEhkUGXAAIAAAAQGYAAEhEUIAAAAQEgEVAAGGIAAAAQAAGHkgEUIAAAAQkhEVmYAAIAAAAQmXAAkhkVg");
	var mask_26_graphics_115 = new cjs.Graphics().p("ArLKuQkpkcAAmSIAAAAQAAmREpkcIAAAAQEpkcGiAAIAAAAQGjAAEpEcIAAAAQEpEcAAGRIAAAAQAAGSkpEcIAAAAQkpEcmjAAIAAAAQmiAAkpkcg");
	var mask_26_graphics_116 = new cjs.Graphics().p("AreLAQkwkkAAmcIAAAAQAAmbEwkkIAAAAQExkkGtAAIAAAAQGuAAExEkIAAAAQEwEkAAGbIAAAAQAAGckwEkIAAAAQkxEkmuAAIAAAAQmtAAkxkkg");
	var mask_26_graphics_117 = new cjs.Graphics().p("ArwLRQk4kqAAmnIAAAAQAAmmE4krIAAAAQE4kqG4AAIAAAAQG5AAE4EqIAAAAQE4ErAAGmIAAAAQAAGnk4EqIAAAAQk4Erm5AAIAAAAQm4AAk4krg");
	var mask_26_graphics_118 = new cjs.Graphics().p("AsCLiQk/kyAAmwIAAAAQAAmvE/kyIAAAAQFAkyHCAAIAAAAQHDAAE/EyIAAAAQFAEyAAGvIAAAAQAAGwlAEyIAAAAQk/EynDAAIAAAAQnCAAlAkyg");
	var mask_26_graphics_119 = new cjs.Graphics().p("AsSLyQlGk4AAm6IAAAAQAAm5FGk5IAAAAQFGk4HMAAIAAAAQHNAAFGE4IAAAAQFGE5AAG5IAAAAQAAG6lGE4IAAAAQlGE5nNAAIAAAAQnMAAlGk5g");
	var mask_26_graphics_120 = new cjs.Graphics().p("AsjMCQlMk/AAnDIAAAAQAAnCFMk/IAAAAQFNk/HWAAIAAAAQHXAAFME/IAAAAQFNE/AAHCIAAAAQAAHDlNE/IAAAAQlME/nXAAIAAAAQnWAAlNk/g");
	var mask_26_graphics_121 = new cjs.Graphics().p("AsyMRQlUlFAAnMIAAAAQAAnLFUlFIAAAAQFTlFHfAAIAAAAQHgAAFTFFIAAAAQFUFFAAHLIAAAAQAAHMlUFFIAAAAQlTFFngAAIAAAAQnfAAlTlFg");
	var mask_26_graphics_122 = new cjs.Graphics().p("AtBMfQlalLAAnUIAAAAQAAnTFalMIAAAAQFZlLHoAAIAAAAQHpAAFZFLIAAAAQFaFMAAHTIAAAAQAAHUlaFLIAAAAQlZFMnpAAIAAAAQnoAAlZlMg");
	var mask_26_graphics_123 = new cjs.Graphics().p("AtQMtQlflRAAncIAAAAQAAnbFflRIAAAAQFglRHwAAIAAAAQHxAAFgFRIAAAAQFfFRAAHbIAAAAQAAHclfFRIAAAAQlgFRnxAAIAAAAQnwAAlglRg");
	var mask_26_graphics_124 = new cjs.Graphics().p("AteM6QlllWAAnkIAAAAQAAnjFllXIAAAAQFmlWH4AAIAAAAQH5AAFlFWIAAAAQFmFXAAHjIAAAAQAAHklmFWIAAAAQllFXn5AAIAAAAQn4AAlmlXg");
	var mask_26_graphics_125 = new cjs.Graphics().p("AtrNHQlrlbAAnsIAAAAQAAnrFrlbIAAAAQFrlcIAAAIAAAAQIBAAFrFcIAAAAQFrFbAAHrIAAAAQAAHslrFbIAAAAQlrFcoBAAIAAAAQoAAAlrlcg");
	var mask_26_graphics_126 = new cjs.Graphics().p("At4NTQlvlgAAnzIAAAAQAAnyFvlgIAAAAQFxlhIHAAIAAAAQIIAAFwFhIAAAAQFwFgAAHyIAAAAQAAHzlwFgIAAAAQlwFhoIAAIAAAAQoHAAlxlhg");
	var mask_26_graphics_127 = new cjs.Graphics().p("AuENeQl0llAAn5IAAAAQAAn4F0lmIAAAAQF2llIOAAIAAAAQIPAAF1FlIAAAAQF1FmAAH4IAAAAQAAH5l1FlIAAAAQl1FmoPAAIAAAAQoOAAl2lmg");
	var mask_26_graphics_128 = new cjs.Graphics().p("AuPNpQl5lpAAoAIAAAAQAAn/F5lqIAAAAQF6lpIVAAIAAAAQIWAAF5FpIAAAAQF6FqAAH/IAAAAQAAIAl6FpIAAAAQl5FqoWAAIAAAAQoVAAl6lqg");
	var mask_26_graphics_129 = new cjs.Graphics().p("AuaN0Ql+luAAoGIAAAAQAAoFF+luIAAAAQF/luIbAAIAAAAQIcAAF+FuIAAAAQF/FuAAIFIAAAAQAAIGl/FuIAAAAQl+FuocAAIAAAAQobAAl/lug");
	var mask_26_graphics_130 = new cjs.Graphics().p("AukN9QmClyAAoLIAAAAQAAoKGClzIAAAAQGDlyIhAAIAAAAQIiAAGCFyIAAAAQGDFzAAIKIAAAAQAAILmDFyIAAAAQmCFzoiAAIAAAAQohAAmDlzg");
	var mask_26_graphics_131 = new cjs.Graphics().p("AutOGQmGl1AAoRIAAAAQAAoQGGl2IAAAAQGGl2InAAIAAAAQIoAAGGF2IAAAAQGGF2AAIQIAAAAQAAIRmGF1IAAAAQmGF3ooAAIAAAAQonAAmGl3g");
	var mask_26_graphics_132 = new cjs.Graphics().p("Au2OPQmKl5AAoWIAAAAQAAoVGKl5IAAAAQGKl6IsAAIAAAAQItAAGKF6IAAAAQGKF5AAIVIAAAAQAAIWmKF5IAAAAQmKF6otAAIAAAAQosAAmKl6g");
	var mask_26_graphics_133 = new cjs.Graphics().p("Au/OXQmNl9AAoaIAAAAQAAoZGNl9IAAAAQGOl9IxAAIAAAAQIyAAGNF9IAAAAQGOF9AAIZIAAAAQAAIamOF9IAAAAQmNF9oyAAIAAAAQoxAAmOl9g");
	var mask_26_graphics_134 = new cjs.Graphics().p("AvGOeQmRl/AAofIAAAAQAAoeGRmAIAAAAQGRl/I1AAIAAAAQI2AAGRF/IAAAAQGRGAAAIeIAAAAQAAIfmRF/IAAAAQmRGAo2AAIAAAAQo1AAmRmAg");
	var mask_26_graphics_135 = new cjs.Graphics().p("AvNOlQmUmCAAojIAAAAQAAoiGUmDIAAAAQGTmCI6AAIAAAAQI7AAGTGCIAAAAQGUGDAAIiIAAAAQAAIjmUGCIAAAAQmTGDo7AAIAAAAQo6AAmTmDg");
	var mask_26_graphics_136 = new cjs.Graphics().p("AvUOrQmWmFAAomIAAAAQAAolGWmGIAAAAQGXmFI9AAIAAAAQI+AAGWGFIAAAAQGXGGAAIlIAAAAQAAImmXGFIAAAAQmWGGo+AAIAAAAQo9AAmXmGg");
	var mask_26_graphics_137 = new cjs.Graphics().p("AvaOxQmYmHAAoqIAAAAQAAopGYmHIAAAAQGZmIJBAAIAAAAQJCAAGYGIIAAAAQGZGHAAIpIAAAAQAAIqmZGHIAAAAQmYGIpCAAIAAAAQpBAAmZmIg");
	var mask_26_graphics_138 = new cjs.Graphics().p("AvfO2QmamKAAosIAAAAQAAorGamKIAAAAQGbmKJEAAIAAAAQJFAAGaGKIAAAAQGbGKAAIrIAAAAQAAIsmbGKIAAAAQmaGKpFAAIAAAAQpEAAmbmKg");
	var mask_26_graphics_139 = new cjs.Graphics().p("AvjO6QmdmLAAovIAAAAQAAouGdmMIAAAAQGdmLJGAAIAAAAQJHAAGdGLIAAAAQGdGMAAIuIAAAAQAAIvmdGLIAAAAQmdGMpHAAIAAAAQpGAAmdmMg");
	var mask_26_graphics_140 = new cjs.Graphics().p("AvnO+QmemNAAoxIAAAAQAAowGemOIAAAAQGemMJJAAIAAAAQJKAAGeGMIAAAAQGeGOAAIwIAAAAQAAIxmeGNIAAAAQmeGNpKAAIAAAAQpJAAmemNg");
	var mask_26_graphics_141 = new cjs.Graphics().p("AvrPBQmfmOAAozIAAAAQAAoyGfmPIAAAAQGgmOJLAAIAAAAQJMAAGfGOIAAAAQGgGPAAIyIAAAAQAAIzmgGOIAAAAQmfGPpMAAIAAAAQpLAAmgmPg");
	var mask_26_graphics_142 = new cjs.Graphics().p("AvuPEQmgmPAAo1IAAAAQAAo0GgmPIAAAAQGimQJMAAIAAAAQJNAAGhGQIAAAAQGhGPAAI0IAAAAQAAI1mhGPIAAAAQmhGQpNAAIAAAAQpMAAmimQg");
	var mask_26_graphics_143 = new cjs.Graphics().p("AvwPGQmhmQAAo2IAAAAQAAo1GhmRIAAAAQGimQJOAAIAAAAQJPAAGhGQIAAAAQGiGRAAI1IAAAAQAAI2miGQIAAAAQmhGRpPAAIAAAAQpOAAmimRg");
	var mask_26_graphics_144 = new cjs.Graphics().p("AvxPIQmimRAAo3IAAAAQAAo2GimRIAAAAQGimRJPAAIAAAAQJQAAGiGRIAAAAQGiGRAAI2IAAAAQAAI3miGRIAAAAQmiGRpQAAIAAAAQpPAAmimRg");
	var mask_26_graphics_145 = new cjs.Graphics().p("AvyPIQmjmRAAo3IAAAAQAAo2GjmSIAAAAQGjmRJPAAIAAAAQJQAAGjGRIAAAAQGjGSAAI2IAAAAQAAI3mjGRIAAAAQmjGSpQAAIAAAAQpPAAmjmSg");
	var mask_26_graphics_146 = new cjs.Graphics().p("AvyPJQmjmRAAo4IAAAAQAAo3GjmRIAAAAQGjmRJPAAIAAAAQJQAAGjGRIAAAAQGjGRAAI3IAAAAQAAI4mjGRIAAAAQmjGRpQAAIAAAAQpPAAmjmRg");

	this.timeline.addTween(cjs.Tween.get(mask_26).to({graphics:null,x:0,y:0}).wait(66).to({graphics:mask_26_graphics_66,x:467.9005,y:591.4003}).wait(1).to({graphics:mask_26_graphics_67,x:467.9014,y:591.4012}).wait(1).to({graphics:mask_26_graphics_68,x:467.9032,y:591.403}).wait(1).to({graphics:mask_26_graphics_69,x:467.9068,y:591.4066}).wait(1).to({graphics:mask_26_graphics_70,x:467.9113,y:591.4125}).wait(1).to({graphics:mask_26_graphics_71,x:467.9181,y:591.4192}).wait(1).to({graphics:mask_26_graphics_72,x:467.9253,y:591.4273}).wait(1).to({graphics:mask_26_graphics_73,x:467.9348,y:591.4373}).wait(1).to({graphics:mask_26_graphics_74,x:467.9451,y:591.4489}).wait(1).to({graphics:mask_26_graphics_75,x:467.9568,y:591.4615}).wait(1).to({graphics:mask_26_graphics_76,x:467.9703,y:591.4759}).wait(1).to({graphics:mask_26_graphics_77,x:467.9852,y:591.4921}).wait(1).to({graphics:mask_26_graphics_78,x:468.0013,y:591.5097}).wait(1).to({graphics:mask_26_graphics_79,x:468.0184,y:591.5286}).wait(1).to({graphics:mask_26_graphics_80,x:468.0378,y:591.5493}).wait(1).to({graphics:mask_26_graphics_81,x:468.0581,y:591.5714}).wait(1).to({graphics:mask_26_graphics_82,x:468.0796,y:591.5943}).wait(1).to({graphics:mask_26_graphics_83,x:468.103,y:591.6199}).wait(1).to({graphics:mask_26_graphics_84,x:468.1273,y:591.6465}).wait(1).to({graphics:mask_26_graphics_85,x:468.153,y:591.6744}).wait(1).to({graphics:mask_26_graphics_86,x:468.1805,y:591.7041}).wait(1).to({graphics:mask_26_graphics_87,x:468.2092,y:591.7351}).wait(1).to({graphics:mask_26_graphics_88,x:468.2394,y:591.768}).wait(1).to({graphics:mask_26_graphics_89,x:468.2709,y:591.8017}).wait(1).to({graphics:mask_26_graphics_90,x:468.3038,y:591.8373}).wait(1).to({graphics:mask_26_graphics_91,x:468.338,y:591.8751}).wait(1).to({graphics:mask_26_graphics_92,x:468.3735,y:591.9138}).wait(1).to({graphics:mask_26_graphics_93,x:468.4113,y:591.9539}).wait(1).to({graphics:mask_26_graphics_94,x:468.4495,y:591.9957}).wait(1).to({graphics:mask_26_graphics_95,x:468.4896,y:592.0389}).wait(1).to({graphics:mask_26_graphics_96,x:468.531,y:592.0834}).wait(1).to({graphics:mask_26_graphics_97,x:468.5733,y:592.1298}).wait(1).to({graphics:mask_26_graphics_98,x:468.6174,y:592.1779}).wait(1).to({graphics:mask_26_graphics_99,x:468.6628,y:592.227}).wait(1).to({graphics:mask_26_graphics_100,x:468.7101,y:592.2778}).wait(1).to({graphics:mask_26_graphics_101,x:468.7587,y:592.3305}).wait(1).to({graphics:mask_26_graphics_102,x:468.8082,y:592.384}).wait(1).to({graphics:mask_26_graphics_103,x:468.859,y:592.4398}).wait(1).to({graphics:mask_26_graphics_104,x:468.9117,y:592.4966}).wait(1).to({graphics:mask_26_graphics_105,x:468.9657,y:592.555}).wait(1).to({graphics:mask_26_graphics_106,x:469.021,y:592.6154}).wait(1).to({graphics:mask_26_graphics_107,x:469.0764,y:592.6752}).wait(1).to({graphics:mask_26_graphics_108,x:469.1304,y:592.7337}).wait(1).to({graphics:mask_26_graphics_109,x:469.183,y:592.7908}).wait(1).to({graphics:mask_26_graphics_110,x:469.2343,y:592.8462}).wait(1).to({graphics:mask_26_graphics_111,x:469.2838,y:592.9002}).wait(1).to({graphics:mask_26_graphics_112,x:469.332,y:592.9524}).wait(1).to({graphics:mask_26_graphics_113,x:469.3792,y:593.0033}).wait(1).to({graphics:mask_26_graphics_114,x:469.4247,y:593.0527}).wait(1).to({graphics:mask_26_graphics_115,x:469.4688,y:593.1004}).wait(1).to({graphics:mask_26_graphics_116,x:469.5116,y:593.1468}).wait(1).to({graphics:mask_26_graphics_117,x:469.5525,y:593.1913}).wait(1).to({graphics:mask_26_graphics_118,x:469.5926,y:593.235}).wait(1).to({graphics:mask_26_graphics_119,x:469.6312,y:593.2769}).wait(1).to({graphics:mask_26_graphics_120,x:469.6686,y:593.3169}).wait(1).to({graphics:mask_26_graphics_121,x:469.7041,y:593.356}).wait(1).to({graphics:mask_26_graphics_122,x:469.7383,y:593.3929}).wait(1).to({graphics:mask_26_graphics_123,x:469.7717,y:593.4285}).wait(1).to({graphics:mask_26_graphics_124,x:469.8031,y:593.4631}).wait(1).to({graphics:mask_26_graphics_125,x:469.8333,y:593.4955}).wait(1).to({graphics:mask_26_graphics_126,x:469.8616,y:593.5266}).wait(1).to({graphics:mask_26_graphics_127,x:469.8891,y:593.5563}).wait(1).to({graphics:mask_26_graphics_128,x:469.9147,y:593.5847}).wait(1).to({graphics:mask_26_graphics_129,x:469.939,y:593.6112}).wait(1).to({graphics:mask_26_graphics_130,x:469.9624,y:593.6359}).wait(1).to({graphics:mask_26_graphics_131,x:469.984,y:593.6598}).wait(1).to({graphics:mask_26_graphics_132,x:470.0047,y:593.6814}).wait(1).to({graphics:mask_26_graphics_133,x:470.0236,y:593.7021}).wait(1).to({graphics:mask_26_graphics_134,x:470.0407,y:593.721}).wait(1).to({graphics:mask_26_graphics_135,x:470.0569,y:593.7385}).wait(1).to({graphics:mask_26_graphics_136,x:470.0718,y:593.7543}).wait(1).to({graphics:mask_26_graphics_137,x:470.0853,y:593.7687}).wait(1).to({graphics:mask_26_graphics_138,x:470.097,y:593.7818}).wait(1).to({graphics:mask_26_graphics_139,x:470.1073,y:593.793}).wait(1).to({graphics:mask_26_graphics_140,x:470.1168,y:593.8029}).wait(1).to({graphics:mask_26_graphics_141,x:470.124,y:593.811}).wait(1).to({graphics:mask_26_graphics_142,x:470.1307,y:593.8182}).wait(1).to({graphics:mask_26_graphics_143,x:470.1352,y:593.8236}).wait(1).to({graphics:mask_26_graphics_144,x:470.1388,y:593.8272}).wait(1).to({graphics:mask_26_graphics_145,x:470.1411,y:593.8299}).wait(1).to({graphics:mask_26_graphics_146,x:471.9141,y:595.5574}).wait(664));

	// Layer_3
	this.instance_46 = new lib.Tween22("synched",0);
	this.instance_46.setTransform(465.7,649.05);
	this.instance_46.alpha = 0.5;
	this.instance_46._off = true;

	var maskedShapeInstanceList = [this.instance_46];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_26;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_46).wait(66).to({_off:false},0).to({alpha:0.9883},80,cjs.Ease.quadInOut).wait(664));

	// Layer_8
	this.instance_47 = new lib.Tween18("synched",2);
	this.instance_47.setTransform(82.6,308.7,0.4569,0.4566,0,0,0,0,0.1);
	this.instance_47._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_47).wait(128).to({_off:false},0).to({startPosition:171},255).wait(427));

	// Layer_6 (mask)
	var mask_27 = new cjs.Shape();
	mask_27._off = true;
	var mask_27_graphics_128 = new cjs.Graphics().p("AgqApQgRgRAAgYIAAAAQAAgXARgRIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQARARAAAXIAAAAQAAAYgRARIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_27_graphics_129 = new cjs.Graphics().p("AgqApQgSgRAAgYIAAAAQAAgXASgRIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQASARAAAXIAAAAQAAAYgSARIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_27_graphics_130 = new cjs.Graphics().p("AgqAqQgSgSAAgYIAAAAQAAgXASgSIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQASASAAAXIAAAAQAAAYgSASIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_27_graphics_131 = new cjs.Graphics().p("AgrAqQgSgRAAgZIAAAAQAAgYASgRIAAAAQASgSAZAAIAAAAQAaAAASASIAAAAQASARAAAYIAAAAQAAAZgSARIAAAAQgSASgaAAIAAAAQgZAAgSgSg");
	var mask_27_graphics_132 = new cjs.Graphics().p("AgsArQgTgSAAgZIAAAAQAAgYATgSIAAAAQATgSAZAAIAAAAQAaAAATASIAAAAQATASAAAYIAAAAQAAAZgTASIAAAAQgTASgaAAIAAAAQgZAAgTgSg");
	var mask_27_graphics_133 = new cjs.Graphics().p("AgtAsQgUgSAAgaIAAAAQAAgZAUgTIAAAAQATgSAaAAIAAAAQAbAAATASIAAAAQAUATAAAZIAAAAQAAAagUASIAAAAQgTATgbAAIAAAAQgaAAgTgTg");
	var mask_27_graphics_134 = new cjs.Graphics().p("AgvAuQgUgTAAgbIAAAAQAAgaAUgTIAAAAQAUgTAbAAIAAAAQAcAAAUATIAAAAQAUATAAAaIAAAAQAAAbgUATIAAAAQgUATgcAAIAAAAQgbAAgUgTg");
	var mask_27_graphics_135 = new cjs.Graphics().p("AgxAwQgVgUAAgcIAAAAQAAgbAVgUIAAAAQAVgUAcAAIAAAAQAdAAAVAUIAAAAQAVAUAAAbIAAAAQAAAcgVAUIAAAAQgVAUgdAAIAAAAQgcAAgVgUg");
	var mask_27_graphics_136 = new cjs.Graphics().p("AgzAyQgWgVAAgdIAAAAQAAgcAWgVIAAAAQAVgVAeAAIAAAAQAfAAAVAVIAAAAQAWAVAAAcIAAAAQAAAdgWAVIAAAAQgVAVgfAAIAAAAQgeAAgVgVg");
	var mask_27_graphics_137 = new cjs.Graphics().p("Ag2A0QgWgVAAgfIAAAAQAAgeAWgVIAAAAQAXgWAfAAIAAAAQAgAAAXAWIAAAAQAWAVAAAeIAAAAQAAAfgWAVIAAAAQgXAWggAAIAAAAQgfAAgXgWg");
	var mask_27_graphics_138 = new cjs.Graphics().p("Ag4A3QgYgXAAggIAAAAQAAgfAYgXIAAAAQAXgXAhAAIAAAAQAiAAAXAXIAAAAQAYAXAAAfIAAAAQAAAggYAXIAAAAQgXAXgiAAIAAAAQghAAgXgXg");
	var mask_27_graphics_139 = new cjs.Graphics().p("Ag8A6QgZgYAAgiIAAAAQAAghAZgYIAAAAQAagYAiAAIAAAAQAjAAAaAYIAAAAQAZAYAAAhIAAAAQAAAigZAYIAAAAQgaAYgjAAIAAAAQgiAAgagYg");
	var mask_27_graphics_140 = new cjs.Graphics().p("Ag/A9QgagZAAgkIAAAAQAAgjAagZIAAAAQAbgaAkAAIAAAAQAlAAAbAaIAAAAQAaAZAAAjIAAAAQAAAkgaAZIAAAAQgbAaglAAIAAAAQgkAAgbgag");
	var mask_27_graphics_141 = new cjs.Graphics().p("AhDBBQgcgbAAgmIAAAAQAAglAcgbIAAAAQAcgbAnAAIAAAAQAoAAAcAbIAAAAQAcAbAAAlIAAAAQAAAmgcAbIAAAAQgcAbgoAAIAAAAQgnAAgcgbg");
	var mask_27_graphics_142 = new cjs.Graphics().p("AhHBFQgdgdAAgoIAAAAQAAgnAdgdIAAAAQAegcApAAIAAAAQAqAAAeAcIAAAAQAdAdAAAnIAAAAQAAAogdAdIAAAAQgeAcgqAAIAAAAQgpAAgegcg");
	var mask_27_graphics_143 = new cjs.Graphics().p("AhLBJQgfgeAAgrIAAAAQAAgqAfgeIAAAAQAggeArAAIAAAAQAsAAAgAeIAAAAQAfAeAAAqIAAAAQAAArgfAeIAAAAQggAegsAAIAAAAQgrAAgggeg");
	var mask_27_graphics_144 = new cjs.Graphics().p("AhPBNQgiggAAgtIAAAAQAAgsAiggIAAAAQAhggAuAAIAAAAQAvAAAhAgIAAAAQAiAgAAAsIAAAAQAAAtgiAgIAAAAQghAggvAAIAAAAQguAAghggg");
	var mask_27_graphics_145 = new cjs.Graphics().p("AhUBSQgkgiAAgwIAAAAQAAgvAkgiIAAAAQAjgiAxAAIAAAAQAyAAAjAiIAAAAQAkAiAAAvIAAAAQAAAwgkAiIAAAAQgjAigyAAIAAAAQgxAAgjgig");
	var mask_27_graphics_146 = new cjs.Graphics().p("AhZBXQgmgkAAgzIAAAAQAAgyAmgkIAAAAQAlgkA0AAIAAAAQA1AAAlAkIAAAAQAmAkAAAyIAAAAQAAAzgmAkIAAAAQglAkg1AAIAAAAQg0AAglgkg");
	var mask_27_graphics_147 = new cjs.Graphics().p("AhfBcQgogmAAg2IAAAAQAAg1AogmIAAAAQAogmA3AAIAAAAQA4AAAoAmIAAAAQAoAmAAA1IAAAAQAAA2goAmIAAAAQgoAmg4AAIAAAAQg3AAgogmg");
	var mask_27_graphics_148 = new cjs.Graphics().p("AhlBhQgqgoAAg5IAAAAQAAg4AqgoIAAAAQAqgpA7AAIAAAAQA8AAAqApIAAAAQAqAoAAA4IAAAAQAAA5gqAoIAAAAQgqApg8AAIAAAAQg7AAgqgpg");
	var mask_27_graphics_149 = new cjs.Graphics().p("AhrBnQgsgrAAg8IAAAAQAAg7AsgrIAAAAQAtgrA+AAIAAAAQA/AAAtArIAAAAQAsArAAA7IAAAAQAAA8gsArIAAAAQgtArg/AAIAAAAQg+AAgtgrg");
	var mask_27_graphics_150 = new cjs.Graphics().p("AhxBtQgvgtAAhAIAAAAQAAg/AvgtIAAAAQAvgtBCAAIAAAAQBDAAAvAtIAAAAQAvAtAAA/IAAAAQAABAgvAtIAAAAQgvAthDAAIAAAAQhCAAgvgtg");
	var mask_27_graphics_151 = new cjs.Graphics().p("Ah4B0QgygwAAhEIAAAAQAAhDAygwIAAAAQAygvBGAAIAAAAQBHAAAyAvIAAAAQAyAwAABDIAAAAQAABEgyAwIAAAAQgyAvhHAAIAAAAQhGAAgygvg");
	var mask_27_graphics_152 = new cjs.Graphics().p("Ah/B6Qg0gyAAhIIAAAAQAAhHA0gyIAAAAQA1gzBKAAIAAAAQBLAAA1AzIAAAAQA0AyAABHIAAAAQAABIg0AyIAAAAQg1AzhLAAIAAAAQhKAAg1gzg");
	var mask_27_graphics_153 = new cjs.Graphics().p("AiGCBQg4g1AAhMIAAAAQAAhLA4g1IAAAAQA4g2BOAAIAAAAQBPAAA4A2IAAAAQA4A1AABLIAAAAQAABMg4A1IAAAAQg4A2hPAAIAAAAQhOAAg4g2g");
	var mask_27_graphics_154 = new cjs.Graphics().p("AiNCIQg7g4AAhQIAAAAQAAhPA7g4IAAAAQA7g5BSAAIAAAAQBTAAA7A5IAAAAQA7A4AABPIAAAAQAABQg7A4IAAAAQg7A5hTAAIAAAAQhSAAg7g5g");
	var mask_27_graphics_155 = new cjs.Graphics().p("AiVCQQg+g8AAhUIAAAAQAAhTA+g8IAAAAQA+g7BXAAIAAAAQBYAAA+A7IAAAAQA+A8AABTIAAAAQAABUg+A8IAAAAQg+A7hYAAIAAAAQhXAAg+g7g");
	var mask_27_graphics_156 = new cjs.Graphics().p("AidCYQhCg/AAhZIAAAAQAAhYBCg/IAAAAQBBg+BcAAIAAAAQBdAABBA+IAAAAQBCA/AABYIAAAAQAABZhCA/IAAAAQhBA+hdAAIAAAAQhcAAhBg+g");
	var mask_27_graphics_157 = new cjs.Graphics().p("AimCgQhFhDAAhdIAAAAQAAhcBFhDIAAAAQBFhCBhAAIAAAAQBiAABFBCIAAAAQBFBDAABcIAAAAQAABdhFBDIAAAAQhFBChiAAIAAAAQhhAAhFhCg");
	var mask_27_graphics_158 = new cjs.Graphics().p("AiuCoQhJhGAAhiIAAAAQAAhhBJhGIAAAAQBIhFBmAAIAAAAQBnAABIBFIAAAAQBJBGAABhIAAAAQAABihJBGIAAAAQhIBFhnAAIAAAAQhmAAhIhFg");
	var mask_27_graphics_159 = new cjs.Graphics().p("Ai3CwQhNhJAAhnIAAAAQAAhmBNhKIAAAAQBMhJBrAAIAAAAQBsAABMBJIAAAAQBNBKAABmIAAAAQAABnhNBJIAAAAQhMBKhsAAIAAAAQhrAAhMhKg");
	var mask_27_graphics_160 = new cjs.Graphics().p("AjBC5QhQhMAAhtIAAAAQAAhsBQhMIAAAAQBRhNBwAAIAAAAQBxAABQBNIAAAAQBRBMAABsIAAAAQAABthRBMIAAAAQhQBNhxAAIAAAAQhwAAhRhNg");
	var mask_27_graphics_161 = new cjs.Graphics().p("AjKDDQhUhRAAhyIAAAAQAAhxBUhRIAAAAQBUhQB2AAIAAAAQB3AABUBQIAAAAQBUBRAABxIAAAAQAAByhUBRIAAAAQhUBQh3AAIAAAAQh2AAhUhQg");
	var mask_27_graphics_162 = new cjs.Graphics().p("AjUDMQhYhUAAh4IAAAAQAAh3BYhUIAAAAQBYhVB8AAIAAAAQB9AABYBVIAAAAQBYBUAAB3IAAAAQAAB4hYBUIAAAAQhYBVh9AAIAAAAQh8AAhYhVg");
	var mask_27_graphics_163 = new cjs.Graphics().p("AjeDWQhdhZAAh9IAAAAQAAh8BdhZIAAAAQBchYCCAAIAAAAQCDAABcBYIAAAAQBdBZAAB8IAAAAQAAB9hdBZIAAAAQhcBYiDAAIAAAAQiCAAhchYg");
	var mask_27_graphics_164 = new cjs.Graphics().p("AjpDgQhghdAAiDIAAAAQAAiCBghdIAAAAQBhhcCIAAIAAAAQCJAABgBcIAAAAQBhBdAACCIAAAAQAACDhhBdIAAAAQhgBciJAAIAAAAQiIAAhhhcg");
	var mask_27_graphics_165 = new cjs.Graphics().p("AjzDqQhlhhAAiJIAAAAQAAiIBlhhIAAAAQBlhhCOAAIAAAAQCPAABlBhIAAAAQBlBhAACIIAAAAQAACJhlBhIAAAAQhlBhiPAAIAAAAQiOAAhlhhg");
	var mask_27_graphics_166 = new cjs.Graphics().p("Aj+D1QhqhmAAiPIAAAAQAAiOBqhmIAAAAQBphlCVAAIAAAAQCWAABpBlIAAAAQBqBmAACOIAAAAQAACPhqBmIAAAAQhpBliWAAIAAAAQiVAAhphlg");
	var mask_27_graphics_167 = new cjs.Graphics().p("AkKD/QhuhpAAiWIAAAAQAAiVBuhqIAAAAQBvhpCbAAIAAAAQCcAABvBpIAAAAQBuBqAACVIAAAAQAACWhuBpIAAAAQhvBqicAAIAAAAQibAAhvhqg");
	var mask_27_graphics_168 = new cjs.Graphics().p("AkVELQh0hvAAicIAAAAQAAibB0hvIAAAAQBzhuCiAAIAAAAQCjAABzBuIAAAAQB0BvAACbIAAAAQAACch0BvIAAAAQhzBuijAAIAAAAQiiAAhzhug");
	var mask_27_graphics_169 = new cjs.Graphics().p("AkhEWQh4hzAAijIAAAAQAAiiB4hzIAAAAQB4hzCpAAIAAAAQCqAAB4BzIAAAAQB4BzAACiIAAAAQAACjh4BzIAAAAQh4BziqAAIAAAAQipAAh4hzg");
	var mask_27_graphics_170 = new cjs.Graphics().p("AkuEiQh9h4AAiqIAAAAQAAipB9h4IAAAAQB+h4CwAAIAAAAQCxAAB9B4IAAAAQB+B4AACpIAAAAQAACqh+B4IAAAAQh9B4ixAAIAAAAQiwAAh+h4g");
	var mask_27_graphics_171 = new cjs.Graphics().p("Ak6EuQiCh9AAixIAAAAQAAiwCCh9IAAAAQCDh9C3AAIAAAAQC4AACDB9IAAAAQCCB9AACwIAAAAQAACxiCB9IAAAAQiDB9i4AAIAAAAQi3AAiDh9g");
	var mask_27_graphics_172 = new cjs.Graphics().p("AlHE6QiIiCAAi4IAAAAQAAi3CIiCIAAAAQCIiCC/AAIAAAAQDAAACICCIAAAAQCICCAAC3IAAAAQAAC4iICCIAAAAQiICCjAAAIAAAAQi/AAiIiCg");
	var mask_27_graphics_173 = new cjs.Graphics().p("AlUFHQiNiIAAi/IAAAAQAAi+CNiIIAAAAQCNiHDHAAIAAAAQDIAACNCHIAAAAQCNCIAAC+IAAAAQAAC/iNCIIAAAAQiNCHjIAAIAAAAQjHAAiNiHg");
	var mask_27_graphics_174 = new cjs.Graphics().p("AlhFTQiTiMAAjHIAAAAQAAjGCTiNIAAAAQCTiMDOAAIAAAAQDQAACSCMIAAAAQCTCNAADGIAAAAQAADHiTCMIAAAAQiSCNjQAAIAAAAQjOAAiTiNg");
	var mask_27_graphics_175 = new cjs.Graphics().p("AlvFgQiYiRAAjPIAAAAQAAjOCYiSIAAAAQCYiSDXAAIAAAAQDYAACYCSIAAAAQCYCSAADOIAAAAQAADPiYCRIAAAAQiYCTjYAAIAAAAQjXAAiYiTg");
	var mask_27_graphics_176 = new cjs.Graphics().p("Al9FuQieiYAAjWIAAAAQAAjVCeiYIAAAAQCeiYDfAAIAAAAQDgAACeCYIAAAAQCeCYAADVIAAAAQAADWieCYIAAAAQieCYjgAAIAAAAQjfAAieiYg");
	var mask_27_graphics_177 = new cjs.Graphics().p("AmLF8QikieAAjeIAAAAQAAjdCkieIAAAAQCkidDnAAIAAAAQDoAACkCdIAAAAQCkCeAADdIAAAAQAADeikCeIAAAAQikCdjoAAIAAAAQjnAAikidg");
	var mask_27_graphics_178 = new cjs.Graphics().p("AmaGKQiqijAAjnIAAAAQAAjmCqijIAAAAQCqijDwAAIAAAAQDxAACqCjIAAAAQCqCjAADmIAAAAQAADniqCjIAAAAQiqCjjxAAIAAAAQjwAAiqijg");
	var mask_27_graphics_179 = new cjs.Graphics().p("AmpGYQiwipAAjvIAAAAQAAjuCwipIAAAAQCxipD4AAIAAAAQD5AACxCpIAAAAQCwCpAADuIAAAAQAADviwCpIAAAAQixCpj5AAIAAAAQj4AAixipg");
	var mask_27_graphics_180 = new cjs.Graphics().p("Am4GmQi2ivAAj3IAAAAQAAj2C2iwIAAAAQC3iuEBAAIAAAAQECAAC3CuIAAAAQC2CwAAD2IAAAAQAAD3i2CvIAAAAQi3CvkCAAIAAAAQkBAAi3ivg");
	var mask_27_graphics_181 = new cjs.Graphics().p("AnHG1Qi9i1AAkAIAAAAQAAj/C9i1IAAAAQC9i1EKAAIAAAAQELAAC9C1IAAAAQC9C1AAD/IAAAAQAAEAi9C1IAAAAQi9C1kLAAIAAAAQkKAAi9i1g");
	var mask_27_graphics_182 = new cjs.Graphics().p("AnXHEQjEi7AAkJIAAAAQAAkIDEi7IAAAAQDEi8ETAAIAAAAQEUAADEC8IAAAAQDEC7AAEIIAAAAQAAEJjEC7IAAAAQjEC8kUAAIAAAAQkTAAjEi8g");
	var mask_27_graphics_183 = new cjs.Graphics().p("AnnHUQjKjCAAkSIAAAAQAAkRDKjCIAAAAQDKjBEdAAIAAAAQEeAADKDBIAAAAQDKDCAAERIAAAAQAAESjKDCIAAAAQjKDBkeAAIAAAAQkdAAjKjBg");
	var mask_27_graphics_184 = new cjs.Graphics().p("An4HjQjQjIAAkbIAAAAQAAkaDQjIIAAAAQDSjJEmAAIAAAAQEnAADRDJIAAAAQDRDIAAEaIAAAAQAAEbjRDIIAAAAQjRDJknAAIAAAAQkmAAjSjJg");
	var mask_27_graphics_185 = new cjs.Graphics().p("AoIHzQjYjPAAkkIAAAAQAAkjDYjPIAAAAQDYjPEwAAIAAAAQExAADYDPIAAAAQDYDPAAEjIAAAAQAAEkjYDPIAAAAQjYDPkxAAIAAAAQkwAAjYjPg");
	var mask_27_graphics_186 = new cjs.Graphics().p("AoZIDQjfjVAAkuIAAAAQAAktDfjWIAAAAQDfjVE6AAIAAAAQE7AADfDVIAAAAQDfDWAAEtIAAAAQAAEujfDVIAAAAQjfDWk7AAIAAAAQk6AAjfjWg");
	var mask_27_graphics_187 = new cjs.Graphics().p("AoqIUQjmjcAAk4IAAAAQAAk3DmjcIAAAAQDmjcFEAAIAAAAQFFAADmDcIAAAAQDmDcAAE3IAAAAQAAE4jmDcIAAAAQjmDclFAAIAAAAQlEAAjmjcg");
	var mask_27_graphics_188 = new cjs.Graphics().p("Ao8IlQjtjkAAlBIAAAAQAAlADtjkIAAAAQDujjFOAAIAAAAQFPAADuDjIAAAAQDtDkAAFAIAAAAQAAFBjtDkIAAAAQjuDjlPAAIAAAAQlOAAjujjg");
	var mask_27_graphics_189 = new cjs.Graphics().p("ApOI2Qj0jrAAlLIAAAAQAAlKD0jrIAAAAQD1jqFZAAIAAAAQFaAAD0DqIAAAAQD1DrAAFKIAAAAQAAFLj1DrIAAAAQj0DqlaAAIAAAAQlZAAj1jqg");
	var mask_27_graphics_190 = new cjs.Graphics().p("ApgJHQj8jxAAlWIAAAAQAAlVD8jxIAAAAQD8jyFkAAIAAAAQFlAAD8DyIAAAAQD8DxAAFVIAAAAQAAFWj8DxIAAAAQj8DyllAAIAAAAQlkAAj8jyg");
	var mask_27_graphics_191 = new cjs.Graphics().p("ApyJZQkEj5AAlgIAAAAQAAlfEEj5IAAAAQEEj5FuAAIAAAAQFvAAEED5IAAAAQEED5AAFfIAAAAQAAFgkED5IAAAAQkED5lvAAIAAAAQluAAkEj5g");
	var mask_27_graphics_192 = new cjs.Graphics().p("AqFJrQkLkBAAlqIAAAAQAAlpELkBIAAAAQEMkAF5AAIAAAAQF6AAEMEAIAAAAQELEBAAFpIAAAAQAAFqkLEBIAAAAQkMEAl6AAIAAAAQl5AAkMkAg");
	var mask_27_graphics_193 = new cjs.Graphics().p("AqYJ9QkTkIAAl1IAAAAQAAl0ETkIIAAAAQEUkHGEAAIAAAAQGFAAETEHIAAAAQEUEIAAF0IAAAAQAAF1kUEIIAAAAQkTEHmFAAIAAAAQmEAAkUkHg");
	var mask_27_graphics_194 = new cjs.Graphics().p("AqqKOQkbkPAAl/IAAAAQAAl+EbkPIAAAAQEbkPGPAAIAAAAQGQAAEbEPIAAAAQEbEPAAF+IAAAAQAAF/kbEPIAAAAQkbEPmQAAIAAAAQmPAAkbkPg");
	var mask_27_graphics_195 = new cjs.Graphics().p("Aq8KfQkikWAAmJIAAAAQAAmIEikXIAAAAQEikWGaAAIAAAAQGbAAEiEWIAAAAQEiEXAAGIIAAAAQAAGJkiEWIAAAAQkiEXmbAAIAAAAQmaAAkikXg");
	var mask_27_graphics_196 = new cjs.Graphics().p("ArOKxQkqkeAAmTIAAAAQAAmSEqkeIAAAAQEqkdGkAAIAAAAQGlAAEqEdIAAAAQEqEeAAGSIAAAAQAAGTkqEeIAAAAQkqEdmlAAIAAAAQmkAAkqkdg");
	var mask_27_graphics_197 = new cjs.Graphics().p("ArfLBQkxkkAAmdIAAAAQAAmcExklIAAAAQExkkGuAAIAAAAQGvAAExEkIAAAAQExElAAGcIAAAAQAAGdkxEkIAAAAQkxElmvAAIAAAAQmuAAkxklg");
	var mask_27_graphics_198 = new cjs.Graphics().p("ArxLSQk4krAAmnIAAAAQAAmmE4krIAAAAQE5krG4AAIAAAAQG5AAE4ErIAAAAQE5ErAAGmIAAAAQAAGnk5ErIAAAAQk4Erm5AAIAAAAQm4AAk5krg");
	var mask_27_graphics_199 = new cjs.Graphics().p("AsCLiQk/kyAAmwIAAAAQAAmvE/kyIAAAAQFAkyHCAAIAAAAQHDAAE/EyIAAAAQFAEyAAGvIAAAAQAAGwlAEyIAAAAQk/EynDAAIAAAAQnCAAlAkyg");
	var mask_27_graphics_200 = new cjs.Graphics().p("AsSLyQlGk4AAm6IAAAAQAAm5FGk4IAAAAQFGk5HMAAIAAAAQHNAAFGE5IAAAAQFGE4AAG5IAAAAQAAG6lGE4IAAAAQlGE5nNAAIAAAAQnMAAlGk5g");
	var mask_27_graphics_201 = new cjs.Graphics().p("AsjMCQlMk/AAnDIAAAAQAAnCFMk/IAAAAQFNk/HWAAIAAAAQHXAAFME/IAAAAQFNE/AAHCIAAAAQAAHDlNE/IAAAAQlME/nXAAIAAAAQnWAAlNk/g");
	var mask_27_graphics_202 = new cjs.Graphics().p("AszMRQlTlFAAnMIAAAAQAAnLFTlFIAAAAQFUlGHfAAIAAAAQHgAAFTFGIAAAAQFUFFAAHLIAAAAQAAHMlUFFIAAAAQlTFGngAAIAAAAQnfAAlUlGg");
	var mask_27_graphics_203 = new cjs.Graphics().p("AtCMgQlalLAAnVIAAAAQAAnUFalMIAAAAQFalLHoAAIAAAAQHpAAFaFLIAAAAQFaFMAAHUIAAAAQAAHVlaFLIAAAAQlaFMnpAAIAAAAQnoAAlalMg");
	var mask_27_graphics_204 = new cjs.Graphics().p("AtSMvQlglSAAndIAAAAQAAncFglSIAAAAQFhlSHxAAIAAAAQHyAAFgFSIAAAAQFhFSAAHcIAAAAQAAHdlhFSIAAAAQlgFSnyAAIAAAAQnxAAlhlSg");
	var mask_27_graphics_205 = new cjs.Graphics().p("AthM9QlnlXAAnmIAAAAQAAnlFnlYIAAAAQFnlXH6AAIAAAAQH7AAFnFXIAAAAQFnFYAAHlIAAAAQAAHmlnFXIAAAAQlnFYn7AAIAAAAQn6AAlnlYg");
	var mask_27_graphics_206 = new cjs.Graphics().p("AtwNMQltleAAnuIAAAAQAAntFtleIAAAAQFtleIDAAIAAAAQIEAAFtFeIAAAAQFtFeAAHtIAAAAQAAHultFeIAAAAQltFeoEAAIAAAAQoDAAltleg");
	var mask_27_graphics_207 = new cjs.Graphics().p("At/NaQlylkAAn2IAAAAQAAn1FylkIAAAAQF0ljILAAIAAAAQIMAAFzFjIAAAAQFzFkAAH1IAAAAQAAH2lzFkIAAAAQlzFjoMAAIAAAAQoLAAl0ljg");
	var mask_27_graphics_208 = new cjs.Graphics().p("AuNNnQl4lpAAn+IAAAAQAAn9F4lqIAAAAQF5lpIUAAIAAAAQIVAAF4FpIAAAAQF5FqAAH9IAAAAQAAH+l5FpIAAAAQl4FqoVAAIAAAAQoUAAl5lqg");
	var mask_27_graphics_209 = new cjs.Graphics().p("AubN1Ql+lvAAoGIAAAAQAAoFF+lvIAAAAQF/lvIcAAIAAAAQIdAAF+FvIAAAAQF/FvAAIFIAAAAQAAIGl/FvIAAAAQl+FvodAAIAAAAQocAAl/lvg");
	var mask_27_graphics_210 = new cjs.Graphics().p("AuoOCQmFl0AAoOIAAAAQAAoNGFl0IAAAAQGEl0IkAAIAAAAQIlAAGEF0IAAAAQGFF0AAINIAAAAQAAIOmFF0IAAAAQmEF0olAAIAAAAQokAAmEl0g");
	var mask_27_graphics_211 = new cjs.Graphics().p("Au2OPQmJl5AAoWIAAAAQAAoVGJl5IAAAAQGKl5IsAAIAAAAQItAAGJF5IAAAAQGKF5AAIVIAAAAQAAIWmKF5IAAAAQmJF5otAAIAAAAQosAAmKl5g");
	var mask_27_graphics_212 = new cjs.Graphics().p("AvDObQmPl+AAodIAAAAQAAocGPl/IAAAAQGQl+IzAAIAAAAQI0AAGQF+IAAAAQGPF/AAIcIAAAAQAAIdmPF+IAAAAQmQF/o0AAIAAAAQozAAmQl/g");
	var mask_27_graphics_213 = new cjs.Graphics().p("AvQOoQmUmEAAokIAAAAQAAojGUmEIAAAAQGVmDI7AAIAAAAQI8AAGUGDIAAAAQGVGEAAIjIAAAAQAAIkmVGEIAAAAQmUGDo8AAIAAAAQo7AAmVmDg");
	var mask_27_graphics_214 = new cjs.Graphics().p("AvcOzQmamIAAorIAAAAQAAoqGamJIAAAAQGamIJCAAIAAAAQJDAAGaGIIAAAAQGaGJAAIqIAAAAQAAIrmaGIIAAAAQmaGJpDAAIAAAAQpCAAmamJg");
	var mask_27_graphics_215 = new cjs.Graphics().p("AvpO/QmemNAAoyIAAAAQAAoxGemOIAAAAQGgmNJJAAIAAAAQJKAAGfGNIAAAAQGfGOAAIxIAAAAQAAIymfGNIAAAAQmfGOpKAAIAAAAQpJAAmgmOg");
	var mask_27_graphics_216 = new cjs.Graphics().p("Av0PLQmkmSAAo5IAAAAQAAo4GkmSIAAAAQGkmSJQAAIAAAAQJRAAGkGSIAAAAQGkGSAAI4IAAAAQAAI5mkGSIAAAAQmkGSpRAAIAAAAQpQAAmkmSg");
	var mask_27_graphics_217 = new cjs.Graphics().p("AwAPWQmomXAAo/IAAAAQAAo+GomXIAAAAQGpmXJXAAIAAAAQJYAAGpGXIAAAAQGoGXAAI+IAAAAQAAI/moGXIAAAAQmpGXpYAAIAAAAQpXAAmpmXg");
	var mask_27_graphics_218 = new cjs.Graphics().p("AwLPhQmtmbAApGIAAAAQAApFGtmbIAAAAQGtmbJeAAIAAAAQJfAAGtGbIAAAAQGtGbAAJFIAAAAQAAJGmtGbIAAAAQmtGbpfAAIAAAAQpeAAmtmbg");
	var mask_27_graphics_219 = new cjs.Graphics().p("AwWPrQmymfAApMIAAAAQAApLGymgIAAAAQGymfJkAAIAAAAQJlAAGyGfIAAAAQGyGgAAJLIAAAAQAAJMmyGfIAAAAQmyGgplAAIAAAAQpkAAmymgg");
	var mask_27_graphics_220 = new cjs.Graphics().p("AwhP1Qm2mjAApSIAAAAQAApRG2mkIAAAAQG2mkJrAAIAAAAQJsAAG2GkIAAAAQG2GkAAJRIAAAAQAAJSm2GjIAAAAQm2GlpsAAIAAAAQprAAm2mlg");
	var mask_27_graphics_221 = new cjs.Graphics().p("AwsQAQm6moAApYIAAAAQAApXG6moIAAAAQG7moJxAAIAAAAQJyAAG6GoIAAAAQG7GoAAJXIAAAAQAAJYm7GoIAAAAQm6GopyAAIAAAAQpxAAm7mog");
	var mask_27_graphics_222 = new cjs.Graphics().p("Aw2QJQm+msAApdIAAAAQAApcG+mtIAAAAQG/msJ3AAIAAAAQJ4AAG+GsIAAAAQG/GtAAJcIAAAAQAAJdm/GsIAAAAQm+Gtp4AAIAAAAQp3AAm/mtg");
	var mask_27_graphics_223 = new cjs.Graphics().p("AxAQTQnCmwAApjIAAAAQAApiHCmwIAAAAQHDmwJ9AAIAAAAQJ+AAHCGwIAAAAQHDGwAAJiIAAAAQAAJjnDGwIAAAAQnCGwp+AAIAAAAQp9AAnDmwg");
	var mask_27_graphics_224 = new cjs.Graphics().p("AxJQcQnHm0AApoIAAAAQAApnHHm0IAAAAQHHm0KCAAIAAAAQKDAAHHG0IAAAAQHHG0AAJnIAAAAQAAJonHG0IAAAAQnHG0qDAAIAAAAQqCAAnHm0g");
	var mask_27_graphics_225 = new cjs.Graphics().p("AxTQlQnKm4AAptIAAAAQAApsHKm4IAAAAQHLm4KIAAIAAAAQKJAAHKG4IAAAAQHLG4AAJsIAAAAQAAJtnLG4IAAAAQnKG4qJAAIAAAAQqIAAnLm4g");
	var mask_27_graphics_226 = new cjs.Graphics().p("AxcQtQnOm7AApyIAAAAQAApxHOm8IAAAAQHPm7KNAAIAAAAQKOAAHOG7IAAAAQHPG8AAJxIAAAAQAAJynPG7IAAAAQnOG8qOAAIAAAAQqNAAnPm8g");
	var mask_27_graphics_227 = new cjs.Graphics().p("AxkQ2QnSm/AAp3IAAAAQAAp2HSm/IAAAAQHSm+KSAAIAAAAQKTAAHSG+IAAAAQHSG/AAJ2IAAAAQAAJ3nSG/IAAAAQnSG+qTAAIAAAAQqSAAnSm+g");
	var mask_27_graphics_228 = new cjs.Graphics().p("AxtQ+QnVnCAAp8IAAAAQAAp7HVnCIAAAAQHWnCKXAAIAAAAQKYAAHVHCIAAAAQHWHCAAJ7IAAAAQAAJ8nWHCIAAAAQnVHCqYAAIAAAAQqXAAnWnCg");
	var mask_27_graphics_229 = new cjs.Graphics().p("Ax1RFQnYnEAAqBIAAAAQAAqAHYnFIAAAAQHZnFKcAAIAAAAQKdAAHYHFIAAAAQHZHFAAKAIAAAAQAAKBnZHEIAAAAQnYHGqdAAIAAAAQqcAAnZnGg");
	var mask_27_graphics_230 = new cjs.Graphics().p("Ax9RNQnbnIAAqFIAAAAQAAqEHbnIIAAAAQHdnIKgAAIAAAAQKhAAHcHIIAAAAQHcHIAAKEIAAAAQAAKFncHIIAAAAQncHIqhAAIAAAAQqgAAndnIg");
	var mask_27_graphics_231 = new cjs.Graphics().p("AyERUQnfnLAAqJIAAAAQAAqIHfnMIAAAAQHfnLKlAAIAAAAQKmAAHeHLIAAAAQHgHMAAKIIAAAAQAAKJngHLIAAAAQneHMqmAAIAAAAQqlAAnfnMg");
	var mask_27_graphics_232 = new cjs.Graphics().p("AyLRbQninOAAqNIAAAAQAAqMHinPIAAAAQHinNKpAAIAAAAQKqAAHiHNIAAAAQHiHPAAKMIAAAAQAAKNniHOIAAAAQniHOqqAAIAAAAQqpAAninOg");
	var mask_27_graphics_233 = new cjs.Graphics().p("AySRiQnlnRAAqRIAAAAQAAqQHlnRIAAAAQHlnRKtAAIAAAAQKuAAHlHRIAAAAQHlHRAAKQIAAAAQAAKRnlHRIAAAAQnlHRquAAIAAAAQqtAAnlnRg");
	var mask_27_graphics_234 = new cjs.Graphics().p("AyZRoQnnnTAAqVIAAAAQAAqUHnnUIAAAAQHonTKxAAIAAAAQKyAAHnHTIAAAAQHoHUAAKUIAAAAQAAKVnoHTIAAAAQnnHUqyAAIAAAAQqxAAnonUg");
	var mask_27_graphics_235 = new cjs.Graphics().p("AyfRuQnqnWAAqYIAAAAQAAqXHqnXIAAAAQHrnVK0AAIAAAAQK1AAHrHVIAAAAQHqHXAAKXIAAAAQAAKYnqHWIAAAAQnrHWq1AAIAAAAQq0AAnrnWg");
	var mask_27_graphics_236 = new cjs.Graphics().p("AylR0QntnYAAqcIAAAAQAAqbHtnYIAAAAQHtnYK4AAIAAAAQK5AAHtHYIAAAAQHtHYAAKbIAAAAQAAKcntHYIAAAAQntHYq5AAIAAAAQq4AAntnYg");
	var mask_27_graphics_237 = new cjs.Graphics().p("AyrR5QnvnaAAqfIAAAAQAAqeHvnbIAAAAQHwnaK7AAIAAAAQK8AAHvHaIAAAAQHwHbAAKeIAAAAQAAKfnwHaIAAAAQnvHbq8AAIAAAAQq7AAnwnbg");
	var mask_27_graphics_238 = new cjs.Graphics().p("AywR/QnyndAAqiIAAAAQAAqhHyndIAAAAQHyndK+AAIAAAAQK/AAHyHdIAAAAQHyHdAAKhIAAAAQAAKinyHdIAAAAQnyHdq/AAIAAAAQq+AAnyndg");
	var mask_27_graphics_239 = new cjs.Graphics().p("Ay2SEQnznfAAqlIAAAAQAAqkHznfIAAAAQH0nfLCAAIAAAAQLDAAHzHfIAAAAQH0HfAAKkIAAAAQAAKln0HfIAAAAQnzHfrDAAIAAAAQrCAAn0nfg");
	var mask_27_graphics_240 = new cjs.Graphics().p("Ay6SIQn2ngAAqoIAAAAQAAqnH2nhIAAAAQH2ngLEAAIAAAAQLFAAH2HgIAAAAQH2HhAAKnIAAAAQAAKon2HgIAAAAQn2HhrFAAIAAAAQrEAAn2nhg");
	var mask_27_graphics_241 = new cjs.Graphics().p("Ay/SNQn3njAAqqIAAAAQAAqpH3njIAAAAQH4niLHAAIAAAAQLIAAH3HiIAAAAQH4HjAAKpIAAAAQAAKqn4HjIAAAAQn3HirIAAIAAAAQrHAAn4nig");
	var mask_27_graphics_242 = new cjs.Graphics().p("AzDSRQn5nkAAqtIAAAAQAAqsH5nkIAAAAQH5nkLKAAIAAAAQLLAAH5HkIAAAAQH5HkAAKsIAAAAQAAKtn5HkIAAAAQn5HkrLAAIAAAAQrKAAn5nkg");
	var mask_27_graphics_243 = new cjs.Graphics().p("AzHSUQn7nlAAqvIAAAAQAAquH7nmIAAAAQH7nmLMAAIAAAAQLNAAH7HmIAAAAQH7HmAAKuIAAAAQAAKvn7HlIAAAAQn7HnrNAAIAAAAQrMAAn7nng");
	var mask_27_graphics_244 = new cjs.Graphics().p("AzLSYQn8nnAAqxIAAAAQAAqwH8noIAAAAQH9nnLOAAIAAAAQLPAAH8HnIAAAAQH9HoAAKwIAAAAQAAKxn9HnIAAAAQn8HorPAAIAAAAQrOAAn9nog");
	var mask_27_graphics_245 = new cjs.Graphics().p("AzOSbQn+noAAqzIAAAAQAAqyH+npIAAAAQH+noLQAAIAAAAQLRAAH+HoIAAAAQH+HpAAKyIAAAAQAAKzn+HoIAAAAQn+HprRAAIAAAAQrQAAn+npg");
	var mask_27_graphics_246 = new cjs.Graphics().p("AzRSeQn/npAAq1IAAAAQAAq0H/nqIAAAAQH/npLSAAIAAAAQLTAAH/HpIAAAAQH/HqAAK0IAAAAQAAK1n/HpIAAAAQn/HqrTAAIAAAAQrSAAn/nqg");
	var mask_27_graphics_247 = new cjs.Graphics().p("AzUShQoAnrAAq2IAAAAQAAq1IAnrIAAAAQIBnrLTAAIAAAAQLUAAIBHrIAAAAQIAHrAAK1IAAAAQAAK2oAHrIAAAAQoBHrrUAAIAAAAQrTAAoBnrg");
	var mask_27_graphics_248 = new cjs.Graphics().p("AzXSjQoBnrAAq4IAAAAQAAq3IBnsIAAAAQICnrLVAAIAAAAQLWAAIBHrIAAAAQICHsAAK3IAAAAQAAK4oCHrIAAAAQoBHsrWAAIAAAAQrVAAoCnsg");
	var mask_27_graphics_249 = new cjs.Graphics().p("AzZSlQoCnsAAq5IAAAAQAAq4ICntIAAAAQIDnsLWAAIAAAAQLXAAICHsIAAAAQIDHtAAK4IAAAAQAAK5oDHsIAAAAQoCHtrXAAIAAAAQrWAAoDntg");
	var mask_27_graphics_250 = new cjs.Graphics().p("AzbSnQoDntAAq6IAAAAQAAq5IDnuIAAAAQIEntLXAAIAAAAQLYAAIDHtIAAAAQIEHuAAK5IAAAAQAAK6oEHtIAAAAQoDHurYAAIAAAAQrXAAoEnug");
	var mask_27_graphics_251 = new cjs.Graphics().p("AzcSpQoEnuAAq7IAAAAQAAq6IEnuIAAAAQIEnuLYAAIAAAAQLZAAIEHuIAAAAQIEHuAAK6IAAAAQAAK7oEHuIAAAAQoEHurZAAIAAAAQrYAAoEnug");
	var mask_27_graphics_252 = new cjs.Graphics().p("AzeSqQoEnuAAq8IAAAAQAAq7IEnvIAAAAQIFnuLZAAIAAAAQLaAAIEHuIAAAAQIFHvAAK7IAAAAQAAK8oFHuIAAAAQoEHvraAAIAAAAQrZAAoFnvg");
	var mask_27_graphics_253 = new cjs.Graphics().p("AzfSrQoEnvAAq8IAAAAQAAq7IEnwIAAAAQIFnuLaAAIAAAAQLbAAIEHuIAAAAQIFHwAAK7IAAAAQAAK8oFHvIAAAAQoEHvrbAAIAAAAQraAAoFnvg");
	var mask_27_graphics_254 = new cjs.Graphics().p("AzfSsQoFnvAAq9IAAAAQAAq8IFnvIAAAAQIFnvLaAAIAAAAQLbAAIFHvIAAAAQIFHvAAK8IAAAAQAAK9oFHvIAAAAQoFHvrbAAIAAAAQraAAoFnvg");
	var mask_27_graphics_255 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_256 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_257 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_258 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_259 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_260 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_261 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_262 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_263 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_264 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_265 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_266 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_267 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_268 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_269 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_270 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_271 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_272 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_273 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_274 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_275 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_276 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_277 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_278 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_279 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_280 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_281 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_282 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_283 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_284 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_285 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_286 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_287 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_288 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_289 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_290 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_291 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_292 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_293 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_294 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_295 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_296 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_297 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_298 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_299 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_300 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_301 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_302 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_303 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_304 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_305 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_306 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_307 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_308 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_309 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_310 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_311 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_312 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_313 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_314 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_315 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_316 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_317 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_318 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_319 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_320 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_321 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_322 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_323 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_324 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_325 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_326 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_327 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_328 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_329 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_330 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_331 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_332 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_333 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_334 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_335 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_336 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_337 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_338 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_339 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_340 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_341 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_342 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_343 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_344 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_345 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_346 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_347 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_348 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_349 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_350 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_351 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_352 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_353 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_354 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_355 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_356 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_357 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_358 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_359 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_360 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_361 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_362 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_363 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_364 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_365 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_366 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_367 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_368 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_369 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_370 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_371 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_372 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_373 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_374 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_375 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_376 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_377 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_378 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_379 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_380 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_381 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_382 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");
	var mask_27_graphics_383 = new cjs.Graphics().p("AzgSsQoFnvAAq9IAAAAQAAq8IFnwIAAAAQIGnvLaAAIAAAAQLbAAIFHvIAAAAQIGHwAAK8IAAAAQAAK9oGHvIAAAAQoFHwrbAAIAAAAQraAAoGnwg");

	this.timeline.addTween(cjs.Tween.get(mask_27).to({graphics:null,x:0,y:0}).wait(128).to({graphics:mask_27_graphics_128,x:298.4008,y:544.3002}).wait(1).to({graphics:mask_27_graphics_129,x:298.4008,y:544.3011}).wait(1).to({graphics:mask_27_graphics_130,x:298.4004,y:544.3024}).wait(1).to({graphics:mask_27_graphics_131,x:298.4004,y:544.3047}).wait(1).to({graphics:mask_27_graphics_132,x:298.4004,y:544.3078}).wait(1).to({graphics:mask_27_graphics_133,x:298.4004,y:544.3128}).wait(1).to({graphics:mask_27_graphics_134,x:298.3999,y:544.3177}).wait(1).to({graphics:mask_27_graphics_135,x:298.4004,y:544.3245}).wait(1).to({graphics:mask_27_graphics_136,x:298.3999,y:544.3317}).wait(1).to({graphics:mask_27_graphics_137,x:298.3999,y:544.3398}).wait(1).to({graphics:mask_27_graphics_138,x:298.3995,y:544.3492}).wait(1).to({graphics:mask_27_graphics_139,x:298.3995,y:544.3596}).wait(1).to({graphics:mask_27_graphics_140,x:298.3995,y:544.3708}).wait(1).to({graphics:mask_27_graphics_141,x:298.399,y:544.383}).wait(1).to({graphics:mask_27_graphics_142,x:298.3986,y:544.396}).wait(1).to({graphics:mask_27_graphics_143,x:298.3986,y:544.4104}).wait(1).to({graphics:mask_27_graphics_144,x:298.3981,y:544.4258}).wait(1).to({graphics:mask_27_graphics_145,x:298.3981,y:544.4415}).wait(1).to({graphics:mask_27_graphics_146,x:298.3977,y:544.459}).wait(1).to({graphics:mask_27_graphics_147,x:298.3968,y:544.4775}).wait(1).to({graphics:mask_27_graphics_148,x:298.3968,y:544.4959}).wait(1).to({graphics:mask_27_graphics_149,x:298.3963,y:544.5166}).wait(1).to({graphics:mask_27_graphics_150,x:298.3963,y:544.5373}).wait(1).to({graphics:mask_27_graphics_151,x:298.3954,y:544.5594}).wait(1).to({graphics:mask_27_graphics_152,x:298.395,y:544.5828}).wait(1).to({graphics:mask_27_graphics_153,x:298.3945,y:544.6066}).wait(1).to({graphics:mask_27_graphics_154,x:298.3941,y:544.6318}).wait(1).to({graphics:mask_27_graphics_155,x:298.3936,y:544.658}).wait(1).to({graphics:mask_27_graphics_156,x:298.3932,y:544.6845}).wait(1).to({graphics:mask_27_graphics_157,x:298.3927,y:544.7124}).wait(1).to({graphics:mask_27_graphics_158,x:298.3918,y:544.7412}).wait(1).to({graphics:mask_27_graphics_159,x:298.3918,y:544.7713}).wait(1).to({graphics:mask_27_graphics_160,x:298.3909,y:544.8019}).wait(1).to({graphics:mask_27_graphics_161,x:298.3905,y:544.8344}).wait(1).to({graphics:mask_27_graphics_162,x:298.3896,y:544.8667}).wait(1).to({graphics:mask_27_graphics_163,x:298.3887,y:544.9009}).wait(1).to({graphics:mask_27_graphics_164,x:298.3882,y:544.9356}).wait(1).to({graphics:mask_27_graphics_165,x:298.3878,y:544.9711}).wait(1).to({graphics:mask_27_graphics_166,x:298.3873,y:545.0081}).wait(1).to({graphics:mask_27_graphics_167,x:298.3864,y:545.0459}).wait(1).to({graphics:mask_27_graphics_168,x:298.3855,y:545.0841}).wait(1).to({graphics:mask_27_graphics_169,x:298.3846,y:545.1241}).wait(1).to({graphics:mask_27_graphics_170,x:298.3837,y:545.1647}).wait(1).to({graphics:mask_27_graphics_171,x:298.3833,y:545.2065}).wait(1).to({graphics:mask_27_graphics_172,x:298.382,y:545.2488}).wait(1).to({graphics:mask_27_graphics_173,x:298.382,y:545.2929}).wait(1).to({graphics:mask_27_graphics_174,x:298.3806,y:545.3374}).wait(1).to({graphics:mask_27_graphics_175,x:298.3797,y:545.3829}).wait(1).to({graphics:mask_27_graphics_176,x:298.3788,y:545.4292}).wait(1).to({graphics:mask_27_graphics_177,x:298.3779,y:545.4769}).wait(1).to({graphics:mask_27_graphics_178,x:298.377,y:545.5255}).wait(1).to({graphics:mask_27_graphics_179,x:298.3761,y:545.575}).wait(1).to({graphics:mask_27_graphics_180,x:298.3752,y:545.6254}).wait(1).to({graphics:mask_27_graphics_181,x:298.3743,y:545.6772}).wait(1).to({graphics:mask_27_graphics_182,x:298.3734,y:545.7294}).wait(1).to({graphics:mask_27_graphics_183,x:298.372,y:545.7825}).wait(1).to({graphics:mask_27_graphics_184,x:298.3711,y:545.837}).wait(1).to({graphics:mask_27_graphics_185,x:298.3698,y:545.8927}).wait(1).to({graphics:mask_27_graphics_186,x:298.3689,y:545.949}).wait(1).to({graphics:mask_27_graphics_187,x:298.368,y:546.0061}).wait(1).to({graphics:mask_27_graphics_188,x:298.3671,y:546.0642}).wait(1).to({graphics:mask_27_graphics_189,x:298.3657,y:546.124}).wait(1).to({graphics:mask_27_graphics_190,x:298.3644,y:546.1839}).wait(1).to({graphics:mask_27_graphics_191,x:298.363,y:546.2456}).wait(1).to({graphics:mask_27_graphics_192,x:298.3621,y:546.3076}).wait(1).to({graphics:mask_27_graphics_193,x:298.3608,y:546.3702}).wait(1).to({graphics:mask_27_graphics_194,x:298.3594,y:546.4314}).wait(1).to({graphics:mask_27_graphics_195,x:298.3585,y:546.4912}).wait(1).to({graphics:mask_27_graphics_196,x:298.3572,y:546.5506}).wait(1).to({graphics:mask_27_graphics_197,x:298.3563,y:546.6091}).wait(1).to({graphics:mask_27_graphics_198,x:298.3554,y:546.6663}).wait(1).to({graphics:mask_27_graphics_199,x:298.354,y:546.7225}).wait(1).to({graphics:mask_27_graphics_200,x:298.3531,y:546.7783}).wait(1).to({graphics:mask_27_graphics_201,x:298.3522,y:546.8328}).wait(1).to({graphics:mask_27_graphics_202,x:298.3509,y:546.8859}).wait(1).to({graphics:mask_27_graphics_203,x:298.35,y:546.9381}).wait(1).to({graphics:mask_27_graphics_204,x:298.3486,y:546.9898}).wait(1).to({graphics:mask_27_graphics_205,x:298.3477,y:547.0402}).wait(1).to({graphics:mask_27_graphics_206,x:298.3473,y:547.0897}).wait(1).to({graphics:mask_27_graphics_207,x:298.3464,y:547.1383}).wait(1).to({graphics:mask_27_graphics_208,x:298.345,y:547.1861}).wait(1).to({graphics:mask_27_graphics_209,x:298.3446,y:547.2324}).wait(1).to({graphics:mask_27_graphics_210,x:298.3433,y:547.2778}).wait(1).to({graphics:mask_27_graphics_211,x:298.3423,y:547.3224}).wait(1).to({graphics:mask_27_graphics_212,x:298.3414,y:547.366}).wait(1).to({graphics:mask_27_graphics_213,x:298.341,y:547.4088}).wait(1).to({graphics:mask_27_graphics_214,x:298.3401,y:547.4507}).wait(1).to({graphics:mask_27_graphics_215,x:298.3392,y:547.4911}).wait(1).to({graphics:mask_27_graphics_216,x:298.3388,y:547.5312}).wait(1).to({graphics:mask_27_graphics_217,x:298.3378,y:547.5699}).wait(1).to({graphics:mask_27_graphics_218,x:298.3369,y:547.6077}).wait(1).to({graphics:mask_27_graphics_219,x:298.3365,y:547.6441}).wait(1).to({graphics:mask_27_graphics_220,x:298.3361,y:547.6801}).wait(1).to({graphics:mask_27_graphics_221,x:298.3347,y:547.7144}).wait(1).to({graphics:mask_27_graphics_222,x:298.3343,y:547.7486}).wait(1).to({graphics:mask_27_graphics_223,x:298.3338,y:547.7814}).wait(1).to({graphics:mask_27_graphics_224,x:298.3329,y:547.8129}).wait(1).to({graphics:mask_27_graphics_225,x:298.3325,y:547.8439}).wait(1).to({graphics:mask_27_graphics_226,x:298.332,y:547.8741}).wait(1).to({graphics:mask_27_graphics_227,x:298.3316,y:547.9029}).wait(1).to({graphics:mask_27_graphics_228,x:298.3306,y:547.9308}).wait(1).to({graphics:mask_27_graphics_229,x:298.3307,y:547.9578}).wait(1).to({graphics:mask_27_graphics_230,x:298.3298,y:547.9839}).wait(1).to({graphics:mask_27_graphics_231,x:298.3297,y:548.0086}).wait(1).to({graphics:mask_27_graphics_232,x:298.3288,y:548.0325}).wait(1).to({graphics:mask_27_graphics_233,x:298.3288,y:548.0559}).wait(1).to({graphics:mask_27_graphics_234,x:298.3279,y:548.0779}).wait(1).to({graphics:mask_27_graphics_235,x:298.3275,y:548.0986}).wait(1).to({graphics:mask_27_graphics_236,x:298.3275,y:548.1189}).wait(1).to({graphics:mask_27_graphics_237,x:298.3266,y:548.1382}).wait(1).to({graphics:mask_27_graphics_238,x:298.3266,y:548.1563}).wait(1).to({graphics:mask_27_graphics_239,x:298.3261,y:548.1734}).wait(1).to({graphics:mask_27_graphics_240,x:298.3257,y:548.1895}).wait(1).to({graphics:mask_27_graphics_241,x:298.3257,y:548.2048}).wait(1).to({graphics:mask_27_graphics_242,x:298.3252,y:548.2192}).wait(1).to({graphics:mask_27_graphics_243,x:298.3248,y:548.2323}).wait(1).to({graphics:mask_27_graphics_244,x:298.3248,y:548.2444}).wait(1).to({graphics:mask_27_graphics_245,x:298.3248,y:548.2557}).wait(1).to({graphics:mask_27_graphics_246,x:298.3248,y:548.2661}).wait(1).to({graphics:mask_27_graphics_247,x:298.3243,y:548.275}).wait(1).to({graphics:mask_27_graphics_248,x:298.3239,y:548.284}).wait(1).to({graphics:mask_27_graphics_249,x:298.3239,y:548.2908}).wait(1).to({graphics:mask_27_graphics_250,x:298.3239,y:548.2971}).wait(1).to({graphics:mask_27_graphics_251,x:298.3239,y:548.3025}).wait(1).to({graphics:mask_27_graphics_252,x:298.3234,y:548.3074}).wait(1).to({graphics:mask_27_graphics_253,x:298.3234,y:548.3106}).wait(1).to({graphics:mask_27_graphics_254,x:298.3239,y:548.3128}).wait(1).to({graphics:mask_27_graphics_255,x:298.3235,y:548.3142}).wait(1).to({graphics:mask_27_graphics_256,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_257,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_258,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_259,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_260,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_261,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_262,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_263,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_264,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_265,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_266,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_267,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_268,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_269,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_270,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_271,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_272,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_273,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_274,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_275,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_276,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_277,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_278,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_279,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_280,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_281,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_282,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_283,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_284,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_285,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_286,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_287,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_288,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_289,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_290,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_291,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_292,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_293,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_294,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_295,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_296,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_297,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_298,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_299,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_300,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_301,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_302,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_303,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_304,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_305,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_306,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_307,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_308,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_309,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_310,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_311,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_312,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_313,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_314,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_315,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_316,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_317,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_318,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_319,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_320,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_321,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_322,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_323,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_324,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_325,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_326,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_327,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_328,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_329,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_330,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_331,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_332,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_333,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_334,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_335,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_336,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_337,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_338,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_339,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_340,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_341,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_342,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_343,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_344,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_345,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_346,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_347,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_348,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_349,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_350,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_351,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_352,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_353,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_354,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_355,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_356,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_357,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_358,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_359,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_360,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_361,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_362,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_363,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_364,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_365,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_366,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_367,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_368,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_369,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_370,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_371,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_372,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_373,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_374,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_375,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_376,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_377,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_378,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_379,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_380,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_381,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_382,x:298.2677,y:548.2589}).wait(1).to({graphics:mask_27_graphics_383,x:298.2677,y:548.2589}).wait(427));

	// Layer_9
	this.instance_48 = new lib.Tween19("synched",0);
	this.instance_48.setTransform(265.9,496.85);
	this.instance_48.alpha = 0.5;
	this.instance_48._off = true;

	var maskedShapeInstanceList = [this.instance_48];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_27;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_48).wait(128).to({_off:false},0).to({alpha:0.7891},74).to({alpha:1},54).to({startPosition:0},127).wait(427));

	// Layer_6 (mask)
	var mask_28 = new cjs.Shape();
	mask_28._off = true;
	var mask_28_graphics_87 = new cjs.Graphics().p("AgqApQgRgRAAgYIAAAAQAAgXARgRIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQARARAAAXIAAAAQAAAYgRARIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_28_graphics_88 = new cjs.Graphics().p("AgqApQgSgRAAgYIAAAAQAAgXASgRIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQASARAAAXIAAAAQAAAYgSARIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_28_graphics_89 = new cjs.Graphics().p("AgqApQgSgRAAgYIAAAAQAAgXASgRIAAAAQASgSAYAAIAAAAQAZAAASASIAAAAQASARAAAXIAAAAQAAAYgSARIAAAAQgSASgZAAIAAAAQgYAAgSgSg");
	var mask_28_graphics_90 = new cjs.Graphics().p("AgrAqQgSgRAAgZIAAAAQAAgYASgRIAAAAQASgRAZAAIAAAAQAaAAASARIAAAAQASARAAAYIAAAAQAAAZgSARIAAAAQgSARgaAAIAAAAQgZAAgSgRg");
	var mask_28_graphics_91 = new cjs.Graphics().p("AgsArQgSgSAAgZIAAAAQAAgYASgSIAAAAQATgSAZAAIAAAAQAaAAATASIAAAAQASASAAAYIAAAAQAAAZgSASIAAAAQgTASgaAAIAAAAQgZAAgTgSg");
	var mask_28_graphics_92 = new cjs.Graphics().p("AgtAsQgTgSAAgaIAAAAQAAgZATgSIAAAAQATgSAaAAIAAAAQAbAAATASIAAAAQATASAAAZIAAAAQAAAagTASIAAAAQgTASgbAAIAAAAQgaAAgTgSg");
	var mask_28_graphics_93 = new cjs.Graphics().p("AguAtQgUgTAAgaIAAAAQAAgZAUgTIAAAAQATgTAbAAIAAAAQAcAAATATIAAAAQAUATAAAZIAAAAQAAAagUATIAAAAQgTATgcAAIAAAAQgbAAgTgTg");
	var mask_28_graphics_94 = new cjs.Graphics().p("AgwAvQgUgUAAgbIAAAAQAAgaAUgUIAAAAQAUgTAcAAIAAAAQAdAAAUATIAAAAQAUAUAAAaIAAAAQAAAbgUAUIAAAAQgUATgdAAIAAAAQgcAAgUgTg");
	var mask_28_graphics_95 = new cjs.Graphics().p("AgyAwQgVgUAAgcIAAAAQAAgbAVgUIAAAAQAVgVAdAAIAAAAQAeAAAVAVIAAAAQAVAUAAAbIAAAAQAAAcgVAUIAAAAQgVAVgeAAIAAAAQgdAAgVgVg");
	var mask_28_graphics_96 = new cjs.Graphics().p("Ag0AyQgWgUAAgeIAAAAQAAgdAWgUIAAAAQAWgVAeAAIAAAAQAfAAAWAVIAAAAQAVAUABAdIAAAAQgBAegVAUIAAAAQgWAVgfAAIAAAAQgeAAgWgVg");
	var mask_28_graphics_97 = new cjs.Graphics().p("Ag2A1QgXgWAAgfIAAAAQAAgeAXgWIAAAAQAXgWAfAAIAAAAQAgAAAXAWIAAAAQAXAWAAAeIAAAAQAAAfgXAWIAAAAQgXAWggAAIAAAAQgfAAgXgWg");
	var mask_28_graphics_98 = new cjs.Graphics().p("Ag5A3QgXgXAAggIAAAAQAAgfAXgXIAAAAQAYgXAhAAIAAAAQAiAAAYAXIAAAAQAXAXAAAfIAAAAQAAAggXAXIAAAAQgYAXgiAAIAAAAQghAAgYgXg");
	var mask_28_graphics_99 = new cjs.Graphics().p("Ag7A6QgZgYAAgiIAAAAQAAghAZgYIAAAAQAZgYAiAAIAAAAQAjAAAZAYIAAAAQAZAYAAAhIAAAAQAAAigZAYIAAAAQgZAYgjAAIAAAAQgiAAgZgYg");
	var mask_28_graphics_100 = new cjs.Graphics().p("Ag+A9QgbgZAAgkIAAAAQAAgjAbgZIAAAAQAagZAkAAIAAAAQAlAAAaAZIAAAAQAbAZAAAjIAAAAQAAAkgbAZIAAAAQgaAZglAAIAAAAQgkAAgagZg");
	var mask_28_graphics_101 = new cjs.Graphics().p("AhCBAQgbgbAAglIAAAAQAAgkAbgbIAAAAQAcgaAmAAIAAAAQAnAAAcAaIAAAAQAbAbAAAkIAAAAQAAAlgbAbIAAAAQgcAagnAAIAAAAQgmAAgcgag");
	var mask_28_graphics_102 = new cjs.Graphics().p("AhFBDQgdgcAAgnIAAAAQAAgmAdgcIAAAAQAdgcAoAAIAAAAQApAAAdAcIAAAAQAdAcAAAmIAAAAQAAAngdAcIAAAAQgdAcgpAAIAAAAQgoAAgdgcg");
	var mask_28_graphics_103 = new cjs.Graphics().p("AhJBHQgfgdAAgqIAAAAQAAgpAfgdIAAAAQAfgdAqAAIAAAAQArAAAfAdIAAAAQAfAdAAApIAAAAQAAAqgfAdIAAAAQgfAdgrAAIAAAAQgqAAgfgdg");
	var mask_28_graphics_104 = new cjs.Graphics().p("AhNBLQghgfAAgsIAAAAQAAgrAhgfIAAAAQAggfAtAAIAAAAQAuAAAgAfIAAAAQAhAfAAArIAAAAQAAAsghAfIAAAAQggAfguAAIAAAAQgtAAgggfg");
	var mask_28_graphics_105 = new cjs.Graphics().p("AhRBPQgjghAAguIAAAAQAAgtAjghIAAAAQAighAvAAIAAAAQAwAAAiAhIAAAAQAjAhAAAtIAAAAQAAAugjAhIAAAAQgiAhgwAAIAAAAQgvAAgighg");
	var mask_28_graphics_106 = new cjs.Graphics().p("AhWBTQgkgiAAgxIAAAAQAAgwAkgiIAAAAQAkgjAyAAIAAAAQAzAAAkAjIAAAAQAkAiAAAwIAAAAQAAAxgkAiIAAAAQgkAjgzAAIAAAAQgyAAgkgjg");
	var mask_28_graphics_107 = new cjs.Graphics().p("AhbBYQgmgkAAg0IAAAAQAAgzAmgkIAAAAQAmgkA1AAIAAAAQA2AAAmAkIAAAAQAmAkAAAzIAAAAQAAA0gmAkIAAAAQgmAkg2AAIAAAAQg1AAgmgkg");
	var mask_28_graphics_108 = new cjs.Graphics().p("AhgBdQgognAAg2IAAAAQAAg1AognIAAAAQAogmA4AAIAAAAQA5AAAoAmIAAAAQAoAnAAA1IAAAAQAAA2goAnIAAAAQgoAmg5AAIAAAAQg4AAgogmg");
	var mask_28_graphics_109 = new cjs.Graphics().p("AhlBiQgqgpAAg5IAAAAQAAg4AqgpIAAAAQAqgoA7AAIAAAAQA8AAAqAoIAAAAQAqApAAA4IAAAAQAAA5gqApIAAAAQgqAog8AAIAAAAQg7AAgqgog");
	var mask_28_graphics_110 = new cjs.Graphics().p("AhrBnQgsgrAAg8IAAAAQAAg7AsgrIAAAAQAtgrA+AAIAAAAQA/AAAtArIAAAAQAsArAAA7IAAAAQAAA8gsArIAAAAQgtArg/AAIAAAAQg+AAgtgrg");
	var mask_28_graphics_111 = new cjs.Graphics().p("AhwBtQgvgtAAhAIAAAAQAAg/AvgtIAAAAQAvgtBBAAIAAAAQBCAAAvAtIAAAAQAvAtAAA/IAAAAQAABAgvAtIAAAAQgvAthCAAIAAAAQhBAAgvgtg");
	var mask_28_graphics_112 = new cjs.Graphics().p("Ah2ByQgygvAAhDIAAAAQAAhCAygvIAAAAQAxgwBFAAIAAAAQBGAAAxAwIAAAAQAyAvAABCIAAAAQAABDgyAvIAAAAQgxAwhGAAIAAAAQhFAAgxgwg");
	var mask_28_graphics_113 = new cjs.Graphics().p("Ah9B4Qg0gyAAhGIAAAAQAAhFA0gyIAAAAQA0gyBJAAIAAAAQBKAAA0AyIAAAAQA0AyAABFIAAAAQAABGg0AyIAAAAQg0AyhKAAIAAAAQhJAAg0gyg");
	var mask_28_graphics_114 = new cjs.Graphics().p("AiDB/Qg3g1AAhKIAAAAQAAhJA3g1IAAAAQA3g0BMAAIAAAAQBNAAA3A0IAAAAQA3A1AABJIAAAAQAABKg3A1IAAAAQg3A0hNAAIAAAAQhMAAg3g0g");
	var mask_28_graphics_115 = new cjs.Graphics().p("AiKCFQg5g3AAhOIAAAAQAAhNA5g3IAAAAQA6g3BQAAIAAAAQBRAAA6A3IAAAAQA5A3AABNIAAAAQAABOg5A3IAAAAQg6A3hRAAIAAAAQhQAAg6g3g");
	var mask_28_graphics_116 = new cjs.Graphics().p("AiRCMQg8g6AAhSIAAAAQAAhRA8g6IAAAAQA9g6BUAAIAAAAQBVAAA9A6IAAAAQA8A6AABRIAAAAQAABSg8A6IAAAAQg9A6hVAAIAAAAQhUAAg9g6g");
	var mask_28_graphics_117 = new cjs.Graphics().p("AiYCTQg/g9AAhWIAAAAQAAhVA/g9IAAAAQA/g8BZAAIAAAAQBaAAA/A8IAAAAQA/A9AABVIAAAAQAABWg/A9IAAAAQg/A8haAAIAAAAQhZAAg/g8g");
	var mask_28_graphics_118 = new cjs.Graphics().p("AigCaQhChAAAhaIAAAAQAAhZBChAIAAAAQBDhABdAAIAAAAQBeAABCBAIAAAAQBDBAAABZIAAAAQAABahDBAIAAAAQhCBAheAAIAAAAQhdAAhDhAg");
	var mask_28_graphics_119 = new cjs.Graphics().p("AinChQhGhDAAheIAAAAQAAhdBGhDIAAAAQBFhDBiAAIAAAAQBjAABFBDIAAAAQBGBDAABdIAAAAQAABehGBDIAAAAQhFBDhjAAIAAAAQhiAAhFhDg");
	var mask_28_graphics_120 = new cjs.Graphics().p("AivCpQhJhGAAhjIAAAAQAAhiBJhGIAAAAQBJhGBmAAIAAAAQBnAABJBGIAAAAQBJBGAABiIAAAAQAABjhJBGIAAAAQhJBGhnAAIAAAAQhmAAhJhGg");
	var mask_28_graphics_121 = new cjs.Graphics().p("Ai3CxQhNhJAAhoIAAAAQAAhnBNhJIAAAAQBMhJBrAAIAAAAQBsAABMBJIAAAAQBNBJAABnIAAAAQAABohNBJIAAAAQhMBJhsAAIAAAAQhrAAhMhJg");
	var mask_28_graphics_122 = new cjs.Graphics().p("AjAC5QhQhNAAhsIAAAAQAAhrBQhNIAAAAQBQhMBwAAIAAAAQBxAABQBMIAAAAQBQBNAABrIAAAAQAABshQBNIAAAAQhQBMhxAAIAAAAQhwAAhQhMg");
	var mask_28_graphics_123 = new cjs.Graphics().p("AjJDBQhThQAAhxIAAAAQAAhwBThQIAAAAQBUhQB1AAIAAAAQB2AABUBQIAAAAQBTBQAABwIAAAAQAABxhTBQIAAAAQhUBQh2AAIAAAAQh1AAhUhQg");
	var mask_28_graphics_124 = new cjs.Graphics().p("AjSDKQhXhUAAh2IAAAAQAAh1BXhUIAAAAQBYhTB6AAIAAAAQB7AABXBTIAAAAQBYBUAAB1IAAAAQAAB2hYBUIAAAAQhXBTh7AAIAAAAQh6AAhYhTg");
	var mask_28_graphics_125 = new cjs.Graphics().p("AjbDSQhbhXAAh7IAAAAQAAh6BbhYIAAAAQBbhXCAAAIAAAAQCBAABbBXIAAAAQBbBYAAB6IAAAAQAAB7hbBXIAAAAQhbBYiBAAIAAAAQiAAAhbhYg");
	var mask_28_graphics_126 = new cjs.Graphics().p("AjkDcQhfhbAAiBIAAAAQAAiABfhbIAAAAQBfhbCFAAIAAAAQCGAABfBbIAAAAQBfBbAACAIAAAAQAACBhfBbIAAAAQhfBbiGAAIAAAAQiFAAhfhbg");
	var mask_28_graphics_127 = new cjs.Graphics().p("AjuDlQhjhfAAiGIAAAAQAAiFBjhfIAAAAQBjhfCLAAIAAAAQCMAABjBfIAAAAQBjBfAACFIAAAAQAACGhjBfIAAAAQhjBfiMAAIAAAAQiLAAhjhfg");
	var mask_28_graphics_128 = new cjs.Graphics().p("Aj4DuQhnhiAAiMIAAAAQAAiLBnhiIAAAAQBnhjCRAAIAAAAQCSAABnBjIAAAAQBnBiAACLIAAAAQAACMhnBiIAAAAQhnBjiSAAIAAAAQiRAAhnhjg");
	var mask_28_graphics_129 = new cjs.Graphics().p("AkCD4QhrhnAAiRIAAAAQAAiQBrhnIAAAAQBrhnCXAAIAAAAQCYAABrBnIAAAAQBrBnAACQIAAAAQAACRhrBnIAAAAQhrBniYAAIAAAAQiXAAhrhng");
	var mask_28_graphics_130 = new cjs.Graphics().p("AkMECQhwhrAAiXIAAAAQAAiWBwhrIAAAAQBvhrCdAAIAAAAQCeAABvBrIAAAAQBwBrAACWIAAAAQAACXhwBrIAAAAQhvBrieAAIAAAAQidAAhvhrg");
	var mask_28_graphics_131 = new cjs.Graphics().p("AkXEMQh0hvAAidIAAAAQAAicB0hvIAAAAQB0hvCjAAIAAAAQCkAAB0BvIAAAAQB0BvAACcIAAAAQAACdh0BvIAAAAQh0BvikAAIAAAAQijAAh0hvg");
	var mask_28_graphics_132 = new cjs.Graphics().p("AkiEXQh4h0AAijIAAAAQAAiiB4h0IAAAAQB5hzCpAAIAAAAQCqAAB5BzIAAAAQB4B0AACiIAAAAQAACjh4B0IAAAAQh5BziqAAIAAAAQipAAh5hzg");
	var mask_28_graphics_133 = new cjs.Graphics().p("AktEhQh9h3AAiqIAAAAQAAipB9h4IAAAAQB9h3CwAAIAAAAQCxAAB9B3IAAAAQB9B4AACpIAAAAQAACqh9B3IAAAAQh9B4ixAAIAAAAQiwAAh9h4g");
	var mask_28_graphics_134 = new cjs.Graphics().p("Ak5EsQiBh8AAiwIAAAAQAAivCBh8IAAAAQCCh9C3AAIAAAAQC4AACBB9IAAAAQCCB8AACvIAAAAQAACwiCB8IAAAAQiBB9i4AAIAAAAQi3AAiCh9g");
	var mask_28_graphics_135 = new cjs.Graphics().p("AlEE3QiHiBAAi2IAAAAQAAi1CHiCIAAAAQCHiBC9AAIAAAAQC+AACHCBIAAAAQCHCCAAC1IAAAAQAAC2iHCBIAAAAQiHCCi+AAIAAAAQi9AAiHiCg");
	var mask_28_graphics_136 = new cjs.Graphics().p("AlQFDQiMiGAAi9IAAAAQAAi8CMiGIAAAAQCMiGDEAAIAAAAQDFAACMCGIAAAAQCMCGAAC8IAAAAQAAC9iMCGIAAAAQiMCGjFAAIAAAAQjEAAiMiGg");
	var mask_28_graphics_137 = new cjs.Graphics().p("AlcFOQiRiKAAjEIAAAAQAAjDCRiLIAAAAQCQiKDMAAIAAAAQDNAACQCKIAAAAQCRCLAADDIAAAAQAADEiRCKIAAAAQiQCLjNAAIAAAAQjMAAiQiLg");
	var mask_28_graphics_138 = new cjs.Graphics().p("AlpFaQiViPAAjLIAAAAQAAjKCViQIAAAAQCWiPDTAAIAAAAQDUAACVCPIAAAAQCWCQAADKIAAAAQAADLiWCPIAAAAQiVCQjUAAIAAAAQjTAAiWiQg");
	var mask_28_graphics_139 = new cjs.Graphics().p("Al1FmQibiUAAjSIAAAAQAAjRCbiVIAAAAQCbiUDaAAIAAAAQDbAACbCUIAAAAQCbCVAADRIAAAAQAADSibCUIAAAAQibCVjbAAIAAAAQjaAAibiVg");
	var mask_28_graphics_140 = new cjs.Graphics().p("AmCFzQigiaAAjZIAAAAQAAjYCgiaIAAAAQCgiZDiAAIAAAAQDjAACgCZIAAAAQCgCaAADYIAAAAQAADZigCaIAAAAQigCZjjAAIAAAAQjiAAigiZg");
	var mask_28_graphics_141 = new cjs.Graphics().p("AmPF/QimieAAjhIAAAAQAAjgCmifIAAAAQCmieDpAAIAAAAQDqAACmCeIAAAAQCmCfAADgIAAAAQAADhimCeIAAAAQimCfjqAAIAAAAQjpAAimifg");
	var mask_28_graphics_142 = new cjs.Graphics().p("AmdGMQirikAAjoIAAAAQAAjnCrikIAAAAQCsikDxAAIAAAAQDyAACrCkIAAAAQCsCkAADnIAAAAQAADoisCkIAAAAQirCkjyAAIAAAAQjxAAisikg");
	var mask_28_graphics_143 = new cjs.Graphics().p("AmqGZQixipAAjwIAAAAQAAjvCxipIAAAAQCxiqD5AAIAAAAQD6AACxCqIAAAAQCxCpAADvIAAAAQAADwixCpIAAAAQixCqj6AAIAAAAQj5AAixiqg");
	var mask_28_graphics_144 = new cjs.Graphics().p("Am4GmQi3ivAAj3IAAAAQAAj2C3iwIAAAAQC3ivEBAAIAAAAQECAAC3CvIAAAAQC3CwAAD2IAAAAQAAD3i3CvIAAAAQi3CwkCAAIAAAAQkBAAi3iwg");
	var mask_28_graphics_145 = new cjs.Graphics().p("AnGG0Qi9i1AAj/IAAAAQAAj+C9i1IAAAAQC8i1EKAAIAAAAQELAAC8C1IAAAAQC9C1AAD+IAAAAQAAD/i9C1IAAAAQi8C1kLAAIAAAAQkKAAi8i1g");
	var mask_28_graphics_146 = new cjs.Graphics().p("AnVHCQjCi7AAkHIAAAAQAAkGDCi7IAAAAQDDi6ESAAIAAAAQETAADCC6IAAAAQDDC7AAEGIAAAAQAAEHjDC7IAAAAQjCC6kTAAIAAAAQkSAAjDi6g");
	var mask_28_graphics_147 = new cjs.Graphics().p("AnjHQQjIjAAAkQIAAAAQAAkPDIjAIAAAAQDJjAEaAAIAAAAQEbAADJDAIAAAAQDIDAAAEPIAAAAQAAEQjIDAIAAAAQjJDAkbAAIAAAAQkaAAjJjAg");
	var mask_28_graphics_148 = new cjs.Graphics().p("AnyHeQjOjGAAkYIAAAAQAAkXDOjGIAAAAQDPjGEjAAIAAAAQEkAADPDGIAAAAQDODGAAEXIAAAAQAAEYjODGIAAAAQjPDGkkAAIAAAAQkjAAjPjGg");
	var mask_28_graphics_149 = new cjs.Graphics().p("AoBHsQjVjMAAkgIAAAAQAAkfDVjNIAAAAQDVjLEsAAIAAAAQEtAADVDLIAAAAQDVDNAAEfIAAAAQAAEgjVDMIAAAAQjVDMktAAIAAAAQksAAjVjMg");
	var mask_28_graphics_150 = new cjs.Graphics().p("AoQH7QjbjSAAkpIAAAAQAAkoDbjSIAAAAQDbjSE1AAIAAAAQE2AADbDSIAAAAQDbDSAAEoIAAAAQAAEpjbDSIAAAAQjbDSk2AAIAAAAQk1AAjbjSg");
	var mask_28_graphics_151 = new cjs.Graphics().p("AogIKQjhjYAAkyIAAAAQAAkxDhjYIAAAAQDijYE+AAIAAAAQE/AADiDYIAAAAQDhDYAAExIAAAAQAAEyjhDYIAAAAQjiDYk/AAIAAAAQk+AAjijYg");
	var mask_28_graphics_152 = new cjs.Graphics().p("AowIZQjojeAAk7IAAAAQAAk6DojeIAAAAQDpjfFHAAIAAAAQFIAADoDfIAAAAQDpDeAAE6IAAAAQAAE7jpDeIAAAAQjoDflIAAIAAAAQlHAAjpjfg");
	var mask_28_graphics_153 = new cjs.Graphics().p("ApAIoQjvjkAAlEIAAAAQAAlDDvjlIAAAAQDvjkFRAAIAAAAQFSAADuDkIAAAAQDwDlAAFDIAAAAQAAFEjwDkIAAAAQjuDllSAAIAAAAQlRAAjvjlg");
	var mask_28_graphics_154 = new cjs.Graphics().p("ApQI4Qj2jrAAlNIAAAAQAAlMD2jrIAAAAQD2jsFaAAIAAAAQFbAAD2DsIAAAAQD2DrAAFMIAAAAQAAFNj2DrIAAAAQj2DslbAAIAAAAQlaAAj2jsg");
	var mask_28_graphics_155 = new cjs.Graphics().p("AphJIQj8jyAAlWIAAAAQAAlVD8jyIAAAAQD9jyFkAAIAAAAQFlAAD8DyIAAAAQD9DyAAFVIAAAAQAAFWj9DyIAAAAQj8DyllAAIAAAAQlkAAj9jyg");
	var mask_28_graphics_156 = new cjs.Graphics().p("ApxJYQkEj5AAlfIAAAAQAAleEEj5IAAAAQEDj5FuAAIAAAAQFvAAEDD5IAAAAQEED5AAFeIAAAAQAAFfkED5IAAAAQkDD5lvAAIAAAAQluAAkDj5g");
	var mask_28_graphics_157 = new cjs.Graphics().p("AqCJoQkKj/AAlpIAAAAQAAloEKj/IAAAAQELj/F3AAIAAAAQF4AAELD/IAAAAQEKD/AAFoIAAAAQAAFpkKD/IAAAAQkLD/l4AAIAAAAQl3AAkLj/g");
	var mask_28_graphics_158 = new cjs.Graphics().p("AqSJ3QkRkFAAlyIAAAAQAAlxERkGIAAAAQERkFGBAAIAAAAQGCAAEREFIAAAAQEREGAAFxIAAAAQAAFykREFIAAAAQkREGmCAAIAAAAQmBAAkRkGg");
	var mask_28_graphics_159 = new cjs.Graphics().p("AqiKHQkYkMAAl7IAAAAQAAl6EYkMIAAAAQEYkMGKAAIAAAAQGLAAEYEMIAAAAQEYEMAAF6IAAAAQAAF7kYEMIAAAAQkYEMmLAAIAAAAQmKAAkYkMg");
	var mask_28_graphics_160 = new cjs.Graphics().p("AqyKWQkekSAAmEIAAAAQAAmDEekSIAAAAQEekSGUAAIAAAAQGVAAEeESIAAAAQEeESAAGDIAAAAQAAGEkeESIAAAAQkeESmVAAIAAAAQmUAAkekSg");
	var mask_28_graphics_161 = new cjs.Graphics().p("ArCKlQkkkYAAmNIAAAAQAAmMEkkYIAAAAQElkYGdAAIAAAAQGeAAEkEYIAAAAQElEYAAGMIAAAAQAAGNklEYIAAAAQkkEYmeAAIAAAAQmdAAklkYg");
	var mask_28_graphics_162 = new cjs.Graphics().p("ArRKzQkrkeAAmVIAAAAQAAmUErkfIAAAAQErkeGmAAIAAAAQGnAAErEeIAAAAQErEfAAGUIAAAAQAAGVkrEeIAAAAQkrEfmnAAIAAAAQmmAAkrkfg");
	var mask_28_graphics_163 = new cjs.Graphics().p("ArgLCQkxkkAAmeIAAAAQAAmdExkkIAAAAQExklGvAAIAAAAQGwAAExElIAAAAQExEkAAGdIAAAAQAAGekxEkIAAAAQkxElmwAAIAAAAQmvAAkxklg");
	var mask_28_graphics_164 = new cjs.Graphics().p("ArvLQQk3kqAAmmIAAAAQAAmlE3kqIAAAAQE4krG3AAIAAAAQG4AAE4ErIAAAAQE3EqAAGlIAAAAQAAGmk3EqIAAAAQk4Erm4AAIAAAAQm3AAk4krg");
	var mask_28_graphics_165 = new cjs.Graphics().p("Ar9LeQk+kwAAmuIAAAAQAAmtE+kwIAAAAQE9kwHAAAIAAAAQHBAAE9EwIAAAAQE+EwAAGtIAAAAQAAGuk+EwIAAAAQk9EwnBAAIAAAAQnAAAk9kwg");
	var mask_28_graphics_166 = new cjs.Graphics().p("AsMLsQlDk2AAm2IAAAAQAAm1FDk2IAAAAQFEk2HIAAIAAAAQHJAAFDE2IAAAAQFEE2AAG1IAAAAQAAG2lEE2IAAAAQlDE2nJAAIAAAAQnIAAlEk2g");
	var mask_28_graphics_167 = new cjs.Graphics().p("AsaL5QlJk7AAm+IAAAAQAAm9FJk8IAAAAQFJk7HRAAIAAAAQHRAAFKE7IAAAAQFJE8AAG9IAAAAQAAG+lJE7IAAAAQlKE8nRAAIAAAAQnRAAlJk8g");
	var mask_28_graphics_168 = new cjs.Graphics().p("AsoMHQlPlBAAnGIAAAAQAAnFFPlBIAAAAQFPlBHZAAIAAAAQHaAAFOFBIAAAAQFQFBAAHFIAAAAQAAHGlQFBIAAAAQlOFBnaAAIAAAAQnZAAlPlBg");
	var mask_28_graphics_169 = new cjs.Graphics().p("As1MUQlVlHAAnNIAAAAQAAnMFVlHIAAAAQFUlGHhAAIAAAAQHiAAFUFGIAAAAQFVFHAAHMIAAAAQAAHNlVFHIAAAAQlUFGniAAIAAAAQnhAAlUlGg");
	var mask_28_graphics_170 = new cjs.Graphics().p("AtDMgQlalLAAnVIAAAAQAAnUFalMIAAAAQFblLHoAAIAAAAQHpAAFaFLIAAAAQFbFMAAHUIAAAAQAAHVlbFLIAAAAQlaFMnpAAIAAAAQnoAAlblMg");
	var mask_28_graphics_171 = new cjs.Graphics().p("AtQMtQlflRAAncIAAAAQAAnbFflRIAAAAQFglRHwAAIAAAAQHxAAFfFRIAAAAQFgFRAAHbIAAAAQAAHclgFRIAAAAQlfFRnxAAIAAAAQnwAAlglRg");
	var mask_28_graphics_172 = new cjs.Graphics().p("AtdM5QlklVAAnkIAAAAQAAnjFklWIAAAAQFllWH4AAIAAAAQH5AAFkFWIAAAAQFlFWAAHjIAAAAQAAHkllFVIAAAAQlkFXn5AAIAAAAQn4AAlllXg");
	var mask_28_graphics_173 = new cjs.Graphics().p("AtpNFQlqlaAAnrIAAAAQAAnqFqlbIAAAAQFqlbH/AAIAAAAQIAAAFqFbIAAAAQFqFbAAHqIAAAAQAAHrlqFaIAAAAQlqFcoAAAIAAAAQn/AAlqlcg");
	var mask_28_graphics_174 = new cjs.Graphics().p("At2NRQlvlfAAnyIAAAAQAAnxFvlgIAAAAQFwlfIGAAIAAAAQIHAAFvFfIAAAAQFwFgAAHxIAAAAQAAHylwFfIAAAAQlvFgoHAAIAAAAQoGAAlwlgg");
	var mask_28_graphics_175 = new cjs.Graphics().p("AuCNdQl0llAAn4IAAAAQAAn3F0llIAAAAQF1llINAAIAAAAQIOAAF0FlIAAAAQF1FlAAH3IAAAAQAAH4l1FlIAAAAQl0FloOAAIAAAAQoNAAl1llg");
	var mask_28_graphics_176 = new cjs.Graphics().p("AuONoQl5lpAAn/IAAAAQAAn+F5lqIAAAAQF6lpIUAAIAAAAQIVAAF5FpIAAAAQF6FqAAH+IAAAAQAAH/l6FpIAAAAQl5FqoVAAIAAAAQoUAAl6lqg");
	var mask_28_graphics_177 = new cjs.Graphics().p("AuZNzQl+ltAAoGIAAAAQAAoFF+luIAAAAQF+luIbAAIAAAAQIcAAF+FuIAAAAQF+FuAAIFIAAAAQAAIGl+FtIAAAAQl+FvocAAIAAAAQobAAl+lvg");
	var mask_28_graphics_178 = new cjs.Graphics().p("AulN+QmClyAAoMIAAAAQAAoLGClzIAAAAQGDlyIiAAIAAAAQIjAAGCFyIAAAAQGDFzAAILIAAAAQAAIMmDFyIAAAAQmCFzojAAIAAAAQoiAAmDlzg");
	var mask_28_graphics_179 = new cjs.Graphics().p("AuwOJQmHl3AAoSIAAAAQAAoRGHl3IAAAAQGIl3IoAAIAAAAQIpAAGIF3IAAAAQGHF3AAIRIAAAAQAAISmHF3IAAAAQmIF3opAAIAAAAQooAAmIl3g");
	var mask_28_graphics_180 = new cjs.Graphics().p("Au7OTQmMl7AAoYIAAAAQAAoXGMl8IAAAAQGMl7IvAAIAAAAQIwAAGLF7IAAAAQGNF8AAIXIAAAAQAAIYmNF7IAAAAQmLF8owAAIAAAAQovAAmMl8g");
	var mask_28_graphics_181 = new cjs.Graphics().p("AvGOeQmQmAAAoeIAAAAQAAodGQmAIAAAAQGRmAI1AAIAAAAQI2AAGQGAIAAAAQGRGAAAIdIAAAAQAAIemRGAIAAAAQmQGAo2AAIAAAAQo1AAmRmAg");
	var mask_28_graphics_182 = new cjs.Graphics().p("AvQOoQmUmEAAokIAAAAQAAojGUmEIAAAAQGVmEI7AAIAAAAQI8AAGVGEIAAAAQGUGEAAIjIAAAAQAAIkmUGEIAAAAQmVGEo8AAIAAAAQo7AAmVmEg");
	var mask_28_graphics_183 = new cjs.Graphics().p("AvaOxQmZmHAAoqIAAAAQAAopGZmIIAAAAQGZmHJBAAIAAAAQJCAAGZGHIAAAAQGZGIAAIpIAAAAQAAIqmZGHIAAAAQmZGIpCAAIAAAAQpBAAmZmIg");
	var mask_28_graphics_184 = new cjs.Graphics().p("AvkO7QmdmMAAovIAAAAQAAouGdmMIAAAAQGdmMJHAAIAAAAQJIAAGdGMIAAAAQGdGMAAIuIAAAAQAAIvmdGMIAAAAQmdGMpIAAIAAAAQpHAAmdmMg");
	var mask_28_graphics_185 = new cjs.Graphics().p("AvuPEQmhmPAAo1IAAAAQAAo0GhmQIAAAAQGhmPJNAAIAAAAQJOAAGgGPIAAAAQGiGQAAI0IAAAAQAAI1miGPIAAAAQmgGQpOAAIAAAAQpNAAmhmQg");
	var mask_28_graphics_186 = new cjs.Graphics().p("Av3PNQmlmTAAo6IAAAAQAAo5GlmUIAAAAQGlmTJSAAIAAAAQJTAAGlGTIAAAAQGlGUAAI5IAAAAQAAI6mlGTIAAAAQmlGUpTAAIAAAAQpSAAmlmUg");
	var mask_28_graphics_187 = new cjs.Graphics().p("AwAPWQmpmXAAo/IAAAAQAAo+GpmYIAAAAQGpmWJXAAIAAAAQJYAAGpGWIAAAAQGpGYAAI+IAAAAQAAI/mpGXIAAAAQmpGXpYAAIAAAAQpXAAmpmXg");
	var mask_28_graphics_188 = new cjs.Graphics().p("AwJPfQmtmbAApEIAAAAQAApDGtmbIAAAAQGsmaJdAAIAAAAQJeAAGsGaIAAAAQGtGbAAJDIAAAAQAAJEmtGbIAAAAQmsGapeAAIAAAAQpdAAmsmag");
	var mask_28_graphics_189 = new cjs.Graphics().p("AwSPnQmwmeAApJIAAAAQAApIGwmeIAAAAQGwmeJiAAIAAAAQJjAAGwGeIAAAAQGwGeAAJIIAAAAQAAJJmwGeIAAAAQmwGepjAAIAAAAQpiAAmwmeg");
	var mask_28_graphics_190 = new cjs.Graphics().p("AwbPvQmzmhAApOIAAAAQAApNGzmiIAAAAQG0mhJnAAIAAAAQJoAAGzGhIAAAAQG0GiAAJNIAAAAQAAJOm0GhIAAAAQmzGipoAAIAAAAQpnAAm0mig");
	var mask_28_graphics_191 = new cjs.Graphics().p("AwjP3Qm2mkAApTIAAAAQAApSG2mkIAAAAQG3mlJsAAIAAAAQJtAAG2GlIAAAAQG3GkAAJSIAAAAQAAJTm3GkIAAAAQm2GlptAAIAAAAQpsAAm3mlg");
	var mask_28_graphics_192 = new cjs.Graphics().p("AwrP/Qm6moAApXIAAAAQAApWG6moIAAAAQG7moJwAAIAAAAQJxAAG6GoIAAAAQG7GoAAJWIAAAAQAAJXm7GoIAAAAQm6GopxAAIAAAAQpwAAm7mog");
	var mask_28_graphics_193 = new cjs.Graphics().p("AwyQGQm+mrAApbIAAAAQAApaG+mrIAAAAQG9mrJ1AAIAAAAQJ2AAG9GrIAAAAQG+GrAAJaIAAAAQAAJbm+GrIAAAAQm9Grp2AAIAAAAQp1AAm9mrg");
	var mask_28_graphics_194 = new cjs.Graphics().p("Aw6QNQnAmtAApgIAAAAQAApfHAmuIAAAAQHBmtJ5AAIAAAAQJ6AAHAGtIAAAAQHBGuAAJfIAAAAQAAJgnBGtIAAAAQnAGup6AAIAAAAQp5AAnBmug");
	var mask_28_graphics_195 = new cjs.Graphics().p("AxBQUQnDmwAApkIAAAAQAApjHDmxIAAAAQHEmwJ9AAIAAAAQJ+AAHEGwIAAAAQHDGxAAJjIAAAAQAAJknDGwIAAAAQnEGxp+AAIAAAAQp9AAnEmxg");
	var mask_28_graphics_196 = new cjs.Graphics().p("AxIQbQnGmzAApoIAAAAQAApnHGmzIAAAAQHHmzKBAAIAAAAQKCAAHHGzIAAAAQHGGzAAJnIAAAAQAAJonGGzIAAAAQnHGzqCAAIAAAAQqBAAnHmzg");
	var mask_28_graphics_197 = new cjs.Graphics().p("AxPQhQnJm2AAprIAAAAQAApqHJm3IAAAAQHKm2KFAAIAAAAQKGAAHJG2IAAAAQHKG3AAJqIAAAAQAAJrnKG2IAAAAQnJG3qGAAIAAAAQqFAAnKm3g");
	var mask_28_graphics_198 = new cjs.Graphics().p("AxVQnQnMm4AApvIAAAAQAApuHMm5IAAAAQHMm4KJAAIAAAAQKKAAHMG4IAAAAQHMG5AAJuIAAAAQAAJvnMG4IAAAAQnMG5qKAAIAAAAQqJAAnMm5g");
	var mask_28_graphics_199 = new cjs.Graphics().p("AxcQtQnOm6AApzIAAAAQAApyHOm7IAAAAQHPm7KNAAIAAAAQKOAAHOG7IAAAAQHPG7AAJyIAAAAQAAJznPG6IAAAAQnOG8qOAAIAAAAQqNAAnPm8g");
	var mask_28_graphics_200 = new cjs.Graphics().p("AxiQzQnQm9AAp2IAAAAQAAp1HQm+IAAAAQHSm9KQAAIAAAAQKRAAHRG9IAAAAQHRG+AAJ1IAAAAQAAJ2nRG9IAAAAQnRG+qRAAIAAAAQqQAAnSm+g");
	var mask_28_graphics_201 = new cjs.Graphics().p("AxnQ5QnTnAAAp5IAAAAQAAp4HTnAIAAAAQHTnAKUAAIAAAAQKVAAHTHAIAAAAQHTHAAAJ4IAAAAQAAJ5nTHAIAAAAQnTHAqVAAIAAAAQqUAAnTnAg");
	var mask_28_graphics_202 = new cjs.Graphics().p("AxtQ+QnVnCAAp8IAAAAQAAp7HVnCIAAAAQHWnCKXAAIAAAAQKYAAHVHCIAAAAQHWHCAAJ7IAAAAQAAJ8nWHCIAAAAQnVHCqYAAIAAAAQqXAAnWnCg");
	var mask_28_graphics_203 = new cjs.Graphics().p("AxyRDQnYnEAAp/IAAAAQAAp+HYnFIAAAAQHYnDKaAAIAAAAQKbAAHYHDIAAAAQHYHFAAJ+IAAAAQAAJ/nYHEIAAAAQnYHEqbAAIAAAAQqaAAnYnEg");
	var mask_28_graphics_204 = new cjs.Graphics().p("Ax3RIQnanGAAqCIAAAAQAAqBHanGIAAAAQHanGKdAAIAAAAQKeAAHaHGIAAAAQHaHGAAKBIAAAAQAAKCnaHGIAAAAQnaHGqeAAIAAAAQqdAAnanGg");
	var mask_28_graphics_205 = new cjs.Graphics().p("Ax8RMQncnHAAqFIAAAAQAAqEHcnIIAAAAQHcnIKgAAIAAAAQKhAAHbHIIAAAAQHdHIAAKEIAAAAQAAKFndHHIAAAAQnbHJqhAAIAAAAQqgAAncnJg");
	var mask_28_graphics_206 = new cjs.Graphics().p("AyBRRQndnKAAqHIAAAAQAAqGHdnKIAAAAQHfnKKiAAIAAAAQKjAAHeHKIAAAAQHeHKAAKGIAAAAQAAKHneHKIAAAAQneHKqjAAIAAAAQqiAAnfnKg");
	var mask_28_graphics_207 = new cjs.Graphics().p("AyFRVQnfnLAAqKIAAAAQAAqJHfnLIAAAAQHgnMKlAAIAAAAQKmAAHfHMIAAAAQHgHLAAKJIAAAAQAAKKngHLIAAAAQnfHMqmAAIAAAAQqlAAngnMg");
	var mask_28_graphics_208 = new cjs.Graphics().p("AyJRZQnhnNAAqMIAAAAQAAqLHhnNIAAAAQHinNKnAAIAAAAQKoAAHhHNIAAAAQHiHNAAKLIAAAAQAAKMniHNIAAAAQnhHNqoAAIAAAAQqnAAninNg");
	var mask_28_graphics_209 = new cjs.Graphics().p("AyNRcQninOAAqOIAAAAQAAqNHinPIAAAAQHjnOKqAAIAAAAQKrAAHiHOIAAAAQHjHPAAKNIAAAAQAAKOnjHOIAAAAQniHPqrAAIAAAAQqqAAnjnPg");
	var mask_28_graphics_210 = new cjs.Graphics().p("AyQRgQnknQAAqQIAAAAQAAqPHknQIAAAAQHknQKsAAIAAAAQKtAAHkHQIAAAAQHkHQAAKPIAAAAQAAKQnkHQIAAAAQnkHQqtAAIAAAAQqsAAnknQg");
	var mask_28_graphics_211 = new cjs.Graphics().p("AyURjQnlnRAAqSIAAAAQAAqRHlnRIAAAAQHmnSKuAAIAAAAQKvAAHlHSIAAAAQHmHRAAKRIAAAAQAAKSnmHRIAAAAQnlHSqvAAIAAAAQquAAnmnSg");
	var mask_28_graphics_212 = new cjs.Graphics().p("AyXRmQnmnSAAqUIAAAAQAAqTHmnSIAAAAQHonTKvAAIAAAAQKwAAHnHTIAAAAQHnHSAAKTIAAAAQAAKUnnHSIAAAAQnnHTqwAAIAAAAQqvAAnonTg");
	var mask_28_graphics_213 = new cjs.Graphics().p("AyZRpQnonUAAqVIAAAAQAAqUHonUIAAAAQHonUKxAAIAAAAQKyAAHoHUIAAAAQHoHUAAKUIAAAAQAAKVnoHUIAAAAQnoHUqyAAIAAAAQqxAAnonUg");
	var mask_28_graphics_214 = new cjs.Graphics().p("AycRrQnpnUAAqXIAAAAQAAqWHpnVIAAAAQHpnUKzAAIAAAAQK0AAHoHUIAAAAQHqHVAAKWIAAAAQAAKXnqHUIAAAAQnoHVq0AAIAAAAQqzAAnpnVg");
	var mask_28_graphics_215 = new cjs.Graphics().p("AyeRtQnqnVAAqYIAAAAQAAqXHqnWIAAAAQHqnVK0AAIAAAAQK1AAHqHVIAAAAQHqHWAAKXIAAAAQAAKYnqHVIAAAAQnqHWq1AAIAAAAQq0AAnqnWg");
	var mask_28_graphics_216 = new cjs.Graphics().p("AygRvQnrnWAAqZIAAAAQAAqYHrnXIAAAAQHrnWK1AAIAAAAQK2AAHrHWIAAAAQHrHXAAKYIAAAAQAAKZnrHWIAAAAQnrHXq2AAIAAAAQq1AAnrnXg");
	var mask_28_graphics_217 = new cjs.Graphics().p("AyiRxQnsnXAAqaIAAAAQAAqZHsnYIAAAAQHsnWK2AAIAAAAQK3AAHsHWIAAAAQHsHYAAKZIAAAAQAAKansHXIAAAAQnsHXq3AAIAAAAQq2AAnsnXg");
	var mask_28_graphics_218 = new cjs.Graphics().p("AykRzQnsnYAAqbIAAAAQAAqaHsnYIAAAAQHtnYK3AAIAAAAQK4AAHsHYIAAAAQHtHYAAKaIAAAAQAAKbntHYIAAAAQnsHYq4AAIAAAAQq3AAntnYg");
	var mask_28_graphics_219 = new cjs.Graphics().p("AylR0QntnYAAqcIAAAAQAAqbHtnYIAAAAQHtnYK4AAIAAAAQK5AAHtHYIAAAAQHtHYAAKbIAAAAQAAKcntHYIAAAAQntHYq5AAIAAAAQq4AAntnYg");
	var mask_28_graphics_220 = new cjs.Graphics().p("AymR1QntnZAAqcIAAAAQAAqbHtnZIAAAAQHtnZK5AAIAAAAQK6AAHtHZIAAAAQHtHZAAKbIAAAAQAAKcntHZIAAAAQntHZq6AAIAAAAQq5AAntnZg");
	var mask_28_graphics_221 = new cjs.Graphics().p("AynR2QnunZAAqdIAAAAQAAqcHunZIAAAAQHunZK5AAIAAAAQK6AAHuHZIAAAAQHuHZAAKcIAAAAQAAKdnuHZIAAAAQnuHZq6AAIAAAAQq5AAnunZg");
	var mask_28_graphics_222 = new cjs.Graphics().p("AyoR2QntnZAAqdIAAAAQAAqcHtnaIAAAAQHvnZK5AAIAAAAQK6AAHuHZIAAAAQHuHaAAKcIAAAAQAAKdnuHZIAAAAQnuHaq6AAIAAAAQq5AAnvnag");
	var mask_28_graphics_223 = new cjs.Graphics().p("AyoR3QnunaAAqdIAAAAQAAqcHunaIAAAAQHunZK6AAIAAAAQK7AAHuHZIAAAAQHuHaAAKcIAAAAQAAKdnuHaIAAAAQnuHZq7AAIAAAAQq6AAnunZg");
	var mask_28_graphics_224 = new cjs.Graphics().p("AyoR3QnunZAAqeIAAAAQAAqdHunZIAAAAQHunaK6AAIAAAAQK7AAHuHaIAAAAQHuHZAAKdIAAAAQAAKenuHZIAAAAQnuHaq7AAIAAAAQq6AAnunag");

	this.timeline.addTween(cjs.Tween.get(mask_28).to({graphics:null,x:0,y:0}).wait(87).to({graphics:mask_28_graphics_87,x:349.0006,y:608.9004}).wait(1).to({graphics:mask_28_graphics_88,x:349.0007,y:608.9004}).wait(1).to({graphics:mask_28_graphics_89,x:349.0011,y:608.9008}).wait(1).to({graphics:mask_28_graphics_90,x:349.002,y:608.9017}).wait(1).to({graphics:mask_28_graphics_91,x:349.0029,y:608.9026}).wait(1).to({graphics:mask_28_graphics_92,x:349.0038,y:608.904}).wait(1).to({graphics:mask_28_graphics_93,x:349.0056,y:608.9058}).wait(1).to({graphics:mask_28_graphics_94,x:349.0074,y:608.9076}).wait(1).to({graphics:mask_28_graphics_95,x:349.0096,y:608.9094}).wait(1).to({graphics:mask_28_graphics_96,x:349.0119,y:608.9116}).wait(1).to({graphics:mask_28_graphics_97,x:349.0146,y:608.9148}).wait(1).to({graphics:mask_28_graphics_98,x:349.0173,y:608.9179}).wait(1).to({graphics:mask_28_graphics_99,x:349.0209,y:608.9211}).wait(1).to({graphics:mask_28_graphics_100,x:349.024,y:608.9251}).wait(1).to({graphics:mask_28_graphics_101,x:349.0276,y:608.9287}).wait(1).to({graphics:mask_28_graphics_102,x:349.0317,y:608.9328}).wait(1).to({graphics:mask_28_graphics_103,x:349.0362,y:608.9373}).wait(1).to({graphics:mask_28_graphics_104,x:349.0411,y:608.9418}).wait(1).to({graphics:mask_28_graphics_105,x:349.0461,y:608.9472}).wait(1).to({graphics:mask_28_graphics_106,x:349.051,y:608.9526}).wait(1).to({graphics:mask_28_graphics_107,x:349.0564,y:608.9584}).wait(1).to({graphics:mask_28_graphics_108,x:349.0623,y:608.9643}).wait(1).to({graphics:mask_28_graphics_109,x:349.0686,y:608.9701}).wait(1).to({graphics:mask_28_graphics_110,x:349.0749,y:608.9769}).wait(1).to({graphics:mask_28_graphics_111,x:349.0812,y:608.9836}).wait(1).to({graphics:mask_28_graphics_112,x:349.0884,y:608.9908}).wait(1).to({graphics:mask_28_graphics_113,x:349.0956,y:608.9985}).wait(1).to({graphics:mask_28_graphics_114,x:349.1028,y:609.0057}).wait(1).to({graphics:mask_28_graphics_115,x:349.1104,y:609.0138}).wait(1).to({graphics:mask_28_graphics_116,x:349.1185,y:609.0219}).wait(1).to({graphics:mask_28_graphics_117,x:349.1266,y:609.0304}).wait(1).to({graphics:mask_28_graphics_118,x:349.1352,y:609.0394}).wait(1).to({graphics:mask_28_graphics_119,x:349.1442,y:609.0484}).wait(1).to({graphics:mask_28_graphics_120,x:349.1536,y:609.0579}).wait(1).to({graphics:mask_28_graphics_121,x:349.1631,y:609.0678}).wait(1).to({graphics:mask_28_graphics_122,x:349.1721,y:609.0772}).wait(1).to({graphics:mask_28_graphics_123,x:349.1824,y:609.0876}).wait(1).to({graphics:mask_28_graphics_124,x:349.1923,y:609.0984}).wait(1).to({graphics:mask_28_graphics_125,x:349.2032,y:609.1092}).wait(1).to({graphics:mask_28_graphics_126,x:349.2139,y:609.1204}).wait(1).to({graphics:mask_28_graphics_127,x:349.2247,y:609.1317}).wait(1).to({graphics:mask_28_graphics_128,x:349.2365,y:609.1434}).wait(1).to({graphics:mask_28_graphics_129,x:349.2477,y:609.1555}).wait(1).to({graphics:mask_28_graphics_130,x:349.2598,y:609.1677}).wait(1).to({graphics:mask_28_graphics_131,x:349.272,y:609.1803}).wait(1).to({graphics:mask_28_graphics_132,x:349.2846,y:609.1933}).wait(1).to({graphics:mask_28_graphics_133,x:349.2977,y:609.2064}).wait(1).to({graphics:mask_28_graphics_134,x:349.3102,y:609.2199}).wait(1).to({graphics:mask_28_graphics_135,x:349.3237,y:609.2338}).wait(1).to({graphics:mask_28_graphics_136,x:349.3372,y:609.2478}).wait(1).to({graphics:mask_28_graphics_137,x:349.3512,y:609.2622}).wait(1).to({graphics:mask_28_graphics_138,x:349.3651,y:609.2766}).wait(1).to({graphics:mask_28_graphics_139,x:349.38,y:609.2919}).wait(1).to({graphics:mask_28_graphics_140,x:349.3949,y:609.3067}).wait(1).to({graphics:mask_28_graphics_141,x:349.4092,y:609.322}).wait(1).to({graphics:mask_28_graphics_142,x:349.4245,y:609.3378}).wait(1).to({graphics:mask_28_graphics_143,x:349.4407,y:609.3544}).wait(1).to({graphics:mask_28_graphics_144,x:349.4565,y:609.3706}).wait(1).to({graphics:mask_28_graphics_145,x:349.4722,y:609.3873}).wait(1).to({graphics:mask_28_graphics_146,x:349.4889,y:609.4039}).wait(1).to({graphics:mask_28_graphics_147,x:349.5051,y:609.4211}).wait(1).to({graphics:mask_28_graphics_148,x:349.5226,y:609.4391}).wait(1).to({graphics:mask_28_graphics_149,x:349.5397,y:609.4566}).wait(1).to({graphics:mask_28_graphics_150,x:349.5573,y:609.4746}).wait(1).to({graphics:mask_28_graphics_151,x:349.5753,y:609.493}).wait(1).to({graphics:mask_28_graphics_152,x:349.5928,y:609.5119}).wait(1).to({graphics:mask_28_graphics_153,x:349.6118,y:609.5304}).wait(1).to({graphics:mask_28_graphics_154,x:349.6302,y:609.5497}).wait(1).to({graphics:mask_28_graphics_155,x:349.6491,y:609.5695}).wait(1).to({graphics:mask_28_graphics_156,x:349.668,y:609.5889}).wait(1).to({graphics:mask_28_graphics_157,x:349.6869,y:609.6087}).wait(1).to({graphics:mask_28_graphics_158,x:349.7058,y:609.6281}).wait(1).to({graphics:mask_28_graphics_159,x:349.7242,y:609.6469}).wait(1).to({graphics:mask_28_graphics_160,x:349.7422,y:609.6654}).wait(1).to({graphics:mask_28_graphics_161,x:349.7602,y:609.6843}).wait(1).to({graphics:mask_28_graphics_162,x:349.7778,y:609.7018}).wait(1).to({graphics:mask_28_graphics_163,x:349.7949,y:609.7198}).wait(1).to({graphics:mask_28_graphics_164,x:349.8115,y:609.7378}).wait(1).to({graphics:mask_28_graphics_165,x:349.8282,y:609.7549}).wait(1).to({graphics:mask_28_graphics_166,x:349.8448,y:609.7716}).wait(1).to({graphics:mask_28_graphics_167,x:349.8611,y:609.7882}).wait(1).to({graphics:mask_28_graphics_168,x:349.8768,y:609.8044}).wait(1).to({graphics:mask_28_graphics_169,x:349.8925,y:609.8206}).wait(1).to({graphics:mask_28_graphics_170,x:349.9074,y:609.8368}).wait(1).to({graphics:mask_28_graphics_171,x:349.9227,y:609.8517}).wait(1).to({graphics:mask_28_graphics_172,x:349.9371,y:609.867}).wait(1).to({graphics:mask_28_graphics_173,x:349.9519,y:609.8819}).wait(1).to({graphics:mask_28_graphics_174,x:349.9659,y:609.8967}).wait(1).to({graphics:mask_28_graphics_175,x:349.9799,y:609.9106}).wait(1).to({graphics:mask_28_graphics_176,x:349.9938,y:609.925}).wait(1).to({graphics:mask_28_graphics_177,x:350.0069,y:609.939}).wait(1).to({graphics:mask_28_graphics_178,x:350.0199,y:609.9525}).wait(1).to({graphics:mask_28_graphics_179,x:350.033,y:609.9656}).wait(1).to({graphics:mask_28_graphics_180,x:350.0451,y:609.9786}).wait(1).to({graphics:mask_28_graphics_181,x:350.0572,y:609.9907}).wait(1).to({graphics:mask_28_graphics_182,x:350.0689,y:610.0033}).wait(1).to({graphics:mask_28_graphics_183,x:350.0811,y:610.0155}).wait(1).to({graphics:mask_28_graphics_184,x:350.0919,y:610.0267}).wait(1).to({graphics:mask_28_graphics_185,x:350.1031,y:610.0385}).wait(1).to({graphics:mask_28_graphics_186,x:350.114,y:610.0492}).wait(1).to({graphics:mask_28_graphics_187,x:350.1243,y:610.0605}).wait(1).to({graphics:mask_28_graphics_188,x:350.1351,y:610.0713}).wait(1).to({graphics:mask_28_graphics_189,x:350.1445,y:610.0812}).wait(1).to({graphics:mask_28_graphics_190,x:350.1544,y:610.0915}).wait(1).to({graphics:mask_28_graphics_191,x:350.1639,y:610.101}).wait(1).to({graphics:mask_28_graphics_192,x:350.1729,y:610.1104}).wait(1).to({graphics:mask_28_graphics_193,x:350.1819,y:610.1194}).wait(1).to({graphics:mask_28_graphics_194,x:350.1905,y:610.128}).wait(1).to({graphics:mask_28_graphics_195,x:350.1986,y:610.137}).wait(1).to({graphics:mask_28_graphics_196,x:350.2066,y:610.1451}).wait(1).to({graphics:mask_28_graphics_197,x:350.2143,y:610.1527}).wait(1).to({graphics:mask_28_graphics_198,x:350.2215,y:610.1608}).wait(1).to({graphics:mask_28_graphics_199,x:350.2291,y:610.168}).wait(1).to({graphics:mask_28_graphics_200,x:350.2359,y:610.1752}).wait(1).to({graphics:mask_28_graphics_201,x:350.2426,y:610.182}).wait(1).to({graphics:mask_28_graphics_202,x:350.2485,y:610.1883}).wait(1).to({graphics:mask_28_graphics_203,x:350.2548,y:610.1946}).wait(1).to({graphics:mask_28_graphics_204,x:350.2606,y:610.2004}).wait(1).to({graphics:mask_28_graphics_205,x:350.2656,y:610.2063}).wait(1).to({graphics:mask_28_graphics_206,x:350.2714,y:610.2117}).wait(1).to({graphics:mask_28_graphics_207,x:350.2759,y:610.2166}).wait(1).to({graphics:mask_28_graphics_208,x:350.2809,y:610.2216}).wait(1).to({graphics:mask_28_graphics_209,x:350.2849,y:610.2261}).wait(1).to({graphics:mask_28_graphics_210,x:350.289,y:610.2301}).wait(1).to({graphics:mask_28_graphics_211,x:350.293,y:610.2342}).wait(1).to({graphics:mask_28_graphics_212,x:350.2966,y:610.2378}).wait(1).to({graphics:mask_28_graphics_213,x:350.2998,y:610.241}).wait(1).to({graphics:mask_28_graphics_214,x:350.3025,y:610.2441}).wait(1).to({graphics:mask_28_graphics_215,x:350.3052,y:610.2468}).wait(1).to({graphics:mask_28_graphics_216,x:350.3079,y:610.2495}).wait(1).to({graphics:mask_28_graphics_217,x:350.3097,y:610.2513}).wait(1).to({graphics:mask_28_graphics_218,x:350.3115,y:610.2531}).wait(1).to({graphics:mask_28_graphics_219,x:350.3133,y:610.2549}).wait(1).to({graphics:mask_28_graphics_220,x:350.3147,y:610.2563}).wait(1).to({graphics:mask_28_graphics_221,x:350.3155,y:610.2576}).wait(1).to({graphics:mask_28_graphics_222,x:350.316,y:610.2581}).wait(1).to({graphics:mask_28_graphics_223,x:350.3165,y:610.2585}).wait(1).to({graphics:mask_28_graphics_224,x:350.3164,y:610.2585}).wait(586));

	// Layer_12
	this.instance_49 = new lib.Tween20("synched",0);
	this.instance_49.setTransform(291.25,638.6);
	this.instance_49.alpha = 0.5;
	this.instance_49._off = true;

	this.instance_50 = new lib.Tween21("synched",0);
	this.instance_50.setTransform(291.25,638.6);

	var maskedShapeInstanceList = [this.instance_49,this.instance_50];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_28;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_49}]},87).to({state:[{t:this.instance_50}]},137).wait(586));
	this.timeline.addTween(cjs.Tween.get(this.instance_49).wait(87).to({_off:false},0).to({_off:true,alpha:1},137).wait(586));

	// Layer_6 (mask)
	var mask_29 = new cjs.Shape();
	mask_29._off = true;
	var mask_29_graphics_232 = new cjs.Graphics().p("AgqApQgRgRAAgYIAAAAQAAgXARgRIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQARARAAAXIAAAAQAAAYgRARIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_29_graphics_233 = new cjs.Graphics().p("AgqApQgSgRAAgYIAAAAQAAgXASgRIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQASARAAAXIAAAAQAAAYgSARIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_29_graphics_234 = new cjs.Graphics().p("AgrAqQgSgRAAgZIAAAAQAAgYASgRIAAAAQASgSAZAAIAAAAQAaAAASASIAAAAQASARAAAYIAAAAQAAAZgSARIAAAAQgSASgaAAIAAAAQgZAAgSgSg");
	var mask_29_graphics_235 = new cjs.Graphics().p("AgsAsQgTgTAAgZIAAAAQAAgYATgTIAAAAQASgSAaAAIAAAAQAbAAASASIAAAAQATATAAAYIAAAAQAAAZgTATIAAAAQgSASgbAAIAAAAQgaAAgSgSg");
	var mask_29_graphics_236 = new cjs.Graphics().p("AgvAuQgTgTAAgbIAAAAQAAgaATgTIAAAAQAUgSAbAAIAAAAQAcAAAUASIAAAAQATATAAAaIAAAAQAAAbgTATIAAAAQgUASgcAAIAAAAQgbAAgUgSg");
	var mask_29_graphics_237 = new cjs.Graphics().p("AgxAwQgVgUAAgcIAAAAQAAgbAVgUIAAAAQAVgUAcAAIAAAAQAdAAAVAUIAAAAQAVAUAAAbIAAAAQAAAcgVAUIAAAAQgVAUgdAAIAAAAQgcAAgVgUg");
	var mask_29_graphics_238 = new cjs.Graphics().p("Ag0AzQgXgVAAgeIAAAAQAAgdAXgVIAAAAQAWgVAeAAIAAAAQAfAAAWAVIAAAAQAXAVAAAdIAAAAQAAAegXAVIAAAAQgWAVgfAAIAAAAQgeAAgWgVg");
	var mask_29_graphics_239 = new cjs.Graphics().p("Ag4A3QgYgXAAggIAAAAQAAgfAYgXIAAAAQAXgXAhAAIAAAAQAiAAAXAXIAAAAQAYAXAAAfIAAAAQAAAggYAXIAAAAQgXAXgiAAIAAAAQghAAgXgXg");
	var mask_29_graphics_240 = new cjs.Graphics().p("Ag9A7QgZgYAAgjIAAAAQAAgiAZgYIAAAAQAagZAjAAIAAAAQAkAAAaAZIAAAAQAZAYAAAiIAAAAQAAAjgZAYIAAAAQgaAZgkAAIAAAAQgjAAgagZg");
	var mask_29_graphics_241 = new cjs.Graphics().p("AhCBAQgcgaAAgmIAAAAQAAglAcgaIAAAAQAcgbAmAAIAAAAQAnAAAcAbIAAAAQAcAaAAAlIAAAAQAAAmgcAaIAAAAQgcAbgnAAIAAAAQgmAAgcgbg");
	var mask_29_graphics_242 = new cjs.Graphics().p("AhIBFQgegcAAgpIAAAAQAAgoAegdIAAAAQAfgcApAAIAAAAQAqAAAfAcIAAAAQAeAdAAAoIAAAAQAAApgeAcIAAAAQgfAdgqAAIAAAAQgpAAgfgdg");
	var mask_29_graphics_243 = new cjs.Graphics().p("AhOBLQgggfAAgsIAAAAQAAgrAgggIAAAAQAhgfAtAAIAAAAQAuAAAhAfIAAAAQAgAgAAArIAAAAQAAAsggAfIAAAAQghAgguAAIAAAAQgtAAghggg");
	var mask_29_graphics_244 = new cjs.Graphics().p("AhVBSQgjgiAAgwIAAAAQAAgvAjgiIAAAAQAkgiAxAAIAAAAQAyAAAkAiIAAAAQAjAiAAAvIAAAAQAAAwgjAiIAAAAQgkAigyAAIAAAAQgxAAgkgig");
	var mask_29_graphics_245 = new cjs.Graphics().p("AhcBZQgnglAAg0IAAAAQAAgzAnglIAAAAQAmglA2AAIAAAAQA3AAAmAlIAAAAQAnAlAAAzIAAAAQAAA0gnAlIAAAAQgmAlg3AAIAAAAQg2AAgmglg");
	var mask_29_graphics_246 = new cjs.Graphics().p("AhkBhQgqgoAAg5IAAAAQAAg4AqgoIAAAAQAqgoA6AAIAAAAQA7AAAqAoIAAAAQAqAoAAA4IAAAAQAAA5gqAoIAAAAQgqAog7AAIAAAAQg6AAgqgog");
	var mask_29_graphics_247 = new cjs.Graphics().p("AhtBpQgtgrAAg+IAAAAQAAg9AtgrIAAAAQAugsA/AAIAAAAQBAAAAuAsIAAAAQAtArAAA9IAAAAQAAA+gtArIAAAAQguAshAAAIAAAAQg/AAgugsg");
	var mask_29_graphics_248 = new cjs.Graphics().p("Ah2ByQgxgvAAhDIAAAAQAAhCAxgvIAAAAQAxgvBFAAIAAAAQBGAAAxAvIAAAAQAxAvAABCIAAAAQAABDgxAvIAAAAQgxAvhGAAIAAAAQhFAAgxgvg");
	var mask_29_graphics_249 = new cjs.Graphics().p("AiAB7Qg1gzAAhIIAAAAQAAhHA1gzIAAAAQA2g0BKAAIAAAAQBLAAA2A0IAAAAQA1AzAABHIAAAAQAABIg1AzIAAAAQg2A0hLAAIAAAAQhKAAg2g0g");
	var mask_29_graphics_250 = new cjs.Graphics().p("AiKCFQg6g3AAhOIAAAAQAAhNA6g3IAAAAQA5g4BRAAIAAAAQBSAAA5A4IAAAAQA6A3AABNIAAAAQAABOg6A3IAAAAQg5A4hSAAIAAAAQhRAAg5g4g");
	var mask_29_graphics_251 = new cjs.Graphics().p("AiVCQQg+g8AAhUIAAAAQAAhTA+g8IAAAAQA+g8BXAAIAAAAQBYAAA+A8IAAAAQA+A8AABTIAAAAQAABUg+A8IAAAAQg+A8hYAAIAAAAQhXAAg+g8g");
	var mask_29_graphics_252 = new cjs.Graphics().p("AihCbQhDhAAAhbIAAAAQAAhaBDhAIAAAAQBDhABeAAIAAAAQBfAABDBAIAAAAQBDBAAABaIAAAAQAABbhDBAIAAAAQhDBAhfAAIAAAAQheAAhDhAg");
	var mask_29_graphics_253 = new cjs.Graphics().p("AitCnQhIhFAAhiIAAAAQAAhhBIhFIAAAAQBIhFBlAAIAAAAQBmAABIBFIAAAAQBIBFAABhIAAAAQAABihIBFIAAAAQhIBFhmAAIAAAAQhlAAhIhFg");
	var mask_29_graphics_254 = new cjs.Graphics().p("Ai6CzQhNhKAAhpIAAAAQAAhoBNhKIAAAAQBOhKBsAAIAAAAQBtAABOBKIAAAAQBNBKAABoIAAAAQAABphNBKIAAAAQhOBKhtAAIAAAAQhsAAhOhKg");
	var mask_29_graphics_255 = new cjs.Graphics().p("AjHDAQhThQAAhwIAAAAQAAhvBThQIAAAAQBThPB0AAIAAAAQB1AABTBPIAAAAQBTBQAABvIAAAAQAABwhTBQIAAAAQhTBPh1AAIAAAAQh0AAhThPg");
	var mask_29_graphics_256 = new cjs.Graphics().p("AjVDNQhZhVAAh4IAAAAQAAh3BZhVIAAAAQBZhVB8AAIAAAAQB9AABZBVIAAAAQBZBVAAB3IAAAAQAAB4hZBVIAAAAQhZBVh9AAIAAAAQh8AAhZhVg");
	var mask_29_graphics_257 = new cjs.Graphics().p("AjkDbQhfhbAAiAIAAAAQAAh/BfhbIAAAAQBfhbCFAAIAAAAQCGAABfBbIAAAAQBfBbAAB/IAAAAQAACAhfBbIAAAAQhfBbiGAAIAAAAQiFAAhfhbg");
	var mask_29_graphics_258 = new cjs.Graphics().p("AjzDqQhlhhAAiJIAAAAQAAiIBlhhIAAAAQBlhhCOAAIAAAAQCPAABlBhIAAAAQBlBhAACIIAAAAQAACJhlBhIAAAAQhlBhiPAAIAAAAQiOAAhlhhg");
	var mask_29_graphics_259 = new cjs.Graphics().p("AkDD5QhrhnAAiSIAAAAQAAiRBrhnIAAAAQBshnCXAAIAAAAQCYAABsBnIAAAAQBrBnAACRIAAAAQAACShrBnIAAAAQhsBniYAAIAAAAQiXAAhshng");
	var mask_29_graphics_260 = new cjs.Graphics().p("AkTEJQhzhuAAibIAAAAQAAiaBzhuIAAAAQByhtChAAIAAAAQCiAAByBtIAAAAQBzBuAACaIAAAAQAACbhzBuIAAAAQhyBtiiAAIAAAAQihAAhyhtg");
	var mask_29_graphics_261 = new cjs.Graphics().p("AkkEZQh6h0AAilIAAAAQAAikB6h0IAAAAQB5h0CrAAIAAAAQCsAAB5B0IAAAAQB6B0AACkIAAAAQAAClh6B0IAAAAQh5B0isAAIAAAAQirAAh5h0g");
	var mask_29_graphics_262 = new cjs.Graphics().p("Ak2EqQiAh8AAiuIAAAAQAAitCAh8IAAAAQCBh7C1AAIAAAAQC2AACBB7IAAAAQCAB8AACtIAAAAQAACuiAB8IAAAAQiBB7i2AAIAAAAQi1AAiBh7g");
	var mask_29_graphics_263 = new cjs.Graphics().p("AlIE7QiIiCAAi5IAAAAQAAi4CIiCIAAAAQCIiDDAAAIAAAAQDBAACICDIAAAAQCICCAAC4IAAAAQAAC5iICCIAAAAQiICDjBAAIAAAAQjAAAiIiDg");
	var mask_29_graphics_264 = new cjs.Graphics().p("AlbFNQiQiKAAjDIAAAAQAAjCCQiKIAAAAQCQiKDLAAIAAAAQDMAACQCKIAAAAQCQCKAADCIAAAAQAADDiQCKIAAAAQiQCKjMAAIAAAAQjLAAiQiKg");
	var mask_29_graphics_265 = new cjs.Graphics().p("AluFgQiYiSAAjOIAAAAQAAjNCYiSIAAAAQCYiRDWAAIAAAAQDXAACYCRIAAAAQCYCSAADNIAAAAQAADOiYCSIAAAAQiYCRjXAAIAAAAQjWAAiYiRg");
	var mask_29_graphics_266 = new cjs.Graphics().p("AmCFzQigiaAAjZIAAAAQAAjYCgiaIAAAAQCgiZDiAAIAAAAQDjAACgCZIAAAAQCgCaAADYIAAAAQAADZigCaIAAAAQigCZjjAAIAAAAQjiAAigiZg");
	var mask_29_graphics_267 = new cjs.Graphics().p("AmXGGQioihAAjlIAAAAQAAjkCoiiIAAAAQCpihDuAAIAAAAQDvAACoChIAAAAQCpCiAADkIAAAAQAADlipChIAAAAQioCijvAAIAAAAQjuAAipiig");
	var mask_29_graphics_268 = new cjs.Graphics().p("AmsGbQixiqAAjxIAAAAQAAjwCxiqIAAAAQCyiqD6AAIAAAAQD7AACyCqIAAAAQCxCqAADwIAAAAQAADxixCqIAAAAQiyCqj7AAIAAAAQj6AAiyiqg");
	var mask_29_graphics_269 = new cjs.Graphics().p("AnBGvQi7iyAAj9IAAAAQAAj8C7izIAAAAQC6iyEHAAIAAAAQEIAAC6CyIAAAAQC7CzAAD8IAAAAQAAD9i7CyIAAAAQi6CzkIAAIAAAAQkHAAi6izg");
	var mask_29_graphics_270 = new cjs.Graphics().p("AnYHFQjEi8AAkJIAAAAQAAkIDEi8IAAAAQDEi8EUAAIAAAAQEVAADEC8IAAAAQDEC8AAEIIAAAAQAAEJjEC8IAAAAQjEC8kVAAIAAAAQkUAAjEi8g");
	var mask_29_graphics_271 = new cjs.Graphics().p("AnvHbQjNjFAAkWIAAAAQAAkVDNjFIAAAAQDOjFEhAAIAAAAQEiAADNDFIAAAAQDODFAAEVIAAAAQAAEWjODFIAAAAQjNDFkiAAIAAAAQkhAAjOjFg");
	var mask_29_graphics_272 = new cjs.Graphics().p("AoGHxQjXjOAAkjIAAAAQAAkiDXjPIAAAAQDXjOEvAAIAAAAQEwAADXDOIAAAAQDXDPAAEiIAAAAQAAEjjXDOIAAAAQjXDPkwAAIAAAAQkvAAjXjPg");
	var mask_29_graphics_273 = new cjs.Graphics().p("AoeIIQjhjXAAkxIAAAAQAAkwDhjYIAAAAQDhjXE9AAIAAAAQE+AADhDXIAAAAQDhDYAAEwIAAAAQAAExjhDXIAAAAQjhDYk+AAIAAAAQk9AAjhjYg");
	var mask_29_graphics_274 = new cjs.Graphics().p("Ao3IgQjrjhAAk/IAAAAQAAk+DrjhIAAAAQDrjiFMAAIAAAAQFNAADrDiIAAAAQDrDhAAE+IAAAAQAAE/jrDhIAAAAQjrDilNAAIAAAAQlMAAjrjig");
	var mask_29_graphics_275 = new cjs.Graphics().p("ApQI4Qj2jrAAlNIAAAAQAAlMD2jsIAAAAQD1jrFbAAIAAAAQFbAAD2DrIAAAAQD2DsAAFMIAAAAQAAFNj2DrIAAAAQj2DslbAAIAAAAQlbAAj1jsg");
	var mask_29_graphics_276 = new cjs.Graphics().p("ApqJRQkBj1AAlcIAAAAQAAlbEBj1IAAAAQEAj2FqAAIAAAAQFrAAEAD2IAAAAQEBD1AAFbIAAAAQAAFckBD1IAAAAQkAD2lrAAIAAAAQlqAAkAj2g");
	var mask_29_graphics_277 = new cjs.Graphics().p("AqFJrQkLkBAAlqIAAAAQAAlpELkBIAAAAQEMkAF5AAIAAAAQF6AAEMEAIAAAAQELEBAAFpIAAAAQAAFqkLEBIAAAAQkMEAl6AAIAAAAQl5AAkMkAg");
	var mask_29_graphics_278 = new cjs.Graphics().p("AqgKEQkWkKAAl6IAAAAQAAl5EWkLIAAAAQEXkLGJAAIAAAAQGKAAEXELIAAAAQEWELAAF5IAAAAQAAF6kWEKIAAAAQkXEMmKAAIAAAAQmJAAkXkMg");
	var mask_29_graphics_279 = new cjs.Graphics().p("Aq8KfQkikWAAmJIAAAAQAAmIEikWIAAAAQEjkWGZAAIAAAAQGaAAEiEWIAAAAQEjEWAAGIIAAAAQAAGJkjEWIAAAAQkiEWmaAAIAAAAQmZAAkjkWg");
	var mask_29_graphics_280 = new cjs.Graphics().p("ArYK6QkukhAAmZIAAAAQAAmYEukhIAAAAQEukiGqAAIAAAAQGrAAEuEiIAAAAQEuEhAAGYIAAAAQAAGZkuEhIAAAAQkuEimrAAIAAAAQmqAAkukig");
	var mask_29_graphics_281 = new cjs.Graphics().p("Ar1LWQk6ktAAmpIAAAAQAAmoE6ktIAAAAQE6ktG7AAIAAAAQG8AAE5EtIAAAAQE7EtAAGoIAAAAQAAGpk7EtIAAAAQk5Etm8AAIAAAAQm7AAk6ktg");
	var mask_29_graphics_282 = new cjs.Graphics().p("AsSLyQlGk4AAm6IAAAAQAAm5FGk4IAAAAQFGk5HMAAIAAAAQHNAAFGE5IAAAAQFGE4AAG5IAAAAQAAG6lGE4IAAAAQlGE5nNAAIAAAAQnMAAlGk5g");
	var mask_29_graphics_283 = new cjs.Graphics().p("AswMPQlTlEAAnLIAAAAQAAnKFTlEIAAAAQFSlEHeAAIAAAAQHfAAFSFEIAAAAQFTFEAAHKIAAAAQAAHLlTFEIAAAAQlSFEnfAAIAAAAQneAAlSlEg");
	var mask_29_graphics_284 = new cjs.Graphics().p("AtPMsQlflQAAncIAAAAQAAnbFflRIAAAAQFflQHwAAIAAAAQHxAAFfFQIAAAAQFfFRAAHbIAAAAQAAHclfFQIAAAAQlfFRnxAAIAAAAQnwAAlflRg");
	var mask_29_graphics_285 = new cjs.Graphics().p("AtuNKQlsldAAntIAAAAQAAnsFsleIAAAAQFslcICAAIAAAAQIDAAFsFcIAAAAQFsFeAAHsIAAAAQAAHtlsFdIAAAAQlsFdoDAAIAAAAQoCAAlsldg");
	var mask_29_graphics_286 = new cjs.Graphics().p("AuONpQl5lqAAn/IAAAAQAAn+F5lqIAAAAQF5lpIVgBIAAAAQIWABF5FpIAAAAQF5FqAAH+IAAAAQAAH/l5FqIAAAAQl5FqoWAAIAAAAQoVAAl5lqg");
	var mask_29_graphics_287 = new cjs.Graphics().p("AuuOHQmGl2AAoRIAAAAQAAoQGGl3IAAAAQGHl2InAAIAAAAQIoAAGHF2IAAAAQGGF3AAIQIAAAAQAAIRmGF2IAAAAQmHF3ooAAIAAAAQonAAmHl3g");
	var mask_29_graphics_288 = new cjs.Graphics().p("AvNOlQmUmCAAojIAAAAQAAoiGUmDIAAAAQGTmCI6AAIAAAAQI7AAGTGCIAAAAQGUGDAAIiIAAAAQAAIjmUGCIAAAAQmTGDo7AAIAAAAQo6AAmTmDg");
	var mask_29_graphics_289 = new cjs.Graphics().p("AvsPDQmgmPAAo0IAAAAQAAozGgmPIAAAAQGgmPJMAAIAAAAQJNAAGgGPIAAAAQGgGPAAIzIAAAAQAAI0mgGPIAAAAQmgGPpNAAIAAAAQpMAAmgmPg");
	var mask_29_graphics_290 = new cjs.Graphics().p("AwKPfQmtmaAApFIAAAAQAApEGtmbIAAAAQGtmaJdAAIAAAAQJeAAGtGaIAAAAQGtGbAAJEIAAAAQAAJFmtGaIAAAAQmtGbpeAAIAAAAQpdAAmtmbg");
	var mask_29_graphics_291 = new cjs.Graphics().p("AwoP8Qm4mnAApVIAAAAQAApUG4mnIAAAAQG6mmJuAAIAAAAQJvAAG5GmIAAAAQG5GnAAJUIAAAAQAAJVm5GnIAAAAQm5GmpvAAIAAAAQpuAAm6mmg");
	var mask_29_graphics_292 = new cjs.Graphics().p("AxEQXQnFmxAApmIAAAAQAAplHFmyIAAAAQHFmxJ/AAIAAAAQKAAAHFGxIAAAAQHFGyAAJlIAAAAQAAJmnFGxIAAAAQnFGyqAAAIAAAAQp/AAnFmyg");
	var mask_29_graphics_293 = new cjs.Graphics().p("AxhQyQnQm9AAp1IAAAAQAAp0HQm+IAAAAQHRm9KQAAIAAAAQKRAAHQG9IAAAAQHRG+AAJ0IAAAAQAAJ1nRG9IAAAAQnQG+qRAAIAAAAQqQAAnRm+g");
	var mask_29_graphics_294 = new cjs.Graphics().p("Ax8RNQncnIAAqFIAAAAQAAqEHcnIIAAAAQHcnIKgAAIAAAAQKhAAHcHIIAAAAQHcHIAAKEIAAAAQAAKFncHIIAAAAQncHIqhAAIAAAAQqgAAncnIg");
	var mask_29_graphics_295 = new cjs.Graphics().p("AyYRnQnnnTAAqUIAAAAQAAqTHnnTIAAAAQHonTKwAAIAAAAQKxAAHnHTIAAAAQHoHTAAKTIAAAAQAAKUnoHTIAAAAQnnHTqxAAIAAAAQqwAAnonTg");
	var mask_29_graphics_296 = new cjs.Graphics().p("AyySAQnyndAAqjIAAAAQAAqiHyneIAAAAQHzndK/AAIAAAAQLAAAHyHdIAAAAQHzHeAAKiIAAAAQAAKjnzHdIAAAAQnyHerAAAIAAAAQq/AAnzneg");
	var mask_29_graphics_297 = new cjs.Graphics().p("AzMSZQn9nnAAqyIAAAAQAAqxH9noIAAAAQH9nnLPAAIAAAAQLQAAH8HnIAAAAQH+HoAAKxIAAAAQAAKyn+HnIAAAAQn8HorQAAIAAAAQrPAAn9nog");
	var mask_29_graphics_298 = new cjs.Graphics().p("AzlSxQoHnxAArAIAAAAQAAq/IHnyIAAAAQIInxLdAAIAAAAQLeAAIIHxIAAAAQIHHyAAK/IAAAAQAALAoHHxIAAAAQoIHyreAAIAAAAQrdAAoInyg");
	var mask_29_graphics_299 = new cjs.Graphics().p("Az+TJQoRn7AArOIAAAAQAArNIRn8IAAAAQISn7LsAAIAAAAQLtAAIRH7IAAAAQISH8AALNIAAAAQAALOoSH7IAAAAQoRH8rtAAIAAAAQrsAAoSn8g");
	var mask_29_graphics_300 = new cjs.Graphics().p("A0WTgQocoFAArbIAAAAQAAraIcoGIAAAAQIcoEL6AAIAAAAQL7AAIbIEIAAAAQIdIGAALaIAAAAQAALbodIFIAAAAQobIFr7AAIAAAAQr6AAocoFg");
	var mask_29_graphics_301 = new cjs.Graphics().p("A0uT3QoloPAAroIAAAAQAArnIloPIAAAAQImoOMIAAIAAAAQMJAAIlIOIAAAAQImIPAALnIAAAAQAALoomIPIAAAAQolIOsJAAIAAAAQsIAAomoOg");
	var mask_29_graphics_302 = new cjs.Graphics().p("A1FUNQouoYAAr1IAAAAQAAr0IuoYIAAAAQIwoXMVAAIAAAAQMWAAIvIXIAAAAQIvIYAAL0IAAAAQAAL1ovIYIAAAAQovIXsWAAIAAAAQsVAAowoXg");
	var mask_29_graphics_303 = new cjs.Graphics().p("A1bUiQo4ogAAsCIAAAAQAAsBI4ohIAAAAQI5ogMiAAIAAAAQMjAAI4IgIAAAAQI5IhAAMBIAAAAQAAMCo5IgIAAAAQo4IhsjAAIAAAAQsiAAo5ohg");
	var mask_29_graphics_304 = new cjs.Graphics().p("A1xU3QpBopAAsOIAAAAQAAsNJBopIAAAAQJCopMvAAIAAAAQMwAAJBIpIAAAAQJCIpAAMNIAAAAQAAMOpCIpIAAAAQpBIpswAAIAAAAQsvAApCopg");
	var mask_29_graphics_305 = new cjs.Graphics().p("A2GVLQpJoxAAsaIAAAAQAAsZJJoyIAAAAQJLoxM7AAIAAAAQM8AAJKIxIAAAAQJKIyAAMZIAAAAQAAMapKIxIAAAAQpKIys8AAIAAAAQs7AApLoyg");
	var mask_29_graphics_306 = new cjs.Graphics().p("A2aVfQpSo6AAslIAAAAQAAskJSo6IAAAAQJSo6NIAAIAAAAQNJAAJSI6IAAAAQJSI6AAMkIAAAAQAAMlpSI6IAAAAQpSI6tJAAIAAAAQtIAApSo6g");
	var mask_29_graphics_307 = new cjs.Graphics().p("A2uVyQpbpBAAsxIAAAAQAAswJbpBIAAAAQJbpCNTAAIAAAAQNUAAJbJCIAAAAQJbJBAAMwIAAAAQAAMxpbJBIAAAAQpbJCtUAAIAAAAQtTAApbpCg");
	var mask_29_graphics_308 = new cjs.Graphics().p("A3CWEQpipJAAs7IAAAAQAAs6JipKIAAAAQJjpJNfAAIAAAAQNgAAJiJJIAAAAQJjJKAAM6IAAAAQAAM7pjJJIAAAAQpiJKtgAAIAAAAQtfAApjpKg");
	var mask_29_graphics_309 = new cjs.Graphics().p("A3UWWQprpQAAtGIAAAAQAAtFJrpRIAAAAQJqpQNqAAIAAAAQNrAAJqJQIAAAAQJrJRAANFIAAAAQAANGprJQIAAAAQpqJRtrAAIAAAAQtqAApqpRg");
	var mask_29_graphics_310 = new cjs.Graphics().p("A3nWoQpxpYAAtQIAAAAQAAtPJxpYIAAAAQJzpYN0AAIAAAAQN1AAJyJYIAAAAQJyJYAANPIAAAAQAANQpyJYIAAAAQpyJYt1AAIAAAAQt0AApzpYg");
	var mask_29_graphics_311 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_29_graphics_312 = new cjs.Graphics().p("A4JXJQqAplAAtkIAAAAQAAtjKApmIAAAAQKBplOIAAIAAAAQOJAAKAJlIAAAAQKBJmAANjIAAAAQAANkqBJlIAAAAQqAJmuJAAIAAAAQuIAAqBpmg");
	var mask_29_graphics_313 = new cjs.Graphics().p("A4aXYQqGprAAttIAAAAQAAtsKGpsIAAAAQKIpsOSAAIAAAAQOTAAKHJsIAAAAQKHJsAANsIAAAAQAANtqHJrIAAAAQqHJtuTAAIAAAAQuSAAqIptg");
	var mask_29_graphics_314 = new cjs.Graphics().p("A4pXoQqOpyAAt2IAAAAQAAt1KOpyIAAAAQKOpyObAAIAAAAQOcAAKOJyIAAAAQKOJyAAN1IAAAAQAAN2qOJyIAAAAQqOJyucAAIAAAAQubAAqOpyg");
	var mask_29_graphics_315 = new cjs.Graphics().p("A44X2QqUp4AAt+IAAAAQAAt9KUp5IAAAAQKUp4OkAAIAAAAQOlAAKUJ4IAAAAQKUJ5AAN9IAAAAQAAN+qUJ4IAAAAQqUJ5ulAAIAAAAQukAAqUp5g");
	var mask_29_graphics_316 = new cjs.Graphics().p("A5HYEQqap+AAuGIAAAAQAAuFKap/IAAAAQKap+OtAAIAAAAQOuAAKZJ+IAAAAQKbJ/AAOFIAAAAQAAOGqbJ+IAAAAQqZJ/uuAAIAAAAQutAAqap/g");
	var mask_29_graphics_317 = new cjs.Graphics().p("A5VYSQqgqEAAuOIAAAAQAAuNKgqEIAAAAQKgqEO1AAIAAAAQO2AAKfKEIAAAAQKhKEAAONIAAAAQAAOOqhKEIAAAAQqfKEu2AAIAAAAQu1AAqgqEg");
	var mask_29_graphics_318 = new cjs.Graphics().p("A5iYeQqlqIAAuWIAAAAQAAuVKlqJIAAAAQKlqJO9AAIAAAAQO+AAKlKJIAAAAQKlKJAAOVIAAAAQAAOWqlKIIAAAAQqlKKu+AAIAAAAQu9AAqlqKg");
	var mask_29_graphics_319 = new cjs.Graphics().p("A5vYrQqrqOAAudIAAAAQAAucKrqOIAAAAQKrqOPEAAIAAAAQPFAAKqKOIAAAAQKsKOAAOcIAAAAQAAOdqsKOIAAAAQqqKOvFAAIAAAAQvEAAqrqOg");
	var mask_29_graphics_320 = new cjs.Graphics().p("A58Y2QqvqSAAukIAAAAQAAujKvqTIAAAAQKxqTPLAAIAAAAQPMAAKwKTIAAAAQKwKTAAOjIAAAAQAAOkqwKSIAAAAQqwKUvMAAIAAAAQvLAAqxqUg");
	var mask_29_graphics_321 = new cjs.Graphics().p("A6HZBQq0qXAAuqIAAAAQAAupK0qYIAAAAQK1qXPSAAIAAAAQPTAAK0KXIAAAAQK1KYAAOpIAAAAQAAOqq1KXIAAAAQq0KYvTAAIAAAAQvSAAq1qYg");
	var mask_29_graphics_322 = new cjs.Graphics().p("A6SZMQq5qcAAuwIAAAAQAAuvK5qdIAAAAQK5qbPZAAIAAAAQPaAAK4KbIAAAAQK6KdAAOvIAAAAQAAOwq6KcIAAAAQq4KcvaAAIAAAAQvZAAq5qcg");
	var mask_29_graphics_323 = new cjs.Graphics().p("A6dZWQq9qgAAu2IAAAAQAAu1K9qhIAAAAQK+qfPfAAIAAAAQPgAAK9KfIAAAAQK+KhAAO1IAAAAQAAO2q+KgIAAAAQq9KgvgAAIAAAAQvfAAq+qgg");
	var mask_29_graphics_324 = new cjs.Graphics().p("A6mZfQrBqjAAu8IAAAAQAAu7LBqkIAAAAQLCqkPkAAIAAAAQPlAALCKkIAAAAQLBKkAAO7IAAAAQAAO8rBKjIAAAAQrCKlvlAAIAAAAQvkAArCqlg");
	var mask_29_graphics_325 = new cjs.Graphics().p("A6wZoQrFqnAAvBIAAAAQAAvALFqoIAAAAQLGqnPqAAIAAAAQPrAALFKnIAAAAQLGKoAAPAIAAAAQAAPBrGKnIAAAAQrFKovrAAIAAAAQvqAArGqog");
	var mask_29_graphics_326 = new cjs.Graphics().p("A64ZwQrJqqAAvGIAAAAQAAvFLJqrIAAAAQLJqrPvAAIAAAAQPwAALIKrIAAAAQLKKrAAPFIAAAAQAAPGrKKqIAAAAQrIKsvwAAIAAAAQvvAArJqsg");
	var mask_29_graphics_327 = new cjs.Graphics().p("A7AZ4QrMquAAvKIAAAAQAAvJLMqvIAAAAQLMquP0AAIAAAAQP1AALLKuIAAAAQLNKvAAPJIAAAAQAAPKrNKuIAAAAQrLKvv1AAIAAAAQv0AArMqvg");
	var mask_29_graphics_328 = new cjs.Graphics().p("A7IZ/QrPqxAAvOIAAAAQAAvNLPqyIAAAAQLQqxP4AAIAAAAQP5AALPKxIAAAAQLQKyAAPNIAAAAQAAPOrQKxIAAAAQrPKyv5AAIAAAAQv4AArQqyg");
	var mask_29_graphics_329 = new cjs.Graphics().p("A7PaGQrRq0AAvSIAAAAQAAvRLRq1IAAAAQLTqzP8AAIAAAAQP9AALSKzIAAAAQLSK1AAPRIAAAAQAAPSrSK0IAAAAQrSK0v9AAIAAAAQv8AArTq0g");
	var mask_29_graphics_330 = new cjs.Graphics().p("A7VaMQrUq2AAvWIAAAAQAAvVLUq3IAAAAQLVq2QAAAIAAAAQQBAALUK2IAAAAQLVK3AAPVIAAAAQAAPWrVK2IAAAAQrUK3wBAAIAAAAQwAAArVq3g");
	var mask_29_graphics_331 = new cjs.Graphics().p("A7baRQrWq4AAvZIAAAAQAAvYLWq5IAAAAQLYq4QDAAIAAAAQQEAALXK4IAAAAQLXK5AAPYIAAAAQAAPZrXK4IAAAAQrXK5wEAAIAAAAQwDAArYq5g");
	var mask_29_graphics_332 = new cjs.Graphics().p("A7gaWQrYq6AAvcIAAAAQAAvbLYq7IAAAAQLaq6QGAAIAAAAQQHAALZK6IAAAAQLZK7AAPbIAAAAQAAPcrZK6IAAAAQrZK7wHAAIAAAAQwGAAraq7g");
	var mask_29_graphics_333 = new cjs.Graphics().p("A7kaaQrbq8AAveIAAAAQAAvdLbq9IAAAAQLbq8QJAAIAAAAQQKAALaK8IAAAAQLcK9AAPdIAAAAQAAPercK8IAAAAQraK9wKAAIAAAAQwJAArbq9g");
	var mask_29_graphics_334 = new cjs.Graphics().p("A7oaeQrcq9AAvhIAAAAQAAvgLcq+IAAAAQLdq+QLAAIAAAAQQMAALcK+IAAAAQLdK+AAPgIAAAAQAAPhrdK9IAAAAQrcK/wMAAIAAAAQwLAArdq/g");
	var mask_29_graphics_335 = new cjs.Graphics().p("A7rahQreq/AAviIAAAAQAAvhLerAIAAAAQLeq/QNAAIAAAAQQOAALdK/IAAAAQLfLAAAPhIAAAAQAAPirfK/IAAAAQrdLAwOAAIAAAAQwNAArerAg");
	var mask_29_graphics_336 = new cjs.Graphics().p("A7uakQrfrAAAvkIAAAAQAAvjLfrBIAAAAQLgrAQOAAIAAAAQQPAALfLAIAAAAQLgLBAAPjIAAAAQAAPkrgLAIAAAAQrfLBwPAAIAAAAQwOAArgrBg");
	var mask_29_graphics_337 = new cjs.Graphics().p("A7wamQrfrBAAvlIAAAAQAAvkLfrCIAAAAQLgrAQQAAIAAAAQQRAALfLAIAAAAQLgLCAAPkIAAAAQAAPlrgLBIAAAAQrfLBwRAAIAAAAQwQAArgrBg");
	var mask_29_graphics_338 = new cjs.Graphics().p("A7xanQrhrBAAvmIAAAAQAAvlLhrCIAAAAQLhrBQQAAIAAAAQQRAALhLBIAAAAQLhLCAAPlIAAAAQAAPmrhLBIAAAAQrhLCwRAAIAAAAQwQAArhrCg");
	var mask_29_graphics_339 = new cjs.Graphics().p("A7yaoQrhrCAAvmIAAAAQAAvlLhrDIAAAAQLhrCQRAAIAAAAQQSAALgLCIAAAAQLiLDAAPlIAAAAQAAPmriLCIAAAAQrgLDwSAAIAAAAQwRAArhrDg");
	var mask_29_graphics_340 = new cjs.Graphics().p("A7zaoQrgrBAAvnIAAAAQAAvmLgrCIAAAAQLirCQRAAIAAAAQQSAALhLCIAAAAQLhLCAAPmIAAAAQAAPnrhLBIAAAAQrhLDwSAAIAAAAQwRAArirDg");

	this.timeline.addTween(cjs.Tween.get(mask_29).to({graphics:null,x:0,y:0}).wait(232).to({graphics:mask_29_graphics_232,x:349.7008,y:242.2503}).wait(1).to({graphics:mask_29_graphics_233,x:349.7008,y:242.2498}).wait(1).to({graphics:mask_29_graphics_234,x:349.7008,y:242.2494}).wait(1).to({graphics:mask_29_graphics_235,x:349.7008,y:242.2494}).wait(1).to({graphics:mask_29_graphics_236,x:349.7013,y:242.2485}).wait(1).to({graphics:mask_29_graphics_237,x:349.7022,y:242.2472}).wait(1).to({graphics:mask_29_graphics_238,x:349.7027,y:242.2453}).wait(1).to({graphics:mask_29_graphics_239,x:349.7035,y:242.2436}).wait(1).to({graphics:mask_29_graphics_240,x:349.704,y:242.2422}).wait(1).to({graphics:mask_29_graphics_241,x:349.7053,y:242.2395}).wait(1).to({graphics:mask_29_graphics_242,x:349.7063,y:242.2368}).wait(1).to({graphics:mask_29_graphics_243,x:349.7076,y:242.2346}).wait(1).to({graphics:mask_29_graphics_244,x:349.7085,y:242.2309}).wait(1).to({graphics:mask_29_graphics_245,x:349.7103,y:242.2282}).wait(1).to({graphics:mask_29_graphics_246,x:349.7121,y:242.2246}).wait(1).to({graphics:mask_29_graphics_247,x:349.7134,y:242.2206}).wait(1).to({graphics:mask_29_graphics_248,x:349.7152,y:242.2165}).wait(1).to({graphics:mask_29_graphics_249,x:349.717,y:242.2125}).wait(1).to({graphics:mask_29_graphics_250,x:349.7193,y:242.2075}).wait(1).to({graphics:mask_29_graphics_251,x:349.7211,y:242.2026}).wait(1).to({graphics:mask_29_graphics_252,x:349.7238,y:242.1976}).wait(1).to({graphics:mask_29_graphics_253,x:349.7256,y:242.1922}).wait(1).to({graphics:mask_29_graphics_254,x:349.7283,y:242.1868}).wait(1).to({graphics:mask_29_graphics_255,x:349.7305,y:242.1805}).wait(1).to({graphics:mask_29_graphics_256,x:349.7332,y:242.1747}).wait(1).to({graphics:mask_29_graphics_257,x:349.7364,y:242.168}).wait(1).to({graphics:mask_29_graphics_258,x:349.7395,y:242.1612}).wait(1).to({graphics:mask_29_graphics_259,x:349.7422,y:242.1544}).wait(1).to({graphics:mask_29_graphics_260,x:349.7458,y:242.1468}).wait(1).to({graphics:mask_29_graphics_261,x:349.7486,y:242.1396}).wait(1).to({graphics:mask_29_graphics_262,x:349.7517,y:242.1319}).wait(1).to({graphics:mask_29_graphics_263,x:349.7553,y:242.1238}).wait(1).to({graphics:mask_29_graphics_264,x:349.7593,y:242.1153}).wait(1).to({graphics:mask_29_graphics_265,x:349.7629,y:242.1072}).wait(1).to({graphics:mask_29_graphics_266,x:349.7665,y:242.0977}).wait(1).to({graphics:mask_29_graphics_267,x:349.7706,y:242.0892}).wait(1).to({graphics:mask_29_graphics_268,x:349.7751,y:242.0793}).wait(1).to({graphics:mask_29_graphics_269,x:349.7791,y:242.0703}).wait(1).to({graphics:mask_29_graphics_270,x:349.7832,y:242.0604}).wait(1).to({graphics:mask_29_graphics_271,x:349.7872,y:242.05}).wait(1).to({graphics:mask_29_graphics_272,x:349.7922,y:242.0397}).wait(1).to({graphics:mask_29_graphics_273,x:349.7971,y:242.0293}).wait(1).to({graphics:mask_29_graphics_274,x:349.8012,y:242.0181}).wait(1).to({graphics:mask_29_graphics_275,x:349.8066,y:242.0068}).wait(1).to({graphics:mask_29_graphics_276,x:349.8116,y:241.9951}).wait(1).to({graphics:mask_29_graphics_277,x:349.8165,y:241.9834}).wait(1).to({graphics:mask_29_graphics_278,x:349.8214,y:241.9717}).wait(1).to({graphics:mask_29_graphics_279,x:349.8273,y:241.9596}).wait(1).to({graphics:mask_29_graphics_280,x:349.8323,y:241.947}).wait(1).to({graphics:mask_29_graphics_281,x:349.8381,y:241.9339}).wait(1).to({graphics:mask_29_graphics_282,x:349.8435,y:241.9209}).wait(1).to({graphics:mask_29_graphics_283,x:349.8493,y:241.9078}).wait(1).to({graphics:mask_29_graphics_284,x:349.8552,y:241.8943}).wait(1).to({graphics:mask_29_graphics_285,x:349.8615,y:241.8804}).wait(1).to({graphics:mask_29_graphics_286,x:349.8678,y:241.866}).wait(1).to({graphics:mask_29_graphics_287,x:349.8736,y:241.8525}).wait(1).to({graphics:mask_29_graphics_288,x:349.8795,y:241.8385}).wait(1).to({graphics:mask_29_graphics_289,x:349.8853,y:241.825}).wait(1).to({graphics:mask_29_graphics_290,x:349.8912,y:241.8116}).wait(1).to({graphics:mask_29_graphics_291,x:349.8966,y:241.799}).wait(1).to({graphics:mask_29_graphics_292,x:349.9024,y:241.7859}).wait(1).to({graphics:mask_29_graphics_293,x:349.9079,y:241.7733}).wait(1).to({graphics:mask_29_graphics_294,x:349.9132,y:241.7611}).wait(1).to({graphics:mask_29_graphics_295,x:349.9186,y:241.7494}).wait(1).to({graphics:mask_29_graphics_296,x:349.9236,y:241.7377}).wait(1).to({graphics:mask_29_graphics_297,x:349.9285,y:241.7261}).wait(1).to({graphics:mask_29_graphics_298,x:349.9335,y:241.7148}).wait(1).to({graphics:mask_29_graphics_299,x:349.9384,y:241.7035}).wait(1).to({graphics:mask_29_graphics_300,x:349.9429,y:241.6932}).wait(1).to({graphics:mask_29_graphics_301,x:349.9474,y:241.6828}).wait(1).to({graphics:mask_29_graphics_302,x:349.9519,y:241.6725}).wait(1).to({graphics:mask_29_graphics_303,x:349.9564,y:241.6626}).wait(1).to({graphics:mask_29_graphics_304,x:349.9605,y:241.6532}).wait(1).to({graphics:mask_29_graphics_305,x:349.9641,y:241.6437}).wait(1).to({graphics:mask_29_graphics_306,x:349.9681,y:241.6347}).wait(1).to({graphics:mask_29_graphics_307,x:349.9722,y:241.6257}).wait(1).to({graphics:mask_29_graphics_308,x:349.9762,y:241.6171}).wait(1).to({graphics:mask_29_graphics_309,x:349.9794,y:241.609}).wait(1).to({graphics:mask_29_graphics_310,x:349.983,y:241.6009}).wait(1).to({graphics:mask_29_graphics_311,x:349.9861,y:241.5928}).wait(1).to({graphics:mask_29_graphics_312,x:349.9897,y:241.5861}).wait(1).to({graphics:mask_29_graphics_313,x:349.9929,y:241.5784}).wait(1).to({graphics:mask_29_graphics_314,x:349.9956,y:241.5717}).wait(1).to({graphics:mask_29_graphics_315,x:349.9983,y:241.5649}).wait(1).to({graphics:mask_29_graphics_316,x:350.0014,y:241.5582}).wait(1).to({graphics:mask_29_graphics_317,x:350.0041,y:241.5519}).wait(1).to({graphics:mask_29_graphics_318,x:350.0069,y:241.546}).wait(1).to({graphics:mask_29_graphics_319,x:350.0091,y:241.5406}).wait(1).to({graphics:mask_29_graphics_320,x:350.0113,y:241.5352}).wait(1).to({graphics:mask_29_graphics_321,x:350.0136,y:241.5303}).wait(1).to({graphics:mask_29_graphics_322,x:350.0159,y:241.5253}).wait(1).to({graphics:mask_29_graphics_323,x:350.0181,y:241.5204}).wait(1).to({graphics:mask_29_graphics_324,x:350.0199,y:241.5163}).wait(1).to({graphics:mask_29_graphics_325,x:350.0217,y:241.5123}).wait(1).to({graphics:mask_29_graphics_326,x:350.0235,y:241.5083}).wait(1).to({graphics:mask_29_graphics_327,x:350.0248,y:241.5046}).wait(1).to({graphics:mask_29_graphics_328,x:350.0262,y:241.5015}).wait(1).to({graphics:mask_29_graphics_329,x:350.0275,y:241.4984}).wait(1).to({graphics:mask_29_graphics_330,x:350.0289,y:241.4956}).wait(1).to({graphics:mask_29_graphics_331,x:350.0298,y:241.4934}).wait(1).to({graphics:mask_29_graphics_332,x:350.0307,y:241.4907}).wait(1).to({graphics:mask_29_graphics_333,x:350.0316,y:241.4893}).wait(1).to({graphics:mask_29_graphics_334,x:350.0325,y:241.4876}).wait(1).to({graphics:mask_29_graphics_335,x:350.0334,y:241.4857}).wait(1).to({graphics:mask_29_graphics_336,x:350.0334,y:241.4844}).wait(1).to({graphics:mask_29_graphics_337,x:350.0338,y:241.4835}).wait(1).to({graphics:mask_29_graphics_338,x:350.0339,y:241.4831}).wait(1).to({graphics:mask_29_graphics_339,x:350.0343,y:241.483}).wait(1).to({graphics:mask_29_graphics_340,x:349.4749,y:241.1626}).wait(470));

	// Layer_35
	this.instance_51 = new lib.Tween69("synched",0);
	this.instance_51.setTransform(280.05,185.8);
	this.instance_51.alpha = 0.5;
	this.instance_51._off = true;

	var maskedShapeInstanceList = [this.instance_51];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_29;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_51).wait(232).to({_off:false},0).to({alpha:1},108).wait(470));

	// Layer_6 (mask)
	var mask_30 = new cjs.Shape();
	mask_30._off = true;
	var mask_30_graphics_242 = new cjs.Graphics().p("AgPAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAGgGAJAAIAAAAQAKAAAGAGIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgGAGgKAAIAAAAQgJAAgGgGg");
	var mask_30_graphics_243 = new cjs.Graphics().p("AgPAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAGgGAJAAIAAAAQAKAAAGAGIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgGAGgKAAIAAAAQgJAAgGgGg");
	var mask_30_graphics_244 = new cjs.Graphics().p("AgQAQQgHgHAAgJIAAAAQAAgJAHgGIAAAAQAHgHAJAAIAAAAQAKAAAHAHIAAAAQAHAGAAAJIAAAAQAAAJgHAHIAAAAQgHAHgKAAIAAAAQgJAAgHgHg");
	var mask_30_graphics_245 = new cjs.Graphics().p("AgRARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAIgHAJAAIAAAAQAKAAAIAHIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgIAHgKAAIAAAAQgJAAgIgHg");
	var mask_30_graphics_246 = new cjs.Graphics().p("AgSASQgIgHAAgLIAAAAQAAgKAIgHIAAAAQAIgIAKAAIAAAAQALAAAIAIIAAAAQAIAHAAAKIAAAAQAAALgIAHIAAAAQgIAIgLAAIAAAAQgKAAgIgIg");
	var mask_30_graphics_247 = new cjs.Graphics().p("AgUAUQgIgIAAgMIAAAAQAAgLAIgIIAAAAQAJgIALAAIAAAAQAMAAAJAIIAAAAQAIAIAAALIAAAAQAAAMgIAIIAAAAQgJAIgMAAIAAAAQgLAAgJgIg");
	var mask_30_graphics_248 = new cjs.Graphics().p("AgVAVQgKgIAAgNIAAAAQAAgMAKgIIAAAAQAJgJAMAAIAAAAQANAAAJAJIAAAAQAKAIAAAMIAAAAQAAANgKAIIAAAAQgJAJgNAAIAAAAQgMAAgJgJg");
	var mask_30_graphics_249 = new cjs.Graphics().p("AgYAYQgKgKAAgOIAAAAQAAgNAKgKIAAAAQALgJANAAIAAAAQAOAAALAJIAAAAQAKAKAAANIAAAAQAAAOgKAKIAAAAQgLAJgOAAIAAAAQgNAAgLgJg");
	var mask_30_graphics_250 = new cjs.Graphics().p("AgaAaQgLgLAAgPIAAAAQAAgOALgLIAAAAQALgLAPAAIAAAAQAQAAALALIAAAAQALALAAAOIAAAAQAAAPgLALIAAAAQgLALgQAAIAAAAQgPAAgLgLg");
	var mask_30_graphics_251 = new cjs.Graphics().p("AgdAdQgNgMAAgRIAAAAQAAgQANgMIAAAAQAMgMARAAIAAAAQASAAAMAMIAAAAQANAMAAAQIAAAAQAAARgNAMIAAAAQgMAMgSAAIAAAAQgRAAgMgMg");
	var mask_30_graphics_252 = new cjs.Graphics().p("AggAgQgOgNAAgTIAAAAQAAgSAOgNIAAAAQANgNATAAIAAAAQAUAAANANIAAAAQAOANAAASIAAAAQAAATgOANIAAAAQgNANgUAAIAAAAQgTAAgNgNg");
	var mask_30_graphics_253 = new cjs.Graphics().p("AgkAjQgPgOAAgVIAAAAQAAgUAPgOIAAAAQAPgPAVAAIAAAAQAWAAAPAPIAAAAQAPAOAAAUIAAAAQAAAVgPAOIAAAAQgPAPgWAAIAAAAQgVAAgPgPg");
	var mask_30_graphics_254 = new cjs.Graphics().p("AgoAnQgRgQAAgXIAAAAQAAgWARgQIAAAAQARgQAXAAIAAAAQAYAAARAQIAAAAQARAQAAAWIAAAAQAAAXgRAQIAAAAQgRAQgYAAIAAAAQgXAAgRgQg");
	var mask_30_graphics_255 = new cjs.Graphics().p("AgsArQgTgSAAgZIAAAAQAAgYATgSIAAAAQATgSAZAAIAAAAQAaAAATASIAAAAQATASAAAYIAAAAQAAAZgTASIAAAAQgTASgaAAIAAAAQgZAAgTgSg");
	var mask_30_graphics_256 = new cjs.Graphics().p("AgxAwQgUgUAAgcIAAAAQAAgbAUgUIAAAAQAVgTAcAAIAAAAQAdAAAVATIAAAAQAUAUAAAbIAAAAQAAAcgUAUIAAAAQgVATgdAAIAAAAQgcAAgVgTg");
	var mask_30_graphics_257 = new cjs.Graphics().p("Ag2A0QgWgVAAgfIAAAAQAAgeAWgVIAAAAQAXgWAfAAIAAAAQAgAAAXAWIAAAAQAWAVAAAeIAAAAQAAAfgWAVIAAAAQgXAWggAAIAAAAQgfAAgXgWg");
	var mask_30_graphics_258 = new cjs.Graphics().p("Ag7A5QgZgXAAgiIAAAAQAAghAZgXIAAAAQAZgYAiAAIAAAAQAjAAAZAYIAAAAQAZAXAAAhIAAAAQAAAigZAXIAAAAQgZAYgjAAIAAAAQgiAAgZgYg");
	var mask_30_graphics_259 = new cjs.Graphics().p("AhBA/QgbgaAAglIAAAAQAAgkAbgaIAAAAQAcgaAlAAIAAAAQAmAAAcAaIAAAAQAbAaAAAkIAAAAQAAAlgbAaIAAAAQgcAagmAAIAAAAQglAAgcgag");
	var mask_30_graphics_260 = new cjs.Graphics().p("AhHBFQgdgdAAgoIAAAAQAAgnAdgdIAAAAQAegcApAAIAAAAQAqAAAeAcIAAAAQAdAdAAAnIAAAAQAAAogdAdIAAAAQgeAcgqAAIAAAAQgpAAgegcg");
	var mask_30_graphics_261 = new cjs.Graphics().p("AhNBLQgggfAAgsIAAAAQAAgrAggfIAAAAQAggfAtAAIAAAAQAuAAAgAfIAAAAQAgAfAAArIAAAAQAAAsggAfIAAAAQggAfguAAIAAAAQgtAAgggfg");
	var mask_30_graphics_262 = new cjs.Graphics().p("AhUBRQgjgiAAgvIAAAAQAAguAjgiIAAAAQAjgiAxAAIAAAAQAyAAAjAiIAAAAQAjAiAAAuIAAAAQAAAvgjAiIAAAAQgjAigyAAIAAAAQgxAAgjgig");
	var mask_30_graphics_263 = new cjs.Graphics().p("AhbBYQgmglAAgzIAAAAQAAgyAmglIAAAAQAmgkA1AAIAAAAQA2AAAmAkIAAAAQAmAlAAAyIAAAAQAAAzgmAlIAAAAQgmAkg2AAIAAAAQg1AAgmgkg");
	var mask_30_graphics_264 = new cjs.Graphics().p("AhiBfQgpgnAAg4IAAAAQAAg3ApgnIAAAAQApgnA5AAIAAAAQA6AAApAnIAAAAQApAnAAA3IAAAAQAAA4gpAnIAAAAQgpAng6AAIAAAAQg5AAgpgng");
	var mask_30_graphics_265 = new cjs.Graphics().p("AhqBmQgsgqAAg8IAAAAQAAg7AsgqIAAAAQAtgqA9AAIAAAAQA+AAAtAqIAAAAQAsAqAAA7IAAAAQAAA8gsAqIAAAAQgtAqg+AAIAAAAQg9AAgtgqg");
	var mask_30_graphics_266 = new cjs.Graphics().p("AhyBuQgvguAAhAIAAAAQAAg/AvguIAAAAQAwgtBCAAIAAAAQBDAAAwAtIAAAAQAvAuAAA/IAAAAQAABAgvAuIAAAAQgwAthDAAIAAAAQhCAAgwgtg");
	var mask_30_graphics_267 = new cjs.Graphics().p("Ah6B2QgzgxAAhFIAAAAQAAhEAzgxIAAAAQAzgxBHAAIAAAAQBIAAAzAxIAAAAQAzAxAABEIAAAAQAABFgzAxIAAAAQgzAxhIAAIAAAAQhHAAgzgxg");
	var mask_30_graphics_268 = new cjs.Graphics().p("AiDB+Qg2g0AAhKIAAAAQAAhJA2g0IAAAAQA3g1BMAAIAAAAQBNAAA3A1IAAAAQA2A0AABJIAAAAQAABKg2A0IAAAAQg3A0hNABIAAAAQhMgBg3g0g");
	var mask_30_graphics_269 = new cjs.Graphics().p("AiMCHQg6g4AAhPIAAAAQAAhOA6g4IAAAAQA7g4BRAAIAAAAQBSAAA7A4IAAAAQA6A4AABOIAAAAQAABPg6A4IAAAAQg7A4hSAAIAAAAQhRAAg7g4g");
	var mask_30_graphics_270 = new cjs.Graphics().p("AiVCQQg+g8AAhUIAAAAQAAhTA+g8IAAAAQA+g8BXAAIAAAAQBYAAA+A8IAAAAQA+A8AABTIAAAAQAABUg+A8IAAAAQg+A8hYAAIAAAAQhXAAg+g8g");
	var mask_30_graphics_271 = new cjs.Graphics().p("AifCZQhCg/AAhaIAAAAQAAhZBCg/IAAAAQBChABdAAIAAAAQBeAABCBAIAAAAQBCA/AABZIAAAAQAABahCA/IAAAAQhCBAheAAIAAAAQhdAAhChAg");
	var mask_30_graphics_272 = new cjs.Graphics().p("AipCjQhGhEAAhfIAAAAQAAheBGhEIAAAAQBGhDBjAAIAAAAQBkAABGBDIAAAAQBGBEAABeIAAAAQAABfhGBEIAAAAQhGBDhkAAIAAAAQhjAAhGhDg");
	var mask_30_graphics_273 = new cjs.Graphics().p("AizCtQhLhIAAhlIAAAAQAAhkBLhIIAAAAQBKhHBpAAIAAAAQBqAABKBHIAAAAQBLBIAABkIAAAAQAABlhLBIIAAAAQhKBHhqAAIAAAAQhpAAhKhHg");
	var mask_30_graphics_274 = new cjs.Graphics().p("Ai+C3QhPhMAAhrIAAAAQAAhqBPhMIAAAAQBPhMBvAAIAAAAQBwAABPBMIAAAAQBPBMAABqIAAAAQAABrhPBMIAAAAQhPBMhwAAIAAAAQhvAAhPhMg");
	var mask_30_graphics_275 = new cjs.Graphics().p("AjJDCQhUhQAAhyIAAAAQAAhxBUhQIAAAAQBUhQB1AAIAAAAQB2AABUBQIAAAAQBUBQAABxIAAAAQAAByhUBQIAAAAQhUBQh2AAIAAAAQh1AAhUhQg");
	var mask_30_graphics_276 = new cjs.Graphics().p("AjVDNQhYhVAAh4IAAAAQAAh3BYhVIAAAAQBZhVB8AAIAAAAQB9AABZBVIAAAAQBYBVAAB3IAAAAQAAB4hYBVIAAAAQhZBVh9AAIAAAAQh8AAhZhVg");
	var mask_30_graphics_277 = new cjs.Graphics().p("AjhDYQhdhZAAh/IAAAAQAAh+BdhZIAAAAQBehaCDAAIAAAAQCEAABdBaIAAAAQBeBZAAB+IAAAAQAAB/heBZIAAAAQhdBaiEAAIAAAAQiDAAhehag");
	var mask_30_graphics_278 = new cjs.Graphics().p("AjtDkQhihfAAiFIAAAAQAAiEBihfIAAAAQBjheCKAAIAAAAQCLAABjBeIAAAAQBiBfAACEIAAAAQAACFhiBfIAAAAQhjBeiLAAIAAAAQiKAAhjheg");
	var mask_30_graphics_279 = new cjs.Graphics().p("Aj5DwQhohkAAiMIAAAAQAAiLBohkIAAAAQBohjCRAAIAAAAQCSAABoBjIAAAAQBoBkAACLIAAAAQAACMhoBkIAAAAQhoBjiSAAIAAAAQiRAAhohjg");
	var mask_30_graphics_280 = new cjs.Graphics().p("AkGD8QhthoAAiUIAAAAQAAiTBthoIAAAAQBthoCZAAIAAAAQCaAABtBoIAAAAQBtBoAACTIAAAAQAACUhtBoIAAAAQhtBoiaAAIAAAAQiZAAhthog");
	var mask_30_graphics_281 = new cjs.Graphics().p("AkTEIQhyhtAAibIAAAAQAAiaByhuIAAAAQByhtChAAIAAAAQCiAAByBtIAAAAQByBuAACaIAAAAQAACbhyBtIAAAAQhyBuiiAAIAAAAQihAAhyhug");
	var mask_30_graphics_282 = new cjs.Graphics().p("AkhEVQh4hyAAijIAAAAQAAiiB4hzIAAAAQB4hyCpAAIAAAAQCqAAB3ByIAAAAQB5BzAACiIAAAAQAACjh5ByIAAAAQh3BziqAAIAAAAQipAAh4hzg");
	var mask_30_graphics_283 = new cjs.Graphics().p("AkuEjQh+h5AAiqIAAAAQAAipB+h5IAAAAQB9h4CxAAIAAAAQCyAAB9B4IAAAAQB+B5AACpIAAAAQAACqh+B5IAAAAQh9B4iyAAIAAAAQixAAh9h4g");
	var mask_30_graphics_284 = new cjs.Graphics().p("Ak9EwQiDh+AAiyIAAAAQAAixCDh+IAAAAQCEh+C5AAIAAAAQC6AACDB+IAAAAQCEB+AACxIAAAAQAACyiEB+IAAAAQiDB+i6AAIAAAAQi5AAiEh+g");
	var mask_30_graphics_285 = new cjs.Graphics().p("AlLE+QiKiEAAi6IAAAAQAAi5CKiEIAAAAQCJiEDCAAIAAAAQDDAACJCEIAAAAQCKCEAAC5IAAAAQAAC6iKCEIAAAAQiJCEjDAAIAAAAQjCAAiJiEg");
	var mask_30_graphics_286 = new cjs.Graphics().p("AlaFMQiQiJAAjDIAAAAQAAjCCQiKIAAAAQCQiJDKAAIAAAAQDLAACQCJIAAAAQCQCKAADCIAAAAQAADDiQCJIAAAAQiQCKjLAAIAAAAQjKAAiQiKg");
	var mask_30_graphics_287 = new cjs.Graphics().p("AlpFbQiWiQAAjLIAAAAQAAjKCWiQIAAAAQCWiQDTAAIAAAAQDUAACWCQIAAAAQCWCQAADKIAAAAQAADLiWCQIAAAAQiWCQjUAAIAAAAQjTAAiWiQg");
	var mask_30_graphics_288 = new cjs.Graphics().p("Al5FqQiciWAAjUIAAAAQAAjTCciWIAAAAQCdiWDcAAIAAAAQDdAACdCWIAAAAQCcCWAADTIAAAAQAADUicCWIAAAAQidCWjdAAIAAAAQjcAAidiWg");
	var mask_30_graphics_289 = new cjs.Graphics().p("AmJF5QijicAAjdIAAAAQAAjcCjicIAAAAQCjicDmAAIAAAAQDnAACiCcIAAAAQCkCcAADcIAAAAQAADdikCcIAAAAQiiCcjnAAIAAAAQjmAAijicg");
	var mask_30_graphics_290 = new cjs.Graphics().p("AmZGJQiqijAAjmIAAAAQAAjlCqijIAAAAQCqiiDvAAIAAAAQDwAACqCiIAAAAQCqCjAADlIAAAAQAADmiqCjIAAAAQiqCijwAAIAAAAQjvAAiqiig");
	var mask_30_graphics_291 = new cjs.Graphics().p("AmpGYQixipAAjvIAAAAQAAjuCxiqIAAAAQCwipD5AAIAAAAQD6AACwCpIAAAAQCxCqAADuIAAAAQAADvixCpIAAAAQiwCqj6AAIAAAAQj5AAiwiqg");
	var mask_30_graphics_292 = new cjs.Graphics().p("Am6GpQi4iwAAj5IAAAAQAAj4C4iwIAAAAQC3iwEDAAIAAAAQEEAAC3CwIAAAAQC4CwAAD4IAAAAQAAD5i4CwIAAAAQi3CwkEAAIAAAAQkDAAi3iwg");
	var mask_30_graphics_293 = new cjs.Graphics().p("AnMG5Qi+i3AAkCIAAAAQAAkBC+i3IAAAAQC/i3ENAAIAAAAQEOAAC+C3IAAAAQC/C3AAEBIAAAAQAAECi/C3IAAAAQi+C3kOAAIAAAAQkNAAi/i3g");
	var mask_30_graphics_294 = new cjs.Graphics().p("AndHKQjGi+AAkMIAAAAQAAkLDGi+IAAAAQDGi+EXAAIAAAAQEYAADGC+IAAAAQDGC+AAELIAAAAQAAEMjGC+IAAAAQjGC+kYAAIAAAAQkXAAjGi+g");
	var mask_30_graphics_295 = new cjs.Graphics().p("AnvHbQjOjFAAkWIAAAAQAAkVDOjFIAAAAQDNjFEiAAIAAAAQEjAADNDFIAAAAQDODFAAEVIAAAAQAAEWjODFIAAAAQjNDFkjAAIAAAAQkiAAjNjFg");
	var mask_30_graphics_296 = new cjs.Graphics().p("AoBHtQjVjMAAkhIAAAAQAAkgDVjMIAAAAQDVjMEsAAIAAAAQEtAADVDMIAAAAQDVDMAAEgIAAAAQAAEhjVDMIAAAAQjVDMktAAIAAAAQksAAjVjMg");
	var mask_30_graphics_297 = new cjs.Graphics().p("AoUH+QjcjTAAkrIAAAAQAAkqDcjTIAAAAQDdjUE3AAIAAAAQE4AADdDUIAAAAQDcDTAAEqIAAAAQAAErjcDTIAAAAQjdDUk4AAIAAAAQk3AAjdjUg");
	var mask_30_graphics_298 = new cjs.Graphics().p("AomIPQjkjaAAk1IAAAAQAAk0DkjbIAAAAQDljaFBAAIAAAAQFCAADkDaIAAAAQDlDbAAE0IAAAAQAAE1jlDaIAAAAQjkDblCAAIAAAAQlBAAjljbg");
	var mask_30_graphics_299 = new cjs.Graphics().p("Ao3IgQjsjhAAk/IAAAAQAAk+DsjiIAAAAQDrjhFMAAIAAAAQFNAADrDhIAAAAQDsDiAAE+IAAAAQAAE/jsDhIAAAAQjrDilNAAIAAAAQlMAAjrjig");
	var mask_30_graphics_300 = new cjs.Graphics().p("ApJIxQjyjoAAlJIAAAAQAAlIDyjoIAAAAQDzjoFWAAIAAAAQFXAADyDoIAAAAQDzDoAAFIIAAAAQAAFJjzDoIAAAAQjyDolXAAIAAAAQlWAAjzjog");
	var mask_30_graphics_301 = new cjs.Graphics().p("ApZJBQj6jvAAlSIAAAAQAAlRD6jvIAAAAQD5jvFgAAIAAAAQFhAAD5DvIAAAAQD6DvAAFRIAAAAQAAFSj6DvIAAAAQj5DvlhAAIAAAAQlgAAj5jvg");
	var mask_30_graphics_302 = new cjs.Graphics().p("ApqJRQkAj2AAlbIAAAAQAAlaEAj2IAAAAQEBj2FpAAIAAAAQFrAAEAD2IAAAAQEAD2AAFaIAAAAQAAFbkAD2IAAAAQkAD2lrAAIAAAAQlpAAkBj2g");
	var mask_30_graphics_303 = new cjs.Graphics().p("Ap6JgQkHj8AAlkIAAAAQAAljEHj9IAAAAQEHj8FzAAIAAAAQF0AAEHD8IAAAAQEHD9AAFjIAAAAQAAFkkHD8IAAAAQkHD9l0AAIAAAAQlzAAkHj9g");
	var mask_30_graphics_304 = new cjs.Graphics().p("AqKJwQkOkDAAltIAAAAQAAlsEOkDIAAAAQEOkCF8AAIAAAAQF9AAEOECIAAAAQEOEDAAFsIAAAAQAAFtkOEDIAAAAQkOECl9AAIAAAAQl8AAkOkCg");
	var mask_30_graphics_305 = new cjs.Graphics().p("AqaJ/QkUkJAAl2IAAAAQAAl1EUkJIAAAAQEVkIGFAAIAAAAQGGAAEUEIIAAAAQEVEJAAF1IAAAAQAAF2kVEJIAAAAQkUEImGAAIAAAAQmFAAkVkIg");
	var mask_30_graphics_306 = new cjs.Graphics().p("AqpKNQkakOAAl/IAAAAQAAl+EakOIAAAAQEbkPGOAAIAAAAQGPAAEbEPIAAAAQEaEOAAF+IAAAAQAAF/kaEOIAAAAQkbEPmPAAIAAAAQmOAAkbkPg");
	var mask_30_graphics_307 = new cjs.Graphics().p("Aq4KbQkgkUAAmHIAAAAQAAmGEgkVIAAAAQEhkUGXAAIAAAAQGYAAEgEUIAAAAQEhEVAAGGIAAAAQAAGHkhEUIAAAAQkgEVmYAAIAAAAQmXAAkhkVg");
	var mask_30_graphics_308 = new cjs.Graphics().p("ArGKpQknkaAAmPIAAAAQAAmOEnkbIAAAAQEmkaGgAAIAAAAQGhAAEmEaIAAAAQEnEbAAGOIAAAAQAAGPknEaIAAAAQkmEbmhAAIAAAAQmgAAkmkbg");
	var mask_30_graphics_309 = new cjs.Graphics().p("ArUK3QktkgAAmXIAAAAQAAmWEtkgIAAAAQEskgGoAAIAAAAQGpAAEsEgIAAAAQEtEgAAGWIAAAAQAAGXktEgIAAAAQksEgmpAAIAAAAQmoAAkskgg");
	var mask_30_graphics_310 = new cjs.Graphics().p("AriLEQkyklAAmfIAAAAQAAmeEyklIAAAAQEykmGwAAIAAAAQGxAAEyEmIAAAAQEyElAAGeIAAAAQAAGfkyElIAAAAQkyEmmxAAIAAAAQmwAAkykmg");
	var mask_30_graphics_311 = new cjs.Graphics().p("ArwLRQk3krAAmmIAAAAQAAmlE3krIAAAAQE4krG4AAIAAAAQG5AAE3ErIAAAAQE4ErAAGlIAAAAQAAGmk4ErIAAAAQk3Erm5AAIAAAAQm4AAk4krg");
	var mask_30_graphics_312 = new cjs.Graphics().p("Ar9LeQk9kwAAmuIAAAAQAAmtE9kwIAAAAQE9kwHAAAIAAAAQHBAAE9EwIAAAAQE9EwAAGtIAAAAQAAGuk9EwIAAAAQk9EwnBAAIAAAAQnAAAk9kwg");
	var mask_30_graphics_313 = new cjs.Graphics().p("AsKLqQlCk1AAm1IAAAAQAAm0FCk1IAAAAQFDk1HHAAIAAAAQHIAAFCE1IAAAAQFDE1AAG0IAAAAQAAG1lDE1IAAAAQlCE1nIAAIAAAAQnHAAlDk1g");
	var mask_30_graphics_314 = new cjs.Graphics().p("AsWL2QlIk6AAm8IAAAAQAAm7FIk6IAAAAQFIk6HOAAIAAAAQHPAAFIE6IAAAAQFIE6AAG7IAAAAQAAG8lIE6IAAAAQlIE6nPAAIAAAAQnOAAlIk6g");
	var mask_30_graphics_315 = new cjs.Graphics().p("AsiMBQlNk+AAnDIAAAAQAAnCFNk/IAAAAQFNk+HVAAIAAAAQHWAAFNE+IAAAAQFNE/AAHCIAAAAQAAHDlNE+IAAAAQlNE/nWAAIAAAAQnVAAlNk/g");
	var mask_30_graphics_316 = new cjs.Graphics().p("AsuMNQlSlEAAnJIAAAAQAAnIFSlEIAAAAQFSlDHcAAIAAAAQHdAAFSFDIAAAAQFSFEAAHIIAAAAQAAHJlSFEIAAAAQlSFDndAAIAAAAQncAAlSlDg");
	var mask_30_graphics_317 = new cjs.Graphics().p("As6MYQlWlIAAnQIAAAAQAAnPFWlIIAAAAQFXlIHjAAIAAAAQHkAAFWFIIAAAAQFXFIAAHPIAAAAQAAHQlXFIIAAAAQlWFInkAAIAAAAQnjAAlXlIg");
	var mask_30_graphics_318 = new cjs.Graphics().p("AtFMiQlblMAAnWIAAAAQAAnVFblNIAAAAQFblMHqAAIAAAAQHrAAFaFMIAAAAQFcFNAAHVIAAAAQAAHWlcFMIAAAAQlaFNnrAAIAAAAQnqAAlblNg");
	var mask_30_graphics_319 = new cjs.Graphics().p("AtQMtQlflRAAncIAAAAQAAnbFflRIAAAAQFglRHwAAIAAAAQHxAAFfFRIAAAAQFgFRAAHbIAAAAQAAHclgFRIAAAAQlfFRnxAAIAAAAQnwAAlglRg");
	var mask_30_graphics_320 = new cjs.Graphics().p("AtaM3QljlVAAniIAAAAQAAnhFjlVIAAAAQFklVH2AAIAAAAQH3AAFkFVIAAAAQFjFVAAHhIAAAAQAAHiljFVIAAAAQlkFVn3AAIAAAAQn2AAlklVg");
	var mask_30_graphics_321 = new cjs.Graphics().p("AtkNAQlolYAAnoIAAAAQAAnnFolZIAAAAQFolYH8AAIAAAAQH9AAFoFYIAAAAQFoFZAAHnIAAAAQAAHoloFYIAAAAQloFZn9AAIAAAAQn8AAlolZg");
	var mask_30_graphics_322 = new cjs.Graphics().p("AtuNKQlrldAAntIAAAAQAAnsFrldIAAAAQFsldICAAIAAAAQIDAAFrFdIAAAAQFsFdAAHsIAAAAQAAHtlsFdIAAAAQlrFdoDAAIAAAAQoCAAlsldg");
	var mask_30_graphics_323 = new cjs.Graphics().p("At3NTQlwlhAAnyIAAAAQAAnxFwlhIAAAAQFwlgIHAAIAAAAQIIAAFwFgIAAAAQFwFhAAHxIAAAAQAAHylwFhIAAAAQlwFgoIAAIAAAAQoHAAlwlgg");
	var mask_30_graphics_324 = new cjs.Graphics().p("AuANbQl0lkAAn3IAAAAQAAn2F0llIAAAAQF0lkIMAAIAAAAQINAAF0FkIAAAAQF0FlAAH2IAAAAQAAH3l0FkIAAAAQl0FloNAAIAAAAQoMAAl0llg");
	var mask_30_graphics_325 = new cjs.Graphics().p("AuJNkQl3loAAn8IAAAAQAAn7F3loIAAAAQF4lnIRAAIAAAAQISAAF3FnIAAAAQF4FoAAH7IAAAAQAAH8l4FoIAAAAQl3FnoSAAIAAAAQoRAAl4lng");
	var mask_30_graphics_326 = new cjs.Graphics().p("AuRNsQl7lrAAoBIAAAAQAAoAF7lrIAAAAQF7lrIWAAIAAAAQIXAAF7FrIAAAAQF7FrAAIAIAAAAQAAIBl7FrIAAAAQl7FroXAAIAAAAQoWAAl7lrg");
	var mask_30_graphics_327 = new cjs.Graphics().p("AuZNzQl+ltAAoGIAAAAQAAoFF+luIAAAAQF+luIbAAIAAAAQIcAAF+FuIAAAAQF+FuAAIFIAAAAQAAIGl+FtIAAAAQl+FvocAAIAAAAQobAAl+lvg");
	var mask_30_graphics_328 = new cjs.Graphics().p("AuhN7QmBlxAAoKIAAAAQAAoJGBlxIAAAAQGBlxIgAAIAAAAQIhAAGBFxIAAAAQGBFxAAIJIAAAAQAAIKmBFxIAAAAQmBFxohAAIAAAAQogAAmBlxg");
	var mask_30_graphics_329 = new cjs.Graphics().p("AuoOCQmEl0AAoOIAAAAQAAoNGEl0IAAAAQGEl0IkAAIAAAAQIlAAGEF0IAAAAQGEF0AAINIAAAAQAAIOmEF0IAAAAQmEF0olAAIAAAAQokAAmEl0g");
	var mask_30_graphics_330 = new cjs.Graphics().p("AuvOIQmHl2AAoSIAAAAQAAoRGHl3IAAAAQGHl2IoAAIAAAAQIpAAGHF2IAAAAQGHF3AAIRIAAAAQAAISmHF2IAAAAQmHF3opAAIAAAAQooAAmHl3g");
	var mask_30_graphics_331 = new cjs.Graphics().p("Au2OPQmKl5AAoWIAAAAQAAoVGKl5IAAAAQGKl5IsAAIAAAAQItAAGKF5IAAAAQGKF5AAIVIAAAAQAAIWmKF5IAAAAQmKF5otAAIAAAAQosAAmKl5g");
	var mask_30_graphics_332 = new cjs.Graphics().p("Au8OVQmNl8AAoZIAAAAQAAoYGNl8IAAAAQGMl8IwAAIAAAAQIxAAGMF8IAAAAQGNF8AAIYIAAAAQAAIZmNF8IAAAAQmMF8oxAAIAAAAQowAAmMl8g");
	var mask_30_graphics_333 = new cjs.Graphics().p("AvCObQmPl+AAodIAAAAQAAocGPl+IAAAAQGPl+IzAAIAAAAQI0AAGPF+IAAAAQGPF+AAIcIAAAAQAAIdmPF+IAAAAQmPF+o0AAIAAAAQozAAmPl+g");
	var mask_30_graphics_334 = new cjs.Graphics().p("AvIOgQmRmAAAogIAAAAQAAofGRmAIAAAAQGSmBI2AAIAAAAQI3AAGRGBIAAAAQGSGAAAIfIAAAAQAAIgmSGAIAAAAQmRGBo3AAIAAAAQo2AAmSmBg");
	var mask_30_graphics_335 = new cjs.Graphics().p("AvNOlQmUmCAAojIAAAAQAAoiGUmDIAAAAQGTmCI6AAIAAAAQI7AAGTGCIAAAAQGUGDAAIiIAAAAQAAIjmUGCIAAAAQmTGDo7AAIAAAAQo6AAmTmDg");
	var mask_30_graphics_336 = new cjs.Graphics().p("AvSOqQmWmFAAolIAAAAQAAokGWmFIAAAAQGWmFI8AAIAAAAQI9AAGWGFIAAAAQGWGFAAIkIAAAAQAAIlmWGFIAAAAQmWGFo9AAIAAAAQo8AAmWmFg");
	var mask_30_graphics_337 = new cjs.Graphics().p("AvXOuQmXmGAAooIAAAAQAAonGXmHIAAAAQGYmGI/AAIAAAAQJAAAGXGGIAAAAQGYGHAAInIAAAAQAAIomYGGIAAAAQmXGHpAAAIAAAAQo/AAmYmHg");
	var mask_30_graphics_338 = new cjs.Graphics().p("AvbOyQmZmIAAoqIAAAAQAAopGZmJIAAAAQGZmIJCAAIAAAAQJDAAGZGIIAAAAQGZGJAAIpIAAAAQAAIqmZGIIAAAAQmZGJpDAAIAAAAQpCAAmZmJg");
	var mask_30_graphics_339 = new cjs.Graphics().p("AvfO2QmbmJAAotIAAAAQAAosGbmKIAAAAQGbmJJEAAIAAAAQJFAAGbGJIAAAAQGbGKAAIsIAAAAQAAItmbGJIAAAAQmbGKpFAAIAAAAQpEAAmbmKg");
	var mask_30_graphics_340 = new cjs.Graphics().p("AvjO6QmcmLAAovIAAAAQAAouGcmLIAAAAQGdmLJGAAIAAAAQJHAAGcGLIAAAAQGdGLAAIuIAAAAQAAIvmdGLIAAAAQmcGLpHAAIAAAAQpGAAmdmLg");
	var mask_30_graphics_341 = new cjs.Graphics().p("AvmO9QmdmNAAowIAAAAQAAovGdmNIAAAAQGemMJIAAIAAAAQJJAAGdGMIAAAAQGeGNAAIvIAAAAQAAIwmeGNIAAAAQmdGMpJAAIAAAAQpIAAmemMg");
	var mask_30_graphics_342 = new cjs.Graphics().p("AvpO/QmemNAAoyIAAAAQAAoxGemOIAAAAQGfmNJKAAIAAAAQJLAAGeGNIAAAAQGfGOAAIxIAAAAQAAIymfGNIAAAAQmeGOpLAAIAAAAQpKAAmfmOg");
	var mask_30_graphics_343 = new cjs.Graphics().p("AvrPCQmgmOAAo0IAAAAQAAozGgmOIAAAAQGgmPJLAAIAAAAQJMAAGgGPIAAAAQGgGOAAIzIAAAAQAAI0mgGOIAAAAQmgGPpMAAIAAAAQpLAAmgmPg");
	var mask_30_graphics_344 = new cjs.Graphics().p("AvuPEQmgmPAAo1IAAAAQAAo0GgmPIAAAAQGimQJMAAIAAAAQJNAAGhGQIAAAAQGhGPAAI0IAAAAQAAI1mhGPIAAAAQmhGQpNAAIAAAAQpMAAmimQg");
	var mask_30_graphics_345 = new cjs.Graphics().p("AvvPGQmimQAAo2IAAAAQAAo1GimQIAAAAQGhmQJOAAIAAAAQJPAAGhGQIAAAAQGiGQAAI1IAAAAQAAI2miGQIAAAAQmhGQpPAAIAAAAQpOAAmhmQg");
	var mask_30_graphics_346 = new cjs.Graphics().p("AvxPHQmimQAAo3IAAAAQAAo2GimRIAAAAQGjmQJOAAIAAAAQJPAAGiGQIAAAAQGjGRAAI2IAAAAQAAI3mjGQIAAAAQmiGRpPAAIAAAAQpOAAmjmRg");
	var mask_30_graphics_347 = new cjs.Graphics().p("AvyPIQmjmRAAo3IAAAAQAAo2GjmSIAAAAQGjmRJPAAIAAAAQJQAAGjGRIAAAAQGjGSAAI2IAAAAQAAI3mjGRIAAAAQmjGSpQAAIAAAAQpPAAmjmSg");
	var mask_30_graphics_348 = new cjs.Graphics().p("AvzPJQmjmRAAo4IAAAAQAAo3GjmSIAAAAQGjmRJQAAIAAAAQJRAAGjGRIAAAAQGjGSAAI3IAAAAQAAI4mjGRIAAAAQmjGSpRAAIAAAAQpQAAmjmSg");
	var mask_30_graphics_349 = new cjs.Graphics().p("Av0PKQmjmSAAo4IAAAAQAAo3GjmSIAAAAQGkmSJQAAIAAAAQJRAAGjGSIAAAAQGkGSAAI3IAAAAQAAI4mkGSIAAAAQmjGSpRAAIAAAAQpQAAmkmSg");
	var mask_30_graphics_350 = new cjs.Graphics().p("Av0PKQmjmSAAo4IAAAAQAAo3GjmSIAAAAQGkmSJQAAIAAAAQJRAAGjGSIAAAAQGkGSAAI3IAAAAQAAI4mkGSIAAAAQmjGSpRAAIAAAAQpQAAmkmSg");

	this.timeline.addTween(cjs.Tween.get(mask_30).to({graphics:null,x:0,y:0}).wait(242).to({graphics:mask_30_graphics_242,x:581.0499,y:119.9502}).wait(1).to({graphics:mask_30_graphics_243,x:581.0499,y:119.9502}).wait(1).to({graphics:mask_30_graphics_244,x:581.0503,y:119.9502}).wait(1).to({graphics:mask_30_graphics_245,x:581.0503,y:119.9502}).wait(1).to({graphics:mask_30_graphics_246,x:581.0503,y:119.9502}).wait(1).to({graphics:mask_30_graphics_247,x:581.0503,y:119.9506}).wait(1).to({graphics:mask_30_graphics_248,x:581.0504,y:119.9506}).wait(1).to({graphics:mask_30_graphics_249,x:581.0503,y:119.9506}).wait(1).to({graphics:mask_30_graphics_250,x:581.0503,y:119.9506}).wait(1).to({graphics:mask_30_graphics_251,x:581.0503,y:119.9506}).wait(1).to({graphics:mask_30_graphics_252,x:581.0504,y:119.9511}).wait(1).to({graphics:mask_30_graphics_253,x:581.0508,y:119.9515}).wait(1).to({graphics:mask_30_graphics_254,x:581.0503,y:119.9515}).wait(1).to({graphics:mask_30_graphics_255,x:581.0504,y:119.952}).wait(1).to({graphics:mask_30_graphics_256,x:581.0508,y:119.952}).wait(1).to({graphics:mask_30_graphics_257,x:581.0508,y:119.9524}).wait(1).to({graphics:mask_30_graphics_258,x:581.0508,y:119.9524}).wait(1).to({graphics:mask_30_graphics_259,x:581.0508,y:119.9529}).wait(1).to({graphics:mask_30_graphics_260,x:581.0508,y:119.9533}).wait(1).to({graphics:mask_30_graphics_261,x:581.0512,y:119.9533}).wait(1).to({graphics:mask_30_graphics_262,x:581.0512,y:119.9543}).wait(1).to({graphics:mask_30_graphics_263,x:581.0512,y:119.9547}).wait(1).to({graphics:mask_30_graphics_264,x:581.0517,y:119.9547}).wait(1).to({graphics:mask_30_graphics_265,x:581.0517,y:119.9551}).wait(1).to({graphics:mask_30_graphics_266,x:581.0512,y:119.956}).wait(1).to({graphics:mask_30_graphics_267,x:581.0517,y:119.956}).wait(1).to({graphics:mask_30_graphics_268,x:581.0517,y:119.9569}).wait(1).to({graphics:mask_30_graphics_269,x:581.0521,y:119.9569}).wait(1).to({graphics:mask_30_graphics_270,x:581.0521,y:119.9578}).wait(1).to({graphics:mask_30_graphics_271,x:581.0521,y:119.9583}).wait(1).to({graphics:mask_30_graphics_272,x:581.0521,y:119.9592}).wait(1).to({graphics:mask_30_graphics_273,x:581.0526,y:119.9596}).wait(1).to({graphics:mask_30_graphics_274,x:581.0526,y:119.9601}).wait(1).to({graphics:mask_30_graphics_275,x:581.0526,y:119.961}).wait(1).to({graphics:mask_30_graphics_276,x:581.053,y:119.9614}).wait(1).to({graphics:mask_30_graphics_277,x:581.053,y:119.9619}).wait(1).to({graphics:mask_30_graphics_278,x:581.053,y:119.9628}).wait(1).to({graphics:mask_30_graphics_279,x:581.0535,y:119.9637}).wait(1).to({graphics:mask_30_graphics_280,x:581.0535,y:119.9641}).wait(1).to({graphics:mask_30_graphics_281,x:581.0535,y:119.965}).wait(1).to({graphics:mask_30_graphics_282,x:581.054,y:119.9655}).wait(1).to({graphics:mask_30_graphics_283,x:581.0544,y:119.9669}).wait(1).to({graphics:mask_30_graphics_284,x:581.0544,y:119.9673}).wait(1).to({graphics:mask_30_graphics_285,x:581.0548,y:119.9682}).wait(1).to({graphics:mask_30_graphics_286,x:581.0548,y:119.9691}).wait(1).to({graphics:mask_30_graphics_287,x:581.0548,y:119.97}).wait(1).to({graphics:mask_30_graphics_288,x:581.0548,y:119.9709}).wait(1).to({graphics:mask_30_graphics_289,x:581.0553,y:119.9718}).wait(1).to({graphics:mask_30_graphics_290,x:581.0558,y:119.9727}).wait(1).to({graphics:mask_30_graphics_291,x:581.0557,y:119.9736}).wait(1).to({graphics:mask_30_graphics_292,x:581.0562,y:119.9745}).wait(1).to({graphics:mask_30_graphics_293,x:581.0562,y:119.9758}).wait(1).to({graphics:mask_30_graphics_294,x:581.0571,y:119.9767}).wait(1).to({graphics:mask_30_graphics_295,x:581.0566,y:119.9776}).wait(1).to({graphics:mask_30_graphics_296,x:581.0571,y:119.9785}).wait(1).to({graphics:mask_30_graphics_297,x:581.0571,y:119.9794}).wait(1).to({graphics:mask_30_graphics_298,x:581.0575,y:119.9808}).wait(1).to({graphics:mask_30_graphics_299,x:581.058,y:119.9817}).wait(1).to({graphics:mask_30_graphics_300,x:581.058,y:119.9826}).wait(1).to({graphics:mask_30_graphics_301,x:581.0584,y:119.9839}).wait(1).to({graphics:mask_30_graphics_302,x:581.0584,y:119.9848}).wait(1).to({graphics:mask_30_graphics_303,x:581.0585,y:119.9857}).wait(1).to({graphics:mask_30_graphics_304,x:581.0589,y:119.9866}).wait(1).to({graphics:mask_30_graphics_305,x:581.0593,y:119.9875}).wait(1).to({graphics:mask_30_graphics_306,x:581.0593,y:119.9885}).wait(1).to({graphics:mask_30_graphics_307,x:581.0598,y:119.9889}).wait(1).to({graphics:mask_30_graphics_308,x:581.0602,y:119.9903}).wait(1).to({graphics:mask_30_graphics_309,x:581.0603,y:119.9907}).wait(1).to({graphics:mask_30_graphics_310,x:581.0602,y:119.9916}).wait(1).to({graphics:mask_30_graphics_311,x:581.0602,y:119.9921}).wait(1).to({graphics:mask_30_graphics_312,x:581.0607,y:119.9934}).wait(1).to({graphics:mask_30_graphics_313,x:581.0612,y:119.9934}).wait(1).to({graphics:mask_30_graphics_314,x:581.0607,y:119.9947}).wait(1).to({graphics:mask_30_graphics_315,x:581.0611,y:119.9952}).wait(1).to({graphics:mask_30_graphics_316,x:581.0616,y:119.9956}).wait(1).to({graphics:mask_30_graphics_317,x:581.0612,y:119.9965}).wait(1).to({graphics:mask_30_graphics_318,x:581.0616,y:119.9975}).wait(1).to({graphics:mask_30_graphics_319,x:581.062,y:119.9979}).wait(1).to({graphics:mask_30_graphics_320,x:581.062,y:119.9988}).wait(1).to({graphics:mask_30_graphics_321,x:581.062,y:119.9993}).wait(1).to({graphics:mask_30_graphics_322,x:581.0621,y:119.9992}).wait(1).to({graphics:mask_30_graphics_323,x:581.0625,y:120.0001}).wait(1).to({graphics:mask_30_graphics_324,x:581.0625,y:120.0006}).wait(1).to({graphics:mask_30_graphics_325,x:581.063,y:120.0015}).wait(1).to({graphics:mask_30_graphics_326,x:581.0625,y:120.0015}).wait(1).to({graphics:mask_30_graphics_327,x:581.0629,y:120.002}).wait(1).to({graphics:mask_30_graphics_328,x:581.063,y:120.0024}).wait(1).to({graphics:mask_30_graphics_329,x:581.0629,y:120.0029}).wait(1).to({graphics:mask_30_graphics_330,x:581.0634,y:120.0033}).wait(1).to({graphics:mask_30_graphics_331,x:581.0634,y:120.0037}).wait(1).to({graphics:mask_30_graphics_332,x:581.0634,y:120.0042}).wait(1).to({graphics:mask_30_graphics_333,x:581.0634,y:120.0042}).wait(1).to({graphics:mask_30_graphics_334,x:581.0638,y:120.0051}).wait(1).to({graphics:mask_30_graphics_335,x:581.0638,y:120.0051}).wait(1).to({graphics:mask_30_graphics_336,x:581.0634,y:120.0051}).wait(1).to({graphics:mask_30_graphics_337,x:581.0634,y:120.0056}).wait(1).to({graphics:mask_30_graphics_338,x:581.0634,y:120.0055}).wait(1).to({graphics:mask_30_graphics_339,x:581.0639,y:120.006}).wait(1).to({graphics:mask_30_graphics_340,x:581.0638,y:120.0064}).wait(1).to({graphics:mask_30_graphics_341,x:581.0643,y:120.0065}).wait(1).to({graphics:mask_30_graphics_342,x:581.0638,y:120.0064}).wait(1).to({graphics:mask_30_graphics_343,x:581.0643,y:120.0069}).wait(1).to({graphics:mask_30_graphics_344,x:581.0643,y:120.0069}).wait(1).to({graphics:mask_30_graphics_345,x:581.0643,y:120.0069}).wait(1).to({graphics:mask_30_graphics_346,x:581.0643,y:120.0069}).wait(1).to({graphics:mask_30_graphics_347,x:581.0638,y:120.0069}).wait(1).to({graphics:mask_30_graphics_348,x:581.0643,y:120.0073}).wait(1).to({graphics:mask_30_graphics_349,x:581.0638,y:120.0073}).wait(1).to({graphics:mask_30_graphics_350,x:581.0643,y:120.0073}).wait(460));

	// Layer_36
	this.instance_52 = new lib.Tween71("synched",0);
	this.instance_52.setTransform(614.35,108.65);
	this.instance_52.alpha = 0.5;
	this.instance_52._off = true;

	this.instance_53 = new lib.Tween72("synched",0);
	this.instance_53.setTransform(614.35,108.65);

	var maskedShapeInstanceList = [this.instance_52,this.instance_53];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_30;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_52}]},242).to({state:[{t:this.instance_53}]},108).wait(460));
	this.timeline.addTween(cjs.Tween.get(this.instance_52).wait(242).to({_off:false},0).to({_off:true,alpha:1},108).wait(460));

	// Layer_6 (mask)
	var mask_31 = new cjs.Shape();
	mask_31._off = true;
	var mask_31_graphics_320 = new cjs.Graphics().p("AgPAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAGgGAJAAIAAAAQAKAAAGAGIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgGAGgKAAIAAAAQgJAAgGgGg");
	var mask_31_graphics_321 = new cjs.Graphics().p("AgQAQQgGgHAAgJIAAAAQAAgIAGgHIAAAAQAHgGAJAAIAAAAQAKAAAGAGIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgGAGgKAAIAAAAQgJAAgHgGg");
	var mask_31_graphics_322 = new cjs.Graphics().p("AgQARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAHgGAJAAIAAAAQAKAAAHAGIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgHAGgKAAIAAAAQgJAAgHgGg");
	var mask_31_graphics_323 = new cjs.Graphics().p("AgRASQgIgIAAgKIAAAAQAAgJAIgIIAAAAQAHgHAKAAIAAAAQALAAAHAHIAAAAQAIAIAAAJIAAAAQAAAKgIAIIAAAAQgHAHgLAAIAAAAQgKAAgHgHg");
	var mask_31_graphics_324 = new cjs.Graphics().p("AgTATQgJgIAAgLIAAAAQAAgKAJgIIAAAAQAIgIALAAIAAAAQAMAAAIAIIAAAAQAJAIAAAKIAAAAQAAALgJAIIAAAAQgIAIgMAAIAAAAQgLAAgIgIg");
	var mask_31_graphics_325 = new cjs.Graphics().p("AgVAVQgKgIAAgNIAAAAQAAgMAKgIIAAAAQAJgJAMAAIAAAAQANAAAJAJIAAAAQAKAIAAAMIAAAAQAAANgKAIIAAAAQgJAJgNAAIAAAAQgMAAgJgJg");
	var mask_31_graphics_326 = new cjs.Graphics().p("AgYAYQgKgKAAgOIAAAAQAAgNAKgKIAAAAQAKgKAOAAIAAAAQAPAAAKAKIAAAAQAKAKAAANIAAAAQAAAOgKAKIAAAAQgKAKgPAAIAAAAQgOAAgKgKg");
	var mask_31_graphics_327 = new cjs.Graphics().p("AgbAbQgMgLAAgQIAAAAQAAgPAMgLIAAAAQALgLAQAAIAAAAQARAAALALIAAAAQAMALAAAPIAAAAQAAAQgMALIAAAAQgLALgRAAIAAAAQgQAAgLgLg");
	var mask_31_graphics_328 = new cjs.Graphics().p("AgfAfQgNgNAAgSIAAAAQAAgRANgNIAAAAQANgMASAAIAAAAQATAAANAMIAAAAQANANAAARIAAAAQAAASgNANIAAAAQgNAMgTAAIAAAAQgSAAgNgMg");
	var mask_31_graphics_329 = new cjs.Graphics().p("AgjAjQgPgPAAgUIAAAAQAAgTAPgPIAAAAQAPgOAUAAIAAAAQAVAAAPAOIAAAAQAPAPAAATIAAAAQAAAUgPAPIAAAAQgPAOgVAAIAAAAQgUAAgPgOg");
	var mask_31_graphics_330 = new cjs.Graphics().p("AgoAnQgRgQAAgXIAAAAQAAgWARgQIAAAAQARgQAXAAIAAAAQAYAAARAQIAAAAQARAQAAAWIAAAAQAAAXgRAQIAAAAQgRAQgYAAIAAAAQgXAAgRgQg");
	var mask_31_graphics_331 = new cjs.Graphics().p("AgtAsQgTgSAAgaIAAAAQAAgZATgSIAAAAQATgSAaAAIAAAAQAbAAATASIAAAAQATASAAAZIAAAAQAAAagTASIAAAAQgTASgbAAIAAAAQgaAAgTgSg");
	var mask_31_graphics_332 = new cjs.Graphics().p("AgzAxQgVgUAAgdIAAAAQAAgcAVgUIAAAAQAWgVAdAAIAAAAQAeAAAWAVIAAAAQAVAUAAAcIAAAAQAAAdgVAUIAAAAQgWAVgeAAIAAAAQgdAAgWgVg");
	var mask_31_graphics_333 = new cjs.Graphics().p("Ag5A3QgYgXAAggIAAAAQAAgfAYgXIAAAAQAYgXAhAAIAAAAQAiAAAYAXIAAAAQAYAXAAAfIAAAAQAAAggYAXIAAAAQgYAXgiAAIAAAAQghAAgYgXg");
	var mask_31_graphics_334 = new cjs.Graphics().p("Ag/A+QgbgaAAgkIAAAAQAAgjAbgaIAAAAQAagZAlAAIAAAAQAmAAAaAZIAAAAQAbAaAAAjIAAAAQAAAkgbAaIAAAAQgaAZgmAAIAAAAQglAAgagZg");
	var mask_31_graphics_335 = new cjs.Graphics().p("AhGBEQgegcAAgoIAAAAQAAgnAegcIAAAAQAdgdApAAIAAAAQAqAAAdAdIAAAAQAeAcAAAnIAAAAQAAAogeAcIAAAAQgdAdgqAAIAAAAQgpAAgdgdg");
	var mask_31_graphics_336 = new cjs.Graphics().p("AhOBMQghggAAgsIAAAAQAAgrAhggIAAAAQAhgfAtAAIAAAAQAuAAAhAfIAAAAQAhAgAAArIAAAAQAAAsghAgIAAAAQghAfguAAIAAAAQgtAAghgfg");
	var mask_31_graphics_337 = new cjs.Graphics().p("AhWBTQgkgiAAgxIAAAAQAAgwAkgiIAAAAQAkgjAyAAIAAAAQAzAAAkAjIAAAAQAkAiAAAwIAAAAQAAAxgkAiIAAAAQgkAjgzAAIAAAAQgyAAgkgjg");
	var mask_31_graphics_338 = new cjs.Graphics().p("AhfBcQgngmAAg2IAAAAQAAg1AngmIAAAAQAogmA3AAIAAAAQA4AAAoAmIAAAAQAnAmAAA1IAAAAQAAA2gnAmIAAAAQgoAmg4AAIAAAAQg3AAgogmg");
	var mask_31_graphics_339 = new cjs.Graphics().p("AhoBkQgrgpAAg7IAAAAQAAg6ArgpIAAAAQAsgqA8AAIAAAAQA9AAAsAqIAAAAQArApAAA6IAAAAQAAA7grApIAAAAQgsAqg9AAIAAAAQg8AAgsgqg");
	var mask_31_graphics_340 = new cjs.Graphics().p("AhxBtQgwgtAAhAIAAAAQAAg/AwgtIAAAAQAvguBCAAIAAAAQBDAAAvAuIAAAAQAwAtAAA/IAAAAQAABAgwAtIAAAAQgvAuhDAAIAAAAQhCAAgvgug");
	var mask_31_graphics_341 = new cjs.Graphics().p("Ah7B3Qg0gxAAhGIAAAAQAAhFA0gxIAAAAQAzgxBIAAIAAAAQBJAAAzAxIAAAAQA0AxAABFIAAAAQAABGg0AxIAAAAQgzAxhJAAIAAAAQhIAAgzgxg");
	var mask_31_graphics_342 = new cjs.Graphics().p("AiGCBQg4g1AAhMIAAAAQAAhLA4g1IAAAAQA4g2BOAAIAAAAQBPAAA4A2IAAAAQA4A1AABLIAAAAQAABMg4A1IAAAAQg4A2hPAAIAAAAQhOAAg4g2g");
	var mask_31_graphics_343 = new cjs.Graphics().p("AiRCMQg8g6AAhSIAAAAQAAhRA8g6IAAAAQA9g6BUAAIAAAAQBVAAA9A6IAAAAQA8A6AABRIAAAAQAABSg8A6IAAAAQg9A6hVAAIAAAAQhUAAg9g6g");
	var mask_31_graphics_344 = new cjs.Graphics().p("AicCXQhCg/AAhYIAAAAQAAhXBCg/IAAAAQBBg+BbAAIAAAAQBcAABBA+IAAAAQBCA/AABXIAAAAQAABYhCA/IAAAAQhBA+hcAAIAAAAQhbAAhBg+g");
	var mask_31_graphics_345 = new cjs.Graphics().p("AioCiQhHhDAAhfIAAAAQAAheBHhDIAAAAQBGhEBiAAIAAAAQBjAABGBEIAAAAQBHBDAABeIAAAAQAABfhHBDIAAAAQhGBEhjAAIAAAAQhiAAhGhEg");
	var mask_31_graphics_346 = new cjs.Graphics().p("Ai1CuQhLhIAAhmIAAAAQAAhlBLhIIAAAAQBLhIBqAAIAAAAQBrAABLBIIAAAAQBLBIAABlIAAAAQAABmhLBIIAAAAQhLBIhrAAIAAAAQhqAAhLhIg");
	var mask_31_graphics_347 = new cjs.Graphics().p("AjCC7QhRhOAAhtIAAAAQAAhsBRhOIAAAAQBRhNBxAAIAAAAQByAABRBNIAAAAQBRBOAABsIAAAAQAABthRBOIAAAAQhRBNhyAAIAAAAQhxAAhRhNg");
	var mask_31_graphics_348 = new cjs.Graphics().p("AjPDIQhXhTAAh1IAAAAQAAh0BXhTIAAAAQBWhSB5AAIAAAAQB6AABWBSIAAAAQBXBTAAB0IAAAAQAAB1hXBTIAAAAQhWBSh6AAIAAAAQh5AAhWhSg");
	var mask_31_graphics_349 = new cjs.Graphics().p("AjdDVQhchYAAh9IAAAAQAAh8BchYIAAAAQBchYCBAAIAAAAQCCAABcBYIAAAAQBcBYAAB8IAAAAQAAB9hcBYIAAAAQhcBYiCAAIAAAAQiBAAhchYg");
	var mask_31_graphics_350 = new cjs.Graphics().p("AjsDjQhiheAAiFIAAAAQAAiEBiheIAAAAQBiheCKAAIAAAAQCLAABiBeIAAAAQBiBeAACEIAAAAQAACFhiBeIAAAAQhiBeiLAAIAAAAQiKAAhiheg");
	var mask_31_graphics_351 = new cjs.Graphics().p("Aj7DxQhohkAAiNIAAAAQAAiMBohkIAAAAQBphkCSAAIAAAAQCTAABpBkIAAAAQBoBkAACMIAAAAQAACNhoBkIAAAAQhpBkiTAAIAAAAQiSAAhphkg");
	var mask_31_graphics_352 = new cjs.Graphics().p("AkKEAQhvhqAAiWIAAAAQAAiVBvhqIAAAAQBvhqCbAAIAAAAQCcAABvBqIAAAAQBvBqAACVIAAAAQAACWhvBqIAAAAQhvBqicAAIAAAAQibAAhvhqg");
	var mask_31_graphics_353 = new cjs.Graphics().p("AkaEPQh1hwAAifIAAAAQAAieB1hwIAAAAQB1hxClAAIAAAAQCmAAB1BxIAAAAQB1BwAACeIAAAAQAACfh1BwIAAAAQh1BximAAIAAAAQilAAh1hxg");
	var mask_31_graphics_354 = new cjs.Graphics().p("AkrEfQh8h3AAioIAAAAQAAinB8h3IAAAAQB9h3CuAAIAAAAQCvAAB8B3IAAAAQB9B3AACnIAAAAQAACoh9B3IAAAAQh8B3ivAAIAAAAQiuAAh9h3g");
	var mask_31_graphics_355 = new cjs.Graphics().p("Ak7EvQiDh9AAiyIAAAAQAAixCDh9IAAAAQCDh+C4AAIAAAAQC5AACDB+IAAAAQCDB9AACxIAAAAQAACyiDB9IAAAAQiDB+i5AAIAAAAQi4AAiDh+g");
	var mask_31_graphics_356 = new cjs.Graphics().p("AlNFAQiKiFAAi7IAAAAQAAi6CKiFIAAAAQCLiEDCAAIAAAAQDDAACLCEIAAAAQCKCFAAC6IAAAAQAAC7iKCFIAAAAQiLCEjDAAIAAAAQjCAAiLiEg");
	var mask_31_graphics_357 = new cjs.Graphics().p("AlfFRQiRiMAAjFIAAAAQAAjECRiMIAAAAQCSiMDNAAIAAAAQDOAACSCMIAAAAQCRCMAADEIAAAAQAADFiRCMIAAAAQiSCMjOAAIAAAAQjNAAiSiMg");
	var mask_31_graphics_358 = new cjs.Graphics().p("AlxFiQiZiSAAjQIAAAAQAAjPCZiTIAAAAQCZiSDYAAIAAAAQDZAACZCSIAAAAQCZCTAADPIAAAAQAADQiZCSIAAAAQiZCTjZAAIAAAAQjYAAiZiTg");
	var mask_31_graphics_359 = new cjs.Graphics().p("AmEF1QihibAAjaIAAAAQAAjZChibIAAAAQChiaDjAAIAAAAQDkAAChCaIAAAAQChCbAADZIAAAAQAADaihCbIAAAAQihCajkAAIAAAAQjjAAihiag");
	var mask_31_graphics_360 = new cjs.Graphics().p("AmXGHQipiiAAjlIAAAAQAAjkCpiiIAAAAQCpiiDuAAIAAAAQDvAACpCiIAAAAQCpCiAADkIAAAAQAADlipCiIAAAAQipCijvAAIAAAAQjuAAipiig");
	var mask_31_graphics_361 = new cjs.Graphics().p("AmrGaQixiqAAjwIAAAAQAAjvCxiqIAAAAQCxiqD6AAIAAAAQD7AACxCqIAAAAQCxCqAADvIAAAAQAADwixCqIAAAAQixCqj7AAIAAAAQj6AAixiqg");
	var mask_31_graphics_362 = new cjs.Graphics().p("AnAGuQi5iyAAj8IAAAAQAAj7C5iyIAAAAQC6iyEGAAIAAAAQEHAAC5CyIAAAAQC6CyAAD7IAAAAQAAD8i6CyIAAAAQi5CykHAAIAAAAQkGAAi6iyg");
	var mask_31_graphics_363 = new cjs.Graphics().p("AnUHBQjDi6AAkHIAAAAQAAkGDDi7IAAAAQDCi6ESAAIAAAAQETAADCC6IAAAAQDDC7AAEGIAAAAQAAEHjDC6IAAAAQjCC7kTAAIAAAAQkSAAjCi7g");
	var mask_31_graphics_364 = new cjs.Graphics().p("AnqHWQjLjDAAkTIAAAAQAAkSDLjDIAAAAQDMjDEeAAIAAAAQEfAADLDDIAAAAQDMDDAAESIAAAAQAAETjMDDIAAAAQjLDDkfAAIAAAAQkeAAjMjDg");
	var mask_31_graphics_365 = new cjs.Graphics().p("An/HrQjVjLAAkgIAAAAQAAkfDVjLIAAAAQDUjLErAAIAAAAQEsAADUDLIAAAAQDVDLAAEfIAAAAQAAEgjVDLIAAAAQjUDLksAAIAAAAQkrAAjUjLg");
	var mask_31_graphics_366 = new cjs.Graphics().p("AoWIAQjdjUAAksIAAAAQAAkrDdjUIAAAAQDejVE4AAIAAAAQE5AADeDVIAAAAQDdDUAAErIAAAAQAAEsjdDUIAAAAQjeDVk5AAIAAAAQk4AAjejVg");
	var mask_31_graphics_367 = new cjs.Graphics().p("AotIWQjmjdAAk5IAAAAQAAk4DmjdIAAAAQDojdFFAAIAAAAQFHAADmDdIAAAAQDnDdAAE4IAAAAQAAE5jnDdIAAAAQjmDdlHAAIAAAAQlFAAjojdg");
	var mask_31_graphics_368 = new cjs.Graphics().p("ApEIsQjwjmAAlGIAAAAQAAlFDwjnIAAAAQDxjmFTAAIAAAAQFUAADxDmIAAAAQDwDnAAFFIAAAAQAAFGjwDmIAAAAQjxDnlUAAIAAAAQlTAAjxjng");
	var mask_31_graphics_369 = new cjs.Graphics().p("ApcJDQj6jwAAlTIAAAAQAAlSD6jwIAAAAQD7jwFhAAIAAAAQFiAAD6DwIAAAAQD7DwAAFSIAAAAQAAFTj7DwIAAAAQj6DwliAAIAAAAQlhAAj7jwg");
	var mask_31_graphics_370 = new cjs.Graphics().p("Ap0JaQkEj5AAlhIAAAAQAAlgEEj6IAAAAQEFj5FvAAIAAAAQFwAAEFD5IAAAAQEED6AAFgIAAAAQAAFhkED5IAAAAQkFD6lwAAIAAAAQlvAAkFj6g");
	var mask_31_graphics_371 = new cjs.Graphics().p("AqNJyQkOkDAAlvIAAAAQAAluEOkDIAAAAQEPkEF+AAIAAAAQF/AAEOEEIAAAAQEPEDAAFuIAAAAQAAFvkPEDIAAAAQkOEEl/AAIAAAAQl+AAkPkEg");
	var mask_31_graphics_372 = new cjs.Graphics().p("AqmKKQkZkNAAl9IAAAAQAAl8EZkNIAAAAQEZkOGNAAIAAAAQGOAAEZEOIAAAAQEZENAAF8IAAAAQAAF9kZENIAAAAQkZEOmOAAIAAAAQmNAAkZkOg");
	var mask_31_graphics_373 = new cjs.Graphics().p("ArAKjQkjkYAAmLIAAAAQAAmKEjkYIAAAAQEkkYGcAAIAAAAQGdAAEjEYIAAAAQEkEYAAGKIAAAAQAAGLkkEYIAAAAQkjEYmdAAIAAAAQmcAAkkkYg");
	var mask_31_graphics_374 = new cjs.Graphics().p("AraK8QkukiAAmaIAAAAQAAmZEukiIAAAAQEvkiGrAAIAAAAQGsAAEuEiIAAAAQEvEiAAGZIAAAAQAAGakvEiIAAAAQkuEimsAAIAAAAQmrAAkvkig");
	var mask_31_graphics_375 = new cjs.Graphics().p("Ar0LVQk5ksAAmpIAAAAQAAmoE5ksIAAAAQE6ktG6AAIAAAAQG7AAE6EtIAAAAQE5EsAAGoIAAAAQAAGpk5EsIAAAAQk6Etm7AAIAAAAQm6AAk6ktg");
	var mask_31_graphics_376 = new cjs.Graphics().p("AsOLuQlEk3AAm3IAAAAQAAm2FEk3IAAAAQFFk3HJABIAAAAQHKgBFEE3IAAAAQFFE3AAG2IAAAAQAAG3lFE3IAAAAQlEE2nKAAIAAAAQnJAAlFk2g");
	var mask_31_graphics_377 = new cjs.Graphics().p("AsnMGQlOlBAAnFIAAAAQAAnEFOlBIAAAAQFPlBHYAAIAAAAQHZAAFPFBIAAAAQFOFBAAHEIAAAAQAAHFlOFBIAAAAQlPFBnZAAIAAAAQnYAAlPlBg");
	var mask_31_graphics_378 = new cjs.Graphics().p("AtAMeQlYlLAAnTIAAAAQAAnSFYlLIAAAAQFZlKHnAAIAAAAQHoAAFYFKIAAAAQFZFLAAHSIAAAAQAAHTlZFLIAAAAQlYFKnoAAIAAAAQnnAAlZlKg");
	var mask_31_graphics_379 = new cjs.Graphics().p("AtYM1QljlUAAnhIAAAAQAAngFjlUIAAAAQFjlUH1AAIAAAAQH2AAFjFUIAAAAQFjFUAAHgIAAAAQAAHhljFUIAAAAQljFUn2AAIAAAAQn1AAljlUg");
	var mask_31_graphics_380 = new cjs.Graphics().p("AtwNMQlsleAAnuIAAAAQAAntFsleIAAAAQFtldIDAAIAAAAQIEAAFsFdIAAAAQFtFeAAHtIAAAAQAAHultFeIAAAAQlsFdoEAAIAAAAQoDAAltldg");
	var mask_31_graphics_381 = new cjs.Graphics().p("AuHNiQl2lnAAn7IAAAAQAAn6F2lnIAAAAQF3lnIQAAIAAAAQIRAAF3FnIAAAAQF2FnAAH6IAAAAQAAH7l2FnIAAAAQl3FnoRAAIAAAAQoQAAl3lng");
	var mask_31_graphics_382 = new cjs.Graphics().p("AueN4QmAlwAAoIIAAAAQAAoHGAlwIAAAAQGAlwIeAAIAAAAQIfAAF/FwIAAAAQGBFwAAIHIAAAAQAAIImBFwIAAAAQl/FwofAAIAAAAQoeAAmAlwg");
	var mask_31_graphics_383 = new cjs.Graphics().p("Au0ONQmJl4AAoVIAAAAQAAoUGJl4IAAAAQGJl5IrAAIAAAAQIsAAGJF5IAAAAQGJF4AAIUIAAAAQAAIVmJF4IAAAAQmJF5osAAIAAAAQorAAmJl5g");
	var mask_31_graphics_384 = new cjs.Graphics().p("AvKOiQmSmBAAohIAAAAQAAogGSmBIAAAAQGSmBI4AAIAAAAQI5AAGRGBIAAAAQGTGBAAIgIAAAAQAAIhmTGBIAAAAQmRGBo5AAIAAAAQo4AAmSmBg");
	var mask_31_graphics_385 = new cjs.Graphics().p("AvfO2QmbmJAAotIAAAAQAAosGbmKIAAAAQGbmJJEAAIAAAAQJFAAGbGJIAAAAQGbGKAAIsIAAAAQAAItmbGJIAAAAQmbGKpFAAIAAAAQpEAAmbmKg");
	var mask_31_graphics_386 = new cjs.Graphics().p("Av0PKQmjmSAAo4IAAAAQAAo3GjmTIAAAAQGkmSJQAAIAAAAQJRAAGkGSIAAAAQGjGTAAI3IAAAAQAAI4mjGSIAAAAQmkGTpRAAIAAAAQpQAAmkmTg");
	var mask_31_graphics_387 = new cjs.Graphics().p("AwIPeQmsmaAApEIAAAAQAApDGsmaIAAAAQGsmaJcAAIAAAAQJdAAGsGaIAAAAQGsGaAAJDIAAAAQAAJEmsGaIAAAAQmsGapdAAIAAAAQpcAAmsmag");
	var mask_31_graphics_388 = new cjs.Graphics().p("AwcPxQm0miAApPIAAAAQAApOG0miIAAAAQG0miJoAAIAAAAQJpAAG0GiIAAAAQG0GiAAJOIAAAAQAAJPm0GiIAAAAQm0GippAAIAAAAQpoAAm0mig");
	var mask_31_graphics_389 = new cjs.Graphics().p("AwwQDQm8mpAApaIAAAAQAApZG8mqIAAAAQG9mpJzAAIAAAAQJ0AAG8GpIAAAAQG9GqAAJZIAAAAQAAJam9GpIAAAAQm8Gqp0AAIAAAAQpzAAm9mqg");
	var mask_31_graphics_390 = new cjs.Graphics().p("AxDQVQnDmxAApkIAAAAQAApjHDmyIAAAAQHFmxJ+AAIAAAAQJ/AAHEGxIAAAAQHEGyAAJjIAAAAQAAJknEGxIAAAAQnEGyp/AAIAAAAQp+AAnFmyg");
	var mask_31_graphics_391 = new cjs.Graphics().p("AxVQnQnLm4AApvIAAAAQAApuHLm4IAAAAQHMm5KJAAIAAAAQKKAAHLG5IAAAAQHMG4AAJuIAAAAQAAJvnMG4IAAAAQnLG5qKAAIAAAAQqJAAnMm5g");
	var mask_31_graphics_392 = new cjs.Graphics().p("AxnQ4QnTm/AAp5IAAAAQAAp4HTnAIAAAAQHUm/KTAAIAAAAQKUAAHTG/IAAAAQHUHAAAJ4IAAAAQAAJ5nUG/IAAAAQnTHAqUAAIAAAAQqTAAnUnAg");
	var mask_31_graphics_393 = new cjs.Graphics().p("Ax4RJQnanGAAqDIAAAAQAAqCHanGIAAAAQHanHKeAAIAAAAQKfAAHaHHIAAAAQHaHGAAKCIAAAAQAAKDnaHGIAAAAQnaHHqfAAIAAAAQqeAAnanHg");
	var mask_31_graphics_394 = new cjs.Graphics().p("AyJRZQnhnNAAqMIAAAAQAAqLHhnOIAAAAQHhnMKoAAIAAAAQKpAAHhHMIAAAAQHhHOAAKLIAAAAQAAKMnhHNIAAAAQnhHNqpAAIAAAAQqoAAnhnNg");
	var mask_31_graphics_395 = new cjs.Graphics().p("AyaRpQnnnUAAqVIAAAAQAAqUHnnUIAAAAQHpnUKxAAIAAAAQKyAAHoHUIAAAAQHoHUAAKUIAAAAQAAKVnoHUIAAAAQnoHUqyAAIAAAAQqxAAnpnUg");
	var mask_31_graphics_396 = new cjs.Graphics().p("AypR4QnvnaAAqeIAAAAQAAqdHvnbIAAAAQHvnZK6AAIAAAAQK7AAHvHZIAAAAQHvHbAAKdIAAAAQAAKenvHaIAAAAQnvHaq7AAIAAAAQq6AAnvnag");
	var mask_31_graphics_397 = new cjs.Graphics().p("Ay5SHQn1ngAAqnIAAAAQAAqmH1ngIAAAAQH2ngLDAAIAAAAQLEAAH1HgIAAAAQH2HgAAKmIAAAAQAAKnn2HgIAAAAQn1HgrEAAIAAAAQrDAAn2ngg");
	var mask_31_graphics_398 = new cjs.Graphics().p("AzISVQn7nmAAqvIAAAAQAAquH7nnIAAAAQH8nlLMAAIAAAAQLNAAH7HlIAAAAQH8HnAAKuIAAAAQAAKvn8HmIAAAAQn7HmrNAAIAAAAQrMAAn8nmg");
	var mask_31_graphics_399 = new cjs.Graphics().p("AzWSjQoBnsAAq3IAAAAQAAq2IBnsIAAAAQIBnsLVAAIAAAAQLWAAIBHsIAAAAQIBHsAAK2IAAAAQAAK3oBHsIAAAAQoBHsrWAAIAAAAQrVAAoBnsg");
	var mask_31_graphics_400 = new cjs.Graphics().p("AzkSwQoHnxAAq/IAAAAQAAq+IHnyIAAAAQIHnxLdAAIAAAAQLeAAIHHxIAAAAQIHHyAAK+IAAAAQAAK/oHHxIAAAAQoHHyreAAIAAAAQrdAAoHnyg");
	var mask_31_graphics_401 = new cjs.Graphics().p("AzyS9QoMn2AArHIAAAAQAArGIMn3IAAAAQINn2LlAAIAAAAQLmAAIMH2IAAAAQINH3AALGIAAAAQAALHoNH2IAAAAQoMH3rmAAIAAAAQrlAAoNn3g");
	var mask_31_graphics_402 = new cjs.Graphics().p("Az/TKQoRn8AArOIAAAAQAArNIRn8IAAAAQITn8LsAAIAAAAQLtAAISH8IAAAAQISH8AALNIAAAAQAALOoSH8IAAAAQoSH8rtAAIAAAAQrsAAoTn8g");
	var mask_31_graphics_403 = new cjs.Graphics().p("A0LTWQoXoBAArVIAAAAQAArUIXoBIAAAAQIXoBL0AAIAAAAQL1AAIXIBIAAAAQIXIBAALUIAAAAQAALVoXIBIAAAAQoXIBr1AAIAAAAQr0AAoXoBg");
	var mask_31_graphics_404 = new cjs.Graphics().p("A0XThQocoFAArcIAAAAQAArbIcoGIAAAAQIcoFL7AAIAAAAQL8AAIcIFIAAAAQIcIGAALbIAAAAQAALcocIFIAAAAQocIGr8AAIAAAAQr7AAocoGg");
	var mask_31_graphics_405 = new cjs.Graphics().p("A0jTsQogoKAAriIAAAAQAArhIgoLIAAAAQIioKMBAAIAAAAQMCAAIhIKIAAAAQIhILAALhIAAAAQAALiohIKIAAAAQohILsCAAIAAAAQsBAAoioLg");
	var mask_31_graphics_406 = new cjs.Graphics().p("A0uT3QoloPAAroIAAAAQAArnIloPIAAAAQImoPMIAAIAAAAQMJAAIlIPIAAAAQImIPAALnIAAAAQAALoomIPIAAAAQolIPsJAAIAAAAQsIAAomoPg");
	var mask_31_graphics_407 = new cjs.Graphics().p("A04UBQoqoTAAruIAAAAQAArtIqoTIAAAAQIqoTMOAAIAAAAQMPAAIqITIAAAAQIqITAALtIAAAAQAALuoqITIAAAAQoqITsPAAIAAAAQsOAAoqoTg");
	var mask_31_graphics_408 = new cjs.Graphics().p("A1CUKQouoWAAr0IAAAAQAArzIuoXIAAAAQIuoWMUAAIAAAAQMVAAIuIWIAAAAQIuIXAALzIAAAAQAAL0ouIWIAAAAQouIXsVAAIAAAAQsUAAouoXg");
	var mask_31_graphics_409 = new cjs.Graphics().p("A1MUUQoyobAAr5IAAAAQAAr4IyobIAAAAQIyoaMaAAIAAAAQMbAAIxIaIAAAAQIzIbAAL4IAAAAQAAL5ozIbIAAAAQoxIasbAAIAAAAQsaAAoyoag");
	var mask_31_graphics_410 = new cjs.Graphics().p("A1VUcQo1oeAAr+IAAAAQAAr9I1ofIAAAAQI2oeMfAAIAAAAQMgAAI1IeIAAAAQI2IfAAL9IAAAAQAAL+o2IeIAAAAQo1IfsgAAIAAAAQsfAAo2ofg");
	var mask_31_graphics_411 = new cjs.Graphics().p("A1eUkQo5ohAAsDIAAAAQAAsCI5oiIAAAAQI6ohMkAAIAAAAQMlAAI5IhIAAAAQI6IiAAMCIAAAAQAAMDo6IhIAAAAQo5IislAAIAAAAQskAAo6oig");
	var mask_31_graphics_412 = new cjs.Graphics().p("A1mUsQo8okAAsIIAAAAQAAsHI8olIAAAAQI9okMpAAIAAAAQMqAAI8IkIAAAAQI9IlAAMHIAAAAQAAMIo9IkIAAAAQo8IlsqAAIAAAAQspAAo9olg");
	var mask_31_graphics_413 = new cjs.Graphics().p("A1tUzQpAonAAsMIAAAAQAAsLJAooIAAAAQJAooMtAAIAAAAQMuAAJAIoIAAAAQJAIoAAMLIAAAAQAAMMpAInIAAAAQpAIpsuAAIAAAAQstAApAopg");
	var mask_31_graphics_414 = new cjs.Graphics().p("A10U6QpDoqAAsQIAAAAQAAsPJDorIAAAAQJDoqMxAAIAAAAQMyAAJDIqIAAAAQJDIrAAMPIAAAAQAAMQpDIqIAAAAQpDIrsyAAIAAAAQsxAApDorg");
	var mask_31_graphics_415 = new cjs.Graphics().p("A17VBQpFotAAsUIAAAAQAAsTJFotIAAAAQJGotM1AAIAAAAQM2AAJFItIAAAAQJGItAAMTIAAAAQAAMUpGItIAAAAQpFIts2AAIAAAAQs1AApGotg");
	var mask_31_graphics_416 = new cjs.Graphics().p("A2BVGQpIovAAsXIAAAAQAAsWJIowIAAAAQJIovM5AAIAAAAQM6AAJHIvIAAAAQJJIwAAMWIAAAAQAAMXpJIvIAAAAQpHIws6AAIAAAAQs5AApIowg");
	var mask_31_graphics_417 = new cjs.Graphics().p("A2HVMQpKoyAAsaIAAAAQAAsZJKozIAAAAQJLoxM8AAIAAAAQM9AAJKIxIAAAAQJLIzAAMZIAAAAQAAMapLIyIAAAAQpKIys9AAIAAAAQs8AApLoyg");
	var mask_31_graphics_418 = new cjs.Graphics().p("A2MVRQpMo0AAsdIAAAAQAAscJMo0IAAAAQJNo0M/AAIAAAAQNAAAJMI0IAAAAQJNI0AAMcIAAAAQAAMdpNI0IAAAAQpMI0tAAAIAAAAQs/AApNo0g");
	var mask_31_graphics_419 = new cjs.Graphics().p("A2RVVQpOo1AAsgIAAAAQAAsfJOo2IAAAAQJPo1NCAAIAAAAQNDAAJOI1IAAAAQJPI2AAMfIAAAAQAAMgpPI1IAAAAQpOI2tDAAIAAAAQtCAApPo2g");
	var mask_31_graphics_420 = new cjs.Graphics().p("A2VVZQpPo3AAsiIAAAAQAAshJPo4IAAAAQJRo3NEAAIAAAAQNFAAJQI3IAAAAQJQI4AAMhIAAAAQAAMipQI3IAAAAQpQI4tFAAIAAAAQtEAApRo4g");
	var mask_31_graphics_421 = new cjs.Graphics().p("A2YVdQpSo5AAskIAAAAQAAsjJSo5IAAAAQJSo5NGAAIAAAAQNHAAJSI5IAAAAQJSI5AAMjIAAAAQAAMkpSI5IAAAAQpSI5tHAAIAAAAQtGAApSo5g");
	var mask_31_graphics_422 = new cjs.Graphics().p("A2cVgQpSo6AAsmIAAAAQAAslJSo7IAAAAQJUo5NIAAIAAAAQNJAAJTI5IAAAAQJTI7AAMlIAAAAQAAMmpTI6IAAAAQpTI6tJAAIAAAAQtIAApUo6g");
	var mask_31_graphics_423 = new cjs.Graphics().p("A2eViQpUo6AAsoIAAAAQAAsnJUo7IAAAAQJUo7NKAAIAAAAQNLAAJUI7IAAAAQJUI7AAMnIAAAAQAAMopUI6IAAAAQpUI8tLAAIAAAAQtKAApUo8g");
	var mask_31_graphics_424 = new cjs.Graphics().p("A2gVlQpVo8AAspIAAAAQAAsoJVo8IAAAAQJVo8NLAAIAAAAQNMAAJVI8IAAAAQJVI8AAMoIAAAAQAAMppVI8IAAAAQpVI8tMAAIAAAAQtLAApVo8g");
	var mask_31_graphics_425 = new cjs.Graphics().p("A2iVmQpWo8AAsqIAAAAQAAspJWo9IAAAAQJWo8NMAAIAAAAQNNAAJVI8IAAAAQJXI9AAMpIAAAAQAAMqpXI8IAAAAQpVI9tNAAIAAAAQtMAApWo9g");
	var mask_31_graphics_426 = new cjs.Graphics().p("A2jVnQpWo9AAsqIAAAAQAAspJWo+IAAAAQJWo9NNAAIAAAAQNOAAJWI9IAAAAQJWI+AAMpIAAAAQAAMqpWI9IAAAAQpWI+tOAAIAAAAQtNAApWo+g");
	var mask_31_graphics_427 = new cjs.Graphics().p("A2kVoQpWo9AAsrIAAAAQAAsqJWo+IAAAAQJXo9NNAAIAAAAQNOAAJWI9IAAAAQJXI+AAMqIAAAAQAAMrpXI9IAAAAQpWI+tOAAIAAAAQtNAApXo+g");
	var mask_31_graphics_428 = new cjs.Graphics().p("A2kVoQpXo9AAsrIAAAAQAAsqJXo+IAAAAQJXo9NNAAIAAAAQNOAAJXI9IAAAAQJXI+AAMqIAAAAQAAMrpXI9IAAAAQpXI+tOAAIAAAAQtNAApXo+g");

	this.timeline.addTween(cjs.Tween.get(mask_31).to({graphics:null,x:0,y:0}).wait(320).to({graphics:mask_31_graphics_320,x:690.9003,y:167.7501}).wait(1).to({graphics:mask_31_graphics_321,x:690.8998,y:167.7501}).wait(1).to({graphics:mask_31_graphics_322,x:690.8976,y:167.7501}).wait(1).to({graphics:mask_31_graphics_323,x:690.8949,y:167.7501}).wait(1).to({graphics:mask_31_graphics_324,x:690.8908,y:167.7501}).wait(1).to({graphics:mask_31_graphics_325,x:690.8854,y:167.7505}).wait(1).to({graphics:mask_31_graphics_326,x:690.8787,y:167.7501}).wait(1).to({graphics:mask_31_graphics_327,x:690.871,y:167.7501}).wait(1).to({graphics:mask_31_graphics_328,x:690.8625,y:167.7501}).wait(1).to({graphics:mask_31_graphics_329,x:690.8526,y:167.7501}).wait(1).to({graphics:mask_31_graphics_330,x:690.8413,y:167.7501}).wait(1).to({graphics:mask_31_graphics_331,x:690.8292,y:167.7501}).wait(1).to({graphics:mask_31_graphics_332,x:690.8157,y:167.7505}).wait(1).to({graphics:mask_31_graphics_333,x:690.8008,y:167.7505}).wait(1).to({graphics:mask_31_graphics_334,x:690.7851,y:167.7505}).wait(1).to({graphics:mask_31_graphics_335,x:690.768,y:167.7505}).wait(1).to({graphics:mask_31_graphics_336,x:690.7495,y:167.7505}).wait(1).to({graphics:mask_31_graphics_337,x:690.7302,y:167.7505}).wait(1).to({graphics:mask_31_graphics_338,x:690.7099,y:167.7505}).wait(1).to({graphics:mask_31_graphics_339,x:690.6879,y:167.751}).wait(1).to({graphics:mask_31_graphics_340,x:690.6649,y:167.751}).wait(1).to({graphics:mask_31_graphics_341,x:690.6406,y:167.751}).wait(1).to({graphics:mask_31_graphics_342,x:690.6154,y:167.751}).wait(1).to({graphics:mask_31_graphics_343,x:690.5894,y:167.751}).wait(1).to({graphics:mask_31_graphics_344,x:690.5614,y:167.751}).wait(1).to({graphics:mask_31_graphics_345,x:690.5326,y:167.7514}).wait(1).to({graphics:mask_31_graphics_346,x:690.5025,y:167.751}).wait(1).to({graphics:mask_31_graphics_347,x:690.4714,y:167.751}).wait(1).to({graphics:mask_31_graphics_348,x:690.4391,y:167.7514}).wait(1).to({graphics:mask_31_graphics_349,x:690.4053,y:167.7514}).wait(1).to({graphics:mask_31_graphics_350,x:690.3706,y:167.7519}).wait(1).to({graphics:mask_31_graphics_351,x:690.3351,y:167.7519}).wait(1).to({graphics:mask_31_graphics_352,x:690.2982,y:167.7519}).wait(1).to({graphics:mask_31_graphics_353,x:690.2599,y:167.7519}).wait(1).to({graphics:mask_31_graphics_354,x:690.2203,y:167.7523}).wait(1).to({graphics:mask_31_graphics_355,x:690.1798,y:167.7523}).wait(1).to({graphics:mask_31_graphics_356,x:690.1375,y:167.7523}).wait(1).to({graphics:mask_31_graphics_357,x:690.0948,y:167.7523}).wait(1).to({graphics:mask_31_graphics_358,x:690.0507,y:167.7528}).wait(1).to({graphics:mask_31_graphics_359,x:690.0052,y:167.7528}).wait(1).to({graphics:mask_31_graphics_360,x:689.9589,y:167.7528}).wait(1).to({graphics:mask_31_graphics_361,x:689.9117,y:167.7528}).wait(1).to({graphics:mask_31_graphics_362,x:689.863,y:167.7532}).wait(1).to({graphics:mask_31_graphics_363,x:689.8126,y:167.7537}).wait(1).to({graphics:mask_31_graphics_364,x:689.7618,y:167.7532}).wait(1).to({graphics:mask_31_graphics_365,x:689.7091,y:167.7537}).wait(1).to({graphics:mask_31_graphics_366,x:689.6556,y:167.7537}).wait(1).to({graphics:mask_31_graphics_367,x:689.6007,y:167.7537}).wait(1).to({graphics:mask_31_graphics_368,x:689.5453,y:167.7541}).wait(1).to({graphics:mask_31_graphics_369,x:689.4882,y:167.7542}).wait(1).to({graphics:mask_31_graphics_370,x:689.4297,y:167.7541}).wait(1).to({graphics:mask_31_graphics_371,x:689.3707,y:167.7546}).wait(1).to({graphics:mask_31_graphics_372,x:689.31,y:167.7551}).wait(1).to({graphics:mask_31_graphics_373,x:689.2479,y:167.755}).wait(1).to({graphics:mask_31_graphics_374,x:689.1854,y:167.7555}).wait(1).to({graphics:mask_31_graphics_375,x:689.1223,y:167.7555}).wait(1).to({graphics:mask_31_graphics_376,x:689.0607,y:167.7555}).wait(1).to({graphics:mask_31_graphics_377,x:688.9999,y:167.7555}).wait(1).to({graphics:mask_31_graphics_378,x:688.9406,y:167.7559}).wait(1).to({graphics:mask_31_graphics_379,x:688.882,y:167.7559}).wait(1).to({graphics:mask_31_graphics_380,x:688.8249,y:167.7564}).wait(1).to({graphics:mask_31_graphics_381,x:688.7695,y:167.7564}).wait(1).to({graphics:mask_31_graphics_382,x:688.7147,y:167.7569}).wait(1).to({graphics:mask_31_graphics_383,x:688.6611,y:167.7569}).wait(1).to({graphics:mask_31_graphics_384,x:688.6089,y:167.7568}).wait(1).to({graphics:mask_31_graphics_385,x:688.5576,y:167.7573}).wait(1).to({graphics:mask_31_graphics_386,x:688.5076,y:167.7568}).wait(1).to({graphics:mask_31_graphics_387,x:688.459,y:167.7573}).wait(1).to({graphics:mask_31_graphics_388,x:688.4113,y:167.7573}).wait(1).to({graphics:mask_31_graphics_389,x:688.365,y:167.7577}).wait(1).to({graphics:mask_31_graphics_390,x:688.3195,y:167.7578}).wait(1).to({graphics:mask_31_graphics_391,x:688.2755,y:167.7578}).wait(1).to({graphics:mask_31_graphics_392,x:688.2327,y:167.7582}).wait(1).to({graphics:mask_31_graphics_393,x:688.1908,y:167.7582}).wait(1).to({graphics:mask_31_graphics_394,x:688.1499,y:167.7587}).wait(1).to({graphics:mask_31_graphics_395,x:688.1107,y:167.7582}).wait(1).to({graphics:mask_31_graphics_396,x:688.072,y:167.7582}).wait(1).to({graphics:mask_31_graphics_397,x:688.0356,y:167.7587}).wait(1).to({graphics:mask_31_graphics_398,x:687.9996,y:167.7591}).wait(1).to({graphics:mask_31_graphics_399,x:687.9649,y:167.7586}).wait(1).to({graphics:mask_31_graphics_400,x:687.9312,y:167.7591}).wait(1).to({graphics:mask_31_graphics_401,x:687.8988,y:167.7591}).wait(1).to({graphics:mask_31_graphics_402,x:687.8678,y:167.7591}).wait(1).to({graphics:mask_31_graphics_403,x:687.8376,y:167.7596}).wait(1).to({graphics:mask_31_graphics_404,x:687.8092,y:167.7591}).wait(1).to({graphics:mask_31_graphics_405,x:687.7809,y:167.7595}).wait(1).to({graphics:mask_31_graphics_406,x:687.7548,y:167.7595}).wait(1).to({graphics:mask_31_graphics_407,x:687.7296,y:167.7595}).wait(1).to({graphics:mask_31_graphics_408,x:687.7053,y:167.7596}).wait(1).to({graphics:mask_31_graphics_409,x:687.6823,y:167.76}).wait(1).to({graphics:mask_31_graphics_410,x:687.6608,y:167.76}).wait(1).to({graphics:mask_31_graphics_411,x:687.64,y:167.76}).wait(1).to({graphics:mask_31_graphics_412,x:687.6207,y:167.76}).wait(1).to({graphics:mask_31_graphics_413,x:687.6022,y:167.76}).wait(1).to({graphics:mask_31_graphics_414,x:687.5856,y:167.7595}).wait(1).to({graphics:mask_31_graphics_415,x:687.5694,y:167.7605}).wait(1).to({graphics:mask_31_graphics_416,x:687.555,y:167.76}).wait(1).to({graphics:mask_31_graphics_417,x:687.5415,y:167.76}).wait(1).to({graphics:mask_31_graphics_418,x:687.5289,y:167.76}).wait(1).to({graphics:mask_31_graphics_419,x:687.5181,y:167.7604}).wait(1).to({graphics:mask_31_graphics_420,x:687.5078,y:167.76}).wait(1).to({graphics:mask_31_graphics_421,x:687.4992,y:167.76}).wait(1).to({graphics:mask_31_graphics_422,x:687.4915,y:167.7604}).wait(1).to({graphics:mask_31_graphics_423,x:687.4848,y:167.7604}).wait(1).to({graphics:mask_31_graphics_424,x:687.4798,y:167.7604}).wait(1).to({graphics:mask_31_graphics_425,x:687.4758,y:167.7605}).wait(1).to({graphics:mask_31_graphics_426,x:687.4726,y:167.76}).wait(1).to({graphics:mask_31_graphics_427,x:687.4704,y:167.7605}).wait(1).to({graphics:mask_31_graphics_428,x:687.47,y:167.7604}).wait(382));

	// Layer_39
	this.instance_54 = new lib.Tween75("synched",0);
	this.instance_54.setTransform(680.1,156.45);
	this.instance_54.alpha = 0.5;
	this.instance_54._off = true;

	this.instance_55 = new lib.Tween76("synched",0);
	this.instance_55.setTransform(680.1,156.45);

	var maskedShapeInstanceList = [this.instance_54,this.instance_55];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_31;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_54}]},320).to({state:[{t:this.instance_55}]},108).wait(382));
	this.timeline.addTween(cjs.Tween.get(this.instance_54).wait(320).to({_off:false},0).to({_off:true,alpha:1},108).wait(382));

	// Layer_6 (mask)
	var mask_32 = new cjs.Shape();
	mask_32._off = true;
	var mask_32_graphics_479 = new cjs.Graphics().p("AgPAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAGgGAJAAIAAAAQAKAAAGAGIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgGAGgKAAIAAAAQgJAAgGgGg");
	var mask_32_graphics_480 = new cjs.Graphics().p("AgPAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAGgGAJAAIAAAAQAKAAAGAGIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgGAGgKAAIAAAAQgJAAgGgGg");
	var mask_32_graphics_481 = new cjs.Graphics().p("AgQAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAHgHAJAAIAAAAQAKAAAHAHIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgHAHgKAAIAAAAQgJAAgHgHg");
	var mask_32_graphics_482 = new cjs.Graphics().p("AgRARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAIgHAJAAIAAAAQAKAAAIAHIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgIAHgKAAIAAAAQgJAAgIgHg");
	var mask_32_graphics_483 = new cjs.Graphics().p("AgSASQgHgIAAgKIAAAAQAAgJAHgIIAAAAQAIgHAKAAIAAAAQALAAAIAHIAAAAQAHAIAAAJIAAAAQAAAKgHAIIAAAAQgIAHgLAAIAAAAQgKAAgIgHg");
	var mask_32_graphics_484 = new cjs.Graphics().p("AgTATQgIgIAAgLIAAAAQAAgKAIgIIAAAAQAIgIALAAIAAAAQAMAAAIAIIAAAAQAIAIAAAKIAAAAQAAALgIAIIAAAAQgIAIgMAAIAAAAQgLAAgIgIg");
	var mask_32_graphics_485 = new cjs.Graphics().p("AgVAVQgIgJAAgMIAAAAQAAgLAIgJIAAAAQAJgIAMAAIAAAAQANAAAJAIIAAAAQAIAJAAALIAAAAQAAAMgIAJIAAAAQgJAIgNAAIAAAAQgMAAgJgIg");
	var mask_32_graphics_486 = new cjs.Graphics().p("AgWAWQgKgJAAgNIAAAAQAAgMAKgJIAAAAQAJgKANAAIAAAAQAOAAAJAKIAAAAQAKAJAAAMIAAAAQAAANgKAJIAAAAQgJAKgOAAIAAAAQgNAAgJgKg");
	var mask_32_graphics_487 = new cjs.Graphics().p("AgZAZQgKgLAAgOIAAAAQAAgNAKgLIAAAAQALgKAOAAIAAAAQAPAAALAKIAAAAQAKALAAANIAAAAQAAAOgKALIAAAAQgLAKgPAAIAAAAQgOAAgLgKg");
	var mask_32_graphics_488 = new cjs.Graphics().p("AgbAbQgMgLAAgQIAAAAQAAgPAMgLIAAAAQAMgLAPAAIAAAAQAQAAAMALIAAAAQAMALAAAPIAAAAQAAAQgMALIAAAAQgMALgQAAIAAAAQgPAAgMgLg");
	var mask_32_graphics_489 = new cjs.Graphics().p("AgeAeQgNgNAAgRIAAAAQAAgQANgNIAAAAQANgMARAAIAAAAQASAAANAMIAAAAQANANAAAQIAAAAQAAARgNANIAAAAQgNAMgSAAIAAAAQgRAAgNgMg");
	var mask_32_graphics_490 = new cjs.Graphics().p("AghAhQgOgOAAgTIAAAAQAAgSAOgOIAAAAQAOgNATAAIAAAAQAUAAAOANIAAAAQAOAOAAASIAAAAQAAATgOAOIAAAAQgOANgUAAIAAAAQgTAAgOgNg");
	var mask_32_graphics_491 = new cjs.Graphics().p("AgkAkQgQgPAAgVIAAAAQAAgUAQgPIAAAAQAPgPAVAAIAAAAQAWAAAPAPIAAAAQAQAPAAAUIAAAAQAAAVgQAPIAAAAQgPAPgWAAIAAAAQgVAAgPgPg");
	var mask_32_graphics_492 = new cjs.Graphics().p("AgoAnQgRgQAAgXIAAAAQAAgWARgQIAAAAQARgRAXAAIAAAAQAYAAARARIAAAAQARAQAAAWIAAAAQAAAXgRAQIAAAAQgRARgYAAIAAAAQgXAAgRgRg");
	var mask_32_graphics_493 = new cjs.Graphics().p("AgsArQgTgSAAgZIAAAAQAAgYATgSIAAAAQATgSAZAAIAAAAQAaAAATASIAAAAQATASAAAYIAAAAQAAAZgTASIAAAAQgTASgaAAIAAAAQgZAAgTgSg");
	var mask_32_graphics_494 = new cjs.Graphics().p("AgwAvQgVgTAAgcIAAAAQAAgbAVgTIAAAAQAUgUAcAAIAAAAQAdAAAUAUIAAAAQAVATAAAbIAAAAQAAAcgVATIAAAAQgUAUgdAAIAAAAQgcAAgUgUg");
	var mask_32_graphics_495 = new cjs.Graphics().p("Ag1A0QgWgWAAgeIAAAAQAAgdAWgWIAAAAQAWgVAfAAIAAAAQAfAAAXAVIAAAAQAWAWAAAdIAAAAQAAAegWAWIAAAAQgXAVgfAAIAAAAQgfAAgWgVg");
	var mask_32_graphics_496 = new cjs.Graphics().p("Ag6A4QgYgXAAghIAAAAQAAggAYgXIAAAAQAZgXAhAAIAAAAQAiAAAZAXIAAAAQAYAXAAAgIAAAAQAAAhgYAXIAAAAQgZAXgiAAIAAAAQghAAgZgXg");
	var mask_32_graphics_497 = new cjs.Graphics().p("Ag/A9QgagZAAgkIAAAAQAAgjAagZIAAAAQAbgZAkAAIAAAAQAlAAAbAZIAAAAQAaAZAAAjIAAAAQAAAkgaAZIAAAAQgbAZglAAIAAAAQgkAAgbgZg");
	var mask_32_graphics_498 = new cjs.Graphics().p("AhEBCQgdgbAAgnIAAAAQAAgmAdgbIAAAAQAcgcAoAAIAAAAQApAAAcAcIAAAAQAdAbAAAmIAAAAQAAAngdAbIAAAAQgcAcgpAAIAAAAQgoAAgcgcg");
	var mask_32_graphics_499 = new cjs.Graphics().p("AhKBIQgfgeAAgqIAAAAQAAgpAfgeIAAAAQAfgeArAAIAAAAQAsAAAfAeIAAAAQAfAeAAApIAAAAQAAAqgfAeIAAAAQgfAegsAAIAAAAQgrAAgfgeg");
	var mask_32_graphics_500 = new cjs.Graphics().p("AhQBOQghghAAgtIAAAAQAAgsAhghIAAAAQAiggAuAAIAAAAQAvAAAiAgIAAAAQAhAhAAAsIAAAAQAAAtghAhIAAAAQgiAggvAAIAAAAQguAAgiggg");
	var mask_32_graphics_501 = new cjs.Graphics().p("AhWBUQgkgjAAgxIAAAAQAAgwAkgjIAAAAQAkgiAyAAIAAAAQAzAAAkAiIAAAAQAkAjAAAwIAAAAQAAAxgkAjIAAAAQgkAigzAAIAAAAQgyAAgkgig");
	var mask_32_graphics_502 = new cjs.Graphics().p("AhdBaQgnglAAg1IAAAAQAAg0AnglIAAAAQAnglA2AAIAAAAQA3AAAnAlIAAAAQAnAlAAA0IAAAAQAAA1gnAlIAAAAQgnAlg3AAIAAAAQg2AAgnglg");
	var mask_32_graphics_503 = new cjs.Graphics().p("AhkBgQgpgnAAg5IAAAAQAAg4ApgoIAAAAQAqgnA6AAIAAAAQA7AAAqAnIAAAAQApAoAAA4IAAAAQAAA5gpAnIAAAAQgqAog7AAIAAAAQg6AAgqgog");
	var mask_32_graphics_504 = new cjs.Graphics().p("AhrBnQgtgqAAg9IAAAAQAAg8AtgqIAAAAQAtgrA+AAIAAAAQA/AAAtArIAAAAQAtAqAAA8IAAAAQAAA9gtAqIAAAAQgtArg/AAIAAAAQg+AAgtgrg");
	var mask_32_graphics_505 = new cjs.Graphics().p("AhyBvQgwguAAhBIAAAAQAAhAAwguIAAAAQAvgtBDAAIAAAAQBEAAAvAtIAAAAQAwAuAABAIAAAAQAABBgwAuIAAAAQgvAthEAAIAAAAQhDAAgvgtg");
	var mask_32_graphics_506 = new cjs.Graphics().p("Ah6B2QgzgxAAhFIAAAAQAAhEAzgxIAAAAQAzgxBHAAIAAAAQBIAAAzAxIAAAAQAzAxAABEIAAAAQAABFgzAxIAAAAQgzAxhIAAIAAAAQhHAAgzgxg");
	var mask_32_graphics_507 = new cjs.Graphics().p("AiCB+Qg3g0AAhKIAAAAQAAhJA3g0IAAAAQA2g0BMAAIAAAAQBNAAA2A0IAAAAQA3A0AABJIAAAAQAABKg3A0IAAAAQg2A0hNAAIAAAAQhMAAg2g0g");
	var mask_32_graphics_508 = new cjs.Graphics().p("AiLCGQg5g4AAhOIAAAAQAAhNA5g4IAAAAQA6g3BRAAIAAAAQBSAAA6A3IAAAAQA5A4AABNIAAAAQAABOg5A4IAAAAQg6A3hSAAIAAAAQhRAAg6g3g");
	var mask_32_graphics_509 = new cjs.Graphics().p("AiTCOQg+g7AAhTIAAAAQAAhSA+g7IAAAAQA9g7BWAAIAAAAQBXAAA9A7IAAAAQA+A7AABSIAAAAQAABTg+A7IAAAAQg9A7hXAAIAAAAQhWAAg9g7g");
	var mask_32_graphics_510 = new cjs.Graphics().p("AicCXQhBg/AAhYIAAAAQAAhXBBg/IAAAAQBBg+BbAAIAAAAQBcAABBA+IAAAAQBBA/AABXIAAAAQAABYhBA/IAAAAQhBA+hcAAIAAAAQhbAAhBg+g");
	var mask_32_graphics_511 = new cjs.Graphics().p("AilCfQhFhCAAhdIAAAAQAAhcBFhCIAAAAQBFhCBgAAIAAAAQBhAABFBCIAAAAQBFBCAABcIAAAAQAABdhFBCIAAAAQhFBChhAAIAAAAQhgAAhFhCg");
	var mask_32_graphics_512 = new cjs.Graphics().p("AivCpQhJhGAAhjIAAAAQAAhiBJhGIAAAAQBJhFBmAAIAAAAQBnAABJBFIAAAAQBJBGAABiIAAAAQAABjhJBGIAAAAQhJBFhnAAIAAAAQhmAAhJhFg");
	var mask_32_graphics_513 = new cjs.Graphics().p("Ai5CyQhNhKAAhoIAAAAQAAhnBNhKIAAAAQBNhKBsAAIAAAAQBtAABNBKIAAAAQBNBKAABnIAAAAQAABohNBKIAAAAQhNBKhtAAIAAAAQhsAAhNhKg");
	var mask_32_graphics_514 = new cjs.Graphics().p("AjDC8QhRhOAAhuIAAAAQAAhtBRhOIAAAAQBRhNByAAIAAAAQBzAABRBNIAAAAQBRBOAABtIAAAAQAABuhRBOIAAAAQhRBNhzAAIAAAAQhyAAhRhNg");
	var mask_32_graphics_515 = new cjs.Graphics().p("AjNDGQhWhSAAh0IAAAAQAAhzBWhSIAAAAQBVhSB4AAIAAAAQB5AABVBSIAAAAQBWBSAABzIAAAAQAAB0hWBSIAAAAQhVBSh5AAIAAAAQh4AAhVhSg");
	var mask_32_graphics_516 = new cjs.Graphics().p("AjYDQQhahWAAh6IAAAAQAAh5BahWIAAAAQBahWB+AAIAAAAQB/AABaBWIAAAAQBaBWAAB5IAAAAQAAB6haBWIAAAAQhaBWh/AAIAAAAQh+AAhahWg");
	var mask_32_graphics_517 = new cjs.Graphics().p("AjjDaQhehaAAiAIAAAAQAAh/BehbIAAAAQBehaCFAAIAAAAQCGAABeBaIAAAAQBeBbAAB/IAAAAQAACAheBaIAAAAQheBbiGAAIAAAAQiFAAhehbg");
	var mask_32_graphics_518 = new cjs.Graphics().p("AjuDlQhjhfAAiGIAAAAQAAiFBjhfIAAAAQBjhfCLAAIAAAAQCMAABjBfIAAAAQBjBfAACFIAAAAQAACGhjBfIAAAAQhjBfiMAAIAAAAQiLAAhjhfg");
	var mask_32_graphics_519 = new cjs.Graphics().p("Aj6DwQhohjAAiNIAAAAQAAiMBohjIAAAAQBohkCSAAIAAAAQCTAABoBkIAAAAQBoBjAACMIAAAAQAACNhoBjIAAAAQhoBkiTAAIAAAAQiSAAhohkg");
	var mask_32_graphics_520 = new cjs.Graphics().p("AkGD8QhthpAAiTIAAAAQAAiSBthpIAAAAQBthoCZAAIAAAAQCaAABtBoIAAAAQBtBpAACSIAAAAQAACThtBpIAAAAQhtBoiaAAIAAAAQiZAAhthog");
	var mask_32_graphics_521 = new cjs.Graphics().p("AkSEHQhyhtAAiaIAAAAQAAiZByhtIAAAAQByhuCgAAIAAAAQChAAByBuIAAAAQByBtAACZIAAAAQAACahyBtIAAAAQhyBuihAAIAAAAQigAAhyhug");
	var mask_32_graphics_522 = new cjs.Graphics().p("AkeETQh3hyAAihIAAAAQAAigB3hyIAAAAQB3hyCnAAIAAAAQCoAAB3ByIAAAAQB3ByAACgIAAAAQAAChh3ByIAAAAQh3ByioAAIAAAAQinAAh3hyg");
	var mask_32_graphics_523 = new cjs.Graphics().p("AkrEgQh8h4AAioIAAAAQAAinB8h4IAAAAQB8h3CvAAIAAAAQCwAAB8B3IAAAAQB8B4AACnIAAAAQAACoh8B4IAAAAQh8B3iwAAIAAAAQivAAh8h3g");
	var mask_32_graphics_524 = new cjs.Graphics().p("Ak4EsQiCh8AAiwIAAAAQAAivCCh8IAAAAQCCh8C2AAIAAAAQC3AACCB8IAAAAQCCB8AACvIAAAAQAACwiCB8IAAAAQiCB8i3AAIAAAAQi2AAiCh8g");
	var mask_32_graphics_525 = new cjs.Graphics().p("AlGE5QiHiCAAi3IAAAAQAAi2CHiCIAAAAQCIiBC+AAIAAAAQC/AACHCBIAAAAQCICCAAC2IAAAAQAAC3iICCIAAAAQiHCBi/AAIAAAAQi+AAiIiBg");
	var mask_32_graphics_526 = new cjs.Graphics().p("AlTFGQiNiHAAi/IAAAAQAAi+CNiHIAAAAQCNiHDGAAIAAAAQDHAACNCHIAAAAQCNCHAAC+IAAAAQAAC/iNCHIAAAAQiNCHjHAAIAAAAQjGAAiNiHg");
	var mask_32_graphics_527 = new cjs.Graphics().p("AlhFTQiTiMAAjHIAAAAQAAjGCTiMIAAAAQCTiNDOAAIAAAAQDPAACTCNIAAAAQCTCMAADGIAAAAQAADHiTCMIAAAAQiTCNjPAAIAAAAQjOAAiTiNg");
	var mask_32_graphics_528 = new cjs.Graphics().p("AlvFhQiZiSAAjPIAAAAQAAjOCZiSIAAAAQCYiSDXAAIAAAAQDYAACYCSIAAAAQCZCSAADOIAAAAQAADPiZCSIAAAAQiYCSjYAAIAAAAQjXAAiYiSg");
	var mask_32_graphics_529 = new cjs.Graphics().p("Al+FvQieiYAAjXIAAAAQAAjWCeiYIAAAAQCfiYDfAAIAAAAQDgAACfCYIAAAAQCeCYAADWIAAAAQAADXieCYIAAAAQifCYjgAAIAAAAQjfAAifiYg");
	var mask_32_graphics_530 = new cjs.Graphics().p("AmNF9QikieAAjfIAAAAQAAjeCkieIAAAAQClieDoAAIAAAAQDpAAClCeIAAAAQCkCeAADeIAAAAQAADfikCeIAAAAQilCejpAAIAAAAQjoAAilieg");
	var mask_32_graphics_531 = new cjs.Graphics().p("AmcGLQirijAAjoIAAAAQAAjnCrikIAAAAQCrijDxAAIAAAAQDyAACrCjIAAAAQCrCkAADnIAAAAQAADoirCjIAAAAQirCkjyAAIAAAAQjxAAirikg");
	var mask_32_graphics_532 = new cjs.Graphics().p("AmrGaQiyiqAAjwIAAAAQAAjvCyiqIAAAAQCxiqD6AAIAAAAQD7AACxCqIAAAAQCyCqAADvIAAAAQAADwiyCqIAAAAQixCqj7AAIAAAAQj6AAixiqg");
	var mask_32_graphics_533 = new cjs.Graphics().p("Am7GpQi4iwAAj5IAAAAQAAj4C4iwIAAAAQC4iwEDAAIAAAAQEEAAC4CwIAAAAQC4CwAAD4IAAAAQAAD5i4CwIAAAAQi4CwkEAAIAAAAQkDAAi4iwg");
	var mask_32_graphics_534 = new cjs.Graphics().p("AnLG4Qi+i2AAkCIAAAAQAAkBC+i2IAAAAQC/i3EMAAIAAAAQENAAC+C3IAAAAQC/C2AAEBIAAAAQAAECi/C2IAAAAQi+C3kNAAIAAAAQkMAAi/i3g");
	var mask_32_graphics_535 = new cjs.Graphics().p("AnaHHQjFi8AAkLIAAAAQAAkKDFi8IAAAAQDFi9EVAAIAAAAQEWAADFC9IAAAAQDFC8AAEKIAAAAQAAELjFC8IAAAAQjFC9kWAAIAAAAQkVAAjFi9g");
	var mask_32_graphics_536 = new cjs.Graphics().p("AnpHVQjLjCAAkTIAAAAQAAkSDLjDIAAAAQDLjCEeAAIAAAAQEfAADLDCIAAAAQDLDDAAESIAAAAQAAETjLDCIAAAAQjLDDkfAAIAAAAQkeAAjLjDg");
	var mask_32_graphics_537 = new cjs.Graphics().p("An4HkQjRjJAAkbIAAAAQAAkaDRjJIAAAAQDRjIEnAAIAAAAQEoAADRDIIAAAAQDRDJAAEaIAAAAQAAEbjRDJIAAAAQjRDIkoAAIAAAAQknAAjRjIg");
	var mask_32_graphics_538 = new cjs.Graphics().p("AoGHyQjYjPAAkjIAAAAQAAkiDYjPIAAAAQDXjOEvAAIAAAAQEwAADXDOIAAAAQDYDPAAEiIAAAAQAAEjjYDPIAAAAQjXDOkwAAIAAAAQkvAAjXjOg");
	var mask_32_graphics_539 = new cjs.Graphics().p("AoVH/QjdjUAAkrIAAAAQAAkqDdjUIAAAAQDdjUE4AAIAAAAQE5AADcDUIAAAAQDeDUAAEqIAAAAQAAErjeDUIAAAAQjcDUk5AAIAAAAQk4AAjdjUg");
	var mask_32_graphics_540 = new cjs.Graphics().p("AojIMQjijZAAkzIAAAAQAAkyDijaIAAAAQDjjZFAAAIAAAAQFBAADiDZIAAAAQDjDaAAEyIAAAAQAAEzjjDZIAAAAQjiDalBAAIAAAAQlAAAjjjag");
	var mask_32_graphics_541 = new cjs.Graphics().p("AowIaQjpjfAAk7IAAAAQAAk6DpjfIAAAAQDojeFIAAIAAAAQFJAADoDeIAAAAQDpDfAAE6IAAAAQAAE7jpDfIAAAAQjoDelJAAIAAAAQlIAAjojeg");
	var mask_32_graphics_542 = new cjs.Graphics().p("Ao+ImQjtjkAAlCIAAAAQAAlBDtjlIAAAAQDujkFQAAIAAAAQFQAADuDkIAAAAQDuDlAAFBIAAAAQAAFCjuDkIAAAAQjuDllQAAIAAAAQlQAAjujlg");
	var mask_32_graphics_543 = new cjs.Graphics().p("ApLIzQjzjpAAlKIAAAAQAAlJDzjpIAAAAQD0jpFXAAIAAAAQFYAADzDpIAAAAQD0DpAAFJIAAAAQAAFKj0DpIAAAAQjzDplYAAIAAAAQlXAAj0jpg");
	var mask_32_graphics_544 = new cjs.Graphics().p("ApXI/Qj5juAAlRIAAAAQAAlQD5juIAAAAQD4juFfgBIAAAAQFgABD4DuIAAAAQD5DuAAFQIAAAAQAAFRj5DuIAAAAQj4DvlgAAIAAAAQlfAAj4jvg");
	var mask_32_graphics_545 = new cjs.Graphics().p("ApkJLQj+jzAAlYIAAAAQAAlXD+jzIAAAAQD+jzFmAAIAAAAQFnAAD+DzIAAAAQD+DzAAFXIAAAAQAAFYj+DzIAAAAQj+DzlnAAIAAAAQlmAAj+jzg");
	var mask_32_graphics_546 = new cjs.Graphics().p("ApwJXQkDj4AAlfIAAAAQAAleEDj4IAAAAQEDj4FtAAIAAAAQFuAAEDD4IAAAAQEDD4AAFeIAAAAQAAFfkDD4IAAAAQkDD4luAAIAAAAQltAAkDj4g");
	var mask_32_graphics_547 = new cjs.Graphics().p("Ap8JiQkIj9AAllIAAAAQAAlkEIj9IAAAAQEIj9F0AAIAAAAQF1AAEID9IAAAAQEID9AAFkIAAAAQAAFlkID9IAAAAQkID9l1AAIAAAAQl0AAkIj9g");
	var mask_32_graphics_548 = new cjs.Graphics().p("AqIJtQkMkBAAlsIAAAAQAAlrEMkBIAAAAQENkCF7AAIAAAAQF8AAEMECIAAAAQENEBAAFrIAAAAQAAFskNEBIAAAAQkMECl8AAIAAAAQl7AAkNkCg");
	var mask_32_graphics_549 = new cjs.Graphics().p("AqTJ4QkRkGAAlyIAAAAQAAlxERkGIAAAAQESkGGBAAIAAAAQGCAAESEGIAAAAQEREGAAFxIAAAAQAAFykREGIAAAAQkSEGmCAAIAAAAQmBAAkSkGg");
	var mask_32_graphics_550 = new cjs.Graphics().p("AqeKCQkWkKAAl4IAAAAQAAl3EWkLIAAAAQEWkKGIAAIAAAAQGJAAEWEKIAAAAQEWELAAF3IAAAAQAAF4kWEKIAAAAQkWELmJAAIAAAAQmIAAkWkLg");
	var mask_32_graphics_551 = new cjs.Graphics().p("AqpKNQkakPAAl+IAAAAQAAl9EakPIAAAAQEbkOGOAAIAAAAQGPAAEaEOIAAAAQEbEPAAF9IAAAAQAAF+kbEPIAAAAQkaEOmPAAIAAAAQmOAAkbkOg");
	var mask_32_graphics_552 = new cjs.Graphics().p("AqzKXQkekTAAmEIAAAAQAAmDEekTIAAAAQEfkSGUAAIAAAAQGVAAEfESIAAAAQEeETAAGDIAAAAQAAGEkeETIAAAAQkfESmVAAIAAAAQmUAAkfkSg");
	var mask_32_graphics_553 = new cjs.Graphics().p("Aq9KgQkjkWAAmKIAAAAQAAmJEjkXIAAAAQEjkWGaAAIAAAAQGbAAEjEWIAAAAQEjEXAAGJIAAAAQAAGKkjEWIAAAAQkjEXmbAAIAAAAQmaAAkjkXg");
	var mask_32_graphics_554 = new cjs.Graphics().p("ArHKqQknkbAAmPIAAAAQAAmOEnkbIAAAAQEnkbGgAAIAAAAQGhAAEnEbIAAAAQEnEbAAGOIAAAAQAAGPknEbIAAAAQknEbmhAAIAAAAQmgAAknkbg");
	var mask_32_graphics_555 = new cjs.Graphics().p("ArQKzQkrkeAAmVIAAAAQAAmUErkeIAAAAQErkeGlAAIAAAAQGmAAErEeIAAAAQErEeAAGUIAAAAQAAGVkrEeIAAAAQkrEemmAAIAAAAQmlAAkrkeg");
	var mask_32_graphics_556 = new cjs.Graphics().p("AraK8QkukiAAmaIAAAAQAAmZEukiIAAAAQEvkiGrAAIAAAAQGsAAEuEiIAAAAQEvEiAAGZIAAAAQAAGakvEiIAAAAQkuEimsAAIAAAAQmrAAkvkig");
	var mask_32_graphics_557 = new cjs.Graphics().p("ArjLEQkyklAAmfIAAAAQAAmeEykmIAAAAQEzklGwAAIAAAAQGxAAEyElIAAAAQEzEmAAGeIAAAAQAAGfkzElIAAAAQkyEmmxAAIAAAAQmwAAkzkmg");
	var mask_32_graphics_558 = new cjs.Graphics().p("ArrLNQk2kpAAmkIAAAAQAAmjE2kpIAAAAQE2kpG1AAIAAAAQG2AAE2EpIAAAAQE2EpAAGjIAAAAQAAGkk2EpIAAAAQk2Epm2AAIAAAAQm1AAk2kpg");
	var mask_32_graphics_559 = new cjs.Graphics().p("Ar0LVQk5ksAAmpIAAAAQAAmoE5ksIAAAAQE6ksG6AAIAAAAQG7AAE5EsIAAAAQE6EsAAGoIAAAAQAAGpk6EsIAAAAQk5Esm7AAIAAAAQm6AAk6ksg");
	var mask_32_graphics_560 = new cjs.Graphics().p("Ar8LcQk8kvAAmtIAAAAQAAmsE8kwIAAAAQE9kvG/AAIAAAAQHAAAE8EvIAAAAQE9EwAAGsIAAAAQAAGtk9EvIAAAAQk8EwnAAAIAAAAQm/AAk9kwg");
	var mask_32_graphics_561 = new cjs.Graphics().p("AsDLkQlAkzAAmxIAAAAQAAmwFAkzIAAAAQFAkzHDAAIAAAAQHEAAFAEzIAAAAQFAEzAAGwIAAAAQAAGxlAEzIAAAAQlAEznEAAIAAAAQnDAAlAkzg");
	var mask_32_graphics_562 = new cjs.Graphics().p("AsLLrQlDk1AAm2IAAAAQAAm1FDk1IAAAAQFDk2HIAAIAAAAQHJAAFDE2IAAAAQFDE1AAG1IAAAAQAAG2lDE1IAAAAQlDE2nJAAIAAAAQnIAAlDk2g");
	var mask_32_graphics_563 = new cjs.Graphics().p("AsSLyQlGk4AAm6IAAAAQAAm5FGk4IAAAAQFGk4HMAAIAAAAQHNAAFGE4IAAAAQFGE4AAG5IAAAAQAAG6lGE4IAAAAQlGE4nNAAIAAAAQnMAAlGk4g");
	var mask_32_graphics_564 = new cjs.Graphics().p("AsZL4QlJk6AAm+IAAAAQAAm9FJk7IAAAAQFJk7HQAAIAAAAQHRAAFJE7IAAAAQFJE7AAG9IAAAAQAAG+lJE6IAAAAQlJE8nRAAIAAAAQnQAAlJk8g");
	var mask_32_graphics_565 = new cjs.Graphics().p("AsgL/QlLk+AAnBIAAAAQAAnAFLk+IAAAAQFMk+HUAAIAAAAQHVAAFLE+IAAAAQFME+AAHAIAAAAQAAHBlME+IAAAAQlLE+nVAAIAAAAQnUAAlMk+g");
	var mask_32_graphics_566 = new cjs.Graphics().p("AsmMFQlOlAAAnFIAAAAQAAnEFOlAIAAAAQFOlAHYAAIAAAAQHZAAFOFAIAAAAQFOFAAAHEIAAAAQAAHFlOFAIAAAAQlOFAnZAAIAAAAQnYAAlOlAg");
	var mask_32_graphics_567 = new cjs.Graphics().p("AssMLQlQlDAAnIIAAAAQAAnHFQlDIAAAAQFRlCHbAAIAAAAQHcAAFRFCIAAAAQFQFDAAHHIAAAAQAAHIlQFDIAAAAQlRFCncAAIAAAAQnbAAlRlCg");
	var mask_32_graphics_568 = new cjs.Graphics().p("AsyMQQlTlFAAnLIAAAAQAAnKFTlFIAAAAQFUlFHeAAIAAAAQHfAAFTFFIAAAAQFUFFAAHKIAAAAQAAHLlUFFIAAAAQlTFFnfAAIAAAAQneAAlUlFg");
	var mask_32_graphics_569 = new cjs.Graphics().p("As3MVQlVlHAAnOIAAAAQAAnNFVlIIAAAAQFVlHHiAAIAAAAQHjAAFVFHIAAAAQFVFIAAHNIAAAAQAAHOlVFHIAAAAQlVFInjAAIAAAAQniAAlVlIg");
	var mask_32_graphics_570 = new cjs.Graphics().p("As8MaQlYlJAAnRIAAAAQAAnQFYlKIAAAAQFXlIHlAAIAAAAQHmAAFXFIIAAAAQFYFKAAHQIAAAAQAAHRlYFJIAAAAQlXFJnmAAIAAAAQnlAAlXlJg");
	var mask_32_graphics_571 = new cjs.Graphics().p("AtBMfQlZlLAAnUIAAAAQAAnTFZlLIAAAAQFalLHnAAIAAAAQHoAAFaFLIAAAAQFZFLAAHTIAAAAQAAHUlZFLIAAAAQlaFLnoAAIAAAAQnnAAlalLg");
	var mask_32_graphics_572 = new cjs.Graphics().p("AtGMjQlblMAAnXIAAAAQAAnWFblNIAAAAQFclMHqAAIAAAAQHrAAFbFMIAAAAQFcFNAAHWIAAAAQAAHXlcFMIAAAAQlbFNnrAAIAAAAQnqAAlclNg");
	var mask_32_graphics_573 = new cjs.Graphics().p("AtKMnQldlOAAnZIAAAAQAAnYFdlPIAAAAQFdlOHtAAIAAAAQHuAAFcFOIAAAAQFeFPAAHYIAAAAQAAHZleFOIAAAAQlcFPnuAAIAAAAQntAAldlPg");
	var mask_32_graphics_574 = new cjs.Graphics().p("AtOMrQlelQAAnbIAAAAQAAnaFelQIAAAAQFflQHvAAIAAAAQHwAAFeFQIAAAAQFfFQAAHaIAAAAQAAHblfFQIAAAAQleFQnwAAIAAAAQnvAAlflQg");
	var mask_32_graphics_575 = new cjs.Graphics().p("AtSMvQlglSAAndIAAAAQAAncFglSIAAAAQFhlRHxAAIAAAAQHyAAFgFRIAAAAQFhFSAAHcIAAAAQAAHdlhFSIAAAAQlgFRnyAAIAAAAQnxAAlhlRg");
	var mask_32_graphics_576 = new cjs.Graphics().p("AtVMyQlhlTAAnfIAAAAQAAneFhlTIAAAAQFilTHzAAIAAAAQH0AAFhFTIAAAAQFiFTAAHeIAAAAQAAHfliFTIAAAAQlhFTn0AAIAAAAQnzAAlilTg");
	var mask_32_graphics_577 = new cjs.Graphics().p("AtYM1QljlUAAnhIAAAAQAAngFjlUIAAAAQFjlUH1AAIAAAAQH2AAFjFUIAAAAQFjFUAAHgIAAAAQAAHhljFUIAAAAQljFUn2AAIAAAAQn1AAljlUg");
	var mask_32_graphics_578 = new cjs.Graphics().p("AtbM3QlklVAAniIAAAAQAAnhFklWIAAAAQFllVH2AAIAAAAQH3AAFkFVIAAAAQFlFWAAHhIAAAAQAAHillFVIAAAAQlkFWn3AAIAAAAQn2AAlllWg");
	var mask_32_graphics_579 = new cjs.Graphics().p("AtdM6QlllWAAnkIAAAAQAAnjFllWIAAAAQFllWH4AAIAAAAQH5AAFlFWIAAAAQFlFWAAHjIAAAAQAAHkllFWIAAAAQllFWn5AAIAAAAQn4AAlllWg");
	var mask_32_graphics_580 = new cjs.Graphics().p("AtfM8QlmlXAAnlIAAAAQAAnkFmlXIAAAAQFmlXH5AAIAAAAQH6AAFmFXIAAAAQFmFXAAHkIAAAAQAAHllmFXIAAAAQlmFXn6AAIAAAAQn5AAlmlXg");
	var mask_32_graphics_581 = new cjs.Graphics().p("AthM+QlnlYAAnmIAAAAQAAnlFnlYIAAAAQFnlYH6AAIAAAAQH7AAFnFYIAAAAQFnFYAAHlIAAAAQAAHmlnFYIAAAAQlnFYn7AAIAAAAQn6AAlnlYg");
	var mask_32_graphics_582 = new cjs.Graphics().p("AtjM/QlnlYAAnnIAAAAQAAnmFnlZIAAAAQFolYH7AAIAAAAQH8AAFoFYIAAAAQFnFZAAHmIAAAAQAAHnlnFYIAAAAQloFZn8AAIAAAAQn7AAlolZg");
	var mask_32_graphics_583 = new cjs.Graphics().p("AtkNBQlolZAAnoIAAAAQAAnnFolZIAAAAQFolZH8AAIAAAAQH9AAFoFZIAAAAQFoFZAAHnIAAAAQAAHoloFZIAAAAQloFZn9AAIAAAAQn8AAlolZg");
	var mask_32_graphics_584 = new cjs.Graphics().p("AtlNCQlplaAAnoIAAAAQAAnnFplaIAAAAQFolZH9AAIAAAAQH+AAFoFZIAAAAQFpFaAAHnIAAAAQAAHolpFaIAAAAQloFZn+AAIAAAAQn9AAlolZg");
	var mask_32_graphics_585 = new cjs.Graphics().p("AtmNCQlplZAAnpIAAAAQAAnoFplaIAAAAQFplZH9AAIAAAAQH+AAFpFZIAAAAQFpFaAAHoIAAAAQAAHplpFZIAAAAQlpFan+AAIAAAAQn9AAlplag");
	var mask_32_graphics_586 = new cjs.Graphics().p("AtnNDQlolaAAnpIAAAAQAAnoFolaIAAAAQFqlaH9AAIAAAAQH+AAFpFaIAAAAQFpFaAAHoIAAAAQAAHplpFaIAAAAQlpFan+AAIAAAAQn9AAlqlag");
	var mask_32_graphics_587 = new cjs.Graphics().p("AtnNDQlolaAAnpIAAAAQAAnoFolaIAAAAQFqlaH9AAIAAAAQH+AAFpFaIAAAAQFpFaAAHoIAAAAQAAHplpFaIAAAAQlpFan+AAIAAAAQn9AAlqlag");

	this.timeline.addTween(cjs.Tween.get(mask_32).to({graphics:null,x:0,y:0}).wait(479).to({graphics:mask_32_graphics_479,x:855.7002,y:324.45}).wait(1).to({graphics:mask_32_graphics_480,x:855.7002,y:324.4504}).wait(1).to({graphics:mask_32_graphics_481,x:855.7002,y:324.4505}).wait(1).to({graphics:mask_32_graphics_482,x:855.7007,y:324.45}).wait(1).to({graphics:mask_32_graphics_483,x:855.7002,y:324.4504}).wait(1).to({graphics:mask_32_graphics_484,x:855.7002,y:324.4504}).wait(1).to({graphics:mask_32_graphics_485,x:855.7002,y:324.4509}).wait(1).to({graphics:mask_32_graphics_486,x:855.7002,y:324.4513}).wait(1).to({graphics:mask_32_graphics_487,x:855.7002,y:324.4513}).wait(1).to({graphics:mask_32_graphics_488,x:855.7006,y:324.4518}).wait(1).to({graphics:mask_32_graphics_489,x:855.7007,y:324.4522}).wait(1).to({graphics:mask_32_graphics_490,x:855.7007,y:324.4527}).wait(1).to({graphics:mask_32_graphics_491,x:855.7006,y:324.4531}).wait(1).to({graphics:mask_32_graphics_492,x:855.7007,y:324.4536}).wait(1).to({graphics:mask_32_graphics_493,x:855.7006,y:324.4545}).wait(1).to({graphics:mask_32_graphics_494,x:855.7006,y:324.4549}).wait(1).to({graphics:mask_32_graphics_495,x:855.7011,y:324.4554}).wait(1).to({graphics:mask_32_graphics_496,x:855.7006,y:324.4563}).wait(1).to({graphics:mask_32_graphics_497,x:855.7011,y:324.4572}).wait(1).to({graphics:mask_32_graphics_498,x:855.7006,y:324.4581}).wait(1).to({graphics:mask_32_graphics_499,x:855.7011,y:324.4585}).wait(1).to({graphics:mask_32_graphics_500,x:855.7011,y:324.4594}).wait(1).to({graphics:mask_32_graphics_501,x:855.7011,y:324.4603}).wait(1).to({graphics:mask_32_graphics_502,x:855.7011,y:324.4612}).wait(1).to({graphics:mask_32_graphics_503,x:855.7016,y:324.4626}).wait(1).to({graphics:mask_32_graphics_504,x:855.7015,y:324.4635}).wait(1).to({graphics:mask_32_graphics_505,x:855.702,y:324.4644}).wait(1).to({graphics:mask_32_graphics_506,x:855.7016,y:324.4657}).wait(1).to({graphics:mask_32_graphics_507,x:855.7015,y:324.4666}).wait(1).to({graphics:mask_32_graphics_508,x:855.702,y:324.468}).wait(1).to({graphics:mask_32_graphics_509,x:855.702,y:324.4689}).wait(1).to({graphics:mask_32_graphics_510,x:855.702,y:324.4702}).wait(1).to({graphics:mask_32_graphics_511,x:855.702,y:324.472}).wait(1).to({graphics:mask_32_graphics_512,x:855.7025,y:324.4734}).wait(1).to({graphics:mask_32_graphics_513,x:855.7024,y:324.4743}).wait(1).to({graphics:mask_32_graphics_514,x:855.7025,y:324.4761}).wait(1).to({graphics:mask_32_graphics_515,x:855.7029,y:324.4774}).wait(1).to({graphics:mask_32_graphics_516,x:855.7029,y:324.4788}).wait(1).to({graphics:mask_32_graphics_517,x:855.7029,y:324.4806}).wait(1).to({graphics:mask_32_graphics_518,x:855.7033,y:324.4824}).wait(1).to({graphics:mask_32_graphics_519,x:855.7033,y:324.4837}).wait(1).to({graphics:mask_32_graphics_520,x:855.7038,y:324.486}).wait(1).to({graphics:mask_32_graphics_521,x:855.7038,y:324.4874}).wait(1).to({graphics:mask_32_graphics_522,x:855.7038,y:324.4896}).wait(1).to({graphics:mask_32_graphics_523,x:855.7038,y:324.4914}).wait(1).to({graphics:mask_32_graphics_524,x:855.7043,y:324.4932}).wait(1).to({graphics:mask_32_graphics_525,x:855.7042,y:324.495}).wait(1).to({graphics:mask_32_graphics_526,x:855.7047,y:324.4968}).wait(1).to({graphics:mask_32_graphics_527,x:855.7047,y:324.4991}).wait(1).to({graphics:mask_32_graphics_528,x:855.7051,y:324.5013}).wait(1).to({graphics:mask_32_graphics_529,x:855.7056,y:324.5031}).wait(1).to({graphics:mask_32_graphics_530,x:855.7051,y:324.5053}).wait(1).to({graphics:mask_32_graphics_531,x:855.7056,y:324.5076}).wait(1).to({graphics:mask_32_graphics_532,x:855.706,y:324.5099}).wait(1).to({graphics:mask_32_graphics_533,x:855.7065,y:324.5121}).wait(1).to({graphics:mask_32_graphics_534,x:855.7061,y:324.5143}).wait(1).to({graphics:mask_32_graphics_535,x:855.7065,y:324.5166}).wait(1).to({graphics:mask_32_graphics_536,x:855.7069,y:324.5184}).wait(1).to({graphics:mask_32_graphics_537,x:855.7069,y:324.5211}).wait(1).to({graphics:mask_32_graphics_538,x:855.7074,y:324.5229}).wait(1).to({graphics:mask_32_graphics_539,x:855.7074,y:324.5252}).wait(1).to({graphics:mask_32_graphics_540,x:855.7074,y:324.5265}).wait(1).to({graphics:mask_32_graphics_541,x:855.7079,y:324.5288}).wait(1).to({graphics:mask_32_graphics_542,x:855.7083,y:324.5305}).wait(1).to({graphics:mask_32_graphics_543,x:855.7083,y:324.5328}).wait(1).to({graphics:mask_32_graphics_544,x:855.7083,y:324.5346}).wait(1).to({graphics:mask_32_graphics_545,x:855.7083,y:324.5364}).wait(1).to({graphics:mask_32_graphics_546,x:855.7087,y:324.5382}).wait(1).to({graphics:mask_32_graphics_547,x:855.7087,y:324.5396}).wait(1).to({graphics:mask_32_graphics_548,x:855.7087,y:324.5413}).wait(1).to({graphics:mask_32_graphics_549,x:855.7092,y:324.5431}).wait(1).to({graphics:mask_32_graphics_550,x:855.7092,y:324.5445}).wait(1).to({graphics:mask_32_graphics_551,x:855.7096,y:324.5458}).wait(1).to({graphics:mask_32_graphics_552,x:855.7096,y:324.5476}).wait(1).to({graphics:mask_32_graphics_553,x:855.7097,y:324.5494}).wait(1).to({graphics:mask_32_graphics_554,x:855.7101,y:324.5508}).wait(1).to({graphics:mask_32_graphics_555,x:855.7101,y:324.5517}).wait(1).to({graphics:mask_32_graphics_556,x:855.7101,y:324.5535}).wait(1).to({graphics:mask_32_graphics_557,x:855.7101,y:324.5544}).wait(1).to({graphics:mask_32_graphics_558,x:855.7105,y:324.5557}).wait(1).to({graphics:mask_32_graphics_559,x:855.7105,y:324.5571}).wait(1).to({graphics:mask_32_graphics_560,x:855.7105,y:324.5584}).wait(1).to({graphics:mask_32_graphics_561,x:855.711,y:324.5594}).wait(1).to({graphics:mask_32_graphics_562,x:855.711,y:324.5607}).wait(1).to({graphics:mask_32_graphics_563,x:855.711,y:324.5616}).wait(1).to({graphics:mask_32_graphics_564,x:855.711,y:324.5625}).wait(1).to({graphics:mask_32_graphics_565,x:855.711,y:324.5634}).wait(1).to({graphics:mask_32_graphics_566,x:855.711,y:324.5643}).wait(1).to({graphics:mask_32_graphics_567,x:855.7114,y:324.5652}).wait(1).to({graphics:mask_32_graphics_568,x:855.7115,y:324.5661}).wait(1).to({graphics:mask_32_graphics_569,x:855.7114,y:324.567}).wait(1).to({graphics:mask_32_graphics_570,x:855.7115,y:324.5674}).wait(1).to({graphics:mask_32_graphics_571,x:855.7114,y:324.5684}).wait(1).to({graphics:mask_32_graphics_572,x:855.7119,y:324.5692}).wait(1).to({graphics:mask_32_graphics_573,x:855.7115,y:324.5697}).wait(1).to({graphics:mask_32_graphics_574,x:855.7114,y:324.5697}).wait(1).to({graphics:mask_32_graphics_575,x:855.7119,y:324.5706}).wait(1).to({graphics:mask_32_graphics_576,x:855.7119,y:324.571}).wait(1).to({graphics:mask_32_graphics_577,x:855.7123,y:324.572}).wait(1).to({graphics:mask_32_graphics_578,x:855.7119,y:324.5724}).wait(1).to({graphics:mask_32_graphics_579,x:855.7119,y:324.5724}).wait(1).to({graphics:mask_32_graphics_580,x:855.7119,y:324.5728}).wait(1).to({graphics:mask_32_graphics_581,x:855.7119,y:324.5728}).wait(1).to({graphics:mask_32_graphics_582,x:855.7119,y:324.5728}).wait(1).to({graphics:mask_32_graphics_583,x:855.7119,y:324.5733}).wait(1).to({graphics:mask_32_graphics_584,x:855.7123,y:324.5737}).wait(1).to({graphics:mask_32_graphics_585,x:855.7123,y:324.5733}).wait(1).to({graphics:mask_32_graphics_586,x:855.7123,y:324.5737}).wait(1).to({graphics:mask_32_graphics_587,x:855.7123,y:324.4558}).wait(223));

	// Layer_41
	this.instance_56 = new lib.Tween79("synched",0);
	this.instance_56.setTransform(907.2,308.8);
	this.instance_56.alpha = 0.5;
	this.instance_56._off = true;

	this.instance_57 = new lib.Tween80("synched",0);
	this.instance_57.setTransform(907.2,308.8);

	var maskedShapeInstanceList = [this.instance_56,this.instance_57];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_32;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_56}]},479).to({state:[{t:this.instance_57}]},108).wait(223));
	this.timeline.addTween(cjs.Tween.get(this.instance_56).wait(479).to({_off:false},0).to({_off:true,alpha:1},108).wait(223));

	// Layer_6 (mask)
	var mask_33 = new cjs.Shape();
	mask_33._off = true;
	var mask_33_graphics_399 = new cjs.Graphics().p("AgPAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAGgGAJAAIAAAAQAKAAAGAGIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgGAGgKAAIAAAAQgJAAgGgGg");
	var mask_33_graphics_400 = new cjs.Graphics().p("AgPAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAGgGAJAAIAAAAQAKAAAGAGIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgGAGgKAAIAAAAQgJAAgGgGg");
	var mask_33_graphics_401 = new cjs.Graphics().p("AgQAQQgHgHAAgJIAAAAQAAgIAHgHIAAAAQAHgHAJAAIAAAAQAKAAAHAHIAAAAQAHAHAAAIIAAAAQAAAJgHAHIAAAAQgHAHgKAAIAAAAQgJAAgHgHg");
	var mask_33_graphics_402 = new cjs.Graphics().p("AgRARQgHgHAAgKIAAAAQAAgJAHgHIAAAAQAIgHAJAAIAAAAQAKAAAIAHIAAAAQAHAHAAAJIAAAAQAAAKgHAHIAAAAQgIAHgKAAIAAAAQgJAAgIgHg");
	var mask_33_graphics_403 = new cjs.Graphics().p("AgSASQgHgHAAgLIAAAAQAAgKAHgHIAAAAQAIgHAKAAIAAAAQALAAAIAHIAAAAQAHAHAAAKIAAAAQAAALgHAHIAAAAQgIAHgLAAIAAAAQgKAAgIgHg");
	var mask_33_graphics_404 = new cjs.Graphics().p("AgTATQgIgIAAgLIAAAAQAAgKAIgIIAAAAQAIgIALAAIAAAAQAMAAAIAIIAAAAQAIAIAAAKIAAAAQAAALgIAIIAAAAQgIAIgMAAIAAAAQgLAAgIgIg");
	var mask_33_graphics_405 = new cjs.Graphics().p("AgVAVQgJgJAAgMIAAAAQAAgLAJgJIAAAAQAJgJAMAAIAAAAQANAAAJAJIAAAAQAJAJAAALIAAAAQAAAMgJAJIAAAAQgJAJgNAAIAAAAQgMAAgJgJg");
	var mask_33_graphics_406 = new cjs.Graphics().p("AgXAXQgKgKAAgNIAAAAQAAgMAKgKIAAAAQAKgJANAAIAAAAQAOAAAKAJIAAAAQAKAKAAAMIAAAAQAAANgKAKIAAAAQgKAJgOAAIAAAAQgNAAgKgJg");
	var mask_33_graphics_407 = new cjs.Graphics().p("AgZAZQgLgKAAgPIAAAAQAAgOALgKIAAAAQALgKAOAAIAAAAQAPAAALAKIAAAAQALAKAAAOIAAAAQAAAPgLAKIAAAAQgLAKgPAAIAAAAQgOAAgLgKg");
	var mask_33_graphics_408 = new cjs.Graphics().p("AgcAcQgMgMAAgQIAAAAQAAgPAMgMIAAAAQAMgLAQAAIAAAAQARAAAMALIAAAAQAMAMAAAPIAAAAQAAAQgMAMIAAAAQgMALgRAAIAAAAQgQAAgMgLg");
	var mask_33_graphics_409 = new cjs.Graphics().p("AgfAeQgNgMAAgSIAAAAQAAgRANgMIAAAAQANgNASAAIAAAAQATAAANANIAAAAQANAMAAARIAAAAQAAASgNAMIAAAAQgNANgTAAIAAAAQgSAAgNgNg");
	var mask_33_graphics_410 = new cjs.Graphics().p("AgiAhQgOgNAAgUIAAAAQAAgTAOgNIAAAAQAPgOATAAIAAAAQAUAAAPAOIAAAAQAOANAAATIAAAAQAAAUgOANIAAAAQgPAOgUAAIAAAAQgTAAgPgOg");
	var mask_33_graphics_411 = new cjs.Graphics().p("AglAlQgQgPAAgWIAAAAQAAgVAQgPIAAAAQAPgPAWAAIAAAAQAXAAAPAPIAAAAQAQAPAAAVIAAAAQAAAWgQAPIAAAAQgPAPgXAAIAAAAQgWAAgPgPg");
	var mask_33_graphics_412 = new cjs.Graphics().p("AgpApQgSgRAAgYIAAAAQAAgXASgRIAAAAQARgQAYAAIAAAAQAZAAARAQIAAAAQASARAAAXIAAAAQAAAYgSARIAAAAQgRAQgZAAIAAAAQgYAAgRgQg");
	var mask_33_graphics_413 = new cjs.Graphics().p("AguAtQgTgTAAgaIAAAAQAAgZATgTIAAAAQAUgSAaAAIAAAAQAbAAAUASIAAAAQATATAAAZIAAAAQAAAagTATIAAAAQgUASgbAAIAAAAQgaAAgUgSg");
	var mask_33_graphics_414 = new cjs.Graphics().p("AgyAxQgVgUAAgdIAAAAQAAgcAVgUIAAAAQAVgUAdAAIAAAAQAeAAAVAUIAAAAQAVAUAAAcIAAAAQAAAdgVAUIAAAAQgVAUgeAAIAAAAQgdAAgVgUg");
	var mask_33_graphics_415 = new cjs.Graphics().p("Ag3A1QgXgWAAgfIAAAAQAAgeAXgWIAAAAQAXgXAgAAIAAAAQAhAAAXAXIAAAAQAXAWAAAeIAAAAQAAAfgXAWIAAAAQgXAXghAAIAAAAQggAAgXgXg");
	var mask_33_graphics_416 = new cjs.Graphics().p("Ag8A6QgZgYAAgiIAAAAQAAghAZgYIAAAAQAZgZAjAAIAAAAQAkAAAZAZIAAAAQAZAYAAAhIAAAAQAAAigZAYIAAAAQgZAZgkAAIAAAAQgjAAgZgZg");
	var mask_33_graphics_417 = new cjs.Graphics().p("AhBBAQgcgbAAglIAAAAQAAgkAcgbIAAAAQAbgaAmAAIAAAAQAnAAAbAaIAAAAQAcAbAAAkIAAAAQAAAlgcAbIAAAAQgbAagnAAIAAAAQgmAAgbgag");
	var mask_33_graphics_418 = new cjs.Graphics().p("AhHBFQgegdAAgoIAAAAQAAgnAegdIAAAAQAegdApAAIAAAAQAqAAAeAdIAAAAQAeAdAAAnIAAAAQAAAogeAdIAAAAQgeAdgqAAIAAAAQgpAAgegdg");
	var mask_33_graphics_419 = new cjs.Graphics().p("AhNBLQgggfAAgsIAAAAQAAgrAggfIAAAAQAggfAtAAIAAAAQAuAAAgAfIAAAAQAgAfAAArIAAAAQAAAsggAfIAAAAQggAfguAAIAAAAQgtAAgggfg");
	var mask_33_graphics_420 = new cjs.Graphics().p("AhTBRQgjgiAAgvIAAAAQAAguAjgiIAAAAQAjghAwAAIAAAAQAxAAAjAhIAAAAQAjAiAAAuIAAAAQAAAvgjAiIAAAAQgjAhgxAAIAAAAQgwAAgjghg");
	var mask_33_graphics_421 = new cjs.Graphics().p("AhaBXQgmgkAAgzIAAAAQAAgyAmgkIAAAAQAmgkA0AAIAAAAQA1AAAmAkIAAAAQAmAkAAAyIAAAAQAAAzgmAkIAAAAQgmAkg1AAIAAAAQg0AAgmgkg");
	var mask_33_graphics_422 = new cjs.Graphics().p("AhhBeQgpgnAAg3IAAAAQAAg2ApgnIAAAAQApgnA4AAIAAAAQA5AAApAnIAAAAQApAnAAA2IAAAAQAAA3gpAnIAAAAQgpAng5AAIAAAAQg4AAgpgng");
	var mask_33_graphics_423 = new cjs.Graphics().p("AhoBlQgsgqAAg7IAAAAQAAg6AsgqIAAAAQArgqA9AAIAAAAQA+AAArAqIAAAAQAsAqAAA6IAAAAQAAA7gsAqIAAAAQgrAqg+AAIAAAAQg9AAgrgqg");
	var mask_33_graphics_424 = new cjs.Graphics().p("AhwBsQgvgtAAg/IAAAAQAAg+AvgtIAAAAQAvgtBBAAIAAAAQBCAAAvAtIAAAAQAvAtAAA+IAAAAQAAA/gvAtIAAAAQgvAthCAAIAAAAQhBAAgvgtg");
	var mask_33_graphics_425 = new cjs.Graphics().p("Ah4B0QgygwAAhEIAAAAQAAhDAygwIAAAAQAygwBGAAIAAAAQBHAAAyAwIAAAAQAyAwAABDIAAAAQAABEgyAwIAAAAQgyAwhHAAIAAAAQhGAAgygwg");
	var mask_33_graphics_426 = new cjs.Graphics().p("AiAB7Qg1gzAAhIIAAAAQAAhHA1g0IAAAAQA2gzBKAAIAAAAQBLAAA2AzIAAAAQA1A0AABHIAAAAQAABIg1AzIAAAAQg2A0hLAAIAAAAQhKAAg2g0g");
	var mask_33_graphics_427 = new cjs.Graphics().p("AiICEQg5g3AAhNIAAAAQAAhMA5g3IAAAAQA5g2BPAAIAAAAQBQAAA5A2IAAAAQA5A3AABMIAAAAQAABNg5A3IAAAAQg5A2hQAAIAAAAQhPAAg5g2g");
	var mask_33_graphics_428 = new cjs.Graphics().p("AiRCMQg9g6AAhSIAAAAQAAhRA9g6IAAAAQA8g6BVAAIAAAAQBWAAA8A6IAAAAQA9A6AABRIAAAAQAABSg9A6IAAAAQg8A6hWAAIAAAAQhVAAg8g6g");
	var mask_33_graphics_429 = new cjs.Graphics().p("AiaCVQhBg+AAhXIAAAAQAAhWBBg+IAAAAQBAg9BaAAIAAAAQBbAABAA9IAAAAQBBA+AABWIAAAAQAABXhBA+IAAAAQhAA9hbAAIAAAAQhaAAhAg9g");
	var mask_33_graphics_430 = new cjs.Graphics().p("AikCeQhEhCAAhcIAAAAQAAhbBEhCIAAAAQBFhBBfAAIAAAAQBgAABFBBIAAAAQBEBCAABbIAAAAQAABchEBCIAAAAQhFBBhgAAIAAAAQhfAAhFhBg");
	var mask_33_graphics_431 = new cjs.Graphics().p("AitCnQhJhFAAhiIAAAAQAAhhBJhFIAAAAQBIhFBlAAIAAAAQBmAABIBFIAAAAQBJBFAABhIAAAAQAABihJBFIAAAAQhIBFhmAAIAAAAQhlAAhIhFg");
	var mask_33_graphics_432 = new cjs.Graphics().p("Ai4CxQhMhJAAhoIAAAAQAAhnBMhJIAAAAQBNhJBrAAIAAAAQBsAABMBJIAAAAQBNBJAABnIAAAAQAABohNBJIAAAAQhMBJhsAAIAAAAQhrAAhNhJg");
	var mask_33_graphics_433 = new cjs.Graphics().p("AjCC7QhRhOAAhtIAAAAQAAhsBRhOIAAAAQBRhNBxAAIAAAAQByAABRBNIAAAAQBRBOAABsIAAAAQAABthRBOIAAAAQhRBNhyAAIAAAAQhxAAhRhNg");
	var mask_33_graphics_434 = new cjs.Graphics().p("AjNDFQhVhSAAhzIAAAAQAAhyBVhSIAAAAQBWhRB3AAIAAAAQB4AABVBRIAAAAQBWBSAAByIAAAAQAABzhWBSIAAAAQhVBRh4AAIAAAAQh3AAhWhRg");
	var mask_33_graphics_435 = new cjs.Graphics().p("AjYDPQhZhWAAh5IAAAAQAAh4BZhWIAAAAQBahWB+AAIAAAAQB/AABZBWIAAAAQBaBWAAB4IAAAAQAAB5haBWIAAAAQhZBWh/AAIAAAAQh+AAhahWg");
	var mask_33_graphics_436 = new cjs.Graphics().p("AjjDaQhehaAAiAIAAAAQAAh/BehaIAAAAQBfhbCEAAIAAAAQCFAABfBbIAAAAQBeBaAAB/IAAAAQAACAheBaIAAAAQhfBbiFAAIAAAAQiEAAhfhbg");
	var mask_33_graphics_437 = new cjs.Graphics().p("AjuDlQhjhfAAiGIAAAAQAAiFBjhfIAAAAQBjhfCLAAIAAAAQCMAABjBfIAAAAQBjBfAACFIAAAAQAACGhjBfIAAAAQhjBfiMAAIAAAAQiLAAhjhfg");
	var mask_33_graphics_438 = new cjs.Graphics().p("Aj6DxQhohkAAiNIAAAAQAAiMBohkIAAAAQBohjCSAAIAAAAQCTAABoBjIAAAAQBoBkAACMIAAAAQAACNhoBkIAAAAQhoBjiTAAIAAAAQiSAAhohjg");
	var mask_33_graphics_439 = new cjs.Graphics().p("AkGD8QhuhoAAiUIAAAAQAAiTBuhoIAAAAQBthpCZAAIAAAAQCaAABtBpIAAAAQBuBoAACTIAAAAQAACUhuBoIAAAAQhtBpiaAAIAAAAQiZAAhthpg");
	var mask_33_graphics_440 = new cjs.Graphics().p("AkTEIQhyhtAAibIAAAAQAAiaByhtIAAAAQByhuChAAIAAAAQCiAAByBuIAAAAQByBtAACaIAAAAQAACbhyBtIAAAAQhyBuiiAAIAAAAQihAAhyhug");
	var mask_33_graphics_441 = new cjs.Graphics().p("AkgEVQh3hzAAiiIAAAAQAAihB3hzIAAAAQB4hyCoAAIAAAAQCpAAB4ByIAAAAQB3BzAAChIAAAAQAACih3BzIAAAAQh4ByipAAIAAAAQioAAh4hyg");
	var mask_33_graphics_442 = new cjs.Graphics().p("AktEhQh9h4AAipIAAAAQAAioB9h4IAAAAQB9h4CwAAIAAAAQCxAAB9B4IAAAAQB9B4AACoIAAAAQAACph9B4IAAAAQh9B4ixAAIAAAAQiwAAh9h4g");
	var mask_33_graphics_443 = new cjs.Graphics().p("Ak6EuQiDh9AAixIAAAAQAAiwCDh9IAAAAQCCh9C4AAIAAAAQC5AACCB9IAAAAQCDB9AACwIAAAAQAACxiDB9IAAAAQiCB9i5AAIAAAAQi4AAiCh9g");
	var mask_33_graphics_444 = new cjs.Graphics().p("AlIE7QiIiCAAi5IAAAAQAAi4CIiCIAAAAQCIiDDAAAIAAAAQDBAACICDIAAAAQCICCAAC4IAAAAQAAC5iICCIAAAAQiICDjBAAIAAAAQjAAAiIiDg");
	var mask_33_graphics_445 = new cjs.Graphics().p("AlWFJQiOiIAAjBIAAAAQAAjACOiIIAAAAQCOiIDIAAIAAAAQDJAACOCIIAAAAQCOCIAADAIAAAAQAADBiOCIIAAAAQiOCIjJAAIAAAAQjIAAiOiIg");
	var mask_33_graphics_446 = new cjs.Graphics().p("AllFWQiUiNAAjJIAAAAQAAjICUiOIAAAAQCViNDQAAIAAAAQDRAACUCNIAAAAQCVCOAADIIAAAAQAADJiVCNIAAAAQiUCOjRAAIAAAAQjQAAiViOg");
	var mask_33_graphics_447 = new cjs.Graphics().p("AlzFlQiaiUAAjRIAAAAQAAjQCaiUIAAAAQCaiTDZAAIAAAAQDaAACaCTIAAAAQCaCUAADQIAAAAQAADRiaCUIAAAAQiaCTjaAAIAAAAQjZAAiaiTg");
	var mask_33_graphics_448 = new cjs.Graphics().p("AmCFzQihiaAAjZIAAAAQAAjYChiaIAAAAQCgiaDiAAIAAAAQDjAACgCaIAAAAQChCaAADYIAAAAQAADZihCaIAAAAQigCajjAAIAAAAQjiAAigiag");
	var mask_33_graphics_449 = new cjs.Graphics().p("AmSGCQimigAAjiIAAAAQAAjhCmigIAAAAQCnifDrAAIAAAAQDsAACmCfIAAAAQCnCgAADhIAAAAQAADiinCgIAAAAQimCfjsAAIAAAAQjrAAinifg");
	var mask_33_graphics_450 = new cjs.Graphics().p("AmhGQQitilAAjrIAAAAQAAjqCtimIAAAAQCtimD0AAIAAAAQD1AACtCmIAAAAQCtCmAADqIAAAAQAADritClIAAAAQitCnj1AAIAAAAQj0AAiting");
	var mask_33_graphics_451 = new cjs.Graphics().p("AmxGgQi0isAAj0IAAAAQAAjzC0isIAAAAQC0isD9AAIAAAAQD+AAC0CsIAAAAQC0CsAADzIAAAAQAAD0i0CsIAAAAQi0Csj+AAIAAAAQj9AAi0isg");
	var mask_33_graphics_452 = new cjs.Graphics().p("AnBGvQi7iyAAj9IAAAAQAAj8C7iyIAAAAQC6izEHAAIAAAAQEIAAC6CzIAAAAQC7CyAAD8IAAAAQAAD9i7CyIAAAAQi6CzkIAAIAAAAQkHAAi6izg");
	var mask_33_graphics_453 = new cjs.Graphics().p("AnSG/QjBi5AAkGIAAAAQAAkFDBi5IAAAAQDCi5EQAAIAAAAQERAADCC5IAAAAQDBC5AAEFIAAAAQAAEGjBC5IAAAAQjCC5kRAAIAAAAQkQAAjCi5g");
	var mask_33_graphics_454 = new cjs.Graphics().p("AniHPQjIjAAAkPIAAAAQAAkODIjAIAAAAQDIjAEaAAIAAAAQEbAADIDAIAAAAQDIDAAAEOIAAAAQAAEPjIDAIAAAAQjIDAkbAAIAAAAQkaAAjIjAg");
	var mask_33_graphics_455 = new cjs.Graphics().p("AnzHeQjOjGAAkYIAAAAQAAkXDOjHIAAAAQDPjGEkAAIAAAAQElAADODGIAAAAQDPDHAAEXIAAAAQAAEYjPDGIAAAAQjODHklAAIAAAAQkkAAjPjHg");
	var mask_33_graphics_456 = new cjs.Graphics().p("AoCHuQjWjNAAkhIAAAAQAAkgDWjNIAAAAQDVjMEtAAIAAAAQEuAADVDMIAAAAQDWDNAAEgIAAAAQAAEhjWDNIAAAAQjVDMkuAAIAAAAQktAAjVjMg");
	var mask_33_graphics_457 = new cjs.Graphics().p("AoSH9QjcjTAAkqIAAAAQAAkpDcjTIAAAAQDcjTE2AAIAAAAQE3AADcDTIAAAAQDcDTAAEpIAAAAQAAEqjcDTIAAAAQjcDTk3AAIAAAAQk2AAjcjTg");
	var mask_33_graphics_458 = new cjs.Graphics().p("AohILQjjjYAAkzIAAAAQAAkyDjjZIAAAAQDijYE/AAIAAAAQFAAADiDYIAAAAQDjDZAAEyIAAAAQAAEzjjDYIAAAAQjiDZlAAAIAAAAQk/AAjijZg");
	var mask_33_graphics_459 = new cjs.Graphics().p("AowIaQjpjfAAk7IAAAAQAAk6DpjfIAAAAQDojfFIAAIAAAAQFJAADoDfIAAAAQDpDfAAE6IAAAAQAAE7jpDfIAAAAQjoDflJAAIAAAAQlIAAjojfg");
	var mask_33_graphics_460 = new cjs.Graphics().p("Ao/IoQjvjlAAlDIAAAAQAAlCDvjlIAAAAQDvjkFQAAIAAAAQFRAADvDkIAAAAQDvDlAAFCIAAAAQAAFDjvDlIAAAAQjvDklRAAIAAAAQlQAAjvjkg");
	var mask_33_graphics_461 = new cjs.Graphics().p("ApNI1Qj1jqAAlLIAAAAQAAlKD1jrIAAAAQD0jqFZAAIAAAAQFaAAD0DqIAAAAQD1DrAAFKIAAAAQAAFLj1DqIAAAAQj0DrlaAAIAAAAQlZAAj0jrg");
	var mask_33_graphics_462 = new cjs.Graphics().p("ApbJDQj7jwAAlTIAAAAQAAlSD7jwIAAAAQD6jwFhAAIAAAAQFiAAD6DwIAAAAQD7DwAAFSIAAAAQAAFTj7DwIAAAAQj6DwliAAIAAAAQlhAAj6jwg");
	var mask_33_graphics_463 = new cjs.Graphics().p("AppJQQkAj1AAlbIAAAAQAAlaEAj1IAAAAQEAj2FpAAIAAAAQFqAAEAD2IAAAAQEAD1AAFaIAAAAQAAFbkAD1IAAAAQkAD2lqAAIAAAAQlpAAkAj2g");
	var mask_33_graphics_464 = new cjs.Graphics().p("Ap3JdQkFj7AAliIAAAAQAAlhEFj7IAAAAQEGj7FxAAIAAAAQFyAAEFD7IAAAAQEGD7AAFhIAAAAQAAFikGD7IAAAAQkFD7lyAAIAAAAQlxAAkGj7g");
	var mask_33_graphics_465 = new cjs.Graphics().p("AqEJqQkLkAAAlqIAAAAQAAlpELkAIAAAAQELkAF5AAIAAAAQF6AAELEAIAAAAQELEAAAFpIAAAAQAAFqkLEAIAAAAQkLEAl6AAIAAAAQl5AAkLkAg");
	var mask_33_graphics_466 = new cjs.Graphics().p("AqRJ2QkQkFAAlxIAAAAQAAlwEQkFIAAAAQERkFGAAAIAAAAQGBAAEQEFIAAAAQEREFAAFwIAAAAQAAFxkREFIAAAAQkQEFmBAAIAAAAQmAAAkRkFg");
	var mask_33_graphics_467 = new cjs.Graphics().p("AqdKCQkWkKAAl4IAAAAQAAl3EWkKIAAAAQEWkKGHAAIAAAAQGIAAEWEKIAAAAQEWEKAAF3IAAAAQAAF4kWEKIAAAAQkWEKmIAAIAAAAQmHAAkWkKg");
	var mask_33_graphics_468 = new cjs.Graphics().p("AqpKOQkbkPAAl/IAAAAQAAl+EbkPIAAAAQEakOGPAAIAAAAQGQAAEaEOIAAAAQEbEPAAF+IAAAAQAAF/kbEPIAAAAQkaEOmQAAIAAAAQmPAAkakOg");
	var mask_33_graphics_469 = new cjs.Graphics().p("Aq1KZQkgkTAAmGIAAAAQAAmFEgkTIAAAAQEfkUGWAAIAAAAQGXAAEfEUIAAAAQEgETAAGFIAAAAQAAGGkgETIAAAAQkfEUmXAAIAAAAQmWAAkfkUg");
	var mask_33_graphics_470 = new cjs.Graphics().p("ArBKkQkkkYAAmMIAAAAQAAmLEkkYIAAAAQElkYGcAAIAAAAQGdAAElEYIAAAAQEkEYAAGLIAAAAQAAGMkkEYIAAAAQklEYmdAAIAAAAQmcAAklkYg");
	var mask_33_graphics_471 = new cjs.Graphics().p("ArMKvQkpkdAAmSIAAAAQAAmREpkdIAAAAQEpkdGjAAIAAAAQGkAAEpEdIAAAAQEpEdAAGRIAAAAQAAGSkpEdIAAAAQkpEdmkAAIAAAAQmjAAkpkdg");
	var mask_33_graphics_472 = new cjs.Graphics().p("ArXK5QktkgAAmZIAAAAQAAmYEtkhIAAAAQEukgGpAAIAAAAQGqAAEuEgIAAAAQEtEhAAGYIAAAAQAAGZktEgIAAAAQkuEhmqAAIAAAAQmpAAkukhg");
	var mask_33_graphics_473 = new cjs.Graphics().p("AriLEQkyklAAmfIAAAAQAAmeEyklIAAAAQEyklGwAAIAAAAQGxAAExElIAAAAQEzElAAGeIAAAAQAAGfkzElIAAAAQkxElmxAAIAAAAQmwAAkyklg");
	var mask_33_graphics_474 = new cjs.Graphics().p("ArsLNQk2kpAAmkIAAAAQAAmjE2kqIAAAAQE2kpG2AAIAAAAQG3AAE2EpIAAAAQE2EqAAGjIAAAAQAAGkk2EpIAAAAQk2Eqm3AAIAAAAQm2AAk2kqg");
	var mask_33_graphics_475 = new cjs.Graphics().p("Ar2LXQk6ktAAmqIAAAAQAAmpE6ktIAAAAQE6kuG8AAIAAAAQG9AAE6EuIAAAAQE6EtAAGpIAAAAQAAGqk6EtIAAAAQk6Eum9AAIAAAAQm8AAk6kug");
	var mask_33_graphics_476 = new cjs.Graphics().p("AsALgQk+kxAAmvIAAAAQAAmuE+kyIAAAAQE/kxHBAAIAAAAQHCAAE/ExIAAAAQE+EyAAGuIAAAAQAAGvk+ExIAAAAQk/EynCAAIAAAAQnBAAk/kyg");
	var mask_33_graphics_477 = new cjs.Graphics().p("AsJLpQlCk0AAm1IAAAAQAAm0FCk1IAAAAQFCk0HHAAIAAAAQHIAAFCE0IAAAAQFCE1AAG0IAAAAQAAG1lCE0IAAAAQlCE1nIAAIAAAAQnHAAlCk1g");
	var mask_33_graphics_478 = new cjs.Graphics().p("AsSLyQlGk4AAm6IAAAAQAAm5FGk5IAAAAQFGk4HMAAIAAAAQHNAAFGE4IAAAAQFGE5AAG5IAAAAQAAG6lGE4IAAAAQlGE5nNAAIAAAAQnMAAlGk5g");
	var mask_33_graphics_479 = new cjs.Graphics().p("AsbL7QlKk8AAm/IAAAAQAAm+FKk8IAAAAQFKk8HRAAIAAAAQHSAAFKE8IAAAAQFKE8AAG+IAAAAQAAG/lKE8IAAAAQlKE8nSAAIAAAAQnRAAlKk8g");
	var mask_33_graphics_480 = new cjs.Graphics().p("AskMDQlNk/AAnEIAAAAQAAnDFNk/IAAAAQFOk/HWAAIAAAAQHXAAFNE/IAAAAQFOE/AAHDIAAAAQAAHElOE/IAAAAQlNE/nXAAIAAAAQnWAAlOk/g");
	var mask_33_graphics_481 = new cjs.Graphics().p("AssMLQlQlDAAnIIAAAAQAAnHFQlDIAAAAQFRlCHbAAIAAAAQHcAAFRFCIAAAAQFQFDAAHHIAAAAQAAHIlQFDIAAAAQlRFCncAAIAAAAQnbAAlRlCg");
	var mask_33_graphics_482 = new cjs.Graphics().p("As0MSQlUlFAAnNIAAAAQAAnMFUlFIAAAAQFUlGHgAAIAAAAQHhAAFTFGIAAAAQFVFFAAHMIAAAAQAAHNlVFFIAAAAQlTFGnhAAIAAAAQngAAlUlGg");
	var mask_33_graphics_483 = new cjs.Graphics().p("As7MZQlXlIAAnRIAAAAQAAnQFXlJIAAAAQFXlIHkAAIAAAAQHlAAFXFIIAAAAQFXFJAAHQIAAAAQAAHRlXFIIAAAAQlXFJnlAAIAAAAQnkAAlXlJg");
	var mask_33_graphics_484 = new cjs.Graphics().p("AtDMgQlalLAAnVIAAAAQAAnUFalMIAAAAQFblLHoAAIAAAAQHpAAFaFLIAAAAQFbFMAAHUIAAAAQAAHVlbFLIAAAAQlaFMnpAAIAAAAQnoAAlblMg");
	var mask_33_graphics_485 = new cjs.Graphics().p("AtKMnQlclOAAnZIAAAAQAAnYFclOIAAAAQFelPHsAAIAAAAQHtAAFdFPIAAAAQFdFOAAHYIAAAAQAAHZldFOIAAAAQldFPntAAIAAAAQnsAAlelPg");
	var mask_33_graphics_486 = new cjs.Graphics().p("AtQMtQlglQAAndIAAAAQAAncFglRIAAAAQFglRHwAAIAAAAQHxAAFgFRIAAAAQFgFRAAHcIAAAAQAAHdlgFQIAAAAQlgFSnxAAIAAAAQnwAAlglSg");
	var mask_33_graphics_487 = new cjs.Graphics().p("AtXMzQlilTAAngIAAAAQAAnfFilUIAAAAQFjlTH0AAIAAAAQH1AAFiFTIAAAAQFjFUAAHfIAAAAQAAHgljFTIAAAAQliFUn1AAIAAAAQn0AAljlUg");
	var mask_33_graphics_488 = new cjs.Graphics().p("AtdM5QlklWAAnjIAAAAQAAniFklXIAAAAQFllVH4AAIAAAAQH5AAFkFVIAAAAQFlFXAAHiIAAAAQAAHjllFWIAAAAQlkFWn5AAIAAAAQn4AAlllWg");
	var mask_33_graphics_489 = new cjs.Graphics().p("AtiM/QlnlYAAnnIAAAAQAAnmFnlYIAAAAQFnlYH7AAIAAAAQH8AAFnFYIAAAAQFnFYAAHmIAAAAQAAHnlnFYIAAAAQlnFYn8AAIAAAAQn7AAlnlYg");
	var mask_33_graphics_490 = new cjs.Graphics().p("AtoNEQlplaAAnqIAAAAQAAnpFplaIAAAAQFqlaH+AAIAAAAQH/AAFpFaIAAAAQFqFaAAHpIAAAAQAAHqlqFaIAAAAQlpFan/AAIAAAAQn+AAlqlag");
	var mask_33_graphics_491 = new cjs.Graphics().p("AttNJQlrlcAAntIAAAAQAAnsFrlcIAAAAQFslcIBAAIAAAAQICAAFrFcIAAAAQFsFcAAHsIAAAAQAAHtlsFcIAAAAQlrFcoCAAIAAAAQoBAAlslcg");
	var mask_33_graphics_492 = new cjs.Graphics().p("AtyNNQltleAAnvIAAAAQAAnuFtlfIAAAAQFuleIEAAIAAAAQIFAAFtFeIAAAAQFuFfAAHuIAAAAQAAHvluFeIAAAAQltFfoFAAIAAAAQoEAAlulfg");
	var mask_33_graphics_493 = new cjs.Graphics().p("At2NSQlvlgAAnyIAAAAQAAnxFvlgIAAAAQFwlgIGAAIAAAAQIHAAFwFgIAAAAQFvFgAAHxIAAAAQAAHylvFgIAAAAQlwFgoHAAIAAAAQoGAAlwlgg");
	var mask_33_graphics_494 = new cjs.Graphics().p("At6NWQlxliAAn0IAAAAQAAnzFxliIAAAAQFxliIJABIAAAAQIKgBFxFiIAAAAQFxFiAAHzIAAAAQAAH0lxFiIAAAAQlxFhoKAAIAAAAQoJAAlxlhg");
	var mask_33_graphics_495 = new cjs.Graphics().p("At+NZQlzljAAn2IAAAAQAAn1FzlkIAAAAQFzljILAAIAAAAQIMAAFzFjIAAAAQFzFkAAH1IAAAAQAAH2lzFjIAAAAQlzFkoMAAIAAAAQoLAAlzlkg");
	var mask_33_graphics_496 = new cjs.Graphics().p("AuCNdQl0llAAn4IAAAAQAAn3F0llIAAAAQF1llINAAIAAAAQIOAAF0FlIAAAAQF1FlAAH3IAAAAQAAH4l1FlIAAAAQl0FloOAAIAAAAQoNAAl1llg");
	var mask_33_graphics_497 = new cjs.Graphics().p("AuFNgQl1lmAAn6IAAAAQAAn5F1lmIAAAAQF2lmIPAAIAAAAQIQAAF1FmIAAAAQF2FmAAH5IAAAAQAAH6l2FmIAAAAQl1FmoQAAIAAAAQoPAAl2lmg");
	var mask_33_graphics_498 = new cjs.Graphics().p("AuINjQl2lnAAn8IAAAAQAAn7F2lnIAAAAQF3lnIRAAIAAAAQISAAF2FnIAAAAQF3FnAAH7IAAAAQAAH8l3FnIAAAAQl2FnoSAAIAAAAQoRAAl3lng");
	var mask_33_graphics_499 = new cjs.Graphics().p("AuKNlQl4loAAn9IAAAAQAAn8F4lpIAAAAQF4lnISAAIAAAAQITAAF4FnIAAAAQF4FpAAH8IAAAAQAAH9l4FoIAAAAQl4FooTAAIAAAAQoSAAl4log");
	var mask_33_graphics_500 = new cjs.Graphics().p("AuNNnQl4lpAAn+IAAAAQAAn9F4lqIAAAAQF5lpIUAAIAAAAQIVAAF4FpIAAAAQF5FqAAH9IAAAAQAAH+l5FpIAAAAQl4FqoVAAIAAAAQoUAAl5lqg");
	var mask_33_graphics_501 = new cjs.Graphics().p("AuPNpQl5lpAAoAIAAAAQAAn/F5lqIAAAAQF6lpIVAAIAAAAQIWAAF5FpIAAAAQF6FqAAH/IAAAAQAAIAl6FpIAAAAQl5FqoWAAIAAAAQoVAAl6lqg");
	var mask_33_graphics_502 = new cjs.Graphics().p("AuRNrQl6lqAAoBIAAAAQAAoAF6lqIAAAAQF7lrIWAAIAAAAQIXAAF6FrIAAAAQF7FqAAIAIAAAAQAAIBl7FqIAAAAQl6FroXAAIAAAAQoWAAl7lrg");
	var mask_33_graphics_503 = new cjs.Graphics().p("AuSNsQl7lrAAoBIAAAAQAAoAF7lsIAAAAQF7lrIXAAIAAAAQIYAAF6FrIAAAAQF8FsAAIAIAAAAQAAIBl8FrIAAAAQl6FsoYAAIAAAAQoXAAl7lsg");
	var mask_33_graphics_504 = new cjs.Graphics().p("AuTNtQl7lrAAoCIAAAAQAAoBF7lsIAAAAQF8lrIXAAIAAAAQIYAAF8FrIAAAAQF7FsAAIBIAAAAQAAICl7FrIAAAAQl8FsoYAAIAAAAQoXAAl8lsg");
	var mask_33_graphics_505 = new cjs.Graphics().p("AuUNuQl7lsAAoCIAAAAQAAoBF7lsIAAAAQF8lsIYAAIAAAAQIZAAF7FsIAAAAQF8FsAAIBIAAAAQAAICl8FsIAAAAQl7FsoZAAIAAAAQoYAAl8lsg");
	var mask_33_graphics_506 = new cjs.Graphics().p("AuUNuQl8lrAAoDIAAAAQAAoCF8lsIAAAAQF8lsIYAAIAAAAQIZAAF8FsIAAAAQF8FsAAICIAAAAQAAIDl8FrIAAAAQl8FtoZAAIAAAAQoYAAl8ltg");
	var mask_33_graphics_507 = new cjs.Graphics().p("AuUNvQl8lsAAoDIAAAAQAAoCF8lsIAAAAQF8lsIYAAIAAAAQIZAAF8FsIAAAAQF8FsAAICIAAAAQAAIDl8FsIAAAAQl8FsoZAAIAAAAQoYAAl8lsg");

	this.timeline.addTween(cjs.Tween.get(mask_33).to({graphics:null,x:0,y:0}).wait(399).to({graphics:mask_33_graphics_399,x:821.5501,y:273.8502}).wait(1).to({graphics:mask_33_graphics_400,x:821.5573,y:273.8394}).wait(1).to({graphics:mask_33_graphics_401,x:821.5798,y:273.8074}).wait(1).to({graphics:mask_33_graphics_402,x:821.6172,y:273.7543}).wait(1).to({graphics:mask_33_graphics_403,x:821.6689,y:273.6796}).wait(1).to({graphics:mask_33_graphics_404,x:821.736,y:273.5838}).wait(1).to({graphics:mask_33_graphics_405,x:821.8179,y:273.4663}).wait(1).to({graphics:mask_33_graphics_406,x:821.9146,y:273.3282}).wait(1).to({graphics:mask_33_graphics_407,x:822.0267,y:273.168}).wait(1).to({graphics:mask_33_graphics_408,x:822.1531,y:272.9871}).wait(1).to({graphics:mask_33_graphics_409,x:822.2945,y:272.7846}).wait(1).to({graphics:mask_33_graphics_410,x:822.451,y:272.5609}).wait(1).to({graphics:mask_33_graphics_411,x:822.622,y:272.3157}).wait(1).to({graphics:mask_33_graphics_412,x:822.8083,y:272.0493}).wait(1).to({graphics:mask_33_graphics_413,x:823.0095,y:271.7617}).wait(1).to({graphics:mask_33_graphics_414,x:823.225,y:271.4526}).wait(1).to({graphics:mask_33_graphics_415,x:823.4559,y:271.1223}).wait(1).to({graphics:mask_33_graphics_416,x:823.7011,y:270.7708}).wait(1).to({graphics:mask_33_graphics_417,x:823.9617,y:270.3973}).wait(1).to({graphics:mask_33_graphics_418,x:824.2375,y:270.0036}).wait(1).to({graphics:mask_33_graphics_419,x:824.5278,y:269.5878}).wait(1).to({graphics:mask_33_graphics_420,x:824.8329,y:269.1513}).wait(1).to({graphics:mask_33_graphics_421,x:825.1533,y:268.6927}).wait(1).to({graphics:mask_33_graphics_422,x:825.4876,y:268.2135}).wait(1).to({graphics:mask_33_graphics_423,x:825.8377,y:267.7122}).wait(1).to({graphics:mask_33_graphics_424,x:826.2027,y:267.1902}).wait(1).to({graphics:mask_33_graphics_425,x:826.5825,y:266.6466}).wait(1).to({graphics:mask_33_graphics_426,x:826.9767,y:266.0823}).wait(1).to({graphics:mask_33_graphics_427,x:827.3862,y:265.4964}).wait(1).to({graphics:mask_33_graphics_428,x:827.8105,y:264.8889}).wait(1).to({graphics:mask_33_graphics_429,x:828.2498,y:264.2598}).wait(1).to({graphics:mask_33_graphics_430,x:828.7038,y:263.61}).wait(1).to({graphics:mask_33_graphics_431,x:829.1727,y:262.939}).wait(1).to({graphics:mask_33_graphics_432,x:829.6564,y:262.246}).wait(1).to({graphics:mask_33_graphics_433,x:830.155,y:261.5323}).wait(1).to({graphics:mask_33_graphics_434,x:830.6689,y:260.797}).wait(1).to({graphics:mask_33_graphics_435,x:831.1977,y:260.0406}).wait(1).to({graphics:mask_33_graphics_436,x:831.7408,y:259.263}).wait(1).to({graphics:mask_33_graphics_437,x:832.2993,y:258.4633}).wait(1).to({graphics:mask_33_graphics_438,x:832.8726,y:257.6425}).wait(1).to({graphics:mask_33_graphics_439,x:833.4603,y:256.8015}).wait(1).to({graphics:mask_33_graphics_440,x:834.0633,y:255.9384}).wait(1).to({graphics:mask_33_graphics_441,x:834.6811,y:255.0537}).wait(1).to({graphics:mask_33_graphics_442,x:835.3143,y:254.1479}).wait(1).to({graphics:mask_33_graphics_443,x:835.9614,y:253.2208}).wait(1).to({graphics:mask_33_graphics_444,x:836.6242,y:252.2722}).wait(1).to({graphics:mask_33_graphics_445,x:837.3015,y:251.3025}).wait(1).to({graphics:mask_33_graphics_446,x:837.9936,y:250.312}).wait(1).to({graphics:mask_33_graphics_447,x:838.701,y:249.2995}).wait(1).to({graphics:mask_33_graphics_448,x:839.4228,y:248.2659}).wait(1).to({graphics:mask_33_graphics_449,x:840.1599,y:247.2111}).wait(1).to({graphics:mask_33_graphics_450,x:840.9118,y:246.1347}).wait(1).to({graphics:mask_33_graphics_451,x:841.6782,y:245.0376}).wait(1).to({graphics:mask_33_graphics_452,x:842.4598,y:243.9184}).wait(1).to({graphics:mask_33_graphics_453,x:843.2568,y:242.7786}).wait(1).to({graphics:mask_33_graphics_454,x:844.0528,y:241.6383}).wait(1).to({graphics:mask_33_graphics_455,x:844.8345,y:240.5196}).wait(1).to({graphics:mask_33_graphics_456,x:845.6013,y:239.4216}).wait(1).to({graphics:mask_33_graphics_457,x:846.3532,y:238.3452}).wait(1).to({graphics:mask_33_graphics_458,x:847.0903,y:237.2908}).wait(1).to({graphics:mask_33_graphics_459,x:847.8121,y:236.2572}).wait(1).to({graphics:mask_33_graphics_460,x:848.5195,y:235.2451}).wait(1).to({graphics:mask_33_graphics_461,x:849.2116,y:234.2538}).wait(1).to({graphics:mask_33_graphics_462,x:849.8889,y:233.284}).wait(1).to({graphics:mask_33_graphics_463,x:850.5517,y:232.3354}).wait(1).to({graphics:mask_33_graphics_464,x:851.1993,y:231.4089}).wait(1).to({graphics:mask_33_graphics_465,x:851.8315,y:230.5031}).wait(1).to({graphics:mask_33_graphics_466,x:852.4499,y:229.6188}).wait(1).to({graphics:mask_33_graphics_467,x:853.0528,y:228.7557}).wait(1).to({graphics:mask_33_graphics_468,x:853.6405,y:227.9137}).wait(1).to({graphics:mask_33_graphics_469,x:854.2139,y:227.0934}).wait(1).to({graphics:mask_33_graphics_470,x:854.7723,y:226.2942}).wait(1).to({graphics:mask_33_graphics_471,x:855.3154,y:225.5162}).wait(1).to({graphics:mask_33_graphics_472,x:855.8437,y:224.7597}).wait(1).to({graphics:mask_33_graphics_473,x:856.3576,y:224.0244}).wait(1).to({graphics:mask_33_graphics_474,x:856.8567,y:223.3102}).wait(1).to({graphics:mask_33_graphics_475,x:857.34,y:222.6181}).wait(1).to({graphics:mask_33_graphics_476,x:857.8093,y:221.9467}).wait(1).to({graphics:mask_33_graphics_477,x:858.2634,y:221.2965}).wait(1).to({graphics:mask_33_graphics_478,x:858.7026,y:220.6683}).wait(1).to({graphics:mask_33_graphics_479,x:859.127,y:220.0608}).wait(1).to({graphics:mask_33_graphics_480,x:859.536,y:219.4744}).wait(1).to({graphics:mask_33_graphics_481,x:859.9306,y:218.9097}).wait(1).to({graphics:mask_33_graphics_482,x:860.3105,y:218.3661}).wait(1).to({graphics:mask_33_graphics_483,x:860.6754,y:217.8441}).wait(1).to({graphics:mask_33_graphics_484,x:861.0251,y:217.3437}).wait(1).to({graphics:mask_33_graphics_485,x:861.3598,y:216.864}).wait(1).to({graphics:mask_33_graphics_486,x:861.6798,y:216.4059}).wait(1).to({graphics:mask_33_graphics_487,x:861.9854,y:215.9689}).wait(1).to({graphics:mask_33_graphics_488,x:862.2756,y:215.5532}).wait(1).to({graphics:mask_33_graphics_489,x:862.551,y:215.159}).wait(1).to({graphics:mask_33_graphics_490,x:862.8116,y:214.7863}).wait(1).to({graphics:mask_33_graphics_491,x:863.0572,y:214.434}).wait(1).to({graphics:mask_33_graphics_492,x:863.2877,y:214.1037}).wait(1).to({graphics:mask_33_graphics_493,x:863.5037,y:213.7955}).wait(1).to({graphics:mask_33_graphics_494,x:863.7048,y:213.5074}).wait(1).to({graphics:mask_33_graphics_495,x:863.8906,y:213.2406}).wait(1).to({graphics:mask_33_graphics_496,x:864.0621,y:212.9958}).wait(1).to({graphics:mask_33_graphics_497,x:864.2182,y:212.7721}).wait(1).to({graphics:mask_33_graphics_498,x:864.36,y:212.5697}).wait(1).to({graphics:mask_33_graphics_499,x:864.4865,y:212.3883}).wait(1).to({graphics:mask_33_graphics_500,x:864.5981,y:212.2285}).wait(1).to({graphics:mask_33_graphics_501,x:864.6948,y:212.0904}).wait(1).to({graphics:mask_33_graphics_502,x:864.7767,y:211.973}).wait(1).to({graphics:mask_33_graphics_503,x:864.8437,y:211.8771}).wait(1).to({graphics:mask_33_graphics_504,x:864.8959,y:211.8024}).wait(1).to({graphics:mask_33_graphics_505,x:864.9333,y:211.7488}).wait(1).to({graphics:mask_33_graphics_506,x:864.9553,y:211.7174}).wait(1).to({graphics:mask_33_graphics_507,x:864.963,y:211.7065}).wait(303));

	// Layer_40
	this.instance_58 = new lib.Tween77("synched",0);
	this.instance_58.setTransform(888.95,212.55);
	this.instance_58.alpha = 0.5;
	this.instance_58._off = true;

	this.instance_59 = new lib.Tween78("synched",0);
	this.instance_59.setTransform(888.95,212.55);

	var maskedShapeInstanceList = [this.instance_58,this.instance_59];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_33;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_58}]},399).to({state:[{t:this.instance_59}]},108).wait(303));
	this.timeline.addTween(cjs.Tween.get(this.instance_58).wait(399).to({_off:false},0).to({_off:true,alpha:1},108).wait(303));

	// Layer_8
	this.instance_60 = new lib.Tween18("synched",2);
	this.instance_60.setTransform(-0.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_60).to({startPosition:179},177).to({startPosition:349},170).to({startPosition:85},36).wait(427));

	// Layer_6 (mask)
	var mask_34 = new cjs.Shape();
	mask_34._off = true;
	var mask_34_graphics_20 = new cjs.Graphics().p("AgqApQgRgRAAgYIAAAAQAAgXARgRIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQARARAAAXIAAAAQAAAYgRARIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_34_graphics_21 = new cjs.Graphics().p("AgqApQgSgRAAgYIAAAAQAAgXASgRIAAAAQASgRAYAAIAAAAQAZAAASARIAAAAQASARAAAXIAAAAQAAAYgSARIAAAAQgSARgZAAIAAAAQgYAAgSgRg");
	var mask_34_graphics_22 = new cjs.Graphics().p("AgrAqQgSgRAAgZIAAAAQAAgYASgRIAAAAQASgSAZAAIAAAAQAaAAASASIAAAAQASARAAAYIAAAAQAAAZgSARIAAAAQgSASgaAAIAAAAQgZAAgSgSg");
	var mask_34_graphics_23 = new cjs.Graphics().p("AgsAsQgTgTAAgZIAAAAQAAgYATgTIAAAAQASgSAaAAIAAAAQAbAAASASIAAAAQATATAAAYIAAAAQAAAZgTATIAAAAQgSASgbAAIAAAAQgaAAgSgSg");
	var mask_34_graphics_24 = new cjs.Graphics().p("AgvAuQgTgTAAgbIAAAAQAAgaATgTIAAAAQAUgSAbAAIAAAAQAcAAAUASIAAAAQATATAAAaIAAAAQAAAbgTATIAAAAQgUASgcAAIAAAAQgbAAgUgSg");
	var mask_34_graphics_25 = new cjs.Graphics().p("AgxAwQgVgUAAgcIAAAAQAAgbAVgUIAAAAQAVgUAcAAIAAAAQAdAAAVAUIAAAAQAVAUAAAbIAAAAQAAAcgVAUIAAAAQgVAUgdAAIAAAAQgcAAgVgUg");
	var mask_34_graphics_26 = new cjs.Graphics().p("Ag0AzQgXgVAAgeIAAAAQAAgdAXgVIAAAAQAWgVAeAAIAAAAQAfAAAWAVIAAAAQAXAVAAAdIAAAAQAAAegXAVIAAAAQgWAVgfAAIAAAAQgeAAgWgVg");
	var mask_34_graphics_27 = new cjs.Graphics().p("Ag4A3QgYgXAAggIAAAAQAAgfAYgXIAAAAQAXgXAhAAIAAAAQAiAAAXAXIAAAAQAYAXAAAfIAAAAQAAAggYAXIAAAAQgXAXgiAAIAAAAQghAAgXgXg");
	var mask_34_graphics_28 = new cjs.Graphics().p("Ag9A7QgZgYAAgjIAAAAQAAgiAZgYIAAAAQAagZAjAAIAAAAQAkAAAaAZIAAAAQAZAYAAAiIAAAAQAAAjgZAYIAAAAQgaAZgkAAIAAAAQgjAAgagZg");
	var mask_34_graphics_29 = new cjs.Graphics().p("AhCBAQgcgaAAgmIAAAAQAAglAcgaIAAAAQAcgbAmAAIAAAAQAnAAAcAbIAAAAQAcAaAAAlIAAAAQAAAmgcAaIAAAAQgcAbgnAAIAAAAQgmAAgcgbg");
	var mask_34_graphics_30 = new cjs.Graphics().p("AhIBFQgegcAAgpIAAAAQAAgoAegdIAAAAQAfgcApAAIAAAAQAqAAAfAcIAAAAQAeAdAAAoIAAAAQAAApgeAcIAAAAQgfAdgqAAIAAAAQgpAAgfgdg");
	var mask_34_graphics_31 = new cjs.Graphics().p("AhOBLQgggfAAgsIAAAAQAAgrAgggIAAAAQAhgfAtAAIAAAAQAuAAAhAfIAAAAQAgAgAAArIAAAAQAAAsggAfIAAAAQghAgguAAIAAAAQgtAAghggg");
	var mask_34_graphics_32 = new cjs.Graphics().p("AhVBSQgjgiAAgwIAAAAQAAgvAjgiIAAAAQAkgiAxAAIAAAAQAyAAAkAiIAAAAQAjAiAAAvIAAAAQAAAwgjAiIAAAAQgkAigyAAIAAAAQgxAAgkgig");
	var mask_34_graphics_33 = new cjs.Graphics().p("AhcBZQgnglAAg0IAAAAQAAgzAnglIAAAAQAmglA2AAIAAAAQA3AAAmAlIAAAAQAnAlAAAzIAAAAQAAA0gnAlIAAAAQgmAlg3AAIAAAAQg2AAgmglg");
	var mask_34_graphics_34 = new cjs.Graphics().p("AhkBhQgqgoAAg5IAAAAQAAg4AqgoIAAAAQAqgoA6AAIAAAAQA7AAAqAoIAAAAQAqAoAAA4IAAAAQAAA5gqAoIAAAAQgqAog7AAIAAAAQg6AAgqgog");
	var mask_34_graphics_35 = new cjs.Graphics().p("AhtBpQgtgrAAg+IAAAAQAAg9AtgrIAAAAQAugsA/AAIAAAAQBAAAAuAsIAAAAQAtArAAA9IAAAAQAAA+gtArIAAAAQguAshAAAIAAAAQg/AAgugsg");
	var mask_34_graphics_36 = new cjs.Graphics().p("Ah2ByQgxgvAAhDIAAAAQAAhCAxgvIAAAAQAxgvBFAAIAAAAQBGAAAxAvIAAAAQAxAvAABCIAAAAQAABDgxAvIAAAAQgxAvhGAAIAAAAQhFAAgxgvg");
	var mask_34_graphics_37 = new cjs.Graphics().p("AiAB7Qg1gzAAhIIAAAAQAAhHA1gzIAAAAQA2g0BKAAIAAAAQBLAAA2A0IAAAAQA1AzAABHIAAAAQAABIg1AzIAAAAQg2A0hLAAIAAAAQhKAAg2g0g");
	var mask_34_graphics_38 = new cjs.Graphics().p("AiKCFQg6g3AAhOIAAAAQAAhNA6g3IAAAAQA5g4BRAAIAAAAQBSAAA5A4IAAAAQA6A3AABNIAAAAQAABOg6A3IAAAAQg5A4hSAAIAAAAQhRAAg5g4g");
	var mask_34_graphics_39 = new cjs.Graphics().p("AiVCQQg/g8AAhUIAAAAQAAhTA/g8IAAAAQA+g8BXAAIAAAAQBYAAA+A8IAAAAQA/A8AABTIAAAAQAABUg/A8IAAAAQg+A8hYAAIAAAAQhXAAg+g8g");
	var mask_34_graphics_40 = new cjs.Graphics().p("AihCbQhDhAAAhbIAAAAQAAhaBDhAIAAAAQBDhABeAAIAAAAQBfAABDBAIAAAAQBDBAAABaIAAAAQAABbhDBAIAAAAQhDBAhfAAIAAAAQheAAhDhAg");
	var mask_34_graphics_41 = new cjs.Graphics().p("AitCnQhIhFAAhiIAAAAQAAhhBIhFIAAAAQBIhFBlAAIAAAAQBmAABIBFIAAAAQBIBFAABhIAAAAQAABihIBFIAAAAQhIBFhmAAIAAAAQhlAAhIhFg");
	var mask_34_graphics_42 = new cjs.Graphics().p("Ai6CzQhNhKAAhpIAAAAQAAhoBNhKIAAAAQBOhKBsAAIAAAAQBtAABOBKIAAAAQBNBKAABoIAAAAQAABphNBKIAAAAQhOBKhtAAIAAAAQhsAAhOhKg");
	var mask_34_graphics_43 = new cjs.Graphics().p("AjHDAQhThQAAhwIAAAAQAAhvBThQIAAAAQBThPB0AAIAAAAQB1AABTBPIAAAAQBTBQAABvIAAAAQAABwhTBQIAAAAQhTBPh1AAIAAAAQh0AAhThPg");
	var mask_34_graphics_44 = new cjs.Graphics().p("AjVDNQhZhVAAh4IAAAAQAAh3BZhVIAAAAQBYhVB9AAIAAAAQB+AABYBVIAAAAQBZBVAAB3IAAAAQAAB4hZBVIAAAAQhYBVh+AAIAAAAQh9AAhYhVg");
	var mask_34_graphics_45 = new cjs.Graphics().p("AjkDbQhfhbAAiAIAAAAQAAh/BfhbIAAAAQBfhbCFAAIAAAAQCGAABfBbIAAAAQBfBbAAB/IAAAAQAACAhfBbIAAAAQhfBbiGAAIAAAAQiFAAhfhbg");
	var mask_34_graphics_46 = new cjs.Graphics().p("AjzDqQhlhhAAiJIAAAAQAAiIBlhhIAAAAQBlhhCOAAIAAAAQCPAABlBhIAAAAQBlBhAACIIAAAAQAACJhlBhIAAAAQhlBhiPAAIAAAAQiOAAhlhhg");
	var mask_34_graphics_47 = new cjs.Graphics().p("AkDD5QhshnAAiSIAAAAQAAiRBshnIAAAAQBshnCXAAIAAAAQCYAABsBnIAAAAQBsBnAACRIAAAAQAACShsBnIAAAAQhsBniYAAIAAAAQiXAAhshng");
	var mask_34_graphics_48 = new cjs.Graphics().p("AkTEJQhzhuAAibIAAAAQAAiaBzhuIAAAAQByhtChAAIAAAAQCiAAByBtIAAAAQBzBuAACaIAAAAQAACbhzBuIAAAAQhyBtiiAAIAAAAQihAAhyhtg");
	var mask_34_graphics_49 = new cjs.Graphics().p("AkkEZQh6h0AAilIAAAAQAAikB6h0IAAAAQB5h0CrAAIAAAAQCsAAB5B0IAAAAQB6B0AACkIAAAAQAAClh6B0IAAAAQh5B0isAAIAAAAQirAAh5h0g");
	var mask_34_graphics_50 = new cjs.Graphics().p("Ak2EqQiBh8AAiuIAAAAQAAitCBh8IAAAAQCBh7C1AAIAAAAQC2AACBB7IAAAAQCBB8AACtIAAAAQAACuiBB8IAAAAQiBB7i2AAIAAAAQi1AAiBh7g");
	var mask_34_graphics_51 = new cjs.Graphics().p("AlIE7QiIiCAAi5IAAAAQAAi4CIiCIAAAAQCIiDDAAAIAAAAQDBAACICDIAAAAQCICCAAC4IAAAAQAAC5iICCIAAAAQiICDjBAAIAAAAQjAAAiIiDg");
	var mask_34_graphics_52 = new cjs.Graphics().p("AlbFNQiQiKAAjDIAAAAQAAjCCQiKIAAAAQCQiKDLAAIAAAAQDMAACQCKIAAAAQCQCKAADCIAAAAQAADDiQCKIAAAAQiQCKjMAAIAAAAQjLAAiQiKg");
	var mask_34_graphics_53 = new cjs.Graphics().p("AluFgQiYiSAAjOIAAAAQAAjNCYiSIAAAAQCYiRDWAAIAAAAQDXAACYCRIAAAAQCYCSAADNIAAAAQAADOiYCSIAAAAQiYCRjXAAIAAAAQjWAAiYiRg");
	var mask_34_graphics_54 = new cjs.Graphics().p("AmCFzQigiaAAjZIAAAAQAAjYCgiaIAAAAQCgiZDiAAIAAAAQDjAACgCZIAAAAQCgCaAADYIAAAAQAADZigCaIAAAAQigCZjjAAIAAAAQjiAAigiZg");
	var mask_34_graphics_55 = new cjs.Graphics().p("AmXGGQioihAAjlIAAAAQAAjkCoiiIAAAAQCpihDuAAIAAAAQDvAACoChIAAAAQCpCiAADkIAAAAQAADlipChIAAAAQioCijvAAIAAAAQjuAAipiig");
	var mask_34_graphics_56 = new cjs.Graphics().p("AmsGbQixiqAAjxIAAAAQAAjwCxiqIAAAAQCyiqD6AAIAAAAQD7AACyCqIAAAAQCxCqAADwIAAAAQAADxixCqIAAAAQiyCqj7AAIAAAAQj6AAiyiqg");
	var mask_34_graphics_57 = new cjs.Graphics().p("AnCGwQi6izAAj9IAAAAQAAj8C6izIAAAAQC7iyEHAAIAAAAQEIAAC6CyIAAAAQC7CzAAD8IAAAAQAAD9i7CzIAAAAQi6CykIAAIAAAAQkHAAi7iyg");
	var mask_34_graphics_58 = new cjs.Graphics().p("AnYHFQjEi8AAkJIAAAAQAAkIDEi8IAAAAQDEi8EUAAIAAAAQEVAADEC8IAAAAQDEC8AAEIIAAAAQAAEJjEC8IAAAAQjEC8kVAAIAAAAQkUAAjEi8g");
	var mask_34_graphics_59 = new cjs.Graphics().p("AnvHbQjNjFAAkWIAAAAQAAkVDNjFIAAAAQDOjFEhAAIAAAAQEiAADODFIAAAAQDNDFAAEVIAAAAQAAEWjNDFIAAAAQjODFkiAAIAAAAQkhAAjOjFg");
	var mask_34_graphics_60 = new cjs.Graphics().p("AoGHxQjXjOAAkjIAAAAQAAkiDXjPIAAAAQDXjOEvAAIAAAAQEwAADXDOIAAAAQDXDPAAEiIAAAAQAAEjjXDOIAAAAQjXDPkwAAIAAAAQkvAAjXjPg");
	var mask_34_graphics_61 = new cjs.Graphics().p("AofIJQjgjYAAkxIAAAAQAAkwDgjYIAAAAQDijXE9AAIAAAAQE+AADhDXIAAAAQDhDYAAEwIAAAAQAAExjhDYIAAAAQjhDXk+AAIAAAAQk9AAjijXg");
	var mask_34_graphics_62 = new cjs.Graphics().p("Ao3IgQjrjhAAk/IAAAAQAAk+DrjhIAAAAQDrjiFMAAIAAAAQFNAADrDiIAAAAQDrDhAAE+IAAAAQAAE/jrDhIAAAAQjrDilNAAIAAAAQlMAAjrjig");
	var mask_34_graphics_63 = new cjs.Graphics().p("ApRI4Qj1jrAAlNIAAAAQAAlMD1jsIAAAAQD2jrFbAAIAAAAQFcAAD1DrIAAAAQD2DsAAFMIAAAAQAAFNj2DrIAAAAQj1DslcAAIAAAAQlbAAj2jsg");
	var mask_34_graphics_64 = new cjs.Graphics().p("ApqJRQkBj1AAlcIAAAAQAAlbEBj2IAAAAQEAj1FqAAIAAAAQFrAAEAD1IAAAAQEBD2AAFbIAAAAQAAFckBD1IAAAAQkAD2lrAAIAAAAQlqAAkAj2g");
	var mask_34_graphics_65 = new cjs.Graphics().p("AqFJrQkLkBAAlqIAAAAQAAlpELkBIAAAAQEMkAF5AAIAAAAQF6AAEMEAIAAAAQELEBAAFpIAAAAQAAFqkLEBIAAAAQkMEAl6AAIAAAAQl5AAkMkAg");
	var mask_34_graphics_66 = new cjs.Graphics().p("AqgKFQkXkLAAl6IAAAAQAAl5EXkLIAAAAQEXkLGJAAIAAAAQGKAAEXELIAAAAQEXELAAF5IAAAAQAAF6kXELIAAAAQkXELmKAAIAAAAQmJAAkXkLg");
	var mask_34_graphics_67 = new cjs.Graphics().p("Aq8KfQkikWAAmJIAAAAQAAmIEikWIAAAAQEjkWGZAAIAAAAQGaAAEiEWIAAAAQEjEWAAGIIAAAAQAAGJkjEWIAAAAQkiEWmaAAIAAAAQmZAAkjkWg");
	var mask_34_graphics_68 = new cjs.Graphics().p("ArYK6QkukhAAmZIAAAAQAAmYEukiIAAAAQEukhGqAAIAAAAQGrAAEuEhIAAAAQEuEiAAGYIAAAAQAAGZkuEhIAAAAQkuEimrAAIAAAAQmqAAkukig");
	var mask_34_graphics_69 = new cjs.Graphics().p("Ar1LWQk6ktAAmpIAAAAQAAmoE6ktIAAAAQE6ktG7AAIAAAAQG8AAE6EtIAAAAQE6EtAAGoIAAAAQAAGpk6EtIAAAAQk6Etm8AAIAAAAQm7AAk6ktg");
	var mask_34_graphics_70 = new cjs.Graphics().p("AsSLyQlGk4AAm6IAAAAQAAm5FGk5IAAAAQFGk4HMAAIAAAAQHNAAFGE4IAAAAQFGE5AAG5IAAAAQAAG6lGE4IAAAAQlGE5nNAAIAAAAQnMAAlGk5g");
	var mask_34_graphics_71 = new cjs.Graphics().p("AsxMPQlSlEAAnLIAAAAQAAnKFSlEIAAAAQFTlFHeAAIAAAAQHfAAFSFFIAAAAQFTFEAAHKIAAAAQAAHLlTFEIAAAAQlSFFnfAAIAAAAQneAAlTlFg");
	var mask_34_graphics_72 = new cjs.Graphics().p("AtPMsQlflQAAncIAAAAQAAnbFflRIAAAAQFflQHwAAIAAAAQHxAAFfFQIAAAAQFfFRAAHbIAAAAQAAHclfFQIAAAAQlfFRnxAAIAAAAQnwAAlflRg");
	var mask_34_graphics_73 = new cjs.Graphics().p("AtvNKQlslcAAnuIAAAAQAAntFsldIAAAAQFtldICAAIAAAAQIDAAFsFdIAAAAQFtFdAAHtIAAAAQAAHultFcIAAAAQlsFeoDAAIAAAAQoCAAltleg");
	var mask_34_graphics_74 = new cjs.Graphics().p("AuONpQl6lqAAn/IAAAAQAAn+F6lqIAAAAQF5lqIVAAIAAAAQIWAAF5FqIAAAAQF6FqAAH+IAAAAQAAH/l6FqIAAAAQl5FqoWAAIAAAAQoVAAl5lqg");
	var mask_34_graphics_75 = new cjs.Graphics().p("AuuOHQmHl2AAoRIAAAAQAAoQGHl3IAAAAQGHl2InAAIAAAAQIoAAGHF2IAAAAQGHF3AAIQIAAAAQAAIRmHF2IAAAAQmHF3ooAAIAAAAQonAAmHl3g");
	var mask_34_graphics_76 = new cjs.Graphics().p("AvOOlQmTmCAAojIAAAAQAAoiGTmDIAAAAQGUmCI6AAIAAAAQI7AAGTGCIAAAAQGUGDAAIiIAAAAQAAIjmUGCIAAAAQmTGDo7AAIAAAAQo6AAmUmDg");
	var mask_34_graphics_77 = new cjs.Graphics().p("AvsPDQmgmPAAo0IAAAAQAAozGgmPIAAAAQGgmPJMAAIAAAAQJNAAGgGPIAAAAQGgGPAAIzIAAAAQAAI0mgGPIAAAAQmgGPpNAAIAAAAQpMAAmgmPg");
	var mask_34_graphics_78 = new cjs.Graphics().p("AwKPgQmtmbAApFIAAAAQAApEGtmbIAAAAQGtmbJdAAIAAAAQJeAAGtGbIAAAAQGtGbAAJEIAAAAQAAJFmtGbIAAAAQmtGbpeAAIAAAAQpdAAmtmbg");
	var mask_34_graphics_79 = new cjs.Graphics().p("AwoP8Qm5mnAApVIAAAAQAApUG5mnIAAAAQG5mnJvAAIAAAAQJwAAG4GnIAAAAQG6GnAAJUIAAAAQAAJVm6GnIAAAAQm4GnpwAAIAAAAQpvAAm5mng");
	var mask_34_graphics_80 = new cjs.Graphics().p("AxFQXQnEmxAApmIAAAAQAAplHEmyIAAAAQHGmyJ/AAIAAAAQKAAAHFGyIAAAAQHFGyAAJlIAAAAQAAJmnFGxIAAAAQnFGzqAAAIAAAAQp/AAnGmzg");
	var mask_34_graphics_81 = new cjs.Graphics().p("AxhQzQnQm9AAp2IAAAAQAAp1HQm9IAAAAQHRm9KQAAIAAAAQKRAAHQG9IAAAAQHRG9AAJ1IAAAAQAAJ2nRG9IAAAAQnQG9qRAAIAAAAQqQAAnRm9g");
	var mask_34_graphics_82 = new cjs.Graphics().p("Ax9RNQncnIAAqFIAAAAQAAqEHcnJIAAAAQHdnIKgAAIAAAAQKhAAHcHIIAAAAQHdHJAAKEIAAAAQAAKFndHIIAAAAQncHJqhAAIAAAAQqgAAndnJg");
	var mask_34_graphics_83 = new cjs.Graphics().p("AyYRnQnnnTAAqUIAAAAQAAqTHnnUIAAAAQHonSKwAAIAAAAQKxAAHnHSIAAAAQHoHUAAKTIAAAAQAAKUnoHTIAAAAQnnHTqxAAIAAAAQqwAAnonTg");
	var mask_34_graphics_84 = new cjs.Graphics().p("AyySAQnyndAAqjIAAAAQAAqiHyneIAAAAQHyndLAAAIAAAAQLBAAHyHdIAAAAQHyHeAAKiIAAAAQAAKjnyHdIAAAAQnyHerBAAIAAAAQrAAAnyneg");
	var mask_34_graphics_85 = new cjs.Graphics().p("AzMSZQn9nnAAqyIAAAAQAAqxH9noIAAAAQH9nnLPAAIAAAAQLQAAH9HnIAAAAQH9HoAAKxIAAAAQAAKyn9HnIAAAAQn9HorQAAIAAAAQrPAAn9nog");
	var mask_34_graphics_86 = new cjs.Graphics().p("AzmSyQoHnyAArAIAAAAQAAq/IHnyIAAAAQIInyLeAAIAAAAQLfAAIHHyIAAAAQIIHyAAK/IAAAAQAALAoIHyIAAAAQoHHyrfAAIAAAAQreAAoInyg");
	var mask_34_graphics_87 = new cjs.Graphics().p("Az+TJQoSn7AArOIAAAAQAArNISn8IAAAAQISn7LsAAIAAAAQLtAAISH7IAAAAQISH8AALNIAAAAQAALOoSH7IAAAAQoSH8rtAAIAAAAQrsAAoSn8g");
	var mask_34_graphics_88 = new cjs.Graphics().p("A0WTgQocoFAArbIAAAAQAAraIcoGIAAAAQIcoFL6AAIAAAAQL7AAIcIFIAAAAQIcIGAALaIAAAAQAALbocIFIAAAAQocIGr7AAIAAAAQr6AAocoGg");
	var mask_34_graphics_89 = new cjs.Graphics().p("A0uT3QoloOAArpIAAAAQAAroIloOIAAAAQImoPMIAAIAAAAQMJAAIlIPIAAAAQImIOAALoIAAAAQAALpomIOIAAAAQolIPsJAAIAAAAQsIAAomoPg");
	var mask_34_graphics_90 = new cjs.Graphics().p("A1FUNQovoYAAr1IAAAAQAAr0IvoYIAAAAQIwoYMVAAIAAAAQMWAAIvIYIAAAAQIwIYAAL0IAAAAQAAL1owIYIAAAAQovIYsWAAIAAAAQsVAAowoYg");
	var mask_34_graphics_91 = new cjs.Graphics().p("A1bUiQo4ogAAsCIAAAAQAAsBI4ohIAAAAQI4ogMjAAIAAAAQMkAAI4IgIAAAAQI4IhAAMBIAAAAQAAMCo4IgIAAAAQo4IhskAAIAAAAQsjAAo4ohg");
	var mask_34_graphics_92 = new cjs.Graphics().p("A1xU3QpBopAAsOIAAAAQAAsNJBoqIAAAAQJCopMvAAIAAAAQMwAAJBIpIAAAAQJCIqAAMNIAAAAQAAMOpCIpIAAAAQpBIqswAAIAAAAQsvAApCoqg");
	var mask_34_graphics_93 = new cjs.Graphics().p("A2GVLQpKoxAAsaIAAAAQAAsZJKoyIAAAAQJKoxM8AAIAAAAQM9AAJJIxIAAAAQJLIyAAMZIAAAAQAAMapLIxIAAAAQpJIys9AAIAAAAQs8AApKoyg");
	var mask_34_graphics_94 = new cjs.Graphics().p("A2bVfQpSo5AAsmIAAAAQAAslJSo6IAAAAQJTo5NIAAIAAAAQNJAAJSI5IAAAAQJTI6AAMlIAAAAQAAMmpTI5IAAAAQpSI6tJAAIAAAAQtIAApTo6g");
	var mask_34_graphics_95 = new cjs.Graphics().p("A2vVyQpapBAAsxIAAAAQAAswJapCIAAAAQJcpBNTAAIAAAAQNUAAJbJBIAAAAQJbJCAAMwIAAAAQAAMxpbJBIAAAAQpbJCtUAAIAAAAQtTAApcpCg");
	var mask_34_graphics_96 = new cjs.Graphics().p("A3CWFQpjpJAAs8IAAAAQAAs7JjpJIAAAAQJjpJNfAAIAAAAQNgAAJiJJIAAAAQJkJJAAM7IAAAAQAAM8pkJJIAAAAQpiJJtgAAIAAAAQtfAApjpJg");
	var mask_34_graphics_97 = new cjs.Graphics().p("A3VWXQpqpRAAtGIAAAAQAAtFJqpRIAAAAQJrpRNqAAIAAAAQNrAAJqJRIAAAAQJrJRAANFIAAAAQAANGprJRIAAAAQpqJRtrAAIAAAAQtqAAprpRg");
	var mask_34_graphics_98 = new cjs.Graphics().p("A3nWoQpypYAAtQIAAAAQAAtPJypZIAAAAQJzpXN0AAIAAAAQN1AAJyJXIAAAAQJzJZAANPIAAAAQAANQpzJYIAAAAQpyJYt1AAIAAAAQt0AApzpYg");
	var mask_34_graphics_99 = new cjs.Graphics().p("A35W5Qp5pfAAtaIAAAAQAAtZJ5pgIAAAAQJ6peN/AAIAAAAQOAAAJ5JeIAAAAQJ6JgAANZIAAAAQAANap6JfIAAAAQp5JfuAAAIAAAAQt/AAp6pfg");
	var mask_34_graphics_100 = new cjs.Graphics().p("A4JXJQqBplAAtkIAAAAQAAtjKBpmIAAAAQKAplOJAAIAAAAQOKAAKAJlIAAAAQKBJmAANjIAAAAQAANkqBJlIAAAAQqAJmuKAAIAAAAQuJAAqApmg");
	var mask_34_graphics_101 = new cjs.Graphics().p("A4aXZQqHpsAAttIAAAAQAAtsKHptIAAAAQKIprOSAAIAAAAQOTAAKHJrIAAAAQKIJtAANsIAAAAQAANtqIJsIAAAAQqHJsuTAAIAAAAQuSAAqIpsg");
	var mask_34_graphics_102 = new cjs.Graphics().p("A4qXoQqNpyAAt2IAAAAQAAt1KNpzIAAAAQKPpyObAAIAAAAQOcAAKOJyIAAAAQKOJzAAN1IAAAAQAAN2qOJyIAAAAQqOJzucAAIAAAAQubAAqPpzg");
	var mask_34_graphics_103 = new cjs.Graphics().p("A45X2QqUp4AAt+IAAAAQAAt9KUp5IAAAAQKVp4OkAAIAAAAQOlAAKUJ4IAAAAQKVJ5AAN9IAAAAQAAN+qVJ4IAAAAQqUJ5ulAAIAAAAQukAAqVp5g");
	var mask_34_graphics_104 = new cjs.Graphics().p("A5HYEQqap+AAuGIAAAAQAAuFKap/IAAAAQKap+OtAAIAAAAQOuAAKaJ+IAAAAQKaJ/AAOFIAAAAQAAOGqaJ+IAAAAQqaJ/uuAAIAAAAQutAAqap/g");
	var mask_34_graphics_105 = new cjs.Graphics().p("A5VYSQqgqEAAuOIAAAAQAAuNKgqFIAAAAQKgqDO1AAIAAAAQO2AAKgKDIAAAAQKgKFAAONIAAAAQAAOOqgKEIAAAAQqgKEu2AAIAAAAQu1AAqgqEg");
	var mask_34_graphics_106 = new cjs.Graphics().p("A5jYfQqlqJAAuWIAAAAQAAuVKlqJIAAAAQKmqJO9AAIAAAAQO+AAKlKJIAAAAQKmKJAAOVIAAAAQAAOWqmKJIAAAAQqlKJu+AAIAAAAQu9AAqmqJg");
	var mask_34_graphics_107 = new cjs.Graphics().p("A5wYrQqqqOAAudIAAAAQAAucKqqPIAAAAQKsqOPEAAIAAAAQPFAAKrKOIAAAAQKrKPAAOcIAAAAQAAOdqrKOIAAAAQqrKPvFAAIAAAAQvEAAqsqPg");
	var mask_34_graphics_108 = new cjs.Graphics().p("A58Y3QqvqTAAukIAAAAQAAujKvqTIAAAAQKwqTPMAAIAAAAQPNAAKvKTIAAAAQKwKTAAOjIAAAAQAAOkqwKTIAAAAQqvKTvNAAIAAAAQvMAAqwqTg");
	var mask_34_graphics_109 = new cjs.Graphics().p("A6HZCQq1qYAAuqIAAAAQAAupK1qZIAAAAQK1qXPSAAIAAAAQPTAAK1KXIAAAAQK1KZAAOpIAAAAQAAOqq1KYIAAAAQq1KYvTAAIAAAAQvSAAq1qYg");
	var mask_34_graphics_110 = new cjs.Graphics().p("A6TZMQq4qbAAuxIAAAAQAAuwK4qcIAAAAQK6qcPZAAIAAAAQPaAAK5KcIAAAAQK5KcAAOwIAAAAQAAOxq5KbIAAAAQq5KdvaAAIAAAAQvZAAq6qdg");
	var mask_34_graphics_111 = new cjs.Graphics().p("A6dZWQq9qgAAu2IAAAAQAAu1K9qhIAAAAQK+qgPfAAIAAAAQPgAAK9KgIAAAAQK+KhAAO1IAAAAQAAO2q+KgIAAAAQq9KhvgAAIAAAAQvfAAq+qhg");
	var mask_34_graphics_112 = new cjs.Graphics().p("A6nZgQrBqkAAu8IAAAAQAAu7LBqlIAAAAQLCqjPlAAIAAAAQPmAALBKjIAAAAQLCKlAAO7IAAAAQAAO8rCKkIAAAAQrBKkvmAAIAAAAQvlAArCqkg");
	var mask_34_graphics_113 = new cjs.Graphics().p("A6wZpQrFqoAAvBIAAAAQAAvALFqoIAAAAQLGqoPqAAIAAAAQPrAALFKoIAAAAQLGKoAAPAIAAAAQAAPBrGKoIAAAAQrFKovrAAIAAAAQvqAArGqog");
	var mask_34_graphics_114 = new cjs.Graphics().p("A65ZxQrIqrAAvGIAAAAQAAvFLIqsIAAAAQLKqrPvAAIAAAAQPwAALJKrIAAAAQLJKsAAPFIAAAAQAAPGrJKrIAAAAQrJKsvwAAIAAAAQvvAArKqsg");
	var mask_34_graphics_115 = new cjs.Graphics().p("A7BZ5QrMquAAvLIAAAAQAAvKLMquIAAAAQLNquP0AAIAAAAQP1AALMKuIAAAAQLNKuAAPKIAAAAQAAPLrNKuIAAAAQrMKuv1AAIAAAAQv0AArNqug");
	var mask_34_graphics_116 = new cjs.Graphics().p("A7IaAQrPqxAAvPIAAAAQAAvOLPqyIAAAAQLQqwP4AAIAAAAQP5AALPKwIAAAAQLQKyAAPOIAAAAQAAPPrQKxIAAAAQrPKxv5AAIAAAAQv4AArQqxg");
	var mask_34_graphics_117 = new cjs.Graphics().p("A7PaGQrSqzAAvTIAAAAQAAvSLSq0IAAAAQLTq0P8AAIAAAAQP9AALSK0IAAAAQLTK0AAPSIAAAAQAAPTrTKzIAAAAQrSK1v9AAIAAAAQv8AArTq1g");
	var mask_34_graphics_118 = new cjs.Graphics().p("A7VaMQrVq2AAvWIAAAAQAAvVLVq3IAAAAQLVq2QAAAIAAAAQQBAALUK2IAAAAQLWK3AAPVIAAAAQAAPWrWK2IAAAAQrUK3wBAAIAAAAQwAAArVq3g");
	var mask_34_graphics_119 = new cjs.Graphics().p("A7baSQrXq5AAvZIAAAAQAAvYLXq5IAAAAQLYq5QDAAIAAAAQQEAALXK5IAAAAQLYK5AAPYIAAAAQAAPZrYK5IAAAAQrXK5wEAAIAAAAQwDAArYq5g");
	var mask_34_graphics_120 = new cjs.Graphics().p("A7gaXQrZq7AAvcIAAAAQAAvbLZq7IAAAAQLaq7QGAAIAAAAQQHAALZK7IAAAAQLaK7AAPbIAAAAQAAPcraK7IAAAAQrZK7wHAAIAAAAQwGAAraq7g");
	var mask_34_graphics_121 = new cjs.Graphics().p("A7kabQrbq8AAvfIAAAAQAAveLbq9IAAAAQLbq8QJAAIAAAAQQKAALbK8IAAAAQLbK9AAPeIAAAAQAAPfrbK8IAAAAQrbK9wKAAIAAAAQwJAArbq9g");
	var mask_34_graphics_122 = new cjs.Graphics().p("A7oafQrdq+AAvhIAAAAQAAvgLdq+IAAAAQLdq+QLAAIAAAAQQMAALcK+IAAAAQLeK+AAPgIAAAAQAAPhreK+IAAAAQrcK+wMAAIAAAAQwLAArdq+g");
	var mask_34_graphics_123 = new cjs.Graphics().p("A7saiQrdq/AAvjIAAAAQAAviLdq/IAAAAQLfrAQNAAIAAAAQQOAALeLAIAAAAQLeK/AAPiIAAAAQAAPjreK/IAAAAQreLAwOAAIAAAAQwNAArfrAg");
	var mask_34_graphics_124 = new cjs.Graphics().p("A7uakQrfrAAAvkIAAAAQAAvjLfrBIAAAAQLfrAQPAAIAAAAQQQAALeLAIAAAAQLgLBAAPjIAAAAQAAPkrgLAIAAAAQreLBwQAAIAAAAQwPAArfrBg");
	var mask_34_graphics_125 = new cjs.Graphics().p("A7wamQrgrBAAvlIAAAAQAAvkLgrCIAAAAQLgrBQQAAIAAAAQQRAALfLBIAAAAQLhLCAAPkIAAAAQAAPlrhLBIAAAAQrfLCwRAAIAAAAQwQAArgrCg");
	var mask_34_graphics_126 = new cjs.Graphics().p("A7yaoQrgrCAAvmIAAAAQAAvlLgrCIAAAAQLhrCQRAAIAAAAQQSAALgLCIAAAAQLhLCAAPlIAAAAQAAPmrhLCIAAAAQrgLCwSAAIAAAAQwRAArhrCg");
	var mask_34_graphics_127 = new cjs.Graphics().p("A7zaoQrgrBAAvnIAAAAQAAvmLgrCIAAAAQLirCQRAAIAAAAQQSAALhLCIAAAAQLhLCAAPmIAAAAQAAPnrhLBIAAAAQrhLDwSAAIAAAAQwRAArirDg");
	var mask_34_graphics_128 = new cjs.Graphics().p("A7zapQrhrCAAvnIAAAAQAAvmLhrDIAAAAQLirCQRAAIAAAAQQSAALhLCIAAAAQLiLDAAPmIAAAAQAAPnriLCIAAAAQrhLDwSAAIAAAAQwRAArirDg");
	var mask_34_graphics_129 = new cjs.Graphics().p("A7zapQrhrCAAvnIAAAAQAAvmLhrDIAAAAQLirCQRAAIAAAAQQSAALhLCIAAAAQLiLDAAPmIAAAAQAAPnriLCIAAAAQrhLDwSAAIAAAAQwRAArirDg");
	var mask_34_graphics_130 = new cjs.Graphics().p("A7zapQrhrCAAvnIAAAAQAAvmLhrCIAAAAQLirCQRAAIAAAAQQSAALhLCIAAAAQLiLCAAPmIAAAAQAAPnriLCIAAAAQrhLCwSAAIAAAAQwRAArirCg");
	var mask_34_graphics_131 = new cjs.Graphics().p("A7zapQrgrCAAvnIAAAAQAAvmLgrCIAAAAQLirCQRAAIAAAAQQSAALhLCIAAAAQLhLCAAPmIAAAAQAAPnrhLCIAAAAQrhLCwSAAIAAAAQwRAArirCg");
	var mask_34_graphics_132 = new cjs.Graphics().p("A7zaoQrgrCAAvmIAAAAQAAvlLgrDIAAAAQLirCQRAAIAAAAQQSAALhLCIAAAAQLhLDAAPlIAAAAQAAPmrhLCIAAAAQrhLDwSAAIAAAAQwRAArirDg");
	var mask_34_graphics_133 = new cjs.Graphics().p("A7yaoQrhrCAAvmIAAAAQAAvlLhrDIAAAAQLhrCQRAAIAAAAQQSAALgLCIAAAAQLiLDAAPlIAAAAQAAPmriLCIAAAAQrgLDwSAAIAAAAQwRAArhrDg");
	var mask_34_graphics_134 = new cjs.Graphics().p("A7yaoQrgrCAAvmIAAAAQAAvlLgrDIAAAAQLhrBQRAAIAAAAQQSAALgLBIAAAAQLhLDAAPlIAAAAQAAPmrhLCIAAAAQrgLCwSAAIAAAAQwRAArhrCg");
	var mask_34_graphics_135 = new cjs.Graphics().p("A7yanQrgrBAAvmIAAAAQAAvlLgrCIAAAAQLirCQQAAIAAAAQQRAALhLCIAAAAQLhLCAAPlIAAAAQAAPmrhLBIAAAAQrhLDwRAAIAAAAQwQAArirDg");
	var mask_34_graphics_136 = new cjs.Graphics().p("A7xanQrgrBAAvmIAAAAQAAvlLgrCIAAAAQLhrBQQAAIAAAAQQRAALgLBIAAAAQLhLCAAPlIAAAAQAAPmrhLBIAAAAQrgLCwRAAIAAAAQwQAArhrCg");
	var mask_34_graphics_137 = new cjs.Graphics().p("A7xamQrfrBAAvlIAAAAQAAvkLfrCIAAAAQLhrBQQAAIAAAAQQRAALgLBIAAAAQLgLCAAPkIAAAAQAAPlrgLBIAAAAQrgLCwRAAIAAAAQwQAArhrCg");
	var mask_34_graphics_138 = new cjs.Graphics().p("A7wamQrgrBAAvlIAAAAQAAvkLgrCIAAAAQLgrAQQAAIAAAAQQRAALfLAIAAAAQLgLCABPkIAAAAQgBPlrgLBIAAAAQrfLBwRAAIAAAAQwQAArgrBg");
	var mask_34_graphics_139 = new cjs.Graphics().p("A7valQrgrAAAvlIAAAAQAAvkLgrBIAAAAQLgrBQPAAIAAAAQQQAALfLBIAAAAQLhLBAAPkIAAAAQAAPlrhLAIAAAAQrfLCwQAAIAAAAQwPAArgrCg");
	var mask_34_graphics_140 = new cjs.Graphics().p("A7valQrfrBAAvkIAAAAQAAvjLfrBIAAAAQLgrBQPAAIAAAAQQQAALfLBIAAAAQLgLBAAPjIAAAAQAAPkrgLBIAAAAQrfLBwQAAIAAAAQwPAArgrBg");
	var mask_34_graphics_141 = new cjs.Graphics().p("A7uakQrfrAAAvkIAAAAQAAvjLfrBIAAAAQLgrAQOAAIAAAAQQPAALfLAIAAAAQLgLBAAPjIAAAAQAAPkrgLAIAAAAQrfLBwPAAIAAAAQwOAArgrBg");
	var mask_34_graphics_142 = new cjs.Graphics().p("A7tajQrerAAAvjIAAAAQAAviLerBIAAAAQLfq/QOAAIAAAAQQPAALeK/IAAAAQLfLBAAPiIAAAAQAAPjrfLAIAAAAQreLAwPAAIAAAAQwOAArfrAg");
	var mask_34_graphics_143 = new cjs.Graphics().p("A7saiQreq/AAvjIAAAAQAAviLerAIAAAAQLfq/QNAAIAAAAQQOAALeK/IAAAAQLfLAAAPiIAAAAQAAPjrfK/IAAAAQreLAwOAAIAAAAQwNAArfrAg");
	var mask_34_graphics_144 = new cjs.Graphics().p("A7rahQreq/AAviIAAAAQAAvhLerAIAAAAQLeq/QNAAIAAAAQQOAALdK/IAAAAQLfLAAAPhIAAAAQAAPirfK/IAAAAQrdLAwOAAIAAAAQwNAArerAg");
	var mask_34_graphics_145 = new cjs.Graphics().p("A7qagQrdq+AAviIAAAAQAAvhLdq/IAAAAQLeq/QMAAIAAAAQQNAALdK/IAAAAQLeK/AAPhIAAAAQAAPireK+IAAAAQrdLAwNAAIAAAAQwMAArerAg");
	var mask_34_graphics_146 = new cjs.Graphics().p("A7pafQrdq+AAvhIAAAAQAAvgLdq/IAAAAQLdq+QMAAIAAAAQQNAALcK+IAAAAQLeK/AAPgIAAAAQAAPhreK+IAAAAQrcK/wNAAIAAAAQwMAArdq/g");
	var mask_34_graphics_147 = new cjs.Graphics().p("A7oaeQrcq9AAvhIAAAAQAAvgLcq+IAAAAQLdq+QLAAIAAAAQQMAALcK+IAAAAQLdK+AAPgIAAAAQAAPhrdK9IAAAAQrcK/wMAAIAAAAQwLAArdq/g");
	var mask_34_graphics_148 = new cjs.Graphics().p("A7nadQrcq9AAvgIAAAAQAAvfLcq+IAAAAQLdq9QKAAIAAAAQQLAALcK9IAAAAQLdK+AAPfIAAAAQAAPgrdK9IAAAAQrcK+wLAAIAAAAQwKAArdq+g");
	var mask_34_graphics_149 = new cjs.Graphics().p("A7macQrbq9AAvfIAAAAQAAveLbq+IAAAAQLdq8QJAAIAAAAQQKAALcK8IAAAAQLcK+AAPeIAAAAQAAPfrcK9IAAAAQrcK9wKAAIAAAAQwJAArdq9g");
	var mask_34_graphics_150 = new cjs.Graphics().p("A7kabQrbq9AAveIAAAAQAAvdLbq9IAAAAQLbq9QJAAIAAAAQQKAALaK9IAAAAQLcK9AAPdIAAAAQAAPercK9IAAAAQraK9wKAAIAAAAQwJAArbq9g");
	var mask_34_graphics_151 = new cjs.Graphics().p("A7jaZQraq7AAveIAAAAQAAvdLaq8IAAAAQLbq8QIAAIAAAAQQJAALaK8IAAAAQLbK8AAPdIAAAAQAAPerbK7IAAAAQraK9wJAAIAAAAQwIAArbq9g");
	var mask_34_graphics_152 = new cjs.Graphics().p("A7haYQraq7AAvdIAAAAQAAvcLaq8IAAAAQLaq7QHAAIAAAAQQIAALaK7IAAAAQLaK8AAPcIAAAAQAAPdraK7IAAAAQraK8wIAAIAAAAQwHAAraq8g");
	var mask_34_graphics_153 = new cjs.Graphics().p("A7gaWQrZq6AAvcIAAAAQAAvbLZq7IAAAAQLaq7QGAAIAAAAQQHAALZK7IAAAAQLaK7AAPbIAAAAQAAPcraK6IAAAAQrZK8wHAAIAAAAQwGAAraq8g");
	var mask_34_graphics_154 = new cjs.Graphics().p("A7eaVQrZq6AAvbIAAAAQAAvaLZq7IAAAAQLZq6QFAAIAAAAQQGAALYK6IAAAAQLaK7AAPaIAAAAQAAPbraK6IAAAAQrYK7wGAAIAAAAQwFAArZq7g");
	var mask_34_graphics_155 = new cjs.Graphics().p("A7daTQrXq5AAvaIAAAAQAAvZLXq6IAAAAQLZq5QEAAIAAAAQQFAALYK5IAAAAQLYK6AAPZIAAAAQAAParYK5IAAAAQrYK6wFAAIAAAAQwEAArZq6g");
	var mask_34_graphics_156 = new cjs.Graphics().p("A7baSQrXq5AAvZIAAAAQAAvYLXq6IAAAAQLYq4QDAAIAAAAQQEAALXK4IAAAAQLYK6AAPYIAAAAQAAPZrYK5IAAAAQrXK5wEAAIAAAAQwDAArYq5g");
	var mask_34_graphics_157 = new cjs.Graphics().p("A7ZaQQrWq4AAvYIAAAAQAAvXLWq5IAAAAQLXq4QCAAIAAAAQQDAALWK4IAAAAQLXK5AAPXIAAAAQAAPYrXK4IAAAAQrWK5wDAAIAAAAQwCAArXq5g");
	var mask_34_graphics_158 = new cjs.Graphics().p("A7XaOQrWq3AAvXIAAAAQAAvWLWq4IAAAAQLWq3QBAAIAAAAQQCAALWK3IAAAAQLWK4AAPWIAAAAQAAPXrWK3IAAAAQrWK4wCAAIAAAAQwBAArWq4g");
	var mask_34_graphics_159 = new cjs.Graphics().p("A7WaNQrUq3AAvWIAAAAQAAvVLUq3IAAAAQLWq3QAAAIAAAAQQBAALVK3IAAAAQLVK3AAPVIAAAAQAAPWrVK3IAAAAQrVK3wBAAIAAAAQwAAArWq3g");
	var mask_34_graphics_160 = new cjs.Graphics().p("A7UaLQrUq2AAvVIAAAAQAAvULUq3IAAAAQLVq1P/AAIAAAAQQAAALUK1IAAAAQLVK3AAPUIAAAAQAAPVrVK2IAAAAQrUK2wAAAIAAAAQv/AArVq2g");
	var mask_34_graphics_161 = new cjs.Graphics().p("A7SaJQrTq1AAvUIAAAAQAAvTLTq2IAAAAQLUq0P+AAIAAAAQP/AALTK0IAAAAQLUK2AAPTIAAAAQAAPUrUK1IAAAAQrTK1v/AAIAAAAQv+AArUq1g");
	var mask_34_graphics_162 = new cjs.Graphics().p("A7QaHQrSq0AAvTIAAAAQAAvSLSq1IAAAAQLTq0P9AAIAAAAQP+AALSK0IAAAAQLTK1AAPSIAAAAQAAPTrTK0IAAAAQrSK1v+AAIAAAAQv9AArTq1g");
	var mask_34_graphics_163 = new cjs.Graphics().p("A7OaFQrRqzAAvSIAAAAQAAvRLRq0IAAAAQLTqzP7AAIAAAAQP8AALSKzIAAAAQLSK0AAPRIAAAAQAAPSrSKzIAAAAQrSK0v8AAIAAAAQv7AArTq0g");
	var mask_34_graphics_164 = new cjs.Graphics().p("A7LaDQrRqyAAvRIAAAAQAAvQLRqzIAAAAQLRqyP6AAIAAAAQP7AALRKyIAAAAQLRKzAAPQIAAAAQAAPRrRKyIAAAAQrRKzv7AAIAAAAQv6AArRqzg");
	var mask_34_graphics_165 = new cjs.Graphics().p("A7JaBQrQqyAAvPIAAAAQAAvOLQqyIAAAAQLQqyP5AAIAAAAQP6AALPKyIAAAAQLRKyAAPOIAAAAQAAPPrRKyIAAAAQrPKyv6AAIAAAAQv5AArQqyg");
	var mask_34_graphics_166 = new cjs.Graphics().p("A7HZ+QrOqwAAvOIAAAAQAAvNLOqxIAAAAQLQqxP3AAIAAAAQP4AALPKxIAAAAQLPKxAAPNIAAAAQAAPOrPKwIAAAAQrPKyv4AAIAAAAQv3AArQqyg");
	var mask_34_graphics_167 = new cjs.Graphics().p("A7EZ8QrOqvAAvNIAAAAQAAvMLOqwIAAAAQLOqwP2AAIAAAAQP3AALOKwIAAAAQLOKwAAPMIAAAAQAAPNrOKvIAAAAQrOKxv3AAIAAAAQv2AArOqxg");
	var mask_34_graphics_168 = new cjs.Graphics().p("A7CZ6QrNqvAAvLIAAAAQAAvKLNqwIAAAAQLNquP1AAIAAAAQP2AALMKuIAAAAQLOKwAAPKIAAAAQAAPLrOKvIAAAAQrMKvv2AAIAAAAQv1AArNqvg");
	var mask_34_graphics_169 = new cjs.Graphics().p("A7AZ3QrLqtAAvKIAAAAQAAvJLLquIAAAAQLNquPzAAIAAAAQP0AALMKuIAAAAQLMKuAAPJIAAAAQAAPKrMKtIAAAAQrMKvv0AAIAAAAQvzAArNqvg");
	var mask_34_graphics_170 = new cjs.Graphics().p("A69Z1QrKqtAAvIIAAAAQAAvHLKquIAAAAQLLqsPyAAIAAAAQPzAALKKsIAAAAQLLKuAAPHIAAAAQAAPIrLKtIAAAAQrKKtvzAAIAAAAQvyAArLqtg");
	var mask_34_graphics_171 = new cjs.Graphics().p("A66ZzQrKqsAAvHIAAAAQAAvGLKqsIAAAAQLKqsPwAAIAAAAQPxAALKKsIAAAAQLKKsAAPGIAAAAQAAPHrKKsIAAAAQrKKsvxAAIAAAAQvwAArKqsg");
	var mask_34_graphics_172 = new cjs.Graphics().p("A64ZwQrIqqAAvGIAAAAQAAvFLIqrIAAAAQLJqqPvAAIAAAAQPwAALIKqIAAAAQLJKrAAPFIAAAAQAAPGrJKqIAAAAQrIKrvwAAIAAAAQvvAArJqrg");
	var mask_34_graphics_173 = new cjs.Graphics().p("A61ZtQrHqpAAvEIAAAAQAAvDLHqqIAAAAQLIqqPtAAIAAAAQPuAALHKqIAAAAQLIKqAAPDIAAAAQAAPErIKpIAAAAQrHKrvuAAIAAAAQvtAArIqrg");
	var mask_34_graphics_174 = new cjs.Graphics().p("A6yZrQrGqpAAvCIAAAAQAAvBLGqqIAAAAQLHqoPrAAIAAAAQPsAALGKoIAAAAQLHKqAAPBIAAAAQAAPCrHKpIAAAAQrGKpvsAAIAAAAQvrAArHqpg");
	var mask_34_graphics_175 = new cjs.Graphics().p("A6vZoQrFqnAAvBIAAAAQAAvALFqoIAAAAQLFqnPqAAIAAAAQPrAALFKnIAAAAQLFKoAAPAIAAAAQAAPBrFKnIAAAAQrFKovrAAIAAAAQvqAArFqog");
	var mask_34_graphics_176 = new cjs.Graphics().p("A6sZlQrEqmAAu/IAAAAQAAu+LEqnIAAAAQLEqmPoAAIAAAAQPpAALEKmIAAAAQLEKnAAO+IAAAAQAAO/rEKmIAAAAQrEKnvpAAIAAAAQvoAArEqng");
	var mask_34_graphics_177 = new cjs.Graphics().p("A6qZiQrCqkAAu+IAAAAQAAu9LCqlIAAAAQLEqlPmAAIAAAAQPnAALDKlIAAAAQLDKlAAO9IAAAAQAAO+rDKkIAAAAQrDKmvnAAIAAAAQvmAArEqmg");
	var mask_34_graphics_178 = new cjs.Graphics().p("A6mZfQrCqjAAu8IAAAAQAAu7LCqkIAAAAQLBqkPlAAIAAAAQPmAALBKkIAAAAQLCKkAAO7IAAAAQAAO8rCKjIAAAAQrBKlvmAAIAAAAQvlAArBqlg");
	var mask_34_graphics_179 = new cjs.Graphics().p("A6jZdQrAqjAAu6IAAAAQAAu5LAqjIAAAAQLAqjPjAAIAAAAQPkAALAKjIAAAAQLAKjAAO5IAAAAQAAO6rAKjIAAAAQrAKjvkAAIAAAAQvjAArAqjg");
	var mask_34_graphics_180 = new cjs.Graphics().p("A6gZZQq/qhAAu4IAAAAQAAu3K/qiIAAAAQK/qhPhAAIAAAAQPiAAK+KhIAAAAQLAKiAAO3IAAAAQAAO4rAKhIAAAAQq+KiviAAIAAAAQvhAAq/qig");
	var mask_34_graphics_181 = new cjs.Graphics().p("A6dZWQq9qfAAu3IAAAAQAAu2K9qgIAAAAQK+qgPfAAIAAAAQPgAAK9KgIAAAAQK+KgAAO2IAAAAQAAO3q+KfIAAAAQq9KhvgAAIAAAAQvfAAq+qhg");
	var mask_34_graphics_182 = new cjs.Graphics().p("A6aZTQq8qeAAu1IAAAAQAAu0K8qfIAAAAQK9qfPdAAIAAAAQPeAAK8KfIAAAAQK9KfAAO0IAAAAQAAO1q9KeIAAAAQq8KgveAAIAAAAQvdAAq9qgg");
	var mask_34_graphics_183 = new cjs.Graphics().p("A6WZQQq7qdAAuzIAAAAQAAuyK7qeIAAAAQK7qdPbAAIAAAAQPcAAK7KdIAAAAQK7KeAAOyIAAAAQAAOzq7KdIAAAAQq7KevcAAIAAAAQvbAAq7qeg");
	var mask_34_graphics_184 = new cjs.Graphics().p("A6TZNQq5qcAAuxIAAAAQAAuwK5qdIAAAAQK6qcPZAAIAAAAQPaAAK5KcIAAAAQK6KdAAOwIAAAAQAAOxq6KcIAAAAQq5KdvaAAIAAAAQvZAAq6qdg");
	var mask_34_graphics_185 = new cjs.Graphics().p("A6QZKQq3qbAAuvIAAAAQAAuuK3qbIAAAAQK5qbPXAAIAAAAQPYAAK4KbIAAAAQK4KbAAOuIAAAAQAAOvq4KbIAAAAQq4KbvYAAIAAAAQvXAAq5qbg");
	var mask_34_graphics_186 = new cjs.Graphics().p("A6MZGQq2qZAAutIAAAAQAAusK2qaIAAAAQK3qZPVAAIAAAAQPWAAK2KZIAAAAQK3KaAAOsIAAAAQAAOtq3KZIAAAAQq2KavWAAIAAAAQvVAAq3qag");
	var mask_34_graphics_187 = new cjs.Graphics().p("A6IZDQq1qYAAurIAAAAQAAuqK1qZIAAAAQK1qXPTAAIAAAAQPUAAK1KXIAAAAQK1KZAAOqIAAAAQAAOrq1KYIAAAAQq1KYvUAAIAAAAQvTAAq1qYg");
	var mask_34_graphics_188 = new cjs.Graphics().p("A6FY/QqzqWAAupIAAAAQAAuoKzqXIAAAAQK0qWPRAAIAAAAQPSAAKzKWIAAAAQK0KXAAOoIAAAAQAAOpq0KWIAAAAQqzKXvSAAIAAAAQvRAAq0qXg");
	var mask_34_graphics_189 = new cjs.Graphics().p("A6BY8QqyqVAAunIAAAAQAAumKyqVIAAAAQKyqVPPAAIAAAAQPQAAKxKVIAAAAQKzKVAAOmIAAAAQAAOnqzKVIAAAAQqxKVvQAAIAAAAQvPAAqyqVg");
	var mask_34_graphics_190 = new cjs.Graphics().p("A59Y4QqwqTAAulIAAAAQAAukKwqUIAAAAQKxqTPMAAIAAAAQPNAAKxKTIAAAAQKwKUAAOkIAAAAQAAOlqwKTIAAAAQqxKUvNAAIAAAAQvMAAqxqUg");
	var mask_34_graphics_191 = new cjs.Graphics().p("A56Y0QquqRAAujIAAAAQAAuiKuqSIAAAAQKwqSPKAAIAAAAQPLAAKvKSIAAAAQKvKSAAOiIAAAAQAAOjqvKRIAAAAQqvKTvLAAIAAAAQvKAAqwqTg");
	var mask_34_graphics_192 = new cjs.Graphics().p("A52YxQqtqRAAugIAAAAQAAufKtqRIAAAAQKuqRPIAAIAAAAQPJAAKtKRIAAAAQKuKRAAOfIAAAAQAAOgquKRIAAAAQqtKRvJAAIAAAAQvIAAquqRg");
	var mask_34_graphics_193 = new cjs.Graphics().p("A5yYtQqrqPAAueIAAAAQAAudKrqQIAAAAQKsqOPGAAIAAAAQPHAAKrKOIAAAAQKsKQAAOdIAAAAQAAOeqsKPIAAAAQqrKPvHAAIAAAAQvGAAqsqPg");
	var mask_34_graphics_194 = new cjs.Graphics().p("A5uYpQqqqNAAucIAAAAQAAubKqqOIAAAAQKrqNPDAAIAAAAQPEAAKqKNIAAAAQKrKOAAObIAAAAQAAOcqrKNIAAAAQqqKOvEAAIAAAAQvDAAqrqOg");
	var mask_34_graphics_195 = new cjs.Graphics().p("A5qYmQqoqMAAuaIAAAAQAAuZKoqMIAAAAQKpqMPBAAIAAAAQPCAAKoKMIAAAAQKpKMAAOZIAAAAQAAOaqpKMIAAAAQqoKMvCAAIAAAAQvBAAqpqMg");
	var mask_34_graphics_196 = new cjs.Graphics().p("A5mYiQqnqKAAuYIAAAAQAAuXKnqLIAAAAQKnqKO/AAIAAAAQPAAAKnKKIAAAAQKnKLAAOXIAAAAQAAOYqnKKIAAAAQqnKLvAAAIAAAAQu/AAqnqLg");
	var mask_34_graphics_197 = new cjs.Graphics().p("A5jYfQqlqJAAuWIAAAAQAAuVKlqJIAAAAQKmqJO9AAIAAAAQO+AAKlKJIAAAAQKmKJAAOVIAAAAQAAOWqmKJIAAAAQqlKJu+AAIAAAAQu9AAqmqJg");
	var mask_34_graphics_198 = new cjs.Graphics().p("A5fYbQqkqHAAuUIAAAAQAAuTKkqIIAAAAQKkqHO7AAIAAAAQO8AAKjKHIAAAAQKlKIAAOTIAAAAQAAOUqlKHIAAAAQqjKIu8AAIAAAAQu7AAqkqIg");
	var mask_34_graphics_199 = new cjs.Graphics().p("A5cYYQqiqGAAuSIAAAAQAAuRKiqHIAAAAQKjqGO5AAIAAAAQO6AAKiKGIAAAAQKjKHAAORIAAAAQAAOSqjKGIAAAAQqiKHu6AAIAAAAQu5AAqjqHg");
	var mask_34_graphics_200 = new cjs.Graphics().p("A5YYVQqhqFAAuQIAAAAQAAuPKhqFIAAAAQKhqFO3AAIAAAAQO4AAKgKFIAAAAQKiKFAAOPIAAAAQAAOQqiKFIAAAAQqgKFu4AAIAAAAQu3AAqhqFg");
	var mask_34_graphics_201 = new cjs.Graphics().p("A5VYRQqfqDAAuOIAAAAQAAuNKfqEIAAAAQKgqDO1AAIAAAAQO2AAKfKDIAAAAQKgKEAAONIAAAAQAAOOqgKDIAAAAQqfKEu2AAIAAAAQu1AAqgqEg");
	var mask_34_graphics_202 = new cjs.Graphics().p("A5SYOQqdqCAAuMIAAAAQAAuLKdqDIAAAAQKfqCOzAAIAAAAQO0AAKeKCIAAAAQKeKDAAOLIAAAAQAAOMqeKCIAAAAQqeKDu0AAIAAAAQuzAAqfqDg");
	var mask_34_graphics_203 = new cjs.Graphics().p("A5OYLQqdqBAAuKIAAAAQAAuJKdqCIAAAAQKdqAOxAAIAAAAQOyAAKcKAIAAAAQKeKCAAOJIAAAAQAAOKqeKBIAAAAQqcKBuyAAIAAAAQuxAAqdqBg");
	var mask_34_graphics_204 = new cjs.Graphics().p("A5LYIQqbp/AAuJIAAAAQAAuHKbqBIAAAAQKcp/OvAAIAAAAQOwAAKbJ/IAAAAQKcKBAAOHIAAAAQAAOJqcJ/IAAAAQqbKAuwAAIAAAAQuvAAqcqAg");
	var mask_34_graphics_205 = new cjs.Graphics().p("A5IYFQqap+AAuHIAAAAQAAuGKap/IAAAAQKbp+OtAAIAAAAQOuAAKaJ+IAAAAQKbJ/AAOGIAAAAQAAOHqbJ+IAAAAQqaJ/uuAAIAAAAQutAAqbp/g");
	var mask_34_graphics_206 = new cjs.Graphics().p("A5FYCQqYp9AAuFIAAAAQAAuEKYp+IAAAAQKap9OrAAIAAAAQOsAAKZJ9IAAAAQKZJ+AAOEIAAAAQAAOFqZJ9IAAAAQqZJ+usAAIAAAAQurAAqap+g");
	var mask_34_graphics_207 = new cjs.Graphics().p("A5CX/QqXp8AAuDIAAAAQAAuCKXp9IAAAAQKYp7OqAAIAAAAQOrAAKXJ7IAAAAQKYJ9AAOCIAAAAQAAODqYJ8IAAAAQqXJ8urAAIAAAAQuqAAqYp8g");
	var mask_34_graphics_208 = new cjs.Graphics().p("A4/X8QqWp6AAuCIAAAAQAAuBKWp7IAAAAQKXp6OoAAIAAAAQOpAAKWJ6IAAAAQKXJ7AAOBIAAAAQAAOCqXJ6IAAAAQqWJ7upAAIAAAAQuoAAqXp7g");
	var mask_34_graphics_209 = new cjs.Graphics().p("A48X5QqVp5AAuAIAAAAQAAt/KVp6IAAAAQKWp5OmAAIAAAAQOnAAKVJ5IAAAAQKWJ6AAN/IAAAAQAAOAqWJ5IAAAAQqVJ6unAAIAAAAQumAAqWp6g");
	var mask_34_graphics_210 = new cjs.Graphics().p("A45X3QqUp5AAt+IAAAAQAAt9KUp5IAAAAQKVp5OkAAIAAAAQOlAAKUJ5IAAAAQKVJ5AAN9IAAAAQAAN+qVJ5IAAAAQqUJ5ulAAIAAAAQukAAqVp5g");
	var mask_34_graphics_211 = new cjs.Graphics().p("A42X0QqTp3AAt9IAAAAQAAt8KTp4IAAAAQKTp3OjAAIAAAAQOkAAKSJ3IAAAAQKUJ4AAN8IAAAAQAAN9qUJ3IAAAAQqSJ4ukAAIAAAAQujAAqTp4g");
	var mask_34_graphics_212 = new cjs.Graphics().p("A40XxQqRp2AAt7IAAAAQAAt6KRp3IAAAAQKTp2OhAAIAAAAQOiAAKSJ2IAAAAQKSJ3AAN6IAAAAQAAN7qSJ2IAAAAQqSJ3uiAAIAAAAQuhAAqTp3g");
	var mask_34_graphics_213 = new cjs.Graphics().p("A4xXvQqQp1AAt6IAAAAQAAt5KQp2IAAAAQKRp1OgAAIAAAAQOhAAKQJ1IAAAAQKRJ2AAN5IAAAAQAAN6qRJ1IAAAAQqQJ2uhAAIAAAAQugAAqRp2g");
	var mask_34_graphics_214 = new cjs.Graphics().p("A4uXsQqQp0AAt4IAAAAQAAt3KQp1IAAAAQKQp0OeAAIAAAAQOfAAKPJ0IAAAAQKRJ1AAN3IAAAAQAAN4qRJ0IAAAAQqPJ1ufAAIAAAAQueAAqQp1g");
	var mask_34_graphics_215 = new cjs.Graphics().p("A4sXqQqOpzAAt3IAAAAQAAt2KOp0IAAAAQKPpzOdAAIAAAAQOeAAKOJzIAAAAQKPJ0AAN2IAAAAQAAN3qPJzIAAAAQqOJ0ueAAIAAAAQudAAqPp0g");
	var mask_34_graphics_216 = new cjs.Graphics().p("A4pXoQqOpyAAt2IAAAAQAAt1KOpyIAAAAQKOpyObAAIAAAAQOcAAKNJyIAAAAQKPJyAAN1IAAAAQAAN2qPJyIAAAAQqNJyucAAIAAAAQubAAqOpyg");
	var mask_34_graphics_217 = new cjs.Graphics().p("A4nXlQqMpxAAt0IAAAAQAAtzKMpyIAAAAQKNpxOaAAIAAAAQObAAKMJxIAAAAQKNJyAANzIAAAAQAAN0qNJxIAAAAQqMJyubAAIAAAAQuaAAqNpyg");
	var mask_34_graphics_218 = new cjs.Graphics().p("A4kXjQqMpwAAtzIAAAAQAAtyKMpxIAAAAQKMpwOYAAIAAAAQOZAAKMJwIAAAAQKMJxAANyIAAAAQAANzqMJwIAAAAQqMJxuZAAIAAAAQuYAAqMpxg");
	var mask_34_graphics_219 = new cjs.Graphics().p("A4iXhQqLpvAAtyIAAAAQAAtxKLpvIAAAAQKLpwOXAAIAAAAQOYAAKKJwIAAAAQKMJvAANxIAAAAQAANyqMJvIAAAAQqKJwuYAAIAAAAQuXAAqLpwg");
	var mask_34_graphics_220 = new cjs.Graphics().p("A4gXfQqJpvAAtwIAAAAQAAtvKJpvIAAAAQKKpvOWAAIAAAAQOXAAKJJvIAAAAQKKJvAANvIAAAAQAANwqKJvIAAAAQqJJvuXAAIAAAAQuWAAqKpvg");
	var mask_34_graphics_221 = new cjs.Graphics().p("A4eXdQqIpuAAtvIAAAAQAAtuKIpuIAAAAQKKpuOUAAIAAAAQOVAAKJJuIAAAAQKJJuAANuIAAAAQAANvqJJuIAAAAQqJJuuVAAIAAAAQuUAAqKpug");
	var mask_34_graphics_222 = new cjs.Graphics().p("A4cXaQqHpsAAtuIAAAAQAAttKHptIAAAAQKJptOTAAIAAAAQOUAAKIJtIAAAAQKIJtAANtIAAAAQAANuqIJsIAAAAQqIJuuUAAIAAAAQuTAAqJpug");
	var mask_34_graphics_223 = new cjs.Graphics().p("A4aXZQqGpsAAttIAAAAQAAtsKGpsIAAAAQKIpsOSAAIAAAAQOTAAKHJsIAAAAQKHJsAANsIAAAAQAANtqHJsIAAAAQqHJsuTAAIAAAAQuSAAqIpsg");
	var mask_34_graphics_224 = new cjs.Graphics().p("A4YXXQqGprAAtsIAAAAQAAtrKGprIAAAAQKHprORAAIAAAAQOSAAKGJrIAAAAQKHJrAANrIAAAAQAANsqHJrIAAAAQqGJruSAAIAAAAQuRAAqHprg");
	var mask_34_graphics_225 = new cjs.Graphics().p("A4WXVQqFpqAAtrIAAAAQAAtqKFprIAAAAQKGpqOQAAIAAAAQORAAKFJqIAAAAQKGJrAANqIAAAAQAANrqGJqIAAAAQqFJruRAAIAAAAQuQAAqGprg");
	var mask_34_graphics_226 = new cjs.Graphics().p("A4UXTQqEppAAtqIAAAAQAAtpKEpqIAAAAQKFppOPAAIAAAAQOQAAKEJpIAAAAQKFJqAANpIAAAAQAANqqFJpIAAAAQqEJquQAAIAAAAQuPAAqFpqg");
	var mask_34_graphics_227 = new cjs.Graphics().p("A4SXRQqEpoAAtpIAAAAQAAtoKEppIAAAAQKEppOOAAIAAAAQOPAAKDJpIAAAAQKFJpAANoIAAAAQAANpqFJoIAAAAQqDJquPAAIAAAAQuOAAqEpqg");
	var mask_34_graphics_228 = new cjs.Graphics().p("A4QXQQqDpoAAtoIAAAAQAAtnKDpoIAAAAQKDpoONAAIAAAAQOOAAKCJoIAAAAQKEJoAANnIAAAAQAANoqEJoIAAAAQqCJouOAAIAAAAQuNAAqDpog");
	var mask_34_graphics_229 = new cjs.Graphics().p("A4PXOQqCpnAAtnIAAAAQAAtmKCpoIAAAAQKDpnOMAAIAAAAQONAAKCJnIAAAAQKDJoAANmIAAAAQAANnqDJnIAAAAQqCJouNAAIAAAAQuMAAqDpog");
	var mask_34_graphics_230 = new cjs.Graphics().p("A4NXMQqCpmAAtmIAAAAQAAtlKCpnIAAAAQKCpnOLAAIAAAAQOMAAKBJnIAAAAQKDJnAANlIAAAAQAANmqDJmIAAAAQqBJouMAAIAAAAQuLAAqCpog");
	var mask_34_graphics_231 = new cjs.Graphics().p("A4LXLQqBpmAAtlIAAAAQAAtkKBpnIAAAAQKBpmOKAAIAAAAQOLAAKBJmIAAAAQKBJnAANkIAAAAQAANlqBJmIAAAAQqBJnuLAAIAAAAQuKAAqBpng");
	var mask_34_graphics_232 = new cjs.Graphics().p("A4KXJQqAplAAtkIAAAAQAAtjKApmIAAAAQKBpmOJAAIAAAAQOKAAKAJmIAAAAQKBJmAANjIAAAAQAANkqBJlIAAAAQqAJnuKAAIAAAAQuJAAqBpng");
	var mask_34_graphics_233 = new cjs.Graphics().p("A4IXIQqAplAAtjIAAAAQAAtiKApmIAAAAQKAplOIAAIAAAAQOJAAKAJlIAAAAQKAJmAANiIAAAAQAANjqAJlIAAAAQqAJmuJAAIAAAAQuIAAqApmg");
	var mask_34_graphics_234 = new cjs.Graphics().p("A4HXHQp/plAAtiIAAAAQAAthJ/pmIAAAAQKApkOHAAIAAAAQOIAAJ/JkIAAAAQKAJmAANhIAAAAQAANiqAJlIAAAAQp/JluIAAIAAAAQuHAAqAplg");
	var mask_34_graphics_235 = new cjs.Graphics().p("A4GXGQp+pkAAtiIAAAAQAAthJ+pkIAAAAQKApkOGAAIAAAAQOHAAJ/JkIAAAAQJ/JkAANhIAAAAQAANip/JkIAAAAQp/JkuHAAIAAAAQuGAAqApkg");
	var mask_34_graphics_236 = new cjs.Graphics().p("A4EXEQp/pjAAthIAAAAQAAtgJ/pkIAAAAQJ+pjOGAAIAAAAQOHAAJ+JjIAAAAQJ/JkAANgIAAAAQAANhp/JjIAAAAQp+JkuHAAIAAAAQuGAAp+pkg");
	var mask_34_graphics_237 = new cjs.Graphics().p("A4DXDQp+pjAAtgIAAAAQAAtfJ+pkIAAAAQJ+pjOFAAIAAAAQOGAAJ+JjIAAAAQJ+JkAANfIAAAAQAANgp+JjIAAAAQp+JkuGAAIAAAAQuFAAp+pkg");
	var mask_34_graphics_238 = new cjs.Graphics().p("A4CXCQp9piAAtgIAAAAQAAtfJ9pjIAAAAQJ+piOEAAIAAAAQOFAAJ9JiIAAAAQJ+JjAANfIAAAAQAANgp+JiIAAAAQp9JjuFAAIAAAAQuEAAp+pjg");
	var mask_34_graphics_239 = new cjs.Graphics().p("A4BXBQp9piAAtfIAAAAQAAteJ9pjIAAAAQJ9piOEAAIAAAAQOFAAJ8JiIAAAAQJ+JjAANeIAAAAQAANfp+JiIAAAAQp8JjuFAAIAAAAQuEAAp9pjg");
	var mask_34_graphics_240 = new cjs.Graphics().p("A4AXAQp8piAAteIAAAAQAAtdJ8pjIAAAAQJ9phODAAIAAAAQOEAAJ8JhIAAAAQJ9JjAANdIAAAAQAANep9JiIAAAAQp8JiuEAAIAAAAQuDAAp9pig");
	var mask_34_graphics_241 = new cjs.Graphics().p("A3/W/Qp8phAAteIAAAAQAAtdJ8piIAAAAQJ8phODAAIAAAAQOEAAJ7JhIAAAAQJ9JiAANdIAAAAQAANep9JhIAAAAQp7JiuEAAIAAAAQuDAAp8pig");
	var mask_34_graphics_242 = new cjs.Graphics().p("A3+W+Qp8phAAtdIAAAAQAAtcJ8piIAAAAQJ8phOCAAIAAAAQODAAJ7JhIAAAAQJ9JiAANcIAAAAQAANdp9JhIAAAAQp7JiuDAAIAAAAQuCAAp8pig");
	var mask_34_graphics_243 = new cjs.Graphics().p("A39W+Qp8phAAtdIAAAAQAAtcJ8phIAAAAQJ7phOCAAIAAAAQODAAJ7JhIAAAAQJ8JhAANcIAAAAQAANdp8JhIAAAAQp7JhuDAAIAAAAQuCAAp7phg");
	var mask_34_graphics_244 = new cjs.Graphics().p("A39W9Qp6pgAAtdIAAAAQAAtcJ6phIAAAAQJ8pgOBAAIAAAAQOCAAJ7JgIAAAAQJ7JhAANcIAAAAQAANdp7JgIAAAAQp7JhuCAAIAAAAQuBAAp8phg");
	var mask_34_graphics_245 = new cjs.Graphics().p("A38W8Qp6pgAAtcIAAAAQAAtbJ6phIAAAAQJ7pgOBAAIAAAAQOCAAJ6JgIAAAAQJ7JhAANbIAAAAQAANcp7JgIAAAAQp6JhuCAAIAAAAQuBAAp7phg");
	var mask_34_graphics_246 = new cjs.Graphics().p("A37W8Qp7pgAAtcIAAAAQAAtbJ7pgIAAAAQJ7pgOAAAIAAAAQOBAAJ7JgIAAAAQJ7JgAANbIAAAAQAANcp7JgIAAAAQp7JguBAAIAAAAQuAAAp7pgg");
	var mask_34_graphics_247 = new cjs.Graphics().p("A37W7Qp6pgAAtbIAAAAQAAtaJ6phIAAAAQJ7pfOAAAIAAAAQOBAAJ6JfIAAAAQJ7JhAANaIAAAAQAANbp7JgIAAAAQp6JguBAAIAAAAQuAAAp7pgg");
	var mask_34_graphics_248 = new cjs.Graphics().p("A36W6Qp6pfAAtbIAAAAQAAtaJ6pgIAAAAQJ6pgOAAAIAAAAQOBAAJ5JgIAAAAQJ7JgAANaIAAAAQAANbp7JfIAAAAQp5JhuBAAIAAAAQuAAAp6phg");
	var mask_34_graphics_249 = new cjs.Graphics().p("A36W6Qp5pfAAtbIAAAAQAAtaJ5pgIAAAAQJ7pfN/AAIAAAAQOAAAJ6JfIAAAAQJ6JgAANaIAAAAQAANbp6JfIAAAAQp6JguAAAIAAAAQt/AAp7pgg");
	var mask_34_graphics_250 = new cjs.Graphics().p("A35W6Qp6pfAAtbIAAAAQAAtaJ6pfIAAAAQJ6pfN/AAIAAAAQOAAAJ6JfIAAAAQJ6JfAANaIAAAAQAANbp6JfIAAAAQp6JfuAAAIAAAAQt/AAp6pfg");
	var mask_34_graphics_251 = new cjs.Graphics().p("A35W5Qp5pfAAtaIAAAAQAAtZJ5pgIAAAAQJ6pfN/AAIAAAAQOAAAJ5JfIAAAAQJ6JgAANZIAAAAQAANap6JfIAAAAQp5JguAAAIAAAAQt/AAp6pgg");
	var mask_34_graphics_252 = new cjs.Graphics().p("A35W5Qp5pfAAtaIAAAAQAAtZJ5pgIAAAAQJ6pfN/AAIAAAAQOAAAJ5JfIAAAAQJ6JgAANZIAAAAQAANap6JfIAAAAQp5JguAAAIAAAAQt/AAp6pgg");
	var mask_34_graphics_253 = new cjs.Graphics().p("A35W5Qp5pfAAtaIAAAAQAAtZJ5pgIAAAAQJ6peN/AAIAAAAQOAAAJ5JeIAAAAQJ6JgAANZIAAAAQAANap6JfIAAAAQp5JfuAAAIAAAAQt/AAp6pfg");
	var mask_34_graphics_254 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ5pfN/AAIAAAAQOAAAJ5JfIAAAAQJ5JfAANZIAAAAQAANap5JfIAAAAQp5JfuAAAIAAAAQt/AAp5pfg");
	var mask_34_graphics_255 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ5pfN/AAIAAAAQOAAAJ5JfIAAAAQJ5JfAANZIAAAAQAANap5JfIAAAAQp5JfuAAAIAAAAQt/AAp5pfg");
	var mask_34_graphics_256 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_257 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_258 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_259 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_260 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_261 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_262 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_263 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_264 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_265 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_266 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_267 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_268 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_269 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_270 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_271 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_272 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_273 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_274 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_275 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_276 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_277 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_278 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_279 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_280 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_281 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_282 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_283 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_284 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_285 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_286 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_287 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_288 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_289 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_290 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_291 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_292 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_293 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_294 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_295 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_296 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_297 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_298 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_299 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_300 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_301 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_302 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_303 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_304 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_305 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_306 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_307 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_308 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_309 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_310 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_311 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_312 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_313 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_314 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_315 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_316 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_317 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_318 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_319 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_320 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_321 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_322 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_323 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_324 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_325 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_326 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_327 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_328 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_329 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_330 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_331 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_332 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_333 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_334 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_335 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_336 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_337 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_338 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_339 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_340 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_341 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_342 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_343 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_344 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_345 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_346 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_347 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_348 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_349 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_350 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_351 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_352 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_353 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_354 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_355 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_356 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_357 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_358 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_359 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_360 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_361 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_362 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_363 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_364 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_365 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_366 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_367 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_368 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_369 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_370 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_371 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_372 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_373 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_374 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_375 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_376 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_377 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_378 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_379 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_380 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_381 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_382 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");
	var mask_34_graphics_383 = new cjs.Graphics().p("A34W5Qp5pfAAtaIAAAAQAAtZJ5pfIAAAAQJ6pfN+AAIAAAAQN/AAJ5JfIAAAAQJ6JfAANZIAAAAQAANap6JfIAAAAQp5Jft/AAIAAAAQt+AAp6pfg");

	this.timeline.addTween(cjs.Tween.get(mask_34).to({graphics:null,x:0,y:0}).wait(20).to({graphics:mask_34_graphics_20,x:472.0009,y:517.8001}).wait(1).to({graphics:mask_34_graphics_21,x:471.9829,y:517.8001}).wait(1).to({graphics:mask_34_graphics_22,x:471.9312,y:517.8015}).wait(1).to({graphics:mask_34_graphics_23,x:471.8443,y:517.8024}).wait(1).to({graphics:mask_34_graphics_24,x:471.7233,y:517.8042}).wait(1).to({graphics:mask_34_graphics_25,x:471.5671,y:517.806}).wait(1).to({graphics:mask_34_graphics_26,x:471.3763,y:517.8087}).wait(1).to({graphics:mask_34_graphics_27,x:471.1514,y:517.8114}).wait(1).to({graphics:mask_34_graphics_28,x:470.8913,y:517.8145}).wait(1).to({graphics:mask_34_graphics_29,x:470.5965,y:517.8186}).wait(1).to({graphics:mask_34_graphics_30,x:470.2666,y:517.8231}).wait(1).to({graphics:mask_34_graphics_31,x:469.903,y:517.828}).wait(1).to({graphics:mask_34_graphics_32,x:469.5043,y:517.833}).wait(1).to({graphics:mask_34_graphics_33,x:469.0706,y:517.8393}).wait(1).to({graphics:mask_34_graphics_34,x:468.603,y:517.8452}).wait(1).to({graphics:mask_34_graphics_35,x:468.0999,y:517.8519}).wait(1).to({graphics:mask_34_graphics_36,x:467.5626,y:517.8586}).wait(1).to({graphics:mask_34_graphics_37,x:466.9906,y:517.8663}).wait(1).to({graphics:mask_34_graphics_38,x:466.3836,y:517.8739}).wait(1).to({graphics:mask_34_graphics_39,x:465.7419,y:517.8829}).wait(1).to({graphics:mask_34_graphics_40,x:465.066,y:517.8919}).wait(1).to({graphics:mask_34_graphics_41,x:464.355,y:517.9014}).wait(1).to({graphics:mask_34_graphics_42,x:463.6098,y:517.9109}).wait(1).to({graphics:mask_34_graphics_43,x:462.8295,y:517.9212}).wait(1).to({graphics:mask_34_graphics_44,x:462.0146,y:517.932}).wait(1).to({graphics:mask_34_graphics_45,x:461.1654,y:517.9428}).wait(1).to({graphics:mask_34_graphics_46,x:460.2811,y:517.9545}).wait(1).to({graphics:mask_34_graphics_47,x:459.3622,y:517.9666}).wait(1).to({graphics:mask_34_graphics_48,x:458.4087,y:517.9797}).wait(1).to({graphics:mask_34_graphics_49,x:457.4205,y:517.9923}).wait(1).to({graphics:mask_34_graphics_50,x:456.3976,y:518.0058}).wait(1).to({graphics:mask_34_graphics_51,x:455.3406,y:518.0202}).wait(1).to({graphics:mask_34_graphics_52,x:454.2485,y:518.0346}).wait(1).to({graphics:mask_34_graphics_53,x:453.1212,y:518.049}).wait(1).to({graphics:mask_34_graphics_54,x:451.9597,y:518.0643}).wait(1).to({graphics:mask_34_graphics_55,x:450.7632,y:518.08}).wait(1).to({graphics:mask_34_graphics_56,x:449.5324,y:518.0967}).wait(1).to({graphics:mask_34_graphics_57,x:448.267,y:518.1134}).wait(1).to({graphics:mask_34_graphics_58,x:446.967,y:518.13}).wait(1).to({graphics:mask_34_graphics_59,x:445.6318,y:518.1475}).wait(1).to({graphics:mask_34_graphics_60,x:444.262,y:518.166}).wait(1).to({graphics:mask_34_graphics_61,x:442.858,y:518.1844}).wait(1).to({graphics:mask_34_graphics_62,x:441.4189,y:518.2033}).wait(1).to({graphics:mask_34_graphics_63,x:439.9456,y:518.2227}).wait(1).to({graphics:mask_34_graphics_64,x:438.4377,y:518.2425}).wait(1).to({graphics:mask_34_graphics_65,x:436.8942,y:518.2632}).wait(1).to({graphics:mask_34_graphics_66,x:435.3169,y:518.2834}).wait(1).to({graphics:mask_34_graphics_67,x:433.7046,y:518.3046}).wait(1).to({graphics:mask_34_graphics_68,x:432.0576,y:518.3266}).wait(1).to({graphics:mask_34_graphics_69,x:430.3759,y:518.3487}).wait(1).to({graphics:mask_34_graphics_70,x:428.6596,y:518.3712}).wait(1).to({graphics:mask_34_graphics_71,x:426.9087,y:518.3946}).wait(1).to({graphics:mask_34_graphics_72,x:425.1226,y:518.418}).wait(1).to({graphics:mask_34_graphics_73,x:423.3028,y:518.4418}).wait(1).to({graphics:mask_34_graphics_74,x:421.4475,y:518.4661}).wait(1).to({graphics:mask_34_graphics_75,x:419.5926,y:518.4909}).wait(1).to({graphics:mask_34_graphics_76,x:417.7724,y:518.5152}).wait(1).to({graphics:mask_34_graphics_77,x:415.9867,y:518.5386}).wait(1).to({graphics:mask_34_graphics_78,x:414.2358,y:518.5615}).wait(1).to({graphics:mask_34_graphics_79,x:412.5195,y:518.584}).wait(1).to({graphics:mask_34_graphics_80,x:410.8378,y:518.6061}).wait(1).to({graphics:mask_34_graphics_81,x:409.1908,y:518.6281}).wait(1).to({graphics:mask_34_graphics_82,x:407.5785,y:518.6493}).wait(1).to({graphics:mask_34_graphics_83,x:406.0012,y:518.67}).wait(1).to({graphics:mask_34_graphics_84,x:404.4577,y:518.6902}).wait(1).to({graphics:mask_34_graphics_85,x:402.9498,y:518.7105}).wait(1).to({graphics:mask_34_graphics_86,x:401.4765,y:518.7299}).wait(1).to({graphics:mask_34_graphics_87,x:400.0369,y:518.7487}).wait(1).to({graphics:mask_34_graphics_88,x:398.6329,y:518.7672}).wait(1).to({graphics:mask_34_graphics_89,x:397.2636,y:518.7852}).wait(1).to({graphics:mask_34_graphics_90,x:395.9284,y:518.8027}).wait(1).to({graphics:mask_34_graphics_91,x:394.6279,y:518.8198}).wait(1).to({graphics:mask_34_graphics_92,x:393.3626,y:518.8365}).wait(1).to({graphics:mask_34_graphics_93,x:392.1313,y:518.8531}).wait(1).to({graphics:mask_34_graphics_94,x:390.9352,y:518.8684}).wait(1).to({graphics:mask_34_graphics_95,x:389.7738,y:518.8842}).wait(1).to({graphics:mask_34_graphics_96,x:388.647,y:518.8986}).wait(1).to({graphics:mask_34_graphics_97,x:387.5548,y:518.913}).wait(1).to({graphics:mask_34_graphics_98,x:386.4978,y:518.9269}).wait(1).to({graphics:mask_34_graphics_99,x:385.4745,y:518.9404}).wait(1).to({graphics:mask_34_graphics_100,x:384.4863,y:518.9535}).wait(1).to({graphics:mask_34_graphics_101,x:383.5328,y:518.9661}).wait(1).to({graphics:mask_34_graphics_102,x:382.6143,y:518.9783}).wait(1).to({graphics:mask_34_graphics_103,x:381.73,y:518.99}).wait(1).to({graphics:mask_34_graphics_104,x:380.8804,y:519.0012}).wait(1).to({graphics:mask_34_graphics_105,x:380.0659,y:519.0115}).wait(1).to({graphics:mask_34_graphics_106,x:379.2856,y:519.0223}).wait(1).to({graphics:mask_34_graphics_107,x:378.54,y:519.0318}).wait(1).to({graphics:mask_34_graphics_108,x:377.8294,y:519.0412}).wait(1).to({graphics:mask_34_graphics_109,x:377.1531,y:519.0498}).wait(1).to({graphics:mask_34_graphics_110,x:376.5118,y:519.0588}).wait(1).to({graphics:mask_34_graphics_111,x:375.9048,y:519.0664}).wait(1).to({graphics:mask_34_graphics_112,x:375.3328,y:519.0745}).wait(1).to({graphics:mask_34_graphics_113,x:374.7955,y:519.0813}).wait(1).to({graphics:mask_34_graphics_114,x:374.2924,y:519.0876}).wait(1).to({graphics:mask_34_graphics_115,x:373.8249,y:519.0939}).wait(1).to({graphics:mask_34_graphics_116,x:373.3911,y:519.0997}).wait(1).to({graphics:mask_34_graphics_117,x:372.9924,y:519.1051}).wait(1).to({graphics:mask_34_graphics_118,x:372.6283,y:519.1101}).wait(1).to({graphics:mask_34_graphics_119,x:372.2989,y:519.1142}).wait(1).to({graphics:mask_34_graphics_120,x:372.0042,y:519.1182}).wait(1).to({graphics:mask_34_graphics_121,x:371.7441,y:519.1214}).wait(1).to({graphics:mask_34_graphics_122,x:371.5186,y:519.1245}).wait(1).to({graphics:mask_34_graphics_123,x:371.3283,y:519.1272}).wait(1).to({graphics:mask_34_graphics_124,x:371.1721,y:519.129}).wait(1).to({graphics:mask_34_graphics_125,x:371.0506,y:519.1304}).wait(1).to({graphics:mask_34_graphics_126,x:370.9638,y:519.1317}).wait(1).to({graphics:mask_34_graphics_127,x:370.9121,y:519.1326}).wait(1).to({graphics:mask_34_graphics_128,x:370.575,y:518.8127}).wait(1).to({graphics:mask_34_graphics_129,x:370.5876,y:518.8126}).wait(1).to({graphics:mask_34_graphics_130,x:370.6254,y:518.8122}).wait(1).to({graphics:mask_34_graphics_131,x:370.6884,y:518.8113}).wait(1).to({graphics:mask_34_graphics_132,x:370.7766,y:518.8099}).wait(1).to({graphics:mask_34_graphics_133,x:370.89,y:518.8086}).wait(1).to({graphics:mask_34_graphics_134,x:371.0286,y:518.8072}).wait(1).to({graphics:mask_34_graphics_135,x:371.1928,y:518.805}).wait(1).to({graphics:mask_34_graphics_136,x:371.3818,y:518.8027}).wait(1).to({graphics:mask_34_graphics_137,x:371.5961,y:518.8}).wait(1).to({graphics:mask_34_graphics_138,x:371.8359,y:518.7973}).wait(1).to({graphics:mask_34_graphics_139,x:372.1005,y:518.7937}).wait(1).to({graphics:mask_34_graphics_140,x:372.3907,y:518.7901}).wait(1).to({graphics:mask_34_graphics_141,x:372.7058,y:518.7865}).wait(1).to({graphics:mask_34_graphics_142,x:373.0459,y:518.782}).wait(1).to({graphics:mask_34_graphics_143,x:373.4118,y:518.7775}).wait(1).to({graphics:mask_34_graphics_144,x:373.8024,y:518.773}).wait(1).to({graphics:mask_34_graphics_145,x:374.2187,y:518.7676}).wait(1).to({graphics:mask_34_graphics_146,x:374.6601,y:518.7623}).wait(1).to({graphics:mask_34_graphics_147,x:375.1263,y:518.7569}).wait(1).to({graphics:mask_34_graphics_148,x:375.6181,y:518.7505}).wait(1).to({graphics:mask_34_graphics_149,x:376.1352,y:518.7438}).wait(1).to({graphics:mask_34_graphics_150,x:376.6774,y:518.7371}).wait(1).to({graphics:mask_34_graphics_151,x:377.2449,y:518.7303}).wait(1).to({graphics:mask_34_graphics_152,x:377.8375,y:518.7231}).wait(1).to({graphics:mask_34_graphics_153,x:378.4554,y:518.715}).wait(1).to({graphics:mask_34_graphics_154,x:379.098,y:518.7073}).wait(1).to({graphics:mask_34_graphics_155,x:379.7667,y:518.6992}).wait(1).to({graphics:mask_34_graphics_156,x:380.4601,y:518.6907}).wait(1).to({graphics:mask_34_graphics_157,x:381.1788,y:518.6817}).wait(1).to({graphics:mask_34_graphics_158,x:381.9227,y:518.6723}).wait(1).to({graphics:mask_34_graphics_159,x:382.6917,y:518.6633}).wait(1).to({graphics:mask_34_graphics_160,x:383.4859,y:518.6529}).wait(1).to({graphics:mask_34_graphics_161,x:384.3058,y:518.643}).wait(1).to({graphics:mask_34_graphics_162,x:385.1505,y:518.6322}).wait(1).to({graphics:mask_34_graphics_163,x:386.0203,y:518.6218}).wait(1).to({graphics:mask_34_graphics_164,x:386.9154,y:518.6106}).wait(1).to({graphics:mask_34_graphics_165,x:387.8361,y:518.5993}).wait(1).to({graphics:mask_34_graphics_166,x:388.7815,y:518.5876}).wait(1).to({graphics:mask_34_graphics_167,x:389.7522,y:518.5755}).wait(1).to({graphics:mask_34_graphics_168,x:390.7485,y:518.5633}).wait(1).to({graphics:mask_34_graphics_169,x:391.77,y:518.5507}).wait(1).to({graphics:mask_34_graphics_170,x:392.8167,y:518.5377}).wait(1).to({graphics:mask_34_graphics_171,x:393.8882,y:518.5246}).wait(1).to({graphics:mask_34_graphics_172,x:394.9853,y:518.5112}).wait(1).to({graphics:mask_34_graphics_173,x:396.1071,y:518.4972}).wait(1).to({graphics:mask_34_graphics_174,x:397.255,y:518.4828}).wait(1).to({graphics:mask_34_graphics_175,x:398.4273,y:518.4689}).wait(1).to({graphics:mask_34_graphics_176,x:399.6252,y:518.4535}).wait(1).to({graphics:mask_34_graphics_177,x:400.8483,y:518.4382}).wait(1).to({graphics:mask_34_graphics_178,x:402.0966,y:518.4229}).wait(1).to({graphics:mask_34_graphics_179,x:403.3701,y:518.4072}).wait(1).to({graphics:mask_34_graphics_180,x:404.6683,y:518.3914}).wait(1).to({graphics:mask_34_graphics_181,x:405.9922,y:518.3752}).wait(1).to({graphics:mask_34_graphics_182,x:407.3418,y:518.3582}).wait(1).to({graphics:mask_34_graphics_183,x:408.7161,y:518.3415}).wait(1).to({graphics:mask_34_graphics_184,x:410.1156,y:518.3239}).wait(1).to({graphics:mask_34_graphics_185,x:411.5408,y:518.3064}).wait(1).to({graphics:mask_34_graphics_186,x:412.9906,y:518.2884}).wait(1).to({graphics:mask_34_graphics_187,x:414.4658,y:518.2704}).wait(1).to({graphics:mask_34_graphics_188,x:415.966,y:518.252}).wait(1).to({graphics:mask_34_graphics_189,x:417.4915,y:518.233}).wait(1).to({graphics:mask_34_graphics_190,x:419.0427,y:518.2137}).wait(1).to({graphics:mask_34_graphics_191,x:420.6186,y:518.1944}).wait(1).to({graphics:mask_34_graphics_192,x:422.2197,y:518.1745}).wait(1).to({graphics:mask_34_graphics_193,x:423.8212,y:518.1547}).wait(1).to({graphics:mask_34_graphics_194,x:425.3976,y:518.1349}).wait(1).to({graphics:mask_34_graphics_195,x:426.9483,y:518.116}).wait(1).to({graphics:mask_34_graphics_196,x:428.4742,y:518.0971}).wait(1).to({graphics:mask_34_graphics_197,x:429.9741,y:518.0782}).wait(1).to({graphics:mask_34_graphics_198,x:431.4496,y:518.0602}).wait(1).to({graphics:mask_34_graphics_199,x:432.8996,y:518.0422}).wait(1).to({graphics:mask_34_graphics_200,x:434.3242,y:518.0251}).wait(1).to({graphics:mask_34_graphics_201,x:435.7242,y:518.0076}).wait(1).to({graphics:mask_34_graphics_202,x:437.0985,y:517.9905}).wait(1).to({graphics:mask_34_graphics_203,x:438.4476,y:517.9738}).wait(1).to({graphics:mask_34_graphics_204,x:439.771,y:517.9572}).wait(1).to({graphics:mask_34_graphics_205,x:441.0702,y:517.9414}).wait(1).to({graphics:mask_34_graphics_206,x:442.3437,y:517.9257}).wait(1).to({graphics:mask_34_graphics_207,x:443.592,y:517.9099}).wait(1).to({graphics:mask_34_graphics_208,x:444.8146,y:517.8956}).wait(1).to({graphics:mask_34_graphics_209,x:446.0126,y:517.8802}).wait(1).to({graphics:mask_34_graphics_210,x:447.1852,y:517.8658}).wait(1).to({graphics:mask_34_graphics_211,x:448.3327,y:517.8519}).wait(1).to({graphics:mask_34_graphics_212,x:449.4551,y:517.8379}).wait(1).to({graphics:mask_34_graphics_213,x:450.5517,y:517.8244}).wait(1).to({graphics:mask_34_graphics_214,x:451.6231,y:517.811}).wait(1).to({graphics:mask_34_graphics_215,x:452.6698,y:517.7984}).wait(1).to({graphics:mask_34_graphics_216,x:453.6913,y:517.7853}).wait(1).to({graphics:mask_34_graphics_217,x:454.6872,y:517.7731}).wait(1).to({graphics:mask_34_graphics_218,x:455.6578,y:517.7614}).wait(1).to({graphics:mask_34_graphics_219,x:456.6038,y:517.7493}).wait(1).to({graphics:mask_34_graphics_220,x:457.5245,y:517.738}).wait(1).to({graphics:mask_34_graphics_221,x:458.4195,y:517.7268}).wait(1).to({graphics:mask_34_graphics_222,x:459.2893,y:517.7164}).wait(1).to({graphics:mask_34_graphics_223,x:460.134,y:517.7056}).wait(1).to({graphics:mask_34_graphics_224,x:460.9534,y:517.6953}).wait(1).to({graphics:mask_34_graphics_225,x:461.7482,y:517.6858}).wait(1).to({graphics:mask_34_graphics_226,x:462.5172,y:517.6759}).wait(1).to({graphics:mask_34_graphics_227,x:463.261,y:517.667}).wait(1).to({graphics:mask_34_graphics_228,x:463.9801,y:517.6584}).wait(1).to({graphics:mask_34_graphics_229,x:464.6736,y:517.6499}).wait(1).to({graphics:mask_34_graphics_230,x:465.3414,y:517.6413}).wait(1).to({graphics:mask_34_graphics_231,x:465.9844,y:517.6336}).wait(1).to({graphics:mask_34_graphics_232,x:466.6023,y:517.6255}).wait(1).to({graphics:mask_34_graphics_233,x:467.1954,y:517.6188}).wait(1).to({graphics:mask_34_graphics_234,x:467.7628,y:517.6111}).wait(1).to({graphics:mask_34_graphics_235,x:468.3047,y:517.6048}).wait(1).to({graphics:mask_34_graphics_236,x:468.8217,y:517.5985}).wait(1).to({graphics:mask_34_graphics_237,x:469.3131,y:517.5922}).wait(1).to({graphics:mask_34_graphics_238,x:469.7802,y:517.5864}).wait(1).to({graphics:mask_34_graphics_239,x:470.2212,y:517.581}).wait(1).to({graphics:mask_34_graphics_240,x:470.637,y:517.576}).wait(1).to({graphics:mask_34_graphics_241,x:471.0285,y:517.5711}).wait(1).to({graphics:mask_34_graphics_242,x:471.3939,y:517.5666}).wait(1).to({graphics:mask_34_graphics_243,x:471.7346,y:517.5625}).wait(1).to({graphics:mask_34_graphics_244,x:472.0495,y:517.5585}).wait(1).to({graphics:mask_34_graphics_245,x:472.3394,y:517.5549}).wait(1).to({graphics:mask_34_graphics_246,x:472.6044,y:517.5517}).wait(1).to({graphics:mask_34_graphics_247,x:472.8438,y:517.549}).wait(1).to({graphics:mask_34_graphics_248,x:473.0584,y:517.5459}).wait(1).to({graphics:mask_34_graphics_249,x:473.2474,y:517.5436}).wait(1).to({graphics:mask_34_graphics_250,x:473.4113,y:517.5414}).wait(1).to({graphics:mask_34_graphics_251,x:473.5503,y:517.54}).wait(1).to({graphics:mask_34_graphics_252,x:473.6632,y:517.5387}).wait(1).to({graphics:mask_34_graphics_253,x:473.7519,y:517.5374}).wait(1).to({graphics:mask_34_graphics_254,x:473.8149,y:517.5365}).wait(1).to({graphics:mask_34_graphics_255,x:473.8522,y:517.5364}).wait(1).to({graphics:mask_34_graphics_256,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_257,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_258,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_259,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_260,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_261,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_262,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_263,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_264,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_265,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_266,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_267,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_268,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_269,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_270,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_271,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_272,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_273,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_274,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_275,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_276,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_277,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_278,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_279,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_280,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_281,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_282,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_283,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_284,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_285,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_286,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_287,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_288,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_289,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_290,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_291,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_292,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_293,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_294,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_295,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_296,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_297,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_298,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_299,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_300,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_301,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_302,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_303,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_304,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_305,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_306,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_307,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_308,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_309,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_310,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_311,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_312,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_313,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_314,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_315,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_316,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_317,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_318,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_319,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_320,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_321,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_322,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_323,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_324,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_325,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_326,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_327,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_328,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_329,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_330,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_331,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_332,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_333,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_334,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_335,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_336,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_337,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_338,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_339,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_340,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_341,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_342,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_343,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_344,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_345,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_346,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_347,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_348,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_349,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_350,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_351,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_352,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_353,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_354,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_355,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_356,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_357,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_358,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_359,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_360,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_361,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_362,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_363,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_364,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_365,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_366,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_367,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_368,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_369,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_370,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_371,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_372,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_373,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_374,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_375,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_376,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_377,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_378,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_379,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_380,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_381,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_382,x:474.0714,y:517.811}).wait(1).to({graphics:mask_34_graphics_383,x:474.0714,y:517.811}).wait(427));

	// Layer_4
	this.instance_61 = new lib.Tween7("synched",0);
	this.instance_61.setTransform(438.05,479.3);
	this.instance_61.alpha = 0.5;
	this.instance_61._off = true;

	var maskedShapeInstanceList = [this.instance_61];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_34;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_61).wait(20).to({_off:false},0).to({alpha:1},108,cjs.Ease.quadInOut).to({startPosition:3},128,cjs.Ease.quadInOut).to({startPosition:6},127,cjs.Ease.quadInOut).wait(427));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(6.6,14.9,953.1,718.5);


// stage content:
(lib.anim_grid = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_46
	this.instance = new lib.Tween86("synched",0);
	this.instance.setTransform(476.2,79.35);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({startPosition:751},751).to({alpha:0.0195,startPosition:809},58).wait(1));

	// OBJ_2_svg
	this.instance_1 = new lib.Tween84("synched",0);
	this.instance_1.setTransform(930.75,465.15,0.3799,0.3799);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(8).to({_off:false},0).to({regX:0.1,regY:0.1,scaleX:0.4043,scaleY:0.4043,x:930.8,y:465.2,alpha:1},28).to({scaleX:1.0141,scaleY:1.0141,x:930.7,y:465.15},715).to({scaleX:1.0635,scaleY:1.0635,alpha:0},58).wait(1));

	// OBJ_1_svg
	this.instance_2 = new lib.Tween82("synched",0);
	this.instance_2.setTransform(955.05,474,0.6812,0.6812,0,0,0,0.1,0);
	this.instance_2.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regY:0.1,scaleX:0.6923,scaleY:0.6923,y:474.05,alpha:1},28).to({regX:0.2,scaleX:0.9684,scaleY:0.9684,x:955.1,y:474},723).to({regX:0.1,scaleX:0.9905,scaleY:0.9905,x:955,alpha:0},58).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1442.8,549.2,-6.899999999999864,263.5999999999999);
// library properties:
lib.properties = {
	id: 'BA10197F98EB664082F3CEF3F9936543',
	width: 1920,
	height: 910,
	fps: 60,
	color: "#595959",
	opacity: 0.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['BA10197F98EB664082F3CEF3F9936543'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;