(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D02E1B").s().p("AgxCBQgYgIgTgSQg5g2APhMQALg5AwgfQA2gjA9ATQA+ATAZA8QAYA3gaA4QgOAegaAUQgoAegsAAQgYAAgagKg");
	this.shape.setTransform(-0.0177,-0.0181);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-13.8,-13.8,27.700000000000003,27.700000000000003);


(lib.Tween18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Tween3("synched",0);
	this.instance.setTransform(472.1,517.95,1.037,1.037);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(44).to({_off:false},0).wait(1).to({scaleX:1.0245,scaleY:1.0245,x:472.0831,y:517.9331,startPosition:1},0).wait(1).to({scaleX:1.0148,scaleY:1.0148,x:472.07,y:517.92,startPosition:0},0).wait(1).to({scaleX:1.0076,scaleY:1.0076,x:472.0603,y:517.9103,startPosition:1},0).wait(1).to({scaleX:1.0027,scaleY:1.0027,x:472.0537,y:517.9037,startPosition:0},0).wait(1).to({scaleX:1,scaleY:1,x:472.1,y:517.95},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({scaleX:1.0032,scaleY:1.0032,x:472.1005,startPosition:1},0).wait(1).to({scaleX:1.0075,scaleY:1.0075,x:472.1012,startPosition:0},0).wait(1).to({scaleX:1.0129,scaleY:1.0129,x:472.1021,startPosition:1},0).wait(1).to({scaleX:1.0195,scaleY:1.0195,x:472.1031,startPosition:0},0).wait(1).to({scaleX:1.0272,scaleY:1.0272,x:472.1043,startPosition:1},0).wait(1).to({scaleX:1.0361,scaleY:1.0361,x:472.1057,startPosition:0},0).wait(1).to({scaleX:1.0462,scaleY:1.0462,x:472.1073,startPosition:1},0).wait(1).to({scaleX:1.0575,scaleY:1.0575,x:472.1091,startPosition:0},0).wait(1).to({scaleX:1.07,scaleY:1.07,x:472.1111,startPosition:1},0).wait(1).to({scaleX:1.0839,scaleY:1.0839,x:472.1133,startPosition:0},0).wait(1).to({scaleX:1.099,scaleY:1.099,x:472.1157,startPosition:1},0).wait(1).to({scaleX:1.1155,scaleY:1.1155,x:472.1183,startPosition:0},0).wait(1).to({scaleX:1.1333,scaleY:1.1333,x:472.1211,startPosition:1},0).wait(1).to({scaleX:1.1525,scaleY:1.1525,x:472.1241,startPosition:0},0).wait(1).to({scaleX:1.1731,scaleY:1.1731,x:472.1274,startPosition:1},0).wait(1).to({scaleX:1.1952,scaleY:1.1952,x:472.1309,startPosition:0},0).wait(1).to({scaleX:1.2187,scaleY:1.2187,x:472.1346,startPosition:1},0).wait(1).to({scaleX:1.2437,scaleY:1.2437,x:472.1386,startPosition:0},0).wait(1).to({scaleX:1.2702,scaleY:1.2702,x:472.1427,startPosition:1},0).wait(1).to({scaleX:1.2982,scaleY:1.2982,x:472.1472,startPosition:0},0).wait(1).to({scaleX:1.3278,scaleY:1.3278,x:472.1519,startPosition:1},0).wait(1).to({scaleX:1.3589,scaleY:1.3589,x:472.1568,startPosition:0},0).wait(1).to({scaleX:1.3917,scaleY:1.3917,x:472.162,startPosition:1},0).wait(1).to({scaleX:1.4261,scaleY:1.4261,x:472.1674,startPosition:0},0).wait(1).to({scaleX:1.4621,scaleY:1.4621,x:472.1},0).to({scaleX:1,scaleY:1},25,cjs.Ease.quadInOut).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:1},0).wait(1).to({startPosition:0},0).to({_off:true},1).wait(623));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(451.9,497.7,40.5,40.50000000000006);


// stage content:
(lib.mobilelite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_8
	this.instance = new lib.Tween18("synched",86);
	this.instance.setTransform(788.1,211.3,0.8023,0.8023,0,0,0,472.2,517.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(313));

	// Layer_8
	this.instance_1 = new lib.Tween18("synched",107);
	this.instance_1.setTransform(646.25,180.25,0.3569,0.3569,0,0,0,471.3,517.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(313));

	// Layer_8
	this.instance_2 = new lib.Tween18("synched",44);
	this.instance_2.setTransform(1359,577.45,0.4746,0.4746,0,0,0,472.3,518.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(313));

	// Layer_8
	this.instance_3 = new lib.Tween18("synched",109);
	this.instance_3.setTransform(704,-188.95);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(313));

	// Layer_8
	this.instance_4 = new lib.Tween18("synched",145);
	this.instance_4.setTransform(435.9,314.9,0.3728,0.3728);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(313));

	// Layer_8
	this.instance_5 = new lib.Tween18("synched",50);
	this.instance_5.setTransform(308.85,321.55,0.3728,0.3728);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(313));

	// Layer_8
	this.instance_6 = new lib.Tween18("synched",122);
	this.instance_6.setTransform(423.1,452.05,0.3728,0.3728,0,0,0,-0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(313));

	// Layer_8
	this.instance_7 = new lib.Tween18("synched",93);
	this.instance_7.setTransform(1056.25,692.95,0.3292,0.3292,0,0,0,472.2,518);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(313));

	// Layer_8
	this.instance_8 = new lib.Tween18("synched",50);
	this.instance_8.setTransform(873.4,743.95,0.7016,0.7011,0,0,0,472,518.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(313));

	// Layer_8
	this.instance_9 = new lib.Tween18("synched",66);
	this.instance_9.setTransform(472.9,85.35);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(313));

	// main_svg
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#F6F6F7","#ECEEF0","#BCBEC5"],[0,0.447,0.961],41.8,12.3,-48.6,-5.3).s().p("AnXDHIEnmmIKIG/g");
	this.shape.setTransform(668.7637,442.8189,0.9835,0.9835);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#F6F6F7","#ECEEF0","#BCBEC5"],[0,0.447,0.961],-91.6,-0.3,91.8,0.2).s().p("AuUouIcqGSIrgLMg");
	this.shape_1.setTransform(1121.8751,619.0329,0.9835,0.9835);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#BCBEC5","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-73,-11.6,15,75.7).s().p("AvBHjIeD0BIzLY9g");
	this.shape_2.setTransform(740.7786,719.9866,0.9835,0.9835);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#F6F6F7","#ECEEF0","#BCBEC5"],[0,0.447,0.961],-46.6,115.5,8.7,-96.5).s().p("ApwJ5IFc5uIOFfrg");
	this.shape_3.setTransform(865.4095,294.683,0.9835,0.9835);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-17.4,-2.5,22.2,7.8).s().p("AjKggIGWhBIgGDEg");
	this.shape_4.setTransform(1171.6881,518.9152,0.9835,0.9835);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-27.7,0,27.8,0).s().p("AkVkpIHYBlIBTHug");
	this.shape_5.setTransform(725.1168,265.3754,0.9835,0.9835);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-22.1,17.7,34.7,-16.5).s().p("AnhEMIPDpWIjkKVg");
	this.shape_6.setTransform(687.1793,563.4174,0.9835,0.9835);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-53.4,0,53.4,0).s().p("ABKmAIHMFBIwrHAg");
	this.shape_7.setTransform(1190.3987,454.4976,0.9835,0.9835);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(0.8).p("ApiSCMAN6gj5IFOdvg");
	this.shape_8.setTransform(882.85,208.5,0.9835,0.9835,0,0,0,0.2,-0.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").ss(0.8).p("ACMMlIPP5DMgi2ASjg");
	this.shape_9.setTransform(1165.8406,654.3899,0.9835,0.9835);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(0.8).p("AJ0DQIznmf");
	this.shape_10.setTransform(1117.8429,713.1269,0.9835,0.9835);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FFFFFF").ss(0.8).p("AIbHAIw7CPIAUyYg");
	this.shape_11.setTransform(992.9,732.55,0.9835,0.9835,0,0,0,-0.4,0);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFFFFF").ss(0.8).p("AMKKRI4g0fIG+M3g");
	this.shape_12.setTransform(1088.4,183.15,0.9835,0.9835,0,0,0,-1.3,-0.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FFFFFF").ss(0.8).p("AJAgLIm+s3Iq8aCg");
	this.shape_13.setTransform(999.05,201.6,0.9835,0.9835,0,0,0,-0.1,0);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FFFFFF").ss(0.8).p("AJKlSIhjNVIwnwIg");
	this.shape_14.setTransform(998.4142,725.9772,0.9835,0.9835);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FFFFFF").ss(0.8).p("ACkCuIrdD7IR6tLg");
	this.shape_15.setTransform(999.0485,241.6408,0.9835,0.9835);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(0.8).p("ARokmMgi2ASiIem8Fg");
	this.shape_16.setTransform(1164.518,604.918,0.9835,0.9835);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FFFFFF").ss(0.8).p("AFdQYIqegdIgc/4g");
	this.shape_17.setTransform(1049.5,359.2,0.9835,0.9835,0,0,0,-0.1,0);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFFFFF").ss(0.8).p("APluEI+mcFIgt4cg");
	this.shape_18.setTransform(1150.05,604.5,0.9835,0.9835,0,0,0,-0.6,0.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FFFFFF").ss(0.8).p("AL7DBIxinoImdJQg");
	this.shape_19.setTransform(1090.3,229.55,0.9835,0.9835,0,0,0,-0.9,0);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFFFFF").ss(0.8).p("AloEDIQXk7I1qjJg");
	this.shape_20.setTransform(1367.263,380.4334,0.9835,0.9835);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#FFFFFF").ss(0.8).p("AGtE9IlUp1IoDJjg");
	this.shape_21.setTransform(1317.25,546.45,0.9835,0.9835,0,0,0,-0.2,0);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FFFFFF").ss(0.8).p("Ah7EwIkQpiIMTgBg");
	this.shape_22.setTransform(1287.6,545.65,0.9835,0.9835,0,0,0,0,-0.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#FFFFFF").ss(0.8).p("AGoooIg4RbIsTABg");
	this.shape_23.setTransform(1290.05,460.9,0.9835,0.9835,0,0,0,0,0.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFFFFF").ss(0.8).p("AiSIuIoqtLIV1kRg");
	this.shape_24.setTransform(1263.2,460.6,0.9835,0.9835,0,0,0,0,-0.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#FFFFFF").ss(0.8).p("ALBB5IlToEIwiMVg");
	this.shape_25.setTransform(1262.2,393.95,0.9835,0.9835,0,0,0,-0.2,0);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FFFFFF").ss(0.8).p("AKiNyIgg7lI0fKrg");
	this.shape_26.setTransform(1232.1,267.95,0.9835,0.9835,0,0,0,0,-0.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#FFFFFF").ss(0.8).p("AJqkPIwiMVIi3wOg");
	this.shape_27.setTransform(1237.2,381.75,0.9835,0.9835,0,0,0,-0.4,0);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FFFFFF").ss(0.8).p("Ao/EmITZD5I0/w6g");
	this.shape_28.setTransform(1232.9376,301.6307,0.9835,0.9835);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#FFFFFF").ss(0.8).p("AM6GgIhmtBI3/Bog");
	this.shape_29.setTransform(1094.9,289.45,0.9835,0.9835,0,0,0,-0.1,-0.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FFFFFF").ss(0.8).p("AFPl5IqdgdIFWMmg");
	this.shape_30.setTransform(1050.8,499.4,0.9835,0.9835,0,0,0,-0.1,0);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#FFFFFF").ss(0.8).p("AqpmEIlHMJIfSjqg");
	this.shape_31.setTransform(1150.9807,500.4891,0.9835,0.9835);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FFFFFF").ss(0.8).p("AEfmnIIqNLI6Lofg");
	this.shape_32.setTransform(1166.0509,474.4318,0.9835,0.9835);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#FFFFFF").ss(0.8).p("Ah3QKMgK7ggVIZlLag");
	this.shape_33.setTransform(1095.65,360.15,0.9835,0.9835,0,0,0,0,-0.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FFFFFF").ss(0.8).p("AI0F0Ii3wPIuqU7g");
	this.shape_34.setTransform(1138.778,396.1839,0.9835,0.9835);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#FFFFFF").ss(0.8).p("AqFsVIAQdUMAT1giHg");
	this.shape_35.setTransform(619.0812,364.8394,0.9835,0.9835);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FFFFFF").ss(0.8).p("AqFIdIUFkzIltsJ");
	this.shape_36.setTransform(619.1216,233.8668,0.9835,0.9835);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#FFFFFF").ss(0.8).p("ApeiwIH8IQIK+q/g");
	this.shape_37.setTransform(882.75,709.75,0.9835,0.9835,0,0,0,0.3,0);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFFFFF").ss(0.8).p("AlqGGIlusKIWpE/g");
	this.shape_38.setTransform(717.7674,218.6074,0.9835,0.9835);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#FFFFFF").ss(0.8).p("ArHhmIQ7nMIFZRjg");
	this.shape_39.setTransform(752.6,267.05,0.9835,0.9835,0,0,0,0.5,0);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FFFFFF").ss(0.8).p("AQjUSMgRQgojIv4Xmg");
	this.shape_40.setTransform(947.25,410.8,0.9835,0.9835,0,0,0,-0.3,-0.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#FFFFFF").ss(0.8).p("AwitoMAhIAQ8Iw2Kag");
	this.shape_41.setTransform(947.65,518.25,0.9835,0.9835,0,0,0,0.4,0.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FFFFFF").ss(0.8).p("AoQgYIQ2qaIxcVqg");
	this.shape_42.setTransform(997.5819,606.7208,0.9835,0.9835);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#FFFFFF").ss(0.8).p("Ap+OWMAT1giHMgLLAn/g");
	this.shape_43.setTransform(620.1,381.4,0.9835,0.9835,0,0,0,0.1,0);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#FFFFFF").ss(0.8).p("AmVLxIP23lIzHGKg");
	this.shape_44.setTransform(883.1,357.4,0.9835,0.9835,0,0,0,0,-0.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#FFFFFF").ss(0.8).p("AtOoLIKDlnIQQbWg");
	this.shape_45.setTransform(863.55,518.85,0.9835,0.9835,0,0,0,0.3,0);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#FFFFFF").ss(0.8).p("AsUT/MALMgn/INfUag");
	this.shape_46.setTransform(689.4,382.35,0.9835,0.9835,0,0,0,0.2,-0.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#FFFFFF").ss(0.8).p("ApoHBIS6ivIAmrQg");
	this.shape_47.setTransform(884.25,648.05,0.9835,0.9835,0,0,0,0.8,-0.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#FFFFFF").ss(0.8).p("ABUmdIrSMzIUEoug");
	this.shape_48.setTransform(590.6295,686.5214,0.9835,0.9835);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#FFFFFF").ss(0.8).p("AluAoIJtFlIBzsXg");
	this.shape_49.setTransform(521.15,510.5,0.9835,0.9835,0,0,0,0.4,0);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#FFFFFF").ss(0.8).p("AjcmLIIpF4IqcGeg");
	this.shape_50.setTransform(578.85,510.85,0.9835,0.9835,0,0,0,0,0.2);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#FFFFFF").ss(0.8).p("ADNK2IoavSIKcmgg");
	this.shape_51.setTransform(578.7,576.9,0.9835,0.9835,0,0,0,0,-0.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#FFFFFF").ss(0.8).p("AmJq7IOSGrIwUPHg");
	this.shape_52.setTransform(650.4,577.6,0.9835,0.9835,0,0,0,0,0.1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#FFFFFF").ss(0.8).p("AoLFnIIwEFIHkzMg");
	this.shape_53.setTransform(650.75,610.45,0.9835,0.9835,0,0,0,0.3,0);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#FFFFFF").ss(0.8).p("AtXrnIO9XMIL0z4g");
	this.shape_54.setTransform(738.65,744.75,0.9835,0.9835,0,0,0,0.3,0.1);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#FFFFFF").ss(0.8).p("ApQJnIHjzMIK+MRg");
	this.shape_55.setTransform(712.65,610.8,0.9835,0.9835,0,0,0,0.2,-0.2);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#FFFFFF").ss(0.8).p("AFOlHIyiG6IayDUg");
	this.shape_56.setTransform(737.989,660.1684,0.9835,0.9835);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#FFFFFF").ss(0.8).p("At8jOIIQKOITgt/g");
	this.shape_57.setTransform(858.95,648.25,0.9835,0.9835,0,0,0,0.3,0);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#FFFFFF").ss(0.8).p("ACYKPItf0ZIWUKXg");
	this.shape_58.setTransform(752.05,320.75,0.9835,0.9835,0,0,0,0,-0.2);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#FFFFFF").ss(0.8).p("AGEIuIjRxbIo1KBg");
	this.shape_59.setTransform(804.9,376.8,0.9835,0.9835,0,0,0,-0.1,-0.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#FFFFFF").ss(0.8).p("AkAGiIKClnIsGnZg");
	this.shape_60.setTransform(805.2,426.05,0.9835,0.9835,0,0,0,0,-0.2);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#FFFFFF").ss(0.8).p("ANfDOIiDtAI4rTkg");
	this.shape_61.setTransform(695.0277,447.1009,0.9835,0.9835);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#FFFFFF").ss(0.8).p("AA8GpIuTmqIaumkg");
	this.shape_62.setTransform(695.7954,508.8432,0.9835,0.9835);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#FFFFFF").ss(0.8).p("AsestIaTVvI7wDxg");
	this.shape_63.setTransform(858.5,547.7,0.9835,0.9835,0,0,0,0,0.3);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#FFFFFF").ss(0.8).p("AmMAfIK+MSIBc5gg");
	this.shape_64.setTransform(740.95,547.55,0.9835,0.9835,0,0,0,0.2,0);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],1.4,-19,-3.2,20.4).s().p("AibgDIBki4IDTF3g");
	this.shape_65.setTransform(923.9754,240.5181,0.9835,0.9835);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["#ECEEF0","#F1F2F4","#FFFFFF"],[0,0.22,1],-2.7,-18.8,3.6,21.7).s().p("AgmjGICzBTIkYE6g");
	this.shape_66.setTransform(1157.8703,186.3041,0.9835,0.9835);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.lf(["#ECEEF0","#F1F2F4","#FFFFFF"],[0,0.22,1],-12.1,-4.1,12.2,21.2).s().p("AkBBRID9iqIEGCzg");
	this.shape_67.setTransform(660.0354,625.1059,0.9835,0.9835);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.lf(["#ECEEF0","#F5F6F7","#FFFFFF"],[0,0.384,1],-31.5,-19.2,51.9,65.9).s().p("AwaDxIWIqhIKtNhg");
	this.shape_68.setTransform(972.1657,270.5141,0.9835,0.9835);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.lf(["#ECEEF0","#E4E5E8","#D8D9DD"],[0,0.525,1],-57.3,0,57.4,0).s().p("Ao9mwIR7E7InOImg");
	this.shape_69.setTransform(1064.5385,270.5141,0.9835,0.9835);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.lf(["#ECEEF0","#F1F2F4","#FFFFFF"],[0,0.22,1],-66.4,-48.5,22.1,24).s().p("ApToSISniSIuZVJg");
	this.shape_70.setTransform(1179.5313,311.107,0.9835,0.9835);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.lf(["#BCBEC5","#ECEEF0"],[0.039,0.553],-83.2,0,83.2,0).s().p("As/IWIZ/6JMgUDAjng");
	this.shape_71.setTransform(1065.6449,631.8427,0.9835,0.9835);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.lf(["#ECEEF0","#BCBEC5"],[0,0.961],-28,0,28,0).s().p("AkXswIIvNVIhCMMg");
	this.shape_72.setTransform(822.6283,653.0858,0.9835,0.9835);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-71.2,0,71.2,0).s().p("AqGmFIVOEZI2PHyg");
	this.shape_73.setTransform(913.7473,695.0555,0.9835,0.9835);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["#ECEEF0","#F0F1F3","#F6F6F7"],[0,0.631,1],-36.5,0,36.6,0).s().p("Altg0IHNonIEOS3g");
	this.shape_74.setTransform(1111.524,318.2864,0.9835,0.9835);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-36.5,0,36.6,0).s().p("AltqQILbKQIrbKSg");
	this.shape_75.setTransform(1111.524,377.7374,0.9835,0.9835);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-83.2,0,83.2,0).s().p("Aqeu6IXeDsI5/aJg");
	this.shape_76.setTransform(1065.6449,590.4138,0.9835,0.9835);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-47.9,0,48,0).s().p("AnfHBIO/17Iiid1g");
	this.shape_77.setTransform(952.4716,590.4138,0.9835,0.9835);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-67.9,0,68,0).s().p("AqngbIIxjhIMdH5g");
	this.shape_78.setTransform(916.9681,659.4538,0.9835,0.9835);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-109.6,0,109.7,0).s().p("AvtkSMAg2AC/MgiRAFmg");
	this.shape_79.setTransform(967.7154,321.3106,0.9835,0.9835);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.565,0.961],-75.1,0,75.2,0).s().p("AruCdIMColILcMRg");
	this.shape_80.setTransform(1073.5865,481.0514,0.9835,0.9835);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-47.9,0,48,0).s().p("AgRtxIHxFoIu/V7g");
	this.shape_81.setTransform(952.4716,547.8294,0.9835,0.9835);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.lf(["#BCBEC5","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-0.7,66.8,31.3,-40).s().p("AxIjEMAiRgFnIquRXg");
	this.shape_82.setTransform(967.7154,367.7797,0.9835,0.9835);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-56,0,56,0).s().p("AovmqIRfJ0IowDhg");
	this.shape_83.setTransform(850.1902,614.7302,0.9835,0.9835);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.lf(["#ECEEF0","#EEF0F1","#FBFBFC","#FFFFFF"],[0,0.051,0.541,1],67.4,-32,-73.4,22).s().p("Am1mCINrECIAAIEg");
	this.shape_84.setTransform(708.4223,399.7673,0.9835,0.9835);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.lf(["#ECEEF0","#EEF0F1","#FBFBFC","#FFFFFF"],[0,0.051,0.541,1],10.8,-33.4,-42.2,34).s().p("AkMkpIJNGUIqBC/g");
	this.shape_85.setTransform(837.2575,283.7664,0.9835,0.9835);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],0,-27.5,0,27.5).s().p("AlAhTIKBi/IhbIlg");
	this.shape_86.setTransform(837.2575,321.3106,0.9835,0.9835);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.lf(["#ECEEF0","#FFFFFF"],[0,1],0,-37.6,0,37.7).s().p("AAAl3IInFnIxNGIg");
	this.shape_87.setTransform(805.7126,350.0772,0.9835,0.9835);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.lf(["#BCBEC5","#ECEEF0","#F6F6F7"],[0.039,0.553,1],86.8,-69.5,-69.1,36.7).s().p("AomgbIRNmJIAANJg");
	this.shape_88.setTransform(805.7126,389.8342,0.9835,0.9835);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.lf(["#ECEEF0","#BCBEC5"],[0,0.961],-55,0,55.1,0).s().p("AomkBIRNHAIxNBDg");
	this.shape_89.setTransform(805.7126,412.4787,0.9835,0.9835);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-61.5,0,61.6,0).s().p("ApmIyIMSzfIG7Vbg");
	this.shape_90.setTransform(734.5828,505.3187,0.9835,0.9835);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-55,0,55.1,0).s().p("AomlQIRNhEIldMog");
	this.shape_91.setTransform(805.7126,471.0692,0.9835,0.9835);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-66,58.5,41.9,-58.7).s().p("Al4qtILxLlIk3J2g");
	this.shape_92.setTransform(788.5755,505.3187,0.9835,0.9835);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.lf(["#BCBEC5","#CBCDD2","#E3E5E8","#ECEEF0"],[0,0.243,0.71,1],49.9,-37.7,-47,55.1).s().p("AovABIE2p1IMpTpg");
	this.shape_93.setTransform(850.1902,572.7113,0.9835,0.9835);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.lf(["#D8D9DD","#ECEEF0","#F6F6F7"],[0.039,0.553,1],-1.9,-9.9,13.3,65.1).s().p("AlWHHIKtxXIAAUig");
	this.shape_94.setTransform(1041.8448,377.7374,0.9835,0.9835);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.lf(["#F6F6F7","#ECEEF0","#D8D9DD"],[0,0.447,0.961],-38.5,0,38.6,0).s().p("Akrl3IKtDKIsDIlg");
	this.shape_95.setTransform(1037.6159,459.4888,0.9835,0.9835);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.lf(["#BCBEC5","#ECEEF0"],[0,1],39.4,30.7,-11.1,-51.9).s().p("AkjAQIJHmHIhWLvg");
	this.shape_96.setTransform(979.3942,459.4888,0.9835,0.9835);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.lf(["#F6F6F7","#ECEEF0","#BCBEC5"],[0,0.447,0.961],-75.3,0,75.4,0).s().p("Arxo8IXjLxIpJGIg");
	this.shape_97.setTransform(934.0068,404.7338,0.9835,0.9835);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.lf(["#ECEEF0","#BCBEC5"],[0,0.961],-46.1,0,46.2,0).s().p("AnNEOIAAtKIObR5g");
	this.shape_98.setTransform(905.2648,404.7338,0.9835,0.9835);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.lf(["#BCBEC5","#ECEEF0"],[0.039,1],68.9,59.4,-55,-73).s().p("Ap7l3IT3n6InObjg");
	this.shape_99.setTransform(888.1277,547.8294,0.9835,0.9835);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.lf(["#D8D9DD","#ECEEF0"],[0.043,1],-78.7,-40,47.8,21.6).s().p("AkemUIOaEwIz3H4g");
	this.shape_100.setTransform(888.1277,471.0692,0.9835,0.9835);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(313));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1437.3,549.8,-0.7999999999999545,268.70000000000005);
// library properties:
lib.properties = {
	id: 'BA10197F98EB664082F3CEF3F9936543',
	width: 1920,
	height: 910,
	fps: 60,
	color: "#595959",
	opacity: 0.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['BA10197F98EB664082F3CEF3F9936543'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;