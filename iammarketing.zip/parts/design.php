<section id="design" class="s-content">
<div class="anc" id="s2_anc"></div>
	<div class="container">
	<?php
		$post_id = get_post( 15 );
		echo '<h2>'.$post_id->post_title.'</h2>
		<div class="text56 m-auto">';
		$content = $post_id->post_content;
		$content = apply_filters('the_content', $content);
		$content = str_replace(']]>', ']]&gt;', $content);
		echo $content;
	?>
			<div class="row vw-pad">
				<div class="col-md-4 col-12">
					<div class="box w-100">
						<div class="number">01</div>
						<p>Создание сайтов и<br>лендинг пейдж</p>
					</div>
				</div>
				<div class="col-md-4 col-12">
					<div class="box w-100">
						<div class="number">02</div>
						<p>Упакуем качествено<br>ваш бренд</p>
					</div>
				</div>
				<div class="col-md-4 col-12">
					<div class="box w-100">
						<div class="number">03</div>
						<p>Создадим продающие<br>баннера</p>
					</div>
				</div>
			</div>
			<div class="svg-container design m-auto">
				<img class="over-anim lax" data-lax-preset="lazy100" title="" alt="" src="<?php echo get_template_directory_uri() ?>/images/design/top-2.svg">
				<img class="over-img" title="" alt="" src="<?php echo get_template_directory_uri() ?>/images/design/body.svg">
				<img class="over-anim lax" data-lax-preset="lazy200" title="" alt="" src="<?php echo get_template_directory_uri() ?>/images/design/top.svg">
			</div>
		</div>
	</div>
</section>