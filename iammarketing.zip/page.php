<?php get_header();
if (is_front_page()){
	if ( have_posts() ) while ( have_posts() ) : the_post();
		$content = get_the_content();
		echo do_shortcode($content);
	endwhile;
	get_template_part('parts/marketing/marketing-home');
	get_template_part('parts/design');
	get_template_part('parts/portfolio');
	get_template_part('parts/clients');
	get_template_part('parts/news');
} else {
	if ( have_posts() ) while ( have_posts() ) : the_post();
		the_content();
	endwhile;
}
get_footer(); ?>